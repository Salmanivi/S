# S7 SimStudio

Browser-based Siemens S7 ladder-logic simulator (S7-300 / 400 / 1200 / 1500) with PLCSIM-style I/O, a plant simulation and a TIA-Portal-like editor, now with **accounts, cloud projects, cross-device sync, teams and an admin console**. Runs on **Vercel's free plan** with a PostgreSQL database.

## Features

- Ladder editor, instruction catalog, compile / download / RUN, watch tables, plant view, auto data types, configurable I/O start addresses, phone-friendly layout
- **Accounts:** register, sign in, password change/reset, signed-in devices list, data export, account deletion
- **Cloud projects:** autosave, version history, trash (30 days), duplicate, move between personal space and teams
- **Cross-device sync:** every device sees the latest version; edits from another device appear automatically; conflicts are never overwritten silently (keep both / replace / load theirs); offline edits sync when the connection returns
- **Teams:** invite links, roles (owner / admin / editor / viewer), view-only projects enforced on the server
- **Admin console:** statistics, users (disable, roles, reset links, delete), projects and teams overview (metadata only), activity log, settings (registration, limits, announcement), deployment health
- Optional email for password reset / confirmation (Resend or Brevo). Works without it.
- No payments or subscriptions.

## Author and contact

Created by **Salman** · salmanino.ahmedino@gmail.com · +20 11 54390240
The details are defined once in `src/brand.ts` (shown in the app, also in the offline edition) and can be overridden on an online installation under Admin → Settings.

## Installed app and offline use

The web app is installable (PWA) and opens offline once visited; accounts and sync return when online. `npm run build:single` produces an **offline edition** (one `index.html`) for APK/EXE wrappers. See **[docs/APP_PACKAGING.md](docs/APP_PACKAGING.md)**.

## Documentation

- **[docs/DEPLOYMENT.md](docs/DEPLOYMENT.md)**: step-by-step deployment on Vercel + database
- **[docs/APP_PACKAGING.md](docs/APP_PACKAGING.md)**: install as an app, APK/EXE, offline use
- **[docs/SECURITY.md](docs/SECURITY.md)**: security model, test report, known limits

## Repository layout

```
api/[...path].js        the single serverless function (entry point)
api/_lib/               server code: handler, routes/, db, crypto, mail, migrations
src/                    React app (src/cloud = accounts, sync, teams, admin)
db/schema.sql           the database schema (also applied automatically)
public/                 static files (favicon, theme-init.js)
scripts/                migrate, smoke (post-deploy test), security-check
tests/                  API tests (node:test) and browser tests (tests/e2e)
vercel.json             rewrites, security headers (CSP), daily cron
.env.example            every environment variable
```

## Commands

| Command | Purpose |
|---|---|
| `npm install` | install dependencies (Node.js 22) |
| `npm run build` | production build into `dist/` |
| `npm run build:single` | the offline edition: one self-contained `index.html` (no network, no cloud features) |
| `npm test` | 48 API tests (uses an in-memory SQLite database) |
| `npm run test:e2e` | browser tests incl. installable-app and offline-edition checks (needs `npm i -D playwright && npx playwright install chromium`) |
| `npm run check:security` | static security review |
| `npm run db:migrate` | apply database migrations manually (`DATABASE_URL=…`) |
| `npm run smoke -- https://your-site` | post-deployment end-to-end check against the live site |
| `npm run typecheck` | TypeScript check |

For local development with the API use the Vercel CLI: `vercel env pull .env.local && vercel dev`.

Not affiliated with Siemens AG; SIMATIC, S7 and TIA Portal are trademarks of Siemens AG. The simulator is an educational tool and must not be used to control real machines.
