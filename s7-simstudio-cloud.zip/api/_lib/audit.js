import { uid } from './crypto.js';

/** Writes an audit entry. Never throws: auditing must not break the request. */
export async function audit(ctx, action, { targetType = null, targetId = null, meta = null, actor } = {}) {
  try {
    const a = actor ?? ctx.user;
    await ctx.db.query(
      'INSERT INTO audit_log (id, ts, actor_id, actor_email, action, target_type, target_id, meta, ip) VALUES ($1,$2,$3,$4,$5,$6,$7,$8,$9)',
      [uid(), Date.now(), a?.id ?? null, a?.email ?? null, action, targetType, targetId, meta ? JSON.stringify(meta).slice(0, 2000) : null, ctx.ip ?? null],
    );
  } catch (e) { console.error('[audit] failed', e.message); }
}
