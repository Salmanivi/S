import { scrypt, randomBytes, randomUUID, timingSafeEqual, createHash, createHmac } from 'node:crypto';
import { promisify } from 'node:util';

const scryptAsync = promisify(scrypt);
// Interactive-login cost. N=2^15 needs ~32 MB; tests use a cheaper setting.
const N = process.env.NODE_ENV === 'test' ? 1024 : 32768;
const R = 8, P = 1, KEYLEN = 64;

export const uid = () => randomUUID();
export const randomToken = (bytes = 32) => randomBytes(bytes).toString('base64url');
export const sha256 = (s) => createHash('sha256').update(String(s)).digest('hex');
export const hmac = (secret, value) => createHmac('sha256', secret).update(String(value)).digest('hex').slice(0, 32);

export function safeEqual(a, b) {
  const x = Buffer.from(String(a)), y = Buffer.from(String(b));
  if (x.length !== y.length) { timingSafeEqual(x, x); return false; }
  return timingSafeEqual(x, y);
}

export async function hashPassword(password) {
  const salt = randomBytes(16);
  const dk = await scryptAsync(password, salt, KEYLEN, { N, r: R, p: P, maxmem: 128 * N * R + 1024 * 1024 });
  return `s1$${N}$${R}$${P}$${salt.toString('base64')}$${dk.toString('base64')}`;
}

export async function verifyPassword(password, stored) {
  try {
    const [v, n, r, p, salt, hash] = String(stored).split('$');
    if (v !== 's1') return false;
    const cost = Number(n), rr = Number(r), pp = Number(p);
    if (!(cost >= 1024 && cost <= 1 << 20) || !rr || !pp) return false;
    const expect = Buffer.from(hash, 'base64');
    const dk = await scryptAsync(password, Buffer.from(salt, 'base64'), expect.length, { N: cost, r: rr, p: pp, maxmem: 128 * cost * rr + 1024 * 1024 });
    return timingSafeEqual(dk, expect);
  } catch { return false; }
}

let dummy;
/** Used when the account does not exist so that the response time does not reveal it. */
export async function dummyVerify(password) {
  dummy ??= await hashPassword('not-a-real-password');
  await verifyPassword(password, dummy);
  return false;
}

const COMMON = new Set(['password', 'password1', 'password123', '1234567890', '12345678910', 'qwertyuiop', 'qwerty12345', 'iloveyou123', 'admin12345', 'welcome123', 'letmein123', 'abc1234567', 'passw0rd123', '0123456789', 'changeme123', 'plc123456', 'siemens123', 'siemens1234']);

/** Returns a message when the password is not acceptable, otherwise null. */
export function passwordProblem(password, email = '') {
  if (typeof password !== 'string') return 'Password is required';
  if (password.length < 10) return 'Use at least 10 characters';
  if (password.length > 200) return 'Password is too long (200 characters max)';
  if (COMMON.has(password.toLowerCase())) return 'This password is too common';
  const local = String(email).split('@')[0].toLowerCase();
  if (local.length >= 4 && password.toLowerCase().includes(local)) return 'Password must not contain your email name';
  if (/^(.)\1+$/.test(password)) return 'Password is too repetitive';
  return null;
}
