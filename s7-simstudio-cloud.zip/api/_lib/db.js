import { migrate } from './migrate.js';
import { HttpError } from './http.js';

/**
 * Database access. A driver has the shape { query(text, params) -> rows[], exec(sql), tx(fn) }.
 * Production uses PostgreSQL through "pg" (Neon, Supabase, Vercel Postgres, any Postgres); tests inject an SQLite driver.
 */
let driver = null;
let ready = null;

export function setDriver(d) { driver = d; ready = null; }

function cleanConnectionString(url) {
  try {
    const u = new URL(url);
    u.searchParams.delete('channel_binding'); // not supported by node-postgres
    return u.toString();
  } catch { return url; }
}

async function makePgDriver() {
  const url = process.env.DATABASE_URL || process.env.POSTGRES_URL;
  if (!url) throw new HttpError(503, 'not_configured', 'The server is not configured yet (DATABASE_URL is missing). See /api/health.');
  const pg = (await import('pg')).default;
  pg.types.setTypeParser(20, v => parseInt(v, 10));      // BIGINT / COUNT(*) -> number
  pg.types.setTypeParser(1700, v => parseFloat(v));      // NUMERIC / SUM() -> number
  const pool = new pg.Pool({
    connectionString: cleanConnectionString(url),
    max: Number(process.env.DB_POOL_MAX || 4),
    idleTimeoutMillis: 10_000,
    connectionTimeoutMillis: 10_000,
  });
  pool.on('error', e => console.error('[db] idle client error', e.message));
  const wrap = (c) => ({
    query: async (text, params = []) => (await c.query(text, params)).rows,
    exec: async (sql) => { await c.query(sql); },
  });
  return {
    ...wrap(pool),
    tx: async (fn) => {
      const c = await pool.connect();
      try {
        await c.query('BEGIN');
        const out = await fn(wrap(c));
        await c.query('COMMIT');
        return out;
      } catch (e) {
        try { await c.query('ROLLBACK'); } catch { /* connection already broken */ }
        throw e;
      } finally { c.release(); }
    },
    close: () => pool.end(),
  };
}

/** Returns the driver after making sure the schema is up to date (once per server instance). */
export async function getDb() {
  if (!driver) driver = await makePgDriver();
  if (!ready) {
    ready = process.env.AUTO_MIGRATE === 'false' ? Promise.resolve() : migrate(driver).catch(e => { ready = null; throw e; });
  }
  await ready;
  return driver;
}

/** Maps low-level connection problems to a short safe category (used by /api/health). */
export function classifyDbError(e) {
  const c = e && (e.code || '');
  if (e instanceof HttpError) return e.code;
  if (c === '28P01' || c === '28000') return 'auth_failed';
  if (c === 'ENOTFOUND' || c === 'ECONNREFUSED' || c === 'ETIMEDOUT' || c === 'ECONNRESET') return 'unreachable';
  if (c === '3D000') return 'database_missing';
  if (/self-signed|certificate|SSL/i.test(String(e && e.message))) return 'ssl_error';
  return 'unknown';
}
