import { getDb } from './db.js';

export const DEFAULTS = {
  registrationEnabled: true,
  requireEmailVerification: false,
  announcement: '',
  operatorName: 'Salman',
  contactEmail: 'salmanino.ahmedino@gmail.com',
  contactPhone: '+20 11 54390240',
  maxPersonalProjects: 50,
  maxTeamProjects: 200,
  maxProjectKB: 1024,
  maxTeamsPerUser: 10,
  maxMembersPerTeam: 50,
  versionsPerProject: 20,
};

/** Validation rules for settings an administrator may change. */
export const RULES = {
  registrationEnabled: { type: 'boolean' },
  requireEmailVerification: { type: 'boolean' },
  announcement: { type: 'string', max: 300 },
  operatorName: { type: 'string', max: 120 },
  contactEmail: { type: 'string', max: 254 },
  contactPhone: { type: 'string', max: 40 },
  maxPersonalProjects: { type: 'int', min: 1, max: 1000 },
  maxTeamProjects: { type: 'int', min: 1, max: 5000 },
  maxProjectKB: { type: 'int', min: 16, max: 3000 },
  maxTeamsPerUser: { type: 'int', min: 0, max: 100 },
  maxMembersPerTeam: { type: 'int', min: 1, max: 500 },
  versionsPerProject: { type: 'int', min: 0, max: 100 },
};

let cache = null;
let cachedAt = 0;

export async function getSettings(force = false) {
  if (!force && cache && Date.now() - cachedAt < 10_000) return cache;
  const db = await getDb();
  const rows = await db.query('SELECT k, v FROM settings');
  const out = { ...DEFAULTS };
  for (const r of rows) {
    if (!(r.k in DEFAULTS)) continue;
    try { out[r.k] = JSON.parse(r.v); } catch { /* keep default */ }
  }
  cache = out;
  cachedAt = Date.now();
  return out;
}
export const invalidateSettings = () => { cache = null; };
