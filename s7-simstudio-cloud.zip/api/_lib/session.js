import { parseCookies, serializeCookie, isSecure, forbidden } from './http.js';
import { randomToken, sha256, uid } from './crypto.js';

export const SESSION_MS = 30 * 24 * 3600 * 1000;
export const cookieName = (req) => (isSecure(req) ? '__Host-s7s' : 's7s');

export const userDto = (r) => ({
  id: r.id, email: r.email, name: r.name, role: r.role, status: r.status,
  emailVerified: !!r.email_verified, createdAt: Number(r.created_at),
  lastLoginAt: r.last_login_at == null ? null : Number(r.last_login_at),
});

export async function createSession(ctx, userId) {
  const token = randomToken(32);
  const now = Date.now();
  await ctx.db.query(
    'INSERT INTO sessions (id, user_id, token_hash, created_at, last_used_at, expires_at, user_agent) VALUES ($1,$2,$3,$4,$5,$6,$7)',
    [uid(), userId, sha256(token), now, now, now + SESSION_MS, (ctx.ua || '').slice(0, 255)],
  );
  ctx.setCookie(serializeCookie(cookieName(ctx.req), token, { maxAge: SESSION_MS / 1000, secure: isSecure(ctx.req) }));
}

export function clearSessionCookie(ctx) {
  ctx.setCookie(serializeCookie(cookieName(ctx.req), '', { maxAge: 0, secure: isSecure(ctx.req) }));
}

export function sessionTokenOf(req) {
  const t = parseCookies(req.headers.cookie)[cookieName(req)];
  return t && t.length <= 200 ? t : null;
}

/** Resolves the signed-in user from the cookie, or null. Disabled accounts and expired sessions never resolve. */
export async function loadSession(ctx) {
  const token = sessionTokenOf(ctx.req);
  if (!token) return null;
  const rows = await ctx.db.query(
    `SELECT s.id AS sid, s.expires_at AS s_expires, s.last_used_at AS s_used, u.*
       FROM sessions s JOIN users u ON u.id = s.user_id WHERE s.token_hash = $1`,
    [sha256(token)],
  );
  const r = rows[0];
  if (!r) return null;
  const now = Date.now();
  if (Number(r.s_expires) < now || r.status !== 'active') return null;
  if (now - Number(r.s_used) > 5 * 60 * 1000) {
    // sliding expiry, written at most every 5 minutes to keep database writes low
    const exp = Number(r.s_expires) - now < SESSION_MS / 2 ? now + SESSION_MS : Number(r.s_expires);
    await ctx.db.query('UPDATE sessions SET last_used_at = $1, expires_at = $2 WHERE id = $3', [now, exp, r.sid]);
  }
  return { sessionId: r.sid, user: r };
}

export const requireVerified = (ctx, settings, mail) => {
  if (settings.requireEmailVerification && mail && !ctx.user.email_verified) throw forbidden('Please confirm your email address first', 'email_not_verified');
};

/**
 * Deletes a user and everything they own. Teams where the user is the only owner are handed to another member,
 * or removed together with their projects when nobody else is in them.
 */
export async function deleteUserCascade(db, userId) {
  await db.tx(async t => {
    const owned = await t.query(
      `SELECT tm.team_id,
              (SELECT COUNT(*) FROM team_members o WHERE o.team_id = tm.team_id AND o.role = 'owner' AND o.user_id <> $1) AS other_owners,
              (SELECT COUNT(*) FROM team_members x WHERE x.team_id = tm.team_id AND x.user_id <> $1) AS others
         FROM team_members tm WHERE tm.user_id = $1 AND tm.role = 'owner'`,
      [userId],
    );
    for (const o of owned) {
      if (Number(o.other_owners) > 0) continue;
      if (Number(o.others) > 0) {
        const next = await t.query(
          `SELECT user_id FROM team_members WHERE team_id = $1 AND user_id <> $2
           ORDER BY CASE role WHEN 'admin' THEN 0 WHEN 'editor' THEN 1 ELSE 2 END, joined_at LIMIT 1`,
          [o.team_id, userId],
        );
        await t.query("UPDATE team_members SET role = 'owner' WHERE team_id = $1 AND user_id = $2", [o.team_id, next[0].user_id]);
      } else {
        await t.query('DELETE FROM teams WHERE id = $1', [o.team_id]);
      }
    }
    await t.query('DELETE FROM users WHERE id = $1', [userId]);
  });
}
