import { HttpError } from './http.js';

export const isTest = () => process.env.NODE_ENV === 'test';

/** Secret used to hash IP addresses / e-mail addresses in rate-limit keys. */
export function appSecret() {
  const s = process.env.APP_SECRET;
  if (s && s.length >= 32) return s;
  if (isTest()) return 'test-secret-test-secret-test-secret-0123';
  throw new HttpError(503, 'not_configured', 'The server is not configured yet (APP_SECRET is missing or too short). See /api/health.');
}

export const mailProvider = () => {
  const p = (process.env.MAIL_PROVIDER || '').toLowerCase();
  if (p === 'resend' && process.env.RESEND_API_KEY && process.env.MAIL_FROM) return 'resend';
  if (p === 'brevo' && process.env.BREVO_API_KEY && process.env.MAIL_FROM) return 'brevo';
  return null;
};
export const mailEnabled = () => !!mailProvider();

export const APP_NAME = 'S7 SimStudio';
export const VERSION = '1.1.0';
