import { randomBytes } from 'node:crypto';

export class HttpError extends Error {
  constructor(status, code, message, details) {
    super(message);
    this.status = status;
    this.code = code;
    this.details = details;
  }
}
export const bad = (message, field) => new HttpError(400, 'invalid_input', message, field ? { field } : undefined);
export const unauthorized = (message = 'Please sign in') => new HttpError(401, 'unauthorized', message);
export const forbidden = (message = 'You do not have permission to do that', code = 'forbidden') => new HttpError(403, code, message);
export const notFound = (message = 'Not found') => new HttpError(404, 'not_found', message);
export const conflict = (code, message, details) => new HttpError(409, code, message, details);
export const tooMany = (retryAfter) => new HttpError(429, 'rate_limited', 'Too many attempts. Please wait a few minutes and try again.', { retryAfter });

export const newRequestId = () => randomBytes(6).toString('hex');

export function parseCookies(header) {
  const out = {};
  if (!header) return out;
  for (const part of String(header).split(';')) {
    const i = part.indexOf('=');
    if (i < 0) continue;
    const k = part.slice(0, i).trim();
    if (!k || k in out) continue;
    try { out[k] = decodeURIComponent(part.slice(i + 1).trim()); } catch { /* ignore malformed */ }
  }
  return out;
}

export function serializeCookie(name, value, { maxAge, secure }) {
  const attrs = [`${name}=${encodeURIComponent(value)}`, 'Path=/', 'HttpOnly', 'SameSite=Lax'];
  if (maxAge !== undefined) attrs.push(`Max-Age=${Math.floor(maxAge)}`);
  if (secure) attrs.push('Secure');
  return attrs.join('; ');
}

export function isSecure(req) {
  const proto = String(req.headers['x-forwarded-proto'] || '').split(',')[0].trim();
  return proto === 'https' || !!(req.socket && req.socket.encrypted);
}

/** Client IP. On Vercel the platform sets x-forwarded-for, so the first entry is the real client. */
export function clientIp(req) {
  const xff = String(req.headers['x-forwarded-for'] || '').split(',')[0].trim();
  return xff || String(req.headers['x-real-ip'] || '') || (req.socket && req.socket.remoteAddress) || 'unknown';
}

const BODY_METHODS = new Set(['POST', 'PUT', 'PATCH', 'DELETE']);

/** Reads and parses a JSON body with a hard size limit. Works with Vercel's pre-parsed req.body and with raw Node streams. */
export async function readJson(req, maxBytes) {
  if (!BODY_METHODS.has(req.method)) return undefined;
  const declared = Number(req.headers['content-length'] || 0);
  if (declared > maxBytes) throw new HttpError(413, 'too_large', 'The request is too large');
  const hasBody = declared > 0 || req.headers['transfer-encoding'];
  if (!hasBody && req.body === undefined) return undefined;
  const ct = String(req.headers['content-type'] || '').toLowerCase();
  if (!ct.startsWith('application/json')) throw new HttpError(415, 'unsupported_media_type', 'Content-Type must be application/json');

  let raw = req.body;
  if (raw === undefined || raw === null) {
    const chunks = [];
    let size = 0;
    for await (const c of req) {
      size += c.length;
      if (size > maxBytes) throw new HttpError(413, 'too_large', 'The request is too large');
      chunks.push(c);
    }
    raw = Buffer.concat(chunks).toString('utf8');
  }
  if (Buffer.isBuffer(raw)) raw = raw.toString('utf8');
  if (typeof raw === 'string') {
    if (raw.length > maxBytes) throw new HttpError(413, 'too_large', 'The request is too large');
    if (!raw.trim()) return undefined;
    try { raw = JSON.parse(raw); } catch { throw bad('The request body is not valid JSON'); }
  }
  return raw;
}

export function send(res, status, body, headers = {}) {
  const payload = body === undefined ? '' : JSON.stringify(body);
  res.statusCode = status;
  res.setHeader('Content-Type', 'application/json; charset=utf-8');
  res.setHeader('Cache-Control', 'no-store');
  res.setHeader('X-Content-Type-Options', 'nosniff');
  res.setHeader('Referrer-Policy', 'no-referrer');
  for (const [k, v] of Object.entries(headers)) res.setHeader(k, v);
  res.end(payload);
}

/** Public base URL used in e-mailed links. APP_URL wins; otherwise the host of the current request. */
export function baseUrl(ctx) {
  const a = process.env.APP_URL;
  if (a) return a.replace(/\/+$/, '');
  return `${isSecure(ctx.req) ? 'https' : 'http'}://${ctx.req.headers.host}`;
}
