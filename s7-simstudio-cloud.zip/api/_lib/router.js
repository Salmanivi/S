const routes = [];

/** route('POST', '/projects/:id/move', { auth: 'user' }, async ctx => ...) */
export function route(method, pattern, opts, handler) {
  const keys = [];
  const re = new RegExp('^' + pattern.replace(/:([A-Za-z]+)/g, (_, k) => { keys.push(k); return '([^/]+)'; }) + '/?$');
  routes.push({ method, re, keys, opts: { auth: 'user', maxBody: 64 * 1024, ...opts }, handler, pattern });
}

export function match(method, path) {
  let pathMatched = false;
  const allow = new Set();
  for (const r of routes) {
    const m = r.re.exec(path);
    if (!m) continue;
    pathMatched = true;
    allow.add(r.method);
    if (r.method !== method) continue;
    const params = {};
    r.keys.forEach((k, i) => { try { params[k] = decodeURIComponent(m[i + 1]); } catch { params[k] = m[i + 1]; } });
    return { route: r, params };
  }
  return pathMatched ? { methodNotAllowed: true, allow: [...allow] } : null;
}
