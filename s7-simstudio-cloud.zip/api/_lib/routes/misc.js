import { route } from '../router.js';
import { getSettings } from '../settings.js';
import { getDb, classifyDbError } from '../db.js';
import { mailEnabled, APP_NAME, VERSION } from '../env.js';
import { HttpError, notFound, bad, forbidden } from '../http.js';
import { safeEqual, hashPassword, passwordProblem, uid } from '../crypto.js';
import { createSession, userDto } from '../session.js';
import { rateLimit } from '../ratelimit.js';
import { audit } from '../audit.js';
import * as v from '../validate.js';

const setupEnabled = () => (process.env.SETUP_TOKEN || '').length >= 16;
const adminExists = async (db) => Number((await db.query("SELECT COUNT(*) AS n FROM users WHERE role = 'admin'"))[0].n) > 0;

/** Public information the web app needs before anyone is signed in. */
route('GET', '/config', { auth: 'public' }, async (ctx) => {
  const s = await getSettings();
  return {
    appName: APP_NAME, version: VERSION,
    registrationEnabled: s.registrationEnabled,
    requireEmailVerification: s.requireEmailVerification && mailEnabled(),
    mailEnabled: mailEnabled(),
    announcement: s.announcement,
    operatorName: s.operatorName, contactEmail: s.contactEmail, contactPhone: s.contactPhone,
    maxProjectKB: s.maxProjectKB,
    needsSetup: setupEnabled() && !(await adminExists(ctx.db)),
  };
});

/** Deployment checklist for troubleshooting. Reveals only yes/no facts, never secret values. */
route('GET', '/health', { auth: 'public', db: false }, async () => {
  const checks = {
    databaseUrl: !!(process.env.DATABASE_URL || process.env.POSTGRES_URL),
    appSecret: (process.env.APP_SECRET || '').length >= 32 || process.env.NODE_ENV === 'test',
    setupToken: setupEnabled(),
    cronSecret: !!process.env.CRON_SECRET,
    appUrl: !!process.env.APP_URL,
    mail: mailEnabled(),
    database: 'unknown',
  };
  let adminReady = null;
  try {
    const db = await getDb();
    await db.query('SELECT 1 AS ok');
    checks.database = 'ok';
    adminReady = await adminExists(db);
  } catch (e) { checks.database = classifyDbError(e); }
  const ok = checks.databaseUrl && checks.appSecret && checks.database === 'ok';
  return { ok, version: VERSION, time: Date.now(), checks, adminCreated: adminReady };
});

/** One-time creation of the first administrator. Works only while no admin exists and requires the SETUP_TOKEN secret. */
route('POST', '/setup', { auth: 'public' }, async (ctx) => {
  if (!setupEnabled() || await adminExists(ctx.db)) throw notFound();
  await rateLimit(ctx, 'setup', ctx.ip, 8, 3600);
  const b = v.obj(ctx.body);
  const token = v.str(b.token, { field: 'setup token', max: 300 });
  if (!safeEqual(token, process.env.SETUP_TOKEN)) {
    await audit(ctx, 'setup.bad_token', { actor: { email: null } });
    throw forbidden('The setup token is not correct', 'invalid_setup_token');
  }
  const email = v.email(b.email);
  const name = v.str(b.name, { field: 'name', min: 1, max: 80 });
  const password = b.password;
  const problem = passwordProblem(password, email);
  if (problem) throw bad(problem, 'password');
  const now = Date.now();
  const id = uid();
  const rows = await ctx.db.query(
    `INSERT INTO users (id, email, email_lower, name, password_hash, role, status, email_verified, created_at, updated_at)
     VALUES ($1,$2,$3,$4,$5,'admin','active',1,$6,$6) ON CONFLICT (email_lower) DO NOTHING RETURNING id`,
    [id, email, email.toLowerCase(), name, await hashPassword(password), now],
  );
  if (!rows.length) throw new HttpError(409, 'email_taken', 'An account with this email already exists');
  const user = (await ctx.db.query('SELECT * FROM users WHERE id = $1', [id]))[0];
  await createSession(ctx, id);
  await audit(ctx, 'setup.admin_created', { actor: user, targetType: 'user', targetId: id });
  ctx.status = 201;
  return { user: userDto(user) };
});

/** Daily housekeeping, triggered by Vercel Cron with "Authorization: Bearer $CRON_SECRET". */
route('GET', '/cron/cleanup', { auth: 'public' }, async (ctx) => {
  const secret = process.env.CRON_SECRET;
  if (!secret) throw notFound();
  const got = String(ctx.req.headers.authorization || '').replace(/^Bearer\s+/i, '');
  if (!safeEqual(got, secret)) throw forbidden('Invalid cron secret', 'forbidden');
  const now = Date.now();
  const day = 24 * 3600 * 1000;
  const out = {};
  const del = async (name, sql, params) => { out[name] = (await ctx.db.query(sql + ' RETURNING 1 AS x', params)).length; };
  await del('sessions', 'DELETE FROM sessions WHERE expires_at < $1', [now]);
  await del('tokens', 'DELETE FROM one_time_tokens WHERE expires_at < $1', [now - 7 * day]);
  await del('rateLimits', 'DELETE FROM rate_limits WHERE window_start < $1', [now - day]);
  await del('invites', 'DELETE FROM team_invites WHERE expires_at < $1', [now - 30 * day]);
  await del('audit', 'DELETE FROM audit_log WHERE ts < $1', [now - 180 * day]);
  await del('trashedProjects', 'DELETE FROM projects WHERE deleted_at IS NOT NULL AND deleted_at < $1', [now - 30 * day]);
  return { ok: true, removed: out };
});

