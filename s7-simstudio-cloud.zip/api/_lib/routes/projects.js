import { route } from '../router.js';
import { HttpError, bad, forbidden, notFound, conflict } from '../http.js';
import { uid } from '../crypto.js';
import { rateLimit } from '../ratelimit.js';
import { audit } from '../audit.js';
import { getSettings } from '../settings.js';
import * as v from '../validate.js';

const RANK = { viewer: 1, editor: 2, admin: 3, owner: 4 };
const canWrite = (role) => RANK[role] >= RANK.editor;
const canManage = (role) => RANK[role] >= RANK.admin;
const BIG = 3_400_000;
const SNAPSHOT_EVERY_MS = 15 * 60 * 1000;

const meta = (p, role) => ({
  id: p.id, name: p.name, revision: Number(p.revision), sizeBytes: Number(p.size_bytes),
  createdAt: Number(p.created_at), updatedAt: Number(p.updated_at), deletedAt: p.deleted_at == null ? null : Number(p.deleted_at),
  scope: p.team_id ? 'team' : 'personal', teamId: p.team_id ?? null, teamName: p.team_name ?? null,
  role, updatedBy: p.updated_by_name ?? null,
});

/** Loads a project and the caller's role in it. Unknown ids and other people's private projects both answer 404. */
async function loadAccess(ctx, id, { deleted } = {}) {
  const rows = await ctx.db.query(
    `SELECT p.*, t.name AS team_name, tm.role AS team_role, uu.name AS updated_by_name
       FROM projects p
       LEFT JOIN teams t ON t.id = p.team_id
       LEFT JOIN team_members tm ON tm.team_id = p.team_id AND tm.user_id = $2
       LEFT JOIN users uu ON uu.id = p.updated_by
      WHERE p.id = $1`,
    [id, ctx.user.id],
  );
  const p = rows[0];
  if (!p) throw notFound('Project not found');
  let role;
  if (p.owner_user_id) {
    if (p.owner_user_id !== ctx.user.id) throw notFound('Project not found');
    role = 'owner';
  } else {
    if (!p.team_role) throw notFound('Project not found');
    role = p.team_role;
  }
  if (deleted === false && p.deleted_at != null) throw notFound('Project not found');
  if (deleted === true && p.deleted_at == null) throw bad('Project is not in the trash');
  return { p, role };
}

async function teamRole(db, teamId, userId) {
  const r = (await db.query('SELECT role FROM team_members WHERE team_id = $1 AND user_id = $2', [teamId, userId]))[0];
  return r?.role ?? null;
}

/** Quota check for a new project in the given scope. */
async function checkQuota(ctx, s, teamId) {
  if (teamId) {
    const n = Number((await ctx.db.query('SELECT COUNT(*) AS n FROM projects WHERE team_id = $1 AND deleted_at IS NULL', [teamId]))[0].n);
    if (n >= s.maxTeamProjects) throw new HttpError(409, 'quota_exceeded', `This team has reached its limit of ${s.maxTeamProjects} projects`);
  } else {
    const n = Number((await ctx.db.query('SELECT COUNT(*) AS n FROM projects WHERE owner_user_id = $1 AND deleted_at IS NULL', [ctx.user.id]))[0].n);
    if (n >= s.maxPersonalProjects) throw new HttpError(409, 'quota_exceeded', `You have reached your limit of ${s.maxPersonalProjects} projects. Delete some or ask the administrator.`);
  }
}

async function snapshot(t, s, { projectId, revision, text, size, userId, label = null, force = false }) {
  if (s.versionsPerProject <= 0) return;
  const now = Date.now();
  if (!force) {
    const last = (await t.query('SELECT created_at FROM project_versions WHERE project_id = $1 ORDER BY created_at DESC LIMIT 1', [projectId]))[0];
    if (last && now - Number(last.created_at) < SNAPSHOT_EVERY_MS) return;
  }
  await t.query(
    'INSERT INTO project_versions (id, project_id, revision, data, size_bytes, label, created_by, created_at) VALUES ($1,$2,$3,$4,$5,$6,$7,$8)',
    [uid(), projectId, revision, text, size, label, userId, now],
  );
  await t.query(
    'DELETE FROM project_versions WHERE project_id = $1 AND id NOT IN (SELECT id FROM project_versions WHERE project_id = $1 ORDER BY created_at DESC LIMIT $2)',
    [projectId, s.versionsPerProject],
  );
}

const like = (q) => '%' + q.toLowerCase().replace(/[\\%_]/g, m => '\\' + m) + '%';

// ---- list ---------------------------------------------------------------------------------------
route('GET', '/projects', {}, async (ctx) => {
  const q = ctx.query;
  const trash = q.trash === '1';
  const params = [ctx.user.id];
  let where = '(p.owner_user_id = $1 OR tm.user_id IS NOT NULL)';
  where += trash ? " AND p.deleted_at IS NOT NULL AND (p.owner_user_id = $1 OR tm.role IN ('owner','admin') OR p.created_by = $1)" : ' AND p.deleted_at IS NULL';
  if (q.scope === 'personal') where += ' AND p.owner_user_id = $1';
  else if (q.team) { params.push(v.id(q.team, 'team')); where += ` AND p.team_id = $${params.length}`; }
  if (q.q) { params.push(like(v.str(q.q, { field: 'q', max: 80 }))); where += ` AND LOWER(p.name) LIKE $${params.length} ESCAPE '\\'`; }
  const rows = await ctx.db.query(
    `SELECT p.id, p.name, p.revision, p.size_bytes, p.created_at, p.updated_at, p.deleted_at, p.team_id, p.owner_user_id,
            t.name AS team_name, tm.role AS team_role, uu.name AS updated_by_name
       FROM projects p
       LEFT JOIN teams t ON t.id = p.team_id
       LEFT JOIN team_members tm ON tm.team_id = p.team_id AND tm.user_id = $1
       LEFT JOIN users uu ON uu.id = p.updated_by
      WHERE ${where}
      ORDER BY ${trash ? 'p.deleted_at' : 'p.updated_at'} DESC LIMIT 500`,
    params,
  );
  return { projects: rows.map(r => meta(r, r.owner_user_id ? 'owner' : r.team_role)) };
});

// ---- create -------------------------------------------------------------------------------------
route('POST', '/projects', { maxBody: BIG }, async (ctx) => {
  await rateLimit(ctx, 'proj-write', ctx.user.id, 120, 60);
  const b = v.obj(ctx.body);
  v.onlyKeys(b, ['name', 'data', 'teamId']);
  const s = await getSettings();
  const { text, size } = v.checkProjectData(b.data, s.maxProjectKB * 1024);
  const name = v.str(b.name ?? b.data.name, { field: 'name', min: 1, max: 120 });
  const teamId = b.teamId ? v.id(b.teamId, 'teamId') : null;
  if (teamId) {
    const role = await teamRole(ctx.db, teamId, ctx.user.id);
    if (!role) throw notFound('Team not found');
    if (!canWrite(role)) throw forbidden('Viewers cannot add projects to this team');
  }
  await checkQuota(ctx, s, teamId);
  const id = uid(), now = Date.now();
  await ctx.db.tx(async t => {
    await t.query(
      `INSERT INTO projects (id, owner_user_id, team_id, name, data, revision, size_bytes, created_by, updated_by, created_at, updated_at)
       VALUES ($1,$2,$3,$4,$5,1,$6,$7,$7,$8,$8)`,
      [id, teamId ? null : ctx.user.id, teamId, name, text, size, ctx.user.id, now],
    );
    await snapshot(t, s, { projectId: id, revision: 1, text, size, userId: ctx.user.id, force: true });
  });
  await audit(ctx, 'project.create', { targetType: 'project', targetId: id, meta: { teamId } });
  ctx.status = 201;
  const { p, role } = await loadAccess(ctx, id);
  return { project: meta(p, role) };
});

// ---- read ---------------------------------------------------------------------------------------
route('GET', '/projects/:id', {}, async (ctx) => {
  const { p, role } = await loadAccess(ctx, v.id(ctx.params.id), { deleted: false });
  return { project: meta(p, role), data: JSON.parse(p.data) };
});
route('GET', '/projects/:id/meta', {}, async (ctx) => {
  const { p, role } = await loadAccess(ctx, v.id(ctx.params.id), { deleted: false });
  return { project: meta(p, role) };
});

// ---- save (optimistic concurrency) --------------------------------------------------------------
route('PUT', '/projects/:id', { maxBody: BIG }, async (ctx) => {
  await rateLimit(ctx, 'proj-write', ctx.user.id, 120, 60);
  const id = v.id(ctx.params.id);
  const b = v.obj(ctx.body);
  v.onlyKeys(b, ['baseRevision', 'data', 'name']);
  const base = v.int(b.baseRevision, { field: 'baseRevision', min: 1, max: 2_000_000_000 });
  if (b.data === undefined && b.name === undefined) throw bad('Nothing to save');
  const { p, role } = await loadAccess(ctx, id, { deleted: false });
  if (!canWrite(role)) throw forbidden('You have view-only access to this project');
  const s = await getSettings();
  let text = p.data, size = Number(p.size_bytes);
  if (b.data !== undefined) ({ text, size } = v.checkProjectData(b.data, s.maxProjectKB * 1024));
  const name = b.name !== undefined ? v.str(b.name, { field: 'name', min: 1, max: 120 }) : p.name;
  const now = Date.now();
  const result = await ctx.db.tx(async t => {
    const rows = await t.query(
      `UPDATE projects SET data = $1, name = $2, size_bytes = $3, revision = revision + 1, updated_at = $4, updated_by = $5
        WHERE id = $6 AND revision = $7 AND deleted_at IS NULL RETURNING revision, updated_at`,
      [text, name, size, now, ctx.user.id, id, base],
    );
    if (!rows.length) return null;
    if (b.data !== undefined) await snapshot(t, s, { projectId: id, revision: Number(rows[0].revision), text, size, userId: ctx.user.id });
    return rows[0];
  });
  if (!result) {
    const cur = (await ctx.db.query('SELECT p.revision, p.updated_at, u.name AS by FROM projects p LEFT JOIN users u ON u.id = p.updated_by WHERE p.id = $1', [id]))[0];
    throw conflict('conflict', 'This project was changed on another device or by a teammate', cur ? { revision: Number(cur.revision), updatedAt: Number(cur.updated_at), updatedBy: cur.by ?? null } : undefined);
  }
  return { revision: Number(result.revision), updatedAt: Number(result.updated_at) };
});

// ---- trash / restore / delete -------------------------------------------------------------------
const canDelete = (p, role, userId) => role === 'owner' || canManage(role) || (role === 'editor' && p.created_by === userId);

route('DELETE', '/projects/:id', {}, async (ctx) => {
  const id = v.id(ctx.params.id);
  const permanent = ctx.query.permanent === '1';
  const { p, role } = await loadAccess(ctx, id, { deleted: permanent ? true : false });
  if (!canDelete(p, role, ctx.user.id)) throw forbidden('You cannot delete this project');
  if (permanent) await ctx.db.query('DELETE FROM projects WHERE id = $1', [id]);
  else await ctx.db.query('UPDATE projects SET deleted_at = $1 WHERE id = $2', [Date.now(), id]);
  await audit(ctx, permanent ? 'project.purge' : 'project.delete', { targetType: 'project', targetId: id });
  return { ok: true };
});
route('POST', '/projects/:id/restore', {}, async (ctx) => {
  const id = v.id(ctx.params.id);
  const { p, role } = await loadAccess(ctx, id, { deleted: true });
  if (!canDelete(p, role, ctx.user.id)) throw forbidden('You cannot restore this project');
  await checkQuota(ctx, await getSettings(), p.team_id);
  await ctx.db.query('UPDATE projects SET deleted_at = NULL WHERE id = $1', [id]);
  await audit(ctx, 'project.restore', { targetType: 'project', targetId: id });
  return { ok: true };
});

// ---- duplicate / move ---------------------------------------------------------------------------
route('POST', '/projects/:id/duplicate', { maxBody: 4096 }, async (ctx) => {
  await rateLimit(ctx, 'proj-write', ctx.user.id, 120, 60);
  const { p } = await loadAccess(ctx, v.id(ctx.params.id), { deleted: false });
  const b = ctx.body === undefined ? {} : v.obj(ctx.body);
  v.onlyKeys(b, ['name', 'teamId']);
  const s = await getSettings();
  const name = v.str(b.name ?? `${p.name} (copy)`, { field: 'name', min: 1, max: 120 });
  const teamId = b.teamId ? v.id(b.teamId, 'teamId') : null;
  if (teamId) {
    const role = await teamRole(ctx.db, teamId, ctx.user.id);
    if (!role) throw notFound('Team not found');
    if (!canWrite(role)) throw forbidden('Viewers cannot add projects to this team');
  }
  await checkQuota(ctx, s, teamId);
  const id = uid(), now = Date.now();
  await ctx.db.tx(async t => {
    await t.query(
      `INSERT INTO projects (id, owner_user_id, team_id, name, data, revision, size_bytes, created_by, updated_by, created_at, updated_at)
       VALUES ($1,$2,$3,$4,$5,1,$6,$7,$7,$8,$8)`,
      [id, teamId ? null : ctx.user.id, teamId, name, p.data, p.size_bytes, ctx.user.id, now],
    );
    await snapshot(t, s, { projectId: id, revision: 1, text: p.data, size: Number(p.size_bytes), userId: ctx.user.id, force: true });
  });
  await audit(ctx, 'project.duplicate', { targetType: 'project', targetId: id, meta: { from: p.id } });
  ctx.status = 201;
  const created = await loadAccess(ctx, id);
  return { project: meta(created.p, created.role) };
});

route('POST', '/projects/:id/move', { maxBody: 4096 }, async (ctx) => {
  const id = v.id(ctx.params.id);
  const { p, role } = await loadAccess(ctx, id, { deleted: false });
  if (!canManage(role)) throw forbidden('Only the owner or a team admin can move a project');
  const b = v.obj(ctx.body);
  v.onlyKeys(b, ['teamId']);
  const teamId = b.teamId ? v.id(b.teamId, 'teamId') : null;
  if (teamId === (p.team_id ?? null)) throw bad('The project is already there');
  if (teamId) {
    const r = await teamRole(ctx.db, teamId, ctx.user.id);
    if (!r) throw notFound('Team not found');
    if (!canWrite(r)) throw forbidden('Viewers cannot add projects to this team');
  }
  await checkQuota(ctx, await getSettings(), teamId);
  await ctx.db.query('UPDATE projects SET owner_user_id = $1, team_id = $2, updated_at = $3 WHERE id = $4', [teamId ? null : ctx.user.id, teamId, Date.now(), id]);
  await audit(ctx, 'project.move', { targetType: 'project', targetId: id, meta: { from: p.team_id ?? 'personal', to: teamId ?? 'personal' } });
  return { ok: true };
});

// ---- version history ----------------------------------------------------------------------------
route('GET', '/projects/:id/versions', {}, async (ctx) => {
  const id = v.id(ctx.params.id);
  await loadAccess(ctx, id, { deleted: false });
  const rows = await ctx.db.query(
    `SELECT pv.id, pv.revision, pv.label, pv.size_bytes, pv.created_at, u.name AS by
       FROM project_versions pv LEFT JOIN users u ON u.id = pv.created_by WHERE pv.project_id = $1 ORDER BY pv.created_at DESC`,
    [id],
  );
  return { versions: rows.map(r => ({ id: r.id, revision: Number(r.revision), label: r.label, sizeBytes: Number(r.size_bytes), createdAt: Number(r.created_at), by: r.by ?? null })) };
});
route('GET', '/projects/:id/versions/:vid', {}, async (ctx) => {
  const id = v.id(ctx.params.id);
  await loadAccess(ctx, id, { deleted: false });
  const r = (await ctx.db.query('SELECT data, revision, created_at FROM project_versions WHERE id = $1 AND project_id = $2', [v.id(ctx.params.vid, 'versionId'), id]))[0];
  if (!r) throw notFound('Version not found');
  return { revision: Number(r.revision), createdAt: Number(r.created_at), data: JSON.parse(r.data) };
});
route('POST', '/projects/:id/checkpoint', { maxBody: 4096 }, async (ctx) => {
  await rateLimit(ctx, 'proj-write', ctx.user.id, 120, 60);
  const id = v.id(ctx.params.id);
  const { p, role } = await loadAccess(ctx, id, { deleted: false });
  if (!canWrite(role)) throw forbidden('You have view-only access to this project');
  const b = ctx.body === undefined ? {} : v.obj(ctx.body);
  const label = v.str(b.label, { field: 'label', max: 80, required: false }) ?? 'Checkpoint';
  const s = await getSettings();
  if (s.versionsPerProject <= 0) throw bad('Version history is switched off');
  await ctx.db.tx(t => snapshot(t, s, { projectId: id, revision: Number(p.revision), text: p.data, size: Number(p.size_bytes), userId: ctx.user.id, label, force: true }));
  ctx.status = 201;
  return { ok: true };
});
route('POST', '/projects/:id/versions/:vid/restore', { maxBody: 4096 }, async (ctx) => {
  await rateLimit(ctx, 'proj-write', ctx.user.id, 120, 60);
  const id = v.id(ctx.params.id);
  const { p, role } = await loadAccess(ctx, id, { deleted: false });
  if (!canWrite(role)) throw forbidden('You have view-only access to this project');
  const ver = (await ctx.db.query('SELECT data, size_bytes, revision FROM project_versions WHERE id = $1 AND project_id = $2', [v.id(ctx.params.vid, 'versionId'), id]))[0];
  if (!ver) throw notFound('Version not found');
  const s = await getSettings();
  const now = Date.now();
  const out = await ctx.db.tx(async t => {
    // keep what is being replaced so the restore itself can be undone
    await snapshot(t, s, { projectId: id, revision: Number(p.revision), text: p.data, size: Number(p.size_bytes), userId: ctx.user.id, label: 'Before restore', force: true });
    const rows = await t.query(
      'UPDATE projects SET data = $1, size_bytes = $2, revision = revision + 1, updated_at = $3, updated_by = $4 WHERE id = $5 RETURNING revision',
      [ver.data, ver.size_bytes, now, ctx.user.id, id],
    );
    return rows[0];
  });
  await audit(ctx, 'project.restore_version', { targetType: 'project', targetId: id, meta: { fromRevision: Number(ver.revision) } });
  return { revision: Number(out.revision) };
});
