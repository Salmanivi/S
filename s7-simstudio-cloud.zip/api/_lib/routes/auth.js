import { route } from '../router.js';
import { HttpError, bad, forbidden, notFound, baseUrl } from '../http.js';
import { uid, randomToken, sha256, hashPassword, verifyPassword, dummyVerify, passwordProblem } from '../crypto.js';
import { createSession, clearSessionCookie, sessionTokenOf, userDto, deleteUserCascade } from '../session.js';
import { rateLimit } from '../ratelimit.js';
import { audit } from '../audit.js';
import { getSettings } from '../settings.js';
import { mailEnabled } from '../env.js';
import { sendMail, resetMail, verifyMail } from '../mail.js';
import * as v from '../validate.js';

const DAY = 24 * 3600 * 1000;

async function issueToken(db, userId, purpose, ttlMs) {
  const token = randomToken(32);
  const now = Date.now();
  // one live token per purpose and user
  await db.query("DELETE FROM one_time_tokens WHERE user_id = $1 AND purpose = $2 AND used_at IS NULL", [userId, purpose]);
  await db.query(
    'INSERT INTO one_time_tokens (id, user_id, purpose, token_hash, created_at, expires_at) VALUES ($1,$2,$3,$4,$5,$6)',
    [uid(), userId, purpose, sha256(token), now, now + ttlMs],
  );
  return token;
}
export const issueResetToken = (db, userId) => issueToken(db, userId, 'reset', 3600 * 1000);

async function consumeToken(db, token, purpose) {
  const rows = await db.query(
    'UPDATE one_time_tokens SET used_at = $1 WHERE token_hash = $2 AND purpose = $3 AND used_at IS NULL AND expires_at > $1 RETURNING user_id',
    [Date.now(), sha256(token), purpose],
  );
  return rows[0]?.user_id ?? null;
}

async function sendVerification(ctx, user) {
  const token = await issueToken(ctx.db, user.id, 'verify', DAY);
  const m = verifyMail(user.name, `${baseUrl(ctx)}/verify-email?token=${token}`);
  return sendMail({ to: user.email, ...m });
}

const getUserById = async (db, id) => (await db.query('SELECT * FROM users WHERE id = $1', [id]))[0];

export async function teamsOf(db, userId) {
  const rows = await db.query(
    `SELECT t.id, t.name, tm.role,
            (SELECT COUNT(*) FROM team_members x WHERE x.team_id = t.id) AS member_count,
            (SELECT COUNT(*) FROM projects p WHERE p.team_id = t.id AND p.deleted_at IS NULL) AS project_count
       FROM team_members tm JOIN teams t ON t.id = tm.team_id WHERE tm.user_id = $1 ORDER BY t.name`,
    [userId],
  );
  return rows.map(r => ({ id: r.id, name: r.name, role: r.role, memberCount: Number(r.member_count), projectCount: Number(r.project_count) }));
}

route('POST', '/auth/register', { auth: 'public' }, async (ctx) => {
  const s = await getSettings();
  if (!s.registrationEnabled) throw forbidden('New registrations are closed on this server', 'registration_closed');
  const b = v.obj(ctx.body);
  const email = v.email(b.email);
  const name = v.str(b.name, { field: 'name', min: 1, max: 80 });
  const problem = passwordProblem(b.password, email);
  if (problem) throw bad(problem, 'password');
  // counted only after validation, so typos do not lock anybody out; the expensive work (hashing) starts here
  await rateLimit(ctx, 'register', ctx.ip, 10, 3600);
  const now = Date.now();
  const id = uid();
  const rows = await ctx.db.query(
    `INSERT INTO users (id, email, email_lower, name, password_hash, role, status, email_verified, created_at, updated_at)
     VALUES ($1,$2,$3,$4,$5,'user','active',0,$6,$6) ON CONFLICT (email_lower) DO NOTHING RETURNING id`,
    [id, email, email.toLowerCase(), name, await hashPassword(b.password), now],
  );
  if (!rows.length) throw new HttpError(409, 'email_taken', 'An account with this email already exists. Try signing in.');
  const user = await getUserById(ctx.db, id);
  await audit(ctx, 'auth.register', { actor: user, targetType: 'user', targetId: id });
  ctx.status = 201;
  if (s.requireEmailVerification && mailEnabled()) {
    await sendVerification(ctx, user);
    return { needsVerification: true };
  }
  if (mailEnabled()) await sendVerification(ctx, user); // optional confirmation mail, does not block sign-in
  await createSession(ctx, id);
  return { user: userDto(user), teams: [] };
});

route('POST', '/auth/login', { auth: 'public' }, async (ctx) => {
  const b = v.obj(ctx.body);
  const email = v.str(b.email, { field: 'email', max: 254 }).toLowerCase();
  const password = typeof b.password === 'string' ? b.password : '';
  if (!password || password.length > 200) throw bad('Enter your password', 'password');
  await rateLimit(ctx, 'login-ip', ctx.ip, 40, 600);
  await rateLimit(ctx, 'login-acct', email, 10, 600);

  const user = (await ctx.db.query('SELECT * FROM users WHERE email_lower = $1', [email]))[0];
  const ok = user ? await verifyPassword(password, user.password_hash) : await dummyVerify(password);
  if (!user || !ok) {
    await audit(ctx, 'auth.login_failed', { actor: { id: user?.id ?? null, email }, targetType: 'user', targetId: user?.id ?? null });
    throw new HttpError(401, 'invalid_credentials', 'Incorrect email or password');
  }
  if (user.status !== 'active') throw forbidden('This account has been disabled. Contact the administrator.', 'account_disabled');
  const s = await getSettings();
  if (s.requireEmailVerification && mailEnabled() && !user.email_verified) throw forbidden('Please confirm your email address first. Check your inbox.', 'email_not_verified');
  await ctx.db.query('UPDATE users SET last_login_at = $1 WHERE id = $2', [Date.now(), user.id]);
  await createSession(ctx, user.id);
  await audit(ctx, 'auth.login', { actor: user, targetType: 'user', targetId: user.id });
  return { user: userDto(user), teams: await teamsOf(ctx.db, user.id) };
});

route('POST', '/auth/logout', { auth: 'public' }, async (ctx) => {
  const t = sessionTokenOf(ctx.req);
  if (t) await ctx.db.query('DELETE FROM sessions WHERE token_hash = $1', [sha256(t)]);
  clearSessionCookie(ctx);
  return { ok: true };
});

route('GET', '/auth/me', {}, async (ctx) => ({ user: userDto(ctx.user), teams: await teamsOf(ctx.db, ctx.user.id) }));

route('PATCH', '/auth/profile', {}, async (ctx) => {
  const b = v.obj(ctx.body);
  v.onlyKeys(b, ['name']);
  const name = v.str(b.name, { field: 'name', min: 1, max: 80 });
  await ctx.db.query('UPDATE users SET name = $1, updated_at = $2 WHERE id = $3', [name, Date.now(), ctx.user.id]);
  return { user: userDto(await getUserById(ctx.db, ctx.user.id)) };
});

route('POST', '/auth/password', {}, async (ctx) => {
  await rateLimit(ctx, 'pwchange', ctx.user.id, 10, 3600);
  const b = v.obj(ctx.body);
  if (typeof b.currentPassword !== 'string' || !(await verifyPassword(b.currentPassword, ctx.user.password_hash))) {
    throw new HttpError(403, 'wrong_password', 'Your current password is not correct');
  }
  const problem = passwordProblem(b.newPassword, ctx.user.email);
  if (problem) throw bad(problem, 'newPassword');
  await ctx.db.query('UPDATE users SET password_hash = $1, updated_at = $2 WHERE id = $3', [await hashPassword(b.newPassword), Date.now(), ctx.user.id]);
  await ctx.db.query('DELETE FROM sessions WHERE user_id = $1 AND id <> $2', [ctx.user.id, ctx.sessionId]);
  await audit(ctx, 'auth.password_change', { targetType: 'user', targetId: ctx.user.id });
  return { ok: true };
});

route('POST', '/auth/forgot', { auth: 'public' }, async (ctx) => {
  if (!mailEnabled()) throw new HttpError(501, 'mail_disabled', 'Password reset by email is not enabled on this server. Ask an administrator for a reset link.');
  const b = v.obj(ctx.body);
  const email = v.email(b.email).toLowerCase();
  await rateLimit(ctx, 'forgot-ip', ctx.ip, 8, 3600);
  await rateLimit(ctx, 'forgot-acct', email, 3, 3600);
  const user = (await ctx.db.query("SELECT * FROM users WHERE email_lower = $1 AND status = 'active'", [email]))[0];
  if (user) {
    const token = await issueResetToken(ctx.db, user.id);
    await sendMail({ to: user.email, ...resetMail(user.name, `${baseUrl(ctx)}/reset-password?token=${token}`) });
    await audit(ctx, 'auth.reset_requested', { actor: user, targetType: 'user', targetId: user.id });
  }
  return { ok: true }; // identical answer whether or not the account exists
});

route('POST', '/auth/reset', { auth: 'public' }, async (ctx) => {
  await rateLimit(ctx, 'reset-ip', ctx.ip, 20, 3600);
  const b = v.obj(ctx.body);
  const token = v.str(b.token, { field: 'token', max: 200 });
  const live = (await ctx.db.query(
    `SELECT u.* FROM one_time_tokens t JOIN users u ON u.id = t.user_id
      WHERE t.token_hash = $1 AND t.purpose = 'reset' AND t.used_at IS NULL AND t.expires_at > $2`,
    [sha256(token), Date.now()],
  ))[0];
  if (!live) throw new HttpError(400, 'invalid_token', 'This reset link is invalid or has expired');
  const problem = passwordProblem(b.password, live.email);
  if (problem) throw bad(problem, 'password');          // the link stays valid so the user can try again
  const userId = await consumeToken(ctx.db, token, 'reset');
  if (!userId) throw new HttpError(400, 'invalid_token', 'This reset link is invalid or has expired');
  await ctx.db.query('UPDATE users SET password_hash = $1, updated_at = $2 WHERE id = $3', [await hashPassword(b.password), Date.now(), userId]);
  await ctx.db.query('DELETE FROM sessions WHERE user_id = $1', [userId]);
  await audit(ctx, 'auth.password_reset', { actor: live, targetType: 'user', targetId: userId });
  return { ok: true };
});

route('POST', '/auth/verify', { auth: 'public' }, async (ctx) => {
  await rateLimit(ctx, 'verify-ip', ctx.ip, 30, 3600);
  const token = v.str(v.obj(ctx.body).token, { field: 'token', max: 200 });
  const userId = await consumeToken(ctx.db, token, 'verify');
  if (!userId) throw new HttpError(400, 'invalid_token', 'This confirmation link is invalid or has expired');
  await ctx.db.query('UPDATE users SET email_verified = 1, updated_at = $1 WHERE id = $2', [Date.now(), userId]);
  return { ok: true };
});

route('POST', '/auth/resend', {}, async (ctx) => {
  if (!mailEnabled()) throw new HttpError(501, 'mail_disabled', 'Email is not enabled on this server');
  if (ctx.user.email_verified) return { ok: true };
  await rateLimit(ctx, 'resend', ctx.user.id, 3, 3600);
  await sendVerification(ctx, ctx.user);
  return { ok: true };
});

route('GET', '/auth/sessions', {}, async (ctx) => {
  const rows = await ctx.db.query('SELECT id, created_at, last_used_at, expires_at, user_agent FROM sessions WHERE user_id = $1 AND expires_at > $2 ORDER BY last_used_at DESC', [ctx.user.id, Date.now()]);
  return { sessions: rows.map(r => ({ id: r.id, createdAt: Number(r.created_at), lastUsedAt: Number(r.last_used_at), userAgent: r.user_agent || '', current: r.id === ctx.sessionId })) };
});
route('POST', '/auth/sessions/revoke-others', {}, async (ctx) => {
  const rows = await ctx.db.query('DELETE FROM sessions WHERE user_id = $1 AND id <> $2 RETURNING id', [ctx.user.id, ctx.sessionId]);
  return { revoked: rows.length };
});
route('DELETE', '/auth/sessions/:id', {}, async (ctx) => {
  const id = v.id(ctx.params.id);
  const rows = await ctx.db.query('DELETE FROM sessions WHERE id = $1 AND user_id = $2 RETURNING id', [id, ctx.user.id]);
  if (!rows.length) throw notFound('Session not found');
  return { ok: true };
});

route('POST', '/auth/delete-account', {}, async (ctx) => {
  await rateLimit(ctx, 'delacct', ctx.user.id, 5, 3600);
  const b = v.obj(ctx.body);
  if (typeof b.password !== 'string' || !(await verifyPassword(b.password, ctx.user.password_hash))) throw new HttpError(403, 'wrong_password', 'Your password is not correct');
  if (ctx.user.role === 'admin') {
    const n = Number((await ctx.db.query("SELECT COUNT(*) AS n FROM users WHERE role = 'admin' AND status = 'active'"))[0].n);
    if (n <= 1) throw new HttpError(409, 'last_admin', 'You are the only administrator. Make another account an administrator first.');
  }
  await audit(ctx, 'auth.account_deleted', { targetType: 'user', targetId: ctx.user.id });
  await deleteUserCascade(ctx.db, ctx.user.id);
  clearSessionCookie(ctx);
  return { ok: true };
});

/** Everything the user owns, as one JSON file (personal projects are included in full, capped at ~3.5 MB). */
route('GET', '/auth/export', {}, async (ctx) => {
  await rateLimit(ctx, 'export', ctx.user.id, 6, 3600);
  const projects = await ctx.db.query('SELECT id, name, data, revision, created_at, updated_at FROM projects WHERE owner_user_id = $1 AND deleted_at IS NULL ORDER BY updated_at DESC', [ctx.user.id]);
  const out = [];
  let size = 0, truncated = false;
  for (const p of projects) {
    size += p.data.length;
    if (size > 3_500_000) { truncated = true; break; }
    out.push({ id: p.id, name: p.name, revision: p.revision, createdAt: Number(p.created_at), updatedAt: Number(p.updated_at), project: JSON.parse(p.data) });
  }
  return { exportedAt: Date.now(), user: userDto(ctx.user), teams: await teamsOf(ctx.db, ctx.user.id), projects: out, truncated };
});
