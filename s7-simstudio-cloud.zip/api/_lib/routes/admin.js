import { route } from '../router.js';
import { HttpError, bad, forbidden, notFound, baseUrl } from '../http.js';
import { uid, hashPassword, passwordProblem } from '../crypto.js';
import { userDto, deleteUserCascade } from '../session.js';
import { audit } from '../audit.js';
import { getSettings, invalidateSettings, RULES, DEFAULTS } from '../settings.js';
import { issueResetToken } from './auth.js';
import * as v from '../validate.js';

const DAY = 24 * 3600 * 1000;
const like = (q) => '%' + q.toLowerCase().replace(/[\\%_]/g, m => '\\' + m) + '%';
const num = (rows, k = 'n') => Number(rows[0]?.[k] ?? 0);
const activeAdmins = async (db) => num(await db.query("SELECT COUNT(*) AS n FROM users WHERE role = 'admin' AND status = 'active'"));
const getUser = async (db, id) => (await db.query('SELECT * FROM users WHERE id = $1', [id]))[0];

route('GET', '/admin/stats', { auth: 'admin' }, async (ctx) => {
  const db = ctx.db, now = Date.now();
  const [users, active7, projects, trashed, teams, storage, versionStorage, logins, failed, signups] = await Promise.all([
    db.query("SELECT COUNT(*) AS n, SUM(CASE WHEN status = 'disabled' THEN 1 ELSE 0 END) AS disabled, SUM(CASE WHEN role = 'admin' THEN 1 ELSE 0 END) AS admins FROM users"),
    db.query('SELECT COUNT(*) AS n FROM users WHERE last_login_at > $1', [now - 7 * DAY]),
    db.query('SELECT COUNT(*) AS n FROM projects WHERE deleted_at IS NULL'),
    db.query('SELECT COUNT(*) AS n FROM projects WHERE deleted_at IS NOT NULL'),
    db.query('SELECT COUNT(*) AS n FROM teams'),
    db.query('SELECT COALESCE(SUM(size_bytes), 0) AS n FROM projects'),
    db.query('SELECT COALESCE(SUM(size_bytes), 0) AS n FROM project_versions'),
    db.query("SELECT COUNT(*) AS n FROM audit_log WHERE action = 'auth.login' AND ts > $1", [now - DAY]),
    db.query("SELECT COUNT(*) AS n FROM audit_log WHERE action = 'auth.login_failed' AND ts > $1", [now - DAY]),
    db.query('SELECT created_at / 86400000 AS d, COUNT(*) AS n FROM users WHERE created_at > $1 GROUP BY created_at / 86400000 ORDER BY d', [now - 14 * DAY]),
  ]);
  const byDay = new Map(signups.map(r => [Number(r.d), Number(r.n)]));
  const today = Math.floor(now / DAY);
  const series = [];
  for (let d = today - 13; d <= today; d++) series.push({ day: d * DAY, count: byDay.get(d) ?? 0 });
  return {
    users: { total: num(users), disabled: num(users, 'disabled'), admins: num(users, 'admins'), activeLast7Days: num(active7) },
    projects: { total: num(projects), trashed: num(trashed) },
    teams: num(teams),
    storageBytes: num(storage) + num(versionStorage),
    last24h: { logins: num(logins), failedLogins: num(failed) },
    signups14d: series,
  };
});

route('GET', '/admin/users', { auth: 'admin' }, async (ctx) => {
  const q = ctx.query;
  const limit = v.int(q.limit ?? 25, { field: 'limit', min: 1, max: 100 });
  const offset = v.int(q.offset ?? 0, { field: 'offset', min: 0, max: 1_000_000 });
  const params = [];
  const where = [];
  if (q.q) { params.push(like(v.str(q.q, { field: 'q', max: 80 }))); where.push(`(LOWER(u.email) LIKE $${params.length} ESCAPE '\\' OR LOWER(u.name) LIKE $${params.length} ESCAPE '\\')`); }
  if (q.status) { params.push(v.oneOf(q.status, ['active', 'disabled'], 'status')); where.push(`u.status = $${params.length}`); }
  if (q.role) { params.push(v.oneOf(q.role, ['user', 'admin'], 'role')); where.push(`u.role = $${params.length}`); }
  const w = where.length ? 'WHERE ' + where.join(' AND ') : '';
  const total = num(await ctx.db.query(`SELECT COUNT(*) AS n FROM users u ${w}`, params));
  const rows = await ctx.db.query(
    `SELECT u.*,
       (SELECT COUNT(*) FROM projects p WHERE p.owner_user_id = u.id AND p.deleted_at IS NULL) AS project_count,
       (SELECT COUNT(*) FROM team_members tm WHERE tm.user_id = u.id) AS team_count
       FROM users u ${w} ORDER BY u.created_at DESC LIMIT $${params.length + 1} OFFSET $${params.length + 2}`,
    [...params, limit, offset],
  );
  return { total, users: rows.map(r => ({ ...userDto(r), projectCount: Number(r.project_count), teamCount: Number(r.team_count) })) };
});

route('POST', '/admin/users', { auth: 'admin' }, async (ctx) => {
  const b = v.obj(ctx.body);
  v.onlyKeys(b, ['email', 'name', 'password', 'role']);
  const email = v.email(b.email);
  const name = v.str(b.name, { field: 'name', min: 1, max: 80 });
  const role = v.oneOf(b.role ?? 'user', ['user', 'admin'], 'role');
  const problem = passwordProblem(b.password, email);
  if (problem) throw bad(problem, 'password');
  const id = uid(), now = Date.now();
  const rows = await ctx.db.query(
    `INSERT INTO users (id, email, email_lower, name, password_hash, role, status, email_verified, created_at, updated_at)
     VALUES ($1,$2,$3,$4,$5,$6,'active',1,$7,$7) ON CONFLICT (email_lower) DO NOTHING RETURNING id`,
    [id, email, email.toLowerCase(), name, await hashPassword(b.password), role, now],
  );
  if (!rows.length) throw new HttpError(409, 'email_taken', 'An account with this email already exists');
  await audit(ctx, 'admin.user_create', { targetType: 'user', targetId: id, meta: { role } });
  ctx.status = 201;
  return { user: userDto(await getUser(ctx.db, id)) };
});

route('GET', '/admin/users/:id', { auth: 'admin' }, async (ctx) => {
  const id = v.id(ctx.params.id);
  const u = await getUser(ctx.db, id);
  if (!u) throw notFound('User not found');
  const [sessions, projects, teams, events] = await Promise.all([
    ctx.db.query('SELECT COUNT(*) AS n FROM sessions WHERE user_id = $1 AND expires_at > $2', [id, Date.now()]),
    ctx.db.query('SELECT COUNT(*) AS n, COALESCE(SUM(size_bytes), 0) AS bytes FROM projects WHERE owner_user_id = $1 AND deleted_at IS NULL', [id]),
    ctx.db.query('SELECT t.id, t.name, tm.role FROM team_members tm JOIN teams t ON t.id = tm.team_id WHERE tm.user_id = $1 ORDER BY t.name', [id]),
    ctx.db.query('SELECT ts, action, ip FROM audit_log WHERE actor_id = $1 ORDER BY ts DESC LIMIT 15', [id]),
  ]);
  return {
    user: userDto(u), activeSessions: num(sessions), projects: { count: num(projects), bytes: num(projects, 'bytes') },
    teams: teams.map(t => ({ id: t.id, name: t.name, role: t.role })),
    recent: events.map(e => ({ ts: Number(e.ts), action: e.action, ip: e.ip })),
  };
});

route('PATCH', '/admin/users/:id', { auth: 'admin' }, async (ctx) => {
  const id = v.id(ctx.params.id);
  const b = v.obj(ctx.body);
  v.onlyKeys(b, ['role', 'status', 'name', 'emailVerified']);
  const u = await getUser(ctx.db, id);
  if (!u) throw notFound('User not found');
  const self = id === ctx.user.id;
  const sets = [], params = [];
  const set = (col, val) => { params.push(val); sets.push(`${col} = $${params.length}`); };
  if (b.name !== undefined) set('name', v.str(b.name, { field: 'name', min: 1, max: 80 }));
  if (b.emailVerified !== undefined) set('email_verified', v.bool(b.emailVerified, 'emailVerified') ? 1 : 0);
  if (b.role !== undefined) {
    const role = v.oneOf(b.role, ['user', 'admin'], 'role');
    if (self && role !== u.role) throw forbidden('You cannot change your own role', 'self_change');
    if (u.role === 'admin' && role === 'user' && u.status === 'active' && (await activeAdmins(ctx.db)) <= 1) throw new HttpError(409, 'last_admin', 'There must be at least one active administrator');
    set('role', role);
  }
  if (b.status !== undefined) {
    const status = v.oneOf(b.status, ['active', 'disabled'], 'status');
    if (self && status !== u.status) throw forbidden('You cannot disable your own account', 'self_change');
    if (u.role === 'admin' && status === 'disabled' && u.status === 'active' && (await activeAdmins(ctx.db)) <= 1) throw new HttpError(409, 'last_admin', 'There must be at least one active administrator');
    set('status', status);
  }
  if (!sets.length) throw bad('Nothing to change');
  params.push(Date.now()); sets.push(`updated_at = $${params.length}`);
  params.push(id);
  await ctx.db.query(`UPDATE users SET ${sets.join(', ')} WHERE id = $${params.length}`, params);
  if (b.status === 'disabled') await ctx.db.query('DELETE FROM sessions WHERE user_id = $1', [id]);
  await audit(ctx, 'admin.user_update', { targetType: 'user', targetId: id, meta: { role: b.role, status: b.status, emailVerified: b.emailVerified, name: b.name !== undefined } });
  return { user: userDto(await getUser(ctx.db, id)) };
});

route('POST', '/admin/users/:id/reset-link', { auth: 'admin' }, async (ctx) => {
  const id = v.id(ctx.params.id);
  const u = await getUser(ctx.db, id);
  if (!u) throw notFound('User not found');
  const token = await issueResetToken(ctx.db, id);
  await audit(ctx, 'admin.reset_link', { targetType: 'user', targetId: id });
  return { link: `${baseUrl(ctx)}/reset-password?token=${token}`, expiresInMinutes: 60 };
});

route('POST', '/admin/users/:id/revoke-sessions', { auth: 'admin' }, async (ctx) => {
  const id = v.id(ctx.params.id);
  if (!(await getUser(ctx.db, id))) throw notFound('User not found');
  const rows = await ctx.db.query('DELETE FROM sessions WHERE user_id = $1 RETURNING id', [id]);
  await audit(ctx, 'admin.revoke_sessions', { targetType: 'user', targetId: id });
  return { revoked: rows.length };
});

route('POST', '/admin/users/:id/delete', { auth: 'admin' }, async (ctx) => {
  const id = v.id(ctx.params.id);
  const b = v.obj(ctx.body);
  const u = await getUser(ctx.db, id);
  if (!u) throw notFound('User not found');
  if (id === ctx.user.id) throw forbidden('Delete your own account from the Account page', 'self_change');
  if (typeof b.confirmEmail !== 'string' || b.confirmEmail.trim().toLowerCase() !== u.email_lower) throw bad('Type the user\'s email address to confirm', 'confirmEmail');
  if (u.role === 'admin' && u.status === 'active' && (await activeAdmins(ctx.db)) <= 1) throw new HttpError(409, 'last_admin', 'There must be at least one active administrator');
  await audit(ctx, 'admin.user_delete', { targetType: 'user', targetId: id, meta: { email: u.email } });
  await deleteUserCascade(ctx.db, id);
  return { ok: true };
});

/** Metadata only: administrators manage accounts and storage, they do not read private project contents. */
route('GET', '/admin/projects', { auth: 'admin' }, async (ctx) => {
  const q = ctx.query;
  const limit = v.int(q.limit ?? 25, { field: 'limit', min: 1, max: 100 });
  const offset = v.int(q.offset ?? 0, { field: 'offset', min: 0, max: 1_000_000 });
  const params = [];
  let w = '';
  if (q.q) { params.push(like(v.str(q.q, { field: 'q', max: 80 }))); w = `WHERE LOWER(p.name) LIKE $1 ESCAPE '\\'`; }
  const total = num(await ctx.db.query(`SELECT COUNT(*) AS n FROM projects p ${w}`, params));
  const rows = await ctx.db.query(
    `SELECT p.id, p.name, p.revision, p.size_bytes, p.updated_at, p.deleted_at, u.name AS owner_name, u.email AS owner_email, t.name AS team_name
       FROM projects p LEFT JOIN users u ON u.id = p.owner_user_id LEFT JOIN teams t ON t.id = p.team_id
       ${w} ORDER BY p.updated_at DESC LIMIT $${params.length + 1} OFFSET $${params.length + 2}`,
    [...params, limit, offset],
  );
  return { total, projects: rows.map(r => ({ id: r.id, name: r.name, revision: Number(r.revision), sizeBytes: Number(r.size_bytes), updatedAt: Number(r.updated_at), trashed: r.deleted_at != null, owner: r.team_name ? `Team: ${r.team_name}` : `${r.owner_name ?? 'Deleted user'} (${r.owner_email ?? '-'})` })) };
});

route('GET', '/admin/teams', { auth: 'admin' }, async (ctx) => {
  const rows = await ctx.db.query(
    `SELECT t.id, t.name, t.created_at,
       (SELECT COUNT(*) FROM team_members m WHERE m.team_id = t.id) AS members,
       (SELECT COUNT(*) FROM projects p WHERE p.team_id = t.id AND p.deleted_at IS NULL) AS projects
       FROM teams t ORDER BY t.created_at DESC LIMIT 200`);
  return { teams: rows.map(r => ({ id: r.id, name: r.name, createdAt: Number(r.created_at), members: Number(r.members), projects: Number(r.projects) })) };
});

route('GET', '/admin/audit', { auth: 'admin' }, async (ctx) => {
  const q = ctx.query;
  const limit = v.int(q.limit ?? 50, { field: 'limit', min: 1, max: 200 });
  const params = [];
  const where = [];
  if (q.before) { params.push(v.int(q.before, { field: 'before', min: 0 })); where.push(`ts < $${params.length}`); }
  if (q.action) { params.push(v.str(q.action, { field: 'action', max: 40 }) + '%'); where.push(`action LIKE $${params.length}`); }
  const rows = await ctx.db.query(
    `SELECT id, ts, actor_email, action, target_type, target_id, meta, ip FROM audit_log ${where.length ? 'WHERE ' + where.join(' AND ') : ''} ORDER BY ts DESC LIMIT $${params.length + 1}`,
    [...params, limit],
  );
  return { events: rows.map(r => ({ id: r.id, ts: Number(r.ts), actor: r.actor_email, action: r.action, targetType: r.target_type, targetId: r.target_id, meta: r.meta ? safeParse(r.meta) : null, ip: r.ip })) };
});
const safeParse = (s) => { try { return JSON.parse(s); } catch { return null; } };

route('GET', '/admin/settings', { auth: 'admin' }, async () => ({ settings: await getSettings(true), defaults: DEFAULTS }));

route('PUT', '/admin/settings', { auth: 'admin' }, async (ctx) => {
  const b = v.obj(ctx.body);
  v.onlyKeys(b, Object.keys(RULES));
  const entries = [];
  for (const [k, val] of Object.entries(b)) {
    const r = RULES[k];
    let out;
    if (r.type === 'boolean') out = v.bool(val, k);
    else if (r.type === 'int') out = v.int(val, { field: k, min: r.min, max: r.max });
    else {
      out = v.str(val ?? '', { field: k, max: r.max, required: false }) ?? '';
      if (k === 'contactEmail' && out) v.email(out);
      if (k === 'contactPhone' && out && !/^\+?[\d\s().-]{5,40}$/.test(out)) throw bad('Enter a valid phone number, for example +20 11 54390240', k);
    }
    entries.push([k, out]);
  }
  const now = Date.now();
  for (const [k, val] of entries) {
    await ctx.db.query(
      'INSERT INTO settings (k, v, updated_at, updated_by) VALUES ($1,$2,$3,$4) ON CONFLICT (k) DO UPDATE SET v = excluded.v, updated_at = excluded.updated_at, updated_by = excluded.updated_by',
      [k, JSON.stringify(val), now, ctx.user.id],
    );
  }
  invalidateSettings();
  await audit(ctx, 'admin.settings_update', { meta: Object.fromEntries(entries.filter(([k]) => k !== 'announcement')) });
  return { settings: await getSettings(true) };
});
