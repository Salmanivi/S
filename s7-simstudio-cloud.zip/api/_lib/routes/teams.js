import { route } from '../router.js';
import { HttpError, bad, forbidden, notFound } from '../http.js';
import { uid, randomToken, sha256 } from '../crypto.js';
import { rateLimit } from '../ratelimit.js';
import { audit } from '../audit.js';
import { getSettings } from '../settings.js';
import { teamsOf } from './auth.js';
import * as v from '../validate.js';

const RANK = { viewer: 1, editor: 2, admin: 3, owner: 4 };
const ROLES = ['owner', 'admin', 'editor', 'viewer'];
const DAY = 24 * 3600 * 1000;

async function myRole(db, teamId, userId) {
  return (await db.query('SELECT role FROM team_members WHERE team_id = $1 AND user_id = $2', [teamId, userId]))[0]?.role ?? null;
}
/** Caller must be a member (otherwise the team "does not exist"). Optionally requires a minimum role. */
async function requireRole(ctx, teamId, min = 'viewer') {
  const role = await myRole(ctx.db, teamId, ctx.user.id);
  if (!role) throw notFound('Team not found');
  if (RANK[role] < RANK[min]) throw forbidden('You do not have permission to do that in this team');
  return role;
}
/** Owners may manage everyone; admins may manage editors and viewers. */
const mayManage = (actor, target) => actor === 'owner' || (actor === 'admin' && RANK[target] <= RANK.editor);
const ownerCount = async (db, teamId) => Number((await db.query("SELECT COUNT(*) AS n FROM team_members WHERE team_id = $1 AND role = 'owner'", [teamId]))[0].n);

route('GET', '/teams', {}, async (ctx) => ({ teams: await teamsOf(ctx.db, ctx.user.id) }));

route('POST', '/teams', {}, async (ctx) => {
  await rateLimit(ctx, 'team-create', ctx.user.id, 10, 3600);
  const b = v.obj(ctx.body);
  v.onlyKeys(b, ['name']);
  const name = v.str(b.name, { field: 'team name', min: 2, max: 60 });
  const s = await getSettings();
  const owned = Number((await ctx.db.query("SELECT COUNT(*) AS n FROM team_members WHERE user_id = $1 AND role = 'owner'", [ctx.user.id]))[0].n);
  if (owned >= s.maxTeamsPerUser) throw new HttpError(409, 'quota_exceeded', `You can own up to ${s.maxTeamsPerUser} teams`);
  const id = uid(), now = Date.now();
  await ctx.db.tx(async t => {
    await t.query('INSERT INTO teams (id, name, created_by, created_at) VALUES ($1,$2,$3,$4)', [id, name, ctx.user.id, now]);
    await t.query("INSERT INTO team_members (team_id, user_id, role, joined_at) VALUES ($1,$2,'owner',$3)", [id, ctx.user.id, now]);
  });
  await audit(ctx, 'team.create', { targetType: 'team', targetId: id });
  ctx.status = 201;
  return { team: { id, name, role: 'owner', memberCount: 1, projectCount: 0 } };
});

route('GET', '/teams/:id', {}, async (ctx) => {
  const id = v.id(ctx.params.id);
  const role = await requireRole(ctx, id);
  const team = (await ctx.db.query('SELECT id, name, created_at FROM teams WHERE id = $1', [id]))[0];
  if (!team) throw notFound('Team not found');
  const members = await ctx.db.query(
    'SELECT u.id, u.name, u.email, tm.role, tm.joined_at FROM team_members tm JOIN users u ON u.id = tm.user_id WHERE tm.team_id = $1 ORDER BY tm.joined_at',
    [id],
  );
  const admin = RANK[role] >= RANK.admin;
  const invites = admin ? await ctx.db.query(
    'SELECT id, role, created_at, expires_at, max_uses, uses FROM team_invites WHERE team_id = $1 AND revoked = 0 AND expires_at > $2 AND uses < max_uses ORDER BY created_at DESC',
    [id, Date.now()],
  ) : [];
  return {
    team: { id: team.id, name: team.name, createdAt: Number(team.created_at) },
    myRole: role,
    members: members.map(m => ({ id: m.id, name: m.name, email: admin || m.id === ctx.user.id ? m.email : null, role: m.role, joinedAt: Number(m.joined_at), me: m.id === ctx.user.id })),
    invites: invites.map(i => ({ id: i.id, role: i.role, createdAt: Number(i.created_at), expiresAt: Number(i.expires_at), maxUses: Number(i.max_uses), uses: Number(i.uses) })),
  };
});

route('PATCH', '/teams/:id', {}, async (ctx) => {
  const id = v.id(ctx.params.id);
  await requireRole(ctx, id, 'admin');
  const b = v.obj(ctx.body);
  v.onlyKeys(b, ['name']);
  await ctx.db.query('UPDATE teams SET name = $1 WHERE id = $2', [v.str(b.name, { field: 'team name', min: 2, max: 60 }), id]);
  await audit(ctx, 'team.rename', { targetType: 'team', targetId: id });
  return { ok: true };
});

route('DELETE', '/teams/:id', {}, async (ctx) => {
  const id = v.id(ctx.params.id);
  await requireRole(ctx, id, 'owner');
  const n = Number((await ctx.db.query('SELECT COUNT(*) AS n FROM projects WHERE team_id = $1', [id]))[0].n);
  if (n > 0 && ctx.query.deleteProjects !== '1') throw new HttpError(409, 'team_has_projects', `This team still has ${n} project(s). Deleting the team deletes them too.`, { count: n });
  await ctx.db.query('DELETE FROM teams WHERE id = $1', [id]);
  await audit(ctx, 'team.delete', { targetType: 'team', targetId: id, meta: { projects: n } });
  return { ok: true };
});

// ---- invites ------------------------------------------------------------------------------------
route('POST', '/teams/:id/invites', {}, async (ctx) => {
  const id = v.id(ctx.params.id);
  const mine = await requireRole(ctx, id, 'admin');
  await rateLimit(ctx, 'invite-create', ctx.user.id, 30, 3600);
  const b = v.obj(ctx.body);
  v.onlyKeys(b, ['role', 'days', 'maxUses']);
  const role = v.oneOf(b.role ?? 'editor', ['admin', 'editor', 'viewer'], 'role');
  if (!mayManage(mine, role)) throw forbidden('Only owners can invite admins');
  const days = v.int(b.days ?? 7, { field: 'days', min: 1, max: 30 });
  const maxUses = v.int(b.maxUses ?? 1, { field: 'maxUses', min: 1, max: 100 });
  const code = randomToken(18);
  const now = Date.now();
  const iid = uid();
  await ctx.db.query(
    'INSERT INTO team_invites (id, team_id, code_hash, role, created_by, created_at, expires_at, max_uses, uses, revoked) VALUES ($1,$2,$3,$4,$5,$6,$7,$8,0,0)',
    [iid, id, sha256(code), role, ctx.user.id, now, now + days * DAY, maxUses],
  );
  await audit(ctx, 'team.invite_create', { targetType: 'team', targetId: id, meta: { role, days, maxUses } });
  ctx.status = 201;
  return { invite: { id: iid, role, expiresAt: now + days * DAY, maxUses, uses: 0 }, code };   // the code is shown once and never stored
});

route('DELETE', '/teams/:id/invites/:iid', {}, async (ctx) => {
  const id = v.id(ctx.params.id);
  await requireRole(ctx, id, 'admin');
  const rows = await ctx.db.query('UPDATE team_invites SET revoked = 1 WHERE id = $1 AND team_id = $2 RETURNING id', [v.id(ctx.params.iid, 'inviteId'), id]);
  if (!rows.length) throw notFound('Invite not found');
  return { ok: true };
});

async function findInvite(ctx, code, { allowMember = false } = {}) {
  const c = v.str(code, { field: 'code', min: 10, max: 100 });
  const r = (await ctx.db.query(
    `SELECT i.id, i.team_id, i.role, i.expires_at, i.max_uses, i.uses, i.revoked, t.name AS team_name
       FROM team_invites i JOIN teams t ON t.id = i.team_id WHERE i.code_hash = $1`, [sha256(c)]))[0];
  const gone = () => new HttpError(404, 'invalid_invite', 'This invite link is invalid or has expired');
  if (!r || r.revoked || Number(r.expires_at) < Date.now()) throw gone();
  r.member = !!(await myRole(ctx.db, r.team_id, ctx.user.id));
  // someone who already joined through this link may open it again, even when it has been used up
  if (Number(r.uses) >= Number(r.max_uses) && !(allowMember && r.member)) throw gone();
  return r;
}

route('GET', '/invites/:code', {}, async (ctx) => {
  await rateLimit(ctx, 'invite-look', ctx.user.id, 60, 600);
  const i = await findInvite(ctx, ctx.params.code, { allowMember: true });
  return { team: { id: i.team_id, name: i.team_name }, role: i.role, alreadyMember: i.member };
});

route('POST', '/invites/accept', {}, async (ctx) => {
  await rateLimit(ctx, 'invite-accept', ctx.user.id, 20, 600);
  const i = await findInvite(ctx, v.obj(ctx.body).code, { allowMember: true });
  if (i.member) return { team: { id: i.team_id, name: i.team_name }, alreadyMember: true };
  const s = await getSettings();
  const n = Number((await ctx.db.query('SELECT COUNT(*) AS n FROM team_members WHERE team_id = $1', [i.team_id]))[0].n);
  if (n >= s.maxMembersPerTeam) throw new HttpError(409, 'team_full', 'This team has reached its member limit');
  const joined = await ctx.db.tx(async t => {
    // consuming the invite is atomic: two people cannot both use the last slot
    const used = await t.query('UPDATE team_invites SET uses = uses + 1 WHERE id = $1 AND revoked = 0 AND expires_at > $2 AND uses < max_uses RETURNING id', [i.id, Date.now()]);
    if (!used.length) return false;
    await t.query('INSERT INTO team_members (team_id, user_id, role, joined_at) VALUES ($1,$2,$3,$4) ON CONFLICT (team_id, user_id) DO NOTHING', [i.team_id, ctx.user.id, i.role, Date.now()]);
    return true;
  });
  if (!joined) throw new HttpError(404, 'invalid_invite', 'This invite link is invalid or has expired');
  await audit(ctx, 'team.join', { targetType: 'team', targetId: i.team_id, meta: { role: i.role } });
  ctx.status = 201;
  return { team: { id: i.team_id, name: i.team_name }, role: i.role, alreadyMember: false };
});

// ---- members ------------------------------------------------------------------------------------
route('PATCH', '/teams/:id/members/:uid', {}, async (ctx) => {
  const id = v.id(ctx.params.id);
  const mine = await requireRole(ctx, id, 'admin');
  const target = v.id(ctx.params.uid, 'userId');
  if (target === ctx.user.id) throw bad('You cannot change your own role');
  const b = v.obj(ctx.body);
  v.onlyKeys(b, ['role']);
  const role = v.oneOf(b.role, ROLES, 'role');
  const cur = await myRole(ctx.db, id, target);
  if (!cur) throw notFound('Member not found');
  if (!mayManage(mine, cur) || !mayManage(mine, role)) throw forbidden('You cannot assign or change that role');
  if (cur === 'owner' && role !== 'owner' && (await ownerCount(ctx.db, id)) <= 1) throw new HttpError(409, 'last_owner', 'A team needs at least one owner');
  await ctx.db.query('UPDATE team_members SET role = $1 WHERE team_id = $2 AND user_id = $3', [role, id, target]);
  await audit(ctx, 'team.role_change', { targetType: 'team', targetId: id, meta: { user: target, from: cur, to: role } });
  return { ok: true };
});

route('DELETE', '/teams/:id/members/:uid', {}, async (ctx) => {
  const id = v.id(ctx.params.id);
  const mine = await requireRole(ctx, id);
  const target = v.id(ctx.params.uid, 'userId');
  const cur = await myRole(ctx.db, id, target);
  if (!cur) throw notFound('Member not found');
  if (target !== ctx.user.id && !mayManage(mine, cur)) throw forbidden('You cannot remove this member');
  if (cur === 'owner' && (await ownerCount(ctx.db, id)) <= 1) throw new HttpError(409, 'last_owner', 'A team needs at least one owner. Make someone else an owner first, or delete the team.');
  await ctx.db.query('DELETE FROM team_members WHERE team_id = $1 AND user_id = $2', [id, target]);
  await audit(ctx, target === ctx.user.id ? 'team.leave' : 'team.member_remove', { targetType: 'team', targetId: id, meta: { user: target } });
  return { ok: true };
});
