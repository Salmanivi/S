import { mailProvider, APP_NAME } from './env.js';

const esc = (s) => String(s).replace(/[&<>"']/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));

/**
 * Sends one transactional e-mail through Resend or Brevo (plain HTTPS APIs, no extra packages).
 * Returns true when the provider accepted the message. Never throws.
 */
export async function sendMail({ to, subject, text, html }) {
  const provider = mailProvider();
  if (!provider) return false;
  const from = process.env.MAIL_FROM;
  try {
    let r;
    if (provider === 'resend') {
      r = await fetch('https://api.resend.com/emails', {
        method: 'POST',
        headers: { Authorization: `Bearer ${process.env.RESEND_API_KEY}`, 'Content-Type': 'application/json' },
        body: JSON.stringify({ from, to: [to], subject, text, html }),
      });
    } else {
      const m = /^(.*)<([^>]+)>\s*$/.exec(from);
      const sender = m ? { name: m[1].trim().replace(/^"|"$/g, '') || APP_NAME, email: m[2].trim() } : { name: APP_NAME, email: from.trim() };
      r = await fetch('https://api.brevo.com/v3/smtp/email', {
        method: 'POST',
        headers: { 'api-key': process.env.BREVO_API_KEY, 'Content-Type': 'application/json', accept: 'application/json' },
        body: JSON.stringify({ sender, to: [{ email: to }], subject, textContent: text, htmlContent: html }),
      });
    }
    if (!r.ok) console.error('[mail] provider responded', provider, r.status);
    return r.ok;
  } catch (e) {
    console.error('[mail] send failed', e.message);
    return false;
  }
}

const wrap = (title, bodyHtml) => `<div style="font-family:system-ui,Segoe UI,Arial,sans-serif;max-width:480px;margin:auto;padding:24px;color:#1b2733">
<h2 style="margin:0 0 16px">${esc(title)}</h2>${bodyHtml}
<p style="color:#6b7a89;font-size:12px;margin-top:28px">${esc(APP_NAME)} · If you did not request this, you can ignore this message.</p></div>`;

export const resetMail = (name, link) => ({
  subject: `Reset your ${APP_NAME} password`,
  text: `Hi ${name},\n\nUse this link to choose a new password (valid for 1 hour):\n${link}\n\nIf you did not request this, ignore this message.`,
  html: wrap('Reset your password', `<p>Hi ${esc(name)},</p><p>Use the button below to choose a new password. The link is valid for 1 hour.</p>
<p><a href="${esc(link)}" style="display:inline-block;background:#0f9488;color:#fff;padding:10px 18px;border-radius:8px;text-decoration:none">Choose a new password</a></p>
<p style="font-size:12px;color:#6b7a89;word-break:break-all">${esc(link)}</p>`),
});

export const verifyMail = (name, link) => ({
  subject: `Confirm your email for ${APP_NAME}`,
  text: `Hi ${name},\n\nConfirm your email address with this link (valid for 24 hours):\n${link}`,
  html: wrap('Confirm your email', `<p>Hi ${esc(name)},</p><p>Please confirm your email address. The link is valid for 24 hours.</p>
<p><a href="${esc(link)}" style="display:inline-block;background:#0f9488;color:#fff;padding:10px 18px;border-radius:8px;text-decoration:none">Confirm email</a></p>
<p style="font-size:12px;color:#6b7a89;word-break:break-all">${esc(link)}</p>`),
});
