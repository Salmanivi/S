import { MIGRATIONS } from './migrations.js';

/** Applies every migration that has not been recorded yet. Safe to run many times and from several instances at once. */
export async function migrate(driver) {
  await driver.exec('CREATE TABLE IF NOT EXISTS schema_migrations (version TEXT PRIMARY KEY, applied_at BIGINT NOT NULL)');
  const done = new Set((await driver.query('SELECT version FROM schema_migrations')).map(r => r.version));
  const applied = [];
  for (const m of MIGRATIONS) {
    if (done.has(m.version)) continue;
    await driver.tx(async t => {
      await t.exec(m.sql);
      await t.query('INSERT INTO schema_migrations (version, applied_at) VALUES ($1, $2) ON CONFLICT (version) DO NOTHING', [m.version, Date.now()]);
    });
    applied.push(m.version);
  }
  return applied;
}

/** One SQL file with everything (for pasting into a database console). */
export function fullSchemaSql() {
  const parts = ['-- S7 SimStudio database schema (generated from api/_lib/migrations.js)', 'CREATE TABLE IF NOT EXISTS schema_migrations (version TEXT PRIMARY KEY, applied_at BIGINT NOT NULL);'];
  for (const m of MIGRATIONS) {
    parts.push(`-- migration ${m.version}`, m.sql.trim());
    parts.push(`INSERT INTO schema_migrations (version, applied_at) VALUES ('${m.version}', ${Date.now()}) ON CONFLICT (version) DO NOTHING;`);
  }
  return parts.join('\n\n') + '\n';
}
