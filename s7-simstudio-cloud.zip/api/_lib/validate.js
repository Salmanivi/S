import { bad } from './http.js';

const UUID = /^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/i;
const EMAIL = /^[^\s@<>()[\]\\,;:"]+@[^\s@<>()[\]\\,;:"]+\.[A-Za-z]{2,}$/;
const CONTROL = /[\u0000-\u001f\u007f]/;

export const isObj = (x) => x !== null && typeof x === 'object' && !Array.isArray(x);

export function obj(x, field = 'body') {
  if (!isObj(x)) throw bad(`${field} must be a JSON object`, field);
  return x;
}
export function str(x, { field = 'value', min = 0, max = 200, required = true, multiline = false } = {}) {
  if (x === undefined || x === null || x === '') {
    if (required) throw bad(`${field} is required`, field);
    return undefined;
  }
  if (typeof x !== 'string') throw bad(`${field} must be text`, field);
  const s = x.trim();
  if (s.length < min) throw bad(`${field} must be at least ${min} characters`, field);
  if (s.length > max) throw bad(`${field} must be at most ${max} characters`, field);
  if (!multiline && CONTROL.test(s)) throw bad(`${field} contains invalid characters`, field);
  return s;
}
export function email(x) {
  const s = str(x, { field: 'email', min: 3, max: 254 });
  if (!EMAIL.test(s)) throw bad('Enter a valid email address', 'email');
  return s;
}
export function id(x, field = 'id') {
  if (typeof x !== 'string' || !UUID.test(x)) throw bad(`${field} is not valid`, field);
  return x.toLowerCase();
}
export function int(x, { field = 'value', min = -Infinity, max = Infinity, required = true } = {}) {
  if (x === undefined || x === null || x === '') { if (required) throw bad(`${field} is required`, field); return undefined; }
  const n = typeof x === 'string' && /^-?\d+$/.test(x) ? Number(x) : x;
  if (!Number.isInteger(n) || n < min || n > max) throw bad(`${field} must be a whole number between ${min} and ${max}`, field);
  return n;
}
export function oneOf(x, list, field = 'value') {
  if (!list.includes(x)) throw bad(`${field} must be one of: ${list.join(', ')}`, field);
  return x;
}
export function bool(x, field = 'value') {
  if (typeof x !== 'boolean') throw bad(`${field} must be true or false`, field);
  return x;
}
/** Only the listed keys are allowed in an object. */
export function onlyKeys(o, keys) {
  for (const k of Object.keys(o)) if (!keys.includes(k)) throw bad(`Unknown field: ${k.slice(0, 40)}`, k.slice(0, 40));
}

const FORBIDDEN = new Set(['__proto__', 'constructor', 'prototype']);

/**
 * Validates the shape of a PLC project document. The server never executes it, but it is loaded by browsers of
 * other users (team sharing), so it must be well-formed and free of prototype-pollution keys and absurd nesting.
 */
export function checkProjectData(data, maxBytes) {
  if (!isObj(data)) throw bad('Project data must be an object', 'data');
  if (!Array.isArray(data.blocks) || !isObj(data.hardware) || !Array.isArray(data.tags)) throw bad('This does not look like an S7 SimStudio project', 'data');
  if (typeof data.hardware.cpuId !== 'string' || data.hardware.cpuId.length > 80) throw bad('Project hardware is not valid', 'data');
  let nodes = 0;
  const walk = (v, depth) => {
    if (++nodes > 400_000) throw bad('The project is too complex', 'data');
    if (depth > 60) throw bad('The project is nested too deeply', 'data');
    if (Array.isArray(v)) { for (const x of v) walk(x, depth + 1); return; }
    if (isObj(v)) {
      for (const k of Object.keys(v)) {
        if (FORBIDDEN.has(k)) throw bad('The project contains a forbidden key', 'data');
        walk(v[k], depth + 1);
      }
      return;
    }
    if (typeof v === 'string' && v.length > 20_000) throw bad('A text value in the project is too long', 'data');
  };
  walk(data, 0);
  const text = JSON.stringify(data);
  const size = Buffer.byteLength(text, 'utf8');
  if (size > maxBytes) throw bad(`The project is too large (${Math.round(size / 1024)} KB, limit ${Math.round(maxBytes / 1024)} KB)`, 'data');
  return { text, size };
}
