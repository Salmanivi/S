import { HttpError, send, readJson, newRequestId, clientIp, notFound, unauthorized, forbidden } from './http.js';
import { getDb } from './db.js';
import { match } from './router.js';
import { loadSession } from './session.js';
import './routes/misc.js';
import './routes/auth.js';
import './routes/projects.js';
import './routes/teams.js';
import './routes/admin.js';

const SAFE = new Set(['GET', 'HEAD', 'OPTIONS']);

/** CSRF defence for cookie authentication: state-changing requests must come from this site. */
function checkOrigin(req) {
  if (SAFE.has(req.method)) return;
  const host = String(req.headers.host || '');
  const origin = req.headers.origin;
  if (origin) {
    let h;
    try { h = new URL(origin).host; } catch { throw forbidden('Cross-site request blocked', 'csrf'); }
    if (h !== host) throw forbidden('Cross-site request blocked', 'csrf');
    return;
  }
  if (req.headers['sec-fetch-site'] === 'same-origin') return;
  throw forbidden('Cross-site request blocked', 'csrf');
}

export default async function handler(req, res) {
  const requestId = newRequestId();
  res.setHeader('X-Request-Id', requestId);
  const cookies = [];
  const ctx = {
    req, res, requestId, ip: clientIp(req), ua: String(req.headers['user-agent'] || ''),
    db: null, user: null, sessionId: null, params: {}, query: {}, body: undefined, status: 200,
    setCookie: (c) => cookies.push(c),
  };
  try {
    const url = new URL(req.url || '/', 'http://localhost');
    let path = url.pathname.replace(/^\/api(?=\/|$)/, '') || '/';
    // Safety net: if the platform ever reports a rewritten URL, fall back to the catch-all segments it provides.
    if (!/^\/api(\/|$)/.test(url.pathname) && req.query && req.query.path) path = '/' + [].concat(req.query.path).map(String).join('/');
    ctx.query = Object.fromEntries(url.searchParams);
    ctx.url = url;

    const m = match(req.method, path);
    if (!m) throw notFound('Unknown API route');
    if (m.methodNotAllowed) {
      res.setHeader('Allow', m.allow.join(', '));
      throw new HttpError(405, 'method_not_allowed', 'Method not allowed');
    }
    checkOrigin(req);
    ctx.params = m.params;
    ctx.body = await readJson(req, m.route.opts.maxBody);
    if (m.route.opts.db !== false) ctx.db = await getDb();

    if (m.route.opts.auth === 'user' || m.route.opts.auth === 'admin') {
      const s = await loadSession(ctx);
      if (!s) throw unauthorized();
      ctx.user = s.user;
      ctx.sessionId = s.sessionId;
      if (m.route.opts.auth === 'admin' && s.user.role !== 'admin') throw forbidden('Administrators only');
    }
    const out = await m.route.handler(ctx);
    if (cookies.length) res.setHeader('Set-Cookie', cookies);
    send(res, ctx.status, out === undefined ? { ok: true } : out);
  } catch (e) {
    if (cookies.length) res.setHeader('Set-Cookie', cookies);
    if (e instanceof HttpError) {
      const headers = e.details?.retryAfter ? { 'Retry-After': String(e.details.retryAfter) } : {};
      send(res, e.status, { error: { code: e.code, message: e.message, details: e.details, requestId } }, headers);
      return;
    }
    console.error(`[api] ${requestId} ${req.method} ${req.url} failed:`, e && e.stack ? e.stack : e);
    send(res, 500, { error: { code: 'server_error', message: 'Something went wrong on the server', requestId } });
  }
}
