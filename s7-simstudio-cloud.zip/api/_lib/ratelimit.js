import { tooMany } from './http.js';
import { hmac } from './crypto.js';
import { appSecret } from './env.js';

/**
 * Fixed-window counter stored in the database, so the limit holds across serverless instances.
 * Throws a 429 when `limit` hits within `windowSec` are exceeded.
 */
export async function rateLimit(ctx, name, subject, limit, windowSec) {
  const bucket = `${name}:${hmac(appSecret(), subject)}`;
  const now = Date.now();
  const windowStart = now - windowSec * 1000;
  const rows = await ctx.db.query(
    `INSERT INTO rate_limits (bucket, window_start, hits) VALUES ($1, $2, 1)
     ON CONFLICT (bucket) DO UPDATE SET
       hits = CASE WHEN rate_limits.window_start < $3 THEN 1 ELSE rate_limits.hits + 1 END,
       window_start = CASE WHEN rate_limits.window_start < $3 THEN $2 ELSE rate_limits.window_start END
     RETURNING hits, window_start`,
    [bucket, now, windowStart],
  );
  const hits = Number(rows[0]?.hits ?? 1);
  if (hits > limit) {
    const retry = Math.max(1, Math.ceil((Number(rows[0].window_start) + windowSec * 1000 - now) / 1000));
    throw tooMany(retry);
  }
}
