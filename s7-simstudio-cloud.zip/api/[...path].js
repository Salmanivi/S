// Single serverless function that serves the whole API (keeps the project inside Vercel's free-plan function limit).
import handler from './_lib/handler.js';
export default handler;
