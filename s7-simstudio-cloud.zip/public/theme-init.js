// Applies the saved theme before the first paint (light is the default). Kept as a separate file so the
// Content-Security-Policy can forbid inline scripts.
try {
  var ui = JSON.parse(localStorage.getItem('s7sim.ui.v2') || 'null');
  if (ui && ui.theme === 'dark') {
    document.documentElement.className = 'dark';
    var m = document.querySelector('meta[name=theme-color]');
    if (m) m.setAttribute('content', '#0d1218');
  }
} catch (e) { /* storage unavailable: keep the default */ }
