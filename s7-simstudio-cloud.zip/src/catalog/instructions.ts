import type { DataType } from '../types';

export type Shape = 'contact' | 'coil' | 'box' | 'cmp';
export type PinKind = 'bool' | 'num' | 'time' | 'any' | 'real' | 'int' | 'block';

export interface PinDef { name: string; dir: 'in' | 'out'; kind: PinKind; typed?: boolean; typed2?: boolean; optional?: boolean; def?: string }

export interface InstrDef {
  op: string;
  label: string;
  category: string;
  shape: Shape;
  title: string;
  desc: string;
  symbol?: string;
  operand?: boolean;
  powerIn?: string;
  powerOut?: string;
  pins: PinDef[];
  types?: DataType[];
  defType?: DataType;
  types2?: DataType[];
  defType2?: DataType;
  instance?: 'timer' | 'counter';
  keywords?: string;
}

const NUM: DataType[] = ['Int', 'DInt', 'Real', 'SInt', 'USInt', 'UInt', 'UDInt'];
const CMP: DataType[] = ['Int', 'DInt', 'Real', 'SInt', 'USInt', 'UInt', 'UDInt', 'Byte', 'Word', 'DWord', 'Time'];
const ALLT: DataType[] = ['Int', 'DInt', 'Real', 'Bool', 'Byte', 'Word', 'DWord', 'SInt', 'USInt', 'UInt', 'UDInt', 'Time'];
const BITS: DataType[] = ['Word', 'Byte', 'DWord'];
const CNT: DataType[] = ['Int', 'DInt', 'SInt', 'UInt', 'USInt', 'UDInt'];

const pin = (name: string, dir: 'in' | 'out', kind: PinKind, extra: Partial<PinDef> = {}): PinDef => ({ name, dir, kind, ...extra });

export const INSTRUCTIONS: InstrDef[] = [
  // ---------------- Bit logic
  { op: 'NO', label: 'Normally open', category: 'Bit logic operations', shape: 'contact', title: '', symbol: '', operand: true, pins: [], desc: 'Passes power flow when the operand signal state is "1".', keywords: 'contact open' },
  { op: 'NC', label: 'Normally closed', category: 'Bit logic operations', shape: 'contact', title: '', symbol: '/', operand: true, pins: [], desc: 'Passes power flow when the operand signal state is "0".', keywords: 'contact closed not' },
  { op: 'NOT', label: 'Invert RLO', category: 'Bit logic operations', shape: 'contact', title: '', symbol: 'NOT', pins: [], desc: 'Inverts the result of logic operation (RLO).' },
  { op: 'P', label: 'Scan positive edge', category: 'Bit logic operations', shape: 'contact', title: '', symbol: 'P', operand: true, pins: [pin('M_BIT', 'in', 'bool', { optional: true })], desc: 'Power flow for one cycle when the operand changes 0 → 1. Edge memory bit stores the previous state.', keywords: 'rising edge' },
  { op: 'N', label: 'Scan negative edge', category: 'Bit logic operations', shape: 'contact', title: '', symbol: 'N', operand: true, pins: [pin('M_BIT', 'in', 'bool', { optional: true })], desc: 'Power flow for one cycle when the operand changes 1 → 0.', keywords: 'falling edge' },
  { op: 'OUT', label: 'Assignment', category: 'Bit logic operations', shape: 'coil', title: '', symbol: '', operand: true, pins: [], desc: 'Writes the RLO to the operand.', keywords: 'coil output' },
  { op: 'NEG', label: 'Negate assignment', category: 'Bit logic operations', shape: 'coil', title: '', symbol: '/', operand: true, pins: [], desc: 'Writes the inverted RLO to the operand.' },
  { op: 'SET', label: 'Set output', category: 'Bit logic operations', shape: 'coil', title: '', symbol: 'S', operand: true, pins: [], desc: 'Sets the operand to "1" when RLO is "1" (latching).', keywords: 'latch' },
  { op: 'RESET', label: 'Reset output', category: 'Bit logic operations', shape: 'coil', title: '', symbol: 'R', operand: true, pins: [], desc: 'Resets the operand to "0" when RLO is "1".', keywords: 'unlatch' },
  { op: 'SET_BF', label: 'Set bit field', category: 'Bit logic operations', shape: 'coil', title: '', symbol: 'SET_BF', operand: true, pins: [pin('N', 'in', 'int', { def: '8' })], desc: 'Sets N bits starting at the operand address.' },
  { op: 'RESET_BF', label: 'Reset bit field', category: 'Bit logic operations', shape: 'coil', title: '', symbol: 'RESET_BF', operand: true, pins: [pin('N', 'in', 'int', { def: '8' })], desc: 'Resets N bits starting at the operand address.' },
  { op: 'PCOIL', label: 'Set on positive edge', category: 'Bit logic operations', shape: 'coil', title: '', symbol: 'P', operand: true, pins: [pin('M_BIT', 'in', 'bool', { optional: true })], desc: 'Sets the operand for one cycle on a positive RLO edge.' },
  { op: 'NCOIL', label: 'Set on negative edge', category: 'Bit logic operations', shape: 'coil', title: '', symbol: 'N', operand: true, pins: [pin('M_BIT', 'in', 'bool', { optional: true })], desc: 'Sets the operand for one cycle on a negative RLO edge.' },
  { op: 'SR', label: 'Set/reset flip-flop', category: 'Bit logic operations', shape: 'box', title: 'SR', operand: true, powerIn: 'S', powerOut: 'Q', pins: [pin('R1', 'in', 'bool')], desc: 'Reset-dominant flip-flop. Operand holds the state.' },
  { op: 'RS', label: 'Reset/set flip-flop', category: 'Bit logic operations', shape: 'box', title: 'RS', operand: true, powerIn: 'R', powerOut: 'Q', pins: [pin('S1', 'in', 'bool')], desc: 'Set-dominant flip-flop. Operand holds the state.' },
  { op: 'P_TRIG', label: 'Scan RLO for positive edge', category: 'Bit logic operations', shape: 'box', title: 'P_TRIG', powerIn: 'CLK', powerOut: 'Q', pins: [pin('M_BIT', 'in', 'bool', { optional: true })], desc: 'Q is "1" for one cycle on a rising RLO.' },
  { op: 'N_TRIG', label: 'Scan RLO for negative edge', category: 'Bit logic operations', shape: 'box', title: 'N_TRIG', powerIn: 'CLK', powerOut: 'Q', pins: [pin('M_BIT', 'in', 'bool', { optional: true })], desc: 'Q is "1" for one cycle on a falling RLO.' },

  // ---------------- Timers
  { op: 'TP', label: 'Generate pulse', category: 'Timer operations', shape: 'box', title: 'TP', instance: 'timer', powerIn: 'IN', powerOut: 'Q', pins: [pin('PT', 'in', 'time', { def: 'T#2s' }), pin('ET', 'out', 'time', { optional: true })], desc: 'Generates a pulse of duration PT on a rising edge at IN.', keywords: 'timer pulse' },
  { op: 'TON', label: 'Generate on-delay', category: 'Timer operations', shape: 'box', title: 'TON', instance: 'timer', powerIn: 'IN', powerOut: 'Q', pins: [pin('PT', 'in', 'time', { def: 'T#5s' }), pin('ET', 'out', 'time', { optional: true })], desc: 'Q becomes "1" after IN has been "1" for the time PT.', keywords: 'timer delay on' },
  { op: 'TOF', label: 'Generate off-delay', category: 'Timer operations', shape: 'box', title: 'TOF', instance: 'timer', powerIn: 'IN', powerOut: 'Q', pins: [pin('PT', 'in', 'time', { def: 'T#5s' }), pin('ET', 'out', 'time', { optional: true })], desc: 'Q follows IN and resets after PT once IN goes "0".', keywords: 'timer delay off' },
  { op: 'TONR', label: 'Time accumulator', category: 'Timer operations', shape: 'box', title: 'TONR', instance: 'timer', powerIn: 'IN', powerOut: 'Q', pins: [pin('R', 'in', 'bool', { optional: true }), pin('PT', 'in', 'time', { def: 'T#10s' }), pin('ET', 'out', 'time', { optional: true })], desc: 'Accumulates time while IN is "1". R resets ET.', keywords: 'retentive timer' },
  { op: 'RT', label: 'Reset timer', category: 'Timer operations', shape: 'coil', title: '', symbol: 'RT', operand: true, pins: [], desc: 'Resets the IEC timer instance given as operand.' },

  // ---------------- Counters
  { op: 'CTU', label: 'Count up', category: 'Counter operations', shape: 'box', title: 'CTU', instance: 'counter', powerIn: 'CU', powerOut: 'Q', types: CNT, defType: 'Int', pins: [pin('R', 'in', 'bool', { optional: true }), pin('PV', 'in', 'num', { typed: true, def: '10' }), pin('CV', 'out', 'num', { typed: true, optional: true })], desc: 'CV increments on every rising edge at CU. Q = CV ≥ PV.' },
  { op: 'CTD', label: 'Count down', category: 'Counter operations', shape: 'box', title: 'CTD', instance: 'counter', powerIn: 'CD', powerOut: 'Q', types: CNT, defType: 'Int', pins: [pin('LD', 'in', 'bool', { optional: true }), pin('PV', 'in', 'num', { typed: true, def: '10' }), pin('CV', 'out', 'num', { typed: true, optional: true })], desc: 'CV decrements on every rising edge at CD. LD loads PV. Q = CV ≤ 0.' },
  { op: 'CTUD', label: 'Count up and down', category: 'Counter operations', shape: 'box', title: 'CTUD', instance: 'counter', powerIn: 'CU', powerOut: 'QU', types: CNT, defType: 'Int', pins: [pin('CD', 'in', 'bool', { optional: true }), pin('R', 'in', 'bool', { optional: true }), pin('LD', 'in', 'bool', { optional: true }), pin('PV', 'in', 'num', { typed: true, def: '10' }), pin('QD', 'out', 'bool', { optional: true }), pin('CV', 'out', 'num', { typed: true, optional: true })], desc: 'Up/down counter. QU = CV ≥ PV, QD = CV ≤ 0.' },

  // ---------------- Comparator
  ...([['EQ', '==', 'Equal'], ['NE', '<>', 'Not equal'], ['GE', '>=', 'Greater or equal'], ['LE', '<=', 'Less or equal'], ['GT', '>', 'Greater than'], ['LT', '<', 'Less than']] as const).map(([op, sym, label]): InstrDef => ({
    op: `CMP_${op}`, label: `${label} (CMP ${sym})`, category: 'Comparator operations', shape: 'cmp', title: sym, symbol: sym, types: CMP, defType: 'Int',
    pins: [pin('IN1', 'in', 'num', { typed: true }), pin('IN2', 'in', 'num', { typed: true })], desc: `Passes power flow when IN1 ${sym} IN2.`, keywords: 'compare',
  })),
  { op: 'IN_RANGE', label: 'Value within range', category: 'Comparator operations', shape: 'box', title: 'IN_RANGE', powerIn: '', powerOut: '', types: NUM, defType: 'Int', pins: [pin('MIN', 'in', 'num', { typed: true }), pin('VAL', 'in', 'num', { typed: true }), pin('MAX', 'in', 'num', { typed: true })], desc: 'Power flow if MIN ≤ VAL ≤ MAX.' },
  { op: 'OUT_RANGE', label: 'Value outside range', category: 'Comparator operations', shape: 'box', title: 'OUT_RANGE', powerIn: '', powerOut: '', types: NUM, defType: 'Int', pins: [pin('MIN', 'in', 'num', { typed: true }), pin('VAL', 'in', 'num', { typed: true }), pin('MAX', 'in', 'num', { typed: true })], desc: 'Power flow if VAL < MIN or VAL > MAX.' },

  // ---------------- Math
  ...([['ADD', 'Add', 'OUT := IN1 + IN2'], ['SUB', 'Subtract', 'OUT := IN1 - IN2'], ['MUL', 'Multiply', 'OUT := IN1 × IN2'], ['DIV', 'Divide', 'OUT := IN1 / IN2'], ['MOD', 'Return remainder of division', 'OUT := IN1 MOD IN2'], ['MIN', 'Get minimum', 'OUT := MIN(IN1, IN2)'], ['MAX', 'Get maximum', 'OUT := MAX(IN1, IN2)']] as const).map(([op, label, desc]): InstrDef => ({
    op, label, category: 'Math functions', shape: 'box', title: op, powerIn: 'EN', powerOut: 'ENO', types: op === 'MOD' ? CNT : NUM, defType: 'Int',
    pins: [pin('IN1', 'in', 'num', { typed: true }), pin('IN2', 'in', 'num', { typed: true }), pin('OUT', 'out', 'num', { typed: true })], desc,
  })),
  { op: 'NEG_M', label: 'Create twos complement', category: 'Math functions', shape: 'box', title: 'NEG', powerIn: 'EN', powerOut: 'ENO', types: ['Int', 'DInt', 'Real', 'SInt'], defType: 'Int', pins: [pin('IN', 'in', 'num', { typed: true }), pin('OUT', 'out', 'num', { typed: true })], desc: 'OUT := -IN' },
  { op: 'ABS', label: 'Form absolute value', category: 'Math functions', shape: 'box', title: 'ABS', powerIn: 'EN', powerOut: 'ENO', types: ['Int', 'DInt', 'Real', 'SInt'], defType: 'Int', pins: [pin('IN', 'in', 'num', { typed: true }), pin('OUT', 'out', 'num', { typed: true })], desc: 'OUT := |IN|' },
  { op: 'INC', label: 'Increment', category: 'Math functions', shape: 'box', title: 'INC', powerIn: 'EN', powerOut: 'ENO', types: CNT, defType: 'Int', pins: [pin('IN_OUT', 'in', 'num', { typed: true })], desc: 'IN_OUT := IN_OUT + 1 (each cycle while EN = 1 — use an edge!)' },
  { op: 'DEC', label: 'Decrement', category: 'Math functions', shape: 'box', title: 'DEC', powerIn: 'EN', powerOut: 'ENO', types: CNT, defType: 'Int', pins: [pin('IN_OUT', 'in', 'num', { typed: true })], desc: 'IN_OUT := IN_OUT - 1' },
  { op: 'LIMIT', label: 'Set limit value', category: 'Math functions', shape: 'box', title: 'LIMIT', powerIn: 'EN', powerOut: 'ENO', types: NUM, defType: 'Int', pins: [pin('MN', 'in', 'num', { typed: true }), pin('IN', 'in', 'num', { typed: true }), pin('MX', 'in', 'num', { typed: true }), pin('OUT', 'out', 'num', { typed: true })], desc: 'Limits IN to the range MN…MX.' },
  { op: 'SQRT', label: 'Form square root', category: 'Math functions', shape: 'box', title: 'SQRT', powerIn: 'EN', powerOut: 'ENO', types: ['Real'], defType: 'Real', pins: [pin('IN', 'in', 'real', { typed: true }), pin('OUT', 'out', 'real', { typed: true })], desc: 'OUT := √IN' },
  { op: 'SQR', label: 'Form square', category: 'Math functions', shape: 'box', title: 'SQR', powerIn: 'EN', powerOut: 'ENO', types: ['Real'], defType: 'Real', pins: [pin('IN', 'in', 'real', { typed: true }), pin('OUT', 'out', 'real', { typed: true })], desc: 'OUT := IN²' },

  // ---------------- Move
  { op: 'MOVE', label: 'Move value', category: 'Move operations', shape: 'box', title: 'MOVE', powerIn: 'EN', powerOut: 'ENO', types: ALLT, defType: 'Int', pins: [pin('IN', 'in', 'any', { typed: true }), pin('OUT1', 'out', 'any', { typed: true })], desc: 'Copies IN to OUT1.', keywords: 'mov copy' },
  { op: 'SWAP', label: 'Swap bytes', category: 'Move operations', shape: 'box', title: 'SWAP', powerIn: 'EN', powerOut: 'ENO', types: ['Word', 'DWord'], defType: 'Word', pins: [pin('IN', 'in', 'num', { typed: true }), pin('OUT', 'out', 'num', { typed: true })], desc: 'Reverses byte order.' },

  // ---------------- Conversion
  { op: 'CONV', label: 'Convert value', category: 'Conversion operations', shape: 'box', title: 'CONV', powerIn: 'EN', powerOut: 'ENO', types: NUM.concat(['Byte', 'Word', 'DWord']), defType: 'Int', types2: NUM.concat(['Byte', 'Word', 'DWord']), defType2: 'Real', pins: [pin('IN', 'in', 'num', { typed: true }), pin('OUT', 'out', 'num', { typed2: true })], desc: 'Converts IN from source type to destination type (Real → Int rounds).' },
  { op: 'ROUND', label: 'Round numerical value', category: 'Conversion operations', shape: 'box', title: 'ROUND', powerIn: 'EN', powerOut: 'ENO', types: ['DInt', 'Int'], defType: 'DInt', pins: [pin('IN', 'in', 'real'), pin('OUT', 'out', 'num', { typed: true })], desc: 'Rounds a Real to the nearest integer.' },
  { op: 'TRUNC', label: 'Truncate numerical value', category: 'Conversion operations', shape: 'box', title: 'TRUNC', powerIn: 'EN', powerOut: 'ENO', types: ['DInt', 'Int'], defType: 'DInt', pins: [pin('IN', 'in', 'real'), pin('OUT', 'out', 'num', { typed: true })], desc: 'Integer part of a Real.' },
  { op: 'CEIL', label: 'Generate next higher integer', category: 'Conversion operations', shape: 'box', title: 'CEIL', powerIn: 'EN', powerOut: 'ENO', types: ['DInt', 'Int'], defType: 'DInt', pins: [pin('IN', 'in', 'real'), pin('OUT', 'out', 'num', { typed: true })], desc: 'Next higher integer.' },
  { op: 'FLOOR', label: 'Generate next lower integer', category: 'Conversion operations', shape: 'box', title: 'FLOOR', powerIn: 'EN', powerOut: 'ENO', types: ['DInt', 'Int'], defType: 'DInt', pins: [pin('IN', 'in', 'real'), pin('OUT', 'out', 'num', { typed: true })], desc: 'Next lower integer.' },
  { op: 'NORM_X', label: 'Normalize', category: 'Conversion operations', shape: 'box', title: 'NORM_X', powerIn: 'EN', powerOut: 'ENO', types: ['Int', 'DInt', 'Real'], defType: 'Int', pins: [pin('MIN', 'in', 'num', { typed: true, def: '0' }), pin('VALUE', 'in', 'num', { typed: true }), pin('MAX', 'in', 'num', { typed: true, def: '27648' }), pin('OUT', 'out', 'real')], desc: 'OUT := (VALUE - MIN) / (MAX - MIN)  → Real 0.0…1.0', keywords: 'analog scale' },
  { op: 'SCALE_X', label: 'Scale', category: 'Conversion operations', shape: 'box', title: 'SCALE_X', powerIn: 'EN', powerOut: 'ENO', types: ['Real', 'Int', 'DInt'], defType: 'Real', pins: [pin('MIN', 'in', 'num', { typed: true, def: '0.0' }), pin('VALUE', 'in', 'real'), pin('MAX', 'in', 'num', { typed: true, def: '100.0' }), pin('OUT', 'out', 'num', { typed: true })], desc: 'OUT := VALUE × (MAX - MIN) + MIN', keywords: 'analog scale' },

  // ---------------- Word logic
  ...([['AND', 'AND logic operation'], ['OR', 'OR logic operation'], ['XOR', 'EXCLUSIVE OR logic operation']] as const).map(([op, label]): InstrDef => ({
    op: `W_${op}`, label, category: 'Word logic operations', shape: 'box', title: op, powerIn: 'EN', powerOut: 'ENO', types: BITS, defType: 'Word',
    pins: [pin('IN1', 'in', 'num', { typed: true }), pin('IN2', 'in', 'num', { typed: true }), pin('OUT', 'out', 'num', { typed: true })], desc: `Bitwise ${op}.`,
  })),
  { op: 'INV', label: 'Create ones complement', category: 'Word logic operations', shape: 'box', title: 'INV', powerIn: 'EN', powerOut: 'ENO', types: BITS, defType: 'Word', pins: [pin('IN', 'in', 'num', { typed: true }), pin('OUT', 'out', 'num', { typed: true })], desc: 'Inverts all bits.' },

  // ---------------- Shift & rotate
  ...([['SHL', 'Shift left'], ['SHR', 'Shift right'], ['ROL', 'Rotate left'], ['ROR', 'Rotate right']] as const).map(([op, label]): InstrDef => ({
    op, label, category: 'Shift and rotate', shape: 'box', title: op, powerIn: 'EN', powerOut: 'ENO', types: BITS, defType: 'Word',
    pins: [pin('IN', 'in', 'num', { typed: true }), pin('N', 'in', 'int', { def: '1' }), pin('OUT', 'out', 'num', { typed: true })], desc: `${label} IN by N bits.`,
  })),

  // ---------------- Program control
  { op: 'CALL', label: 'Call function (FC)', category: 'Program control operations', shape: 'box', title: 'CALL', powerIn: 'EN', powerOut: 'ENO', pins: [pin('BLOCK', 'in', 'block')], desc: 'Executes the networks of the selected FC block when EN = 1.', keywords: 'fc block call function' },
];

export const INSTR_MAP: Record<string, InstrDef> = Object.fromEntries(INSTRUCTIONS.map(d => [d.op, d]));
export const CATEGORIES = Array.from(new Set(INSTRUCTIONS.map(d => d.category)));

export const FAVORITES = ['NO', 'NC', 'OUT', 'SET', 'RESET', 'TON', 'CTU', 'CMP_EQ', 'MOVE', 'ADD'];
