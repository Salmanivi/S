import type { HardwareConfig, IoStart } from '../types';
import { IO_BYTES } from '../plc/values';

export type Family = 'S7-300' | 'S7-400' | 'S7-1200' | 'S7-1500';
export type ModFamily = 'S7-300' | 'S7-400' | 'S7-1200' | 'S7-1500' | 'ET200SP';

export interface IOCount { di: number; dq: number; ai: number; aq: number }

export interface CpuDef {
  id: string;
  family: Family;
  sub: string;
  name: string;
  variant: string;
  article: string;
  firmware: string;
  workMem: string;
  loadMem: string;
  bitOpNs: number;
  onboard: IOCount;
  maxModules: number;
  interfaces: string;
  supply: string;
  extras: string[];
  modFamily: ModFamily;
  mBytes: number;
  safety?: boolean;
}

export type ModKind = 'DI' | 'DQ' | 'DIQ' | 'AI' | 'AQ' | 'AIQ' | 'CM' | 'CP' | 'PS' | 'TM';

export interface ModuleDef {
  id: string;
  fam: ModFamily;
  kind: ModKind;
  name: string;
  article: string;
  io: IOCount;
  desc: string;
  board?: boolean; // S7-1200 signal board (slot 1)
}

const io = (di = 0, dq = 0, ai = 0, aq = 0): IOCount => ({ di, dq, ai, aq });

// ---------------------------------------------------------------- S7-1200
const c1200 = (
  model: string, variant: string, article: string, work: string, load: string,
  onboard: IOCount, maxMods: number, ports: number, extras: string[], safety = false
): CpuDef => ({
  id: `${model}-${variant}`.replace(/[^a-zA-Z0-9]/g, '_'),
  family: 'S7-1200', sub: safety ? 'Fail-safe (F)' : 'Standard', name: `CPU ${model}`, variant, article,
  firmware: 'V4.6', workMem: work, loadMem: load, bitOpNs: 85, onboard, maxModules: maxMods,
  interfaces: `PROFINET IO (${ports} port${ports > 1 ? 's' : ''}), 10/100 Mbit/s`,
  supply: variant.startsWith('AC') ? '85…264 V AC' : '20.4…28.8 V DC',
  extras: [
    ...extras,
    variant.endsWith('DC') ? 'Transistor outputs 24 V DC 0.5 A' : 'Relay outputs 2 A, 5…30 V DC / 5…250 V AC',
    variant.endsWith('DC') ? 'Pulse outputs (PTO/PWM): 4' : 'Pulse outputs only with SB',
  ],
  modFamily: 'S7-1200', mBytes: 8192, safety,
});

const S7_1200: CpuDef[] = [
  c1200('1211C', 'DC/DC/DC', '6ES7211-1AE40-0XB0', '50 KB', '1 MB', io(6, 4, 2), 0, 1, ['HSC: 6 (3×100 kHz)', '3 CM max, 1 SB']),
  c1200('1211C', 'AC/DC/Rly', '6ES7211-1BE40-0XB0', '50 KB', '1 MB', io(6, 4, 2), 0, 1, ['HSC: 6 (3×100 kHz)', '3 CM max, 1 SB']),
  c1200('1211C', 'DC/DC/Rly', '6ES7211-1HE40-0XB0', '50 KB', '1 MB', io(6, 4, 2), 0, 1, ['HSC: 6 (3×100 kHz)', '3 CM max, 1 SB']),
  c1200('1212C', 'DC/DC/DC', '6ES7212-1AE40-0XB0', '75 KB', '2 MB', io(8, 6, 2), 2, 1, ['HSC: 6 (3×100 kHz, 1×30 kHz)', '2 SM, 3 CM, 1 SB']),
  c1200('1212C', 'AC/DC/Rly', '6ES7212-1BE40-0XB0', '75 KB', '2 MB', io(8, 6, 2), 2, 1, ['HSC: 6', '2 SM, 3 CM, 1 SB']),
  c1200('1212C', 'DC/DC/Rly', '6ES7212-1HE40-0XB0', '75 KB', '2 MB', io(8, 6, 2), 2, 1, ['HSC: 6', '2 SM, 3 CM, 1 SB']),
  c1200('1214C', 'DC/DC/DC', '6ES7214-1AG40-0XB0', '100 KB', '4 MB', io(14, 10, 2), 8, 1, ['HSC: 6 (3×100 kHz, 3×30 kHz)', '8 SM, 3 CM, 1 SB']),
  c1200('1214C', 'AC/DC/Rly', '6ES7214-1BG40-0XB0', '100 KB', '4 MB', io(14, 10, 2), 8, 1, ['HSC: 6', '8 SM, 3 CM, 1 SB']),
  c1200('1214C', 'DC/DC/Rly', '6ES7214-1HG40-0XB0', '100 KB', '4 MB', io(14, 10, 2), 8, 1, ['HSC: 6', '8 SM, 3 CM, 1 SB']),
  c1200('1215C', 'DC/DC/DC', '6ES7215-1AG40-0XB0', '125 KB', '4 MB', io(14, 10, 2, 2), 8, 2, ['HSC: 6', 'Onboard AQ 2×0-20 mA', '8 SM, 3 CM, 1 SB']),
  c1200('1215C', 'AC/DC/Rly', '6ES7215-1BG40-0XB0', '125 KB', '4 MB', io(14, 10, 2, 2), 8, 2, ['HSC: 6', 'Onboard AQ 2×0-20 mA', '8 SM, 3 CM, 1 SB']),
  c1200('1215C', 'DC/DC/Rly', '6ES7215-1HG40-0XB0', '125 KB', '4 MB', io(14, 10, 2, 2), 8, 2, ['HSC: 6', 'Onboard AQ 2×0-20 mA', '8 SM, 3 CM, 1 SB']),
  c1200('1217C', 'DC/DC/DC', '6ES7217-1AG40-0XB0', '150 KB', '4 MB', io(14, 10, 2, 2), 8, 2, ['HSC: 6 (4×1 MHz differential)', 'PTO up to 1 MHz', '8 SM, 3 CM, 1 SB']),
  c1200('1212FC', 'DC/DC/DC', '6ES7212-1AF40-0XB0', '100 KB', '2 MB', io(8, 6, 2), 2, 1, ['Safety program (F-blocks)', 'SIL 3 / PL e'], true),
  c1200('1212FC', 'DC/DC/Rly', '6ES7212-1HF40-0XB0', '100 KB', '2 MB', io(8, 6, 2), 2, 1, ['Safety program (F-blocks)', 'SIL 3 / PL e'], true),
  c1200('1214FC', 'DC/DC/DC', '6ES7214-1AF40-0XB0', '125 KB', '4 MB', io(14, 10, 2), 8, 1, ['Safety program (F-blocks)', 'SIL 3 / PL e'], true),
  c1200('1214FC', 'DC/DC/Rly', '6ES7214-1HF40-0XB0', '125 KB', '4 MB', io(14, 10, 2), 8, 1, ['Safety program (F-blocks)', 'SIL 3 / PL e'], true),
  c1200('1215FC', 'DC/DC/DC', '6ES7215-1AF40-0XB0', '150 KB', '4 MB', io(14, 10, 2, 2), 8, 2, ['Safety program (F-blocks)', 'SIL 3 / PL e'], true),
];

// ---------------------------------------------------------------- S7-1500
const c1500 = (
  name: string, sub: string, article: string, prog: string, data: string, bitOp: number,
  interfaces: string, extras: string[], onboard: IOCount = io(), modFamily: ModFamily = 'S7-1500', safety = false
): CpuDef => ({
  id: name.replace(/[^a-zA-Z0-9]/g, '_'), family: 'S7-1500', sub, name, variant: '', article, firmware: 'V3.1',
  workMem: `${prog} program / ${data} data`, loadMem: 'SIMATIC Memory Card (up to 32 GB)', bitOpNs: bitOp,
  onboard, maxModules: modFamily === 'ET200SP' ? 64 : 31, interfaces, supply: '24 V DC (via PS / PM)',
  extras, modFamily, mBytes: 16384, safety,
});

const S7_1500: CpuDef[] = [
  c1500('CPU 1511-1 PN', 'Standard', '6ES7511-1AL03-0AB0', '150 KB', '1 MB', 60, 'PROFINET IO (X1: 2 ports)', ['Display 1.38"', 'Motion: 6 axes']),
  c1500('CPU 1513-1 PN', 'Standard', '6ES7513-1AM03-0AB0', '300 KB', '1.5 MB', 40, 'PROFINET IO (X1: 2 ports)', ['Display 3.45"', 'Motion: 10 axes']),
  c1500('CPU 1515-2 PN', 'Standard', '6ES7515-2AN03-0AB0', '500 KB', '3 MB', 30, 'PROFINET IO (X1: 2 ports), PROFINET (X2)', ['Display 3.45"', 'Motion: 30 axes']),
  c1500('CPU 1516-3 PN/DP', 'Standard', '6ES7516-3AP03-0AB0', '1 MB', '5 MB', 10, 'PROFINET X1/X2, PROFIBUS DP (X3)', ['Display 3.45"', 'Motion: 55 axes']),
  c1500('CPU 1517-3 PN/DP', 'Standard', '6ES7517-3AP00-0AB0', '2 MB', '8 MB', 2, 'PROFINET X1/X2, PROFIBUS DP (X3)', ['Display 3.45"', 'Motion: 128 axes']),
  c1500('CPU 1518-4 PN/DP', 'Standard', '6ES7518-4AP00-0AB0', '4 MB', '20 MB', 1, 'PROFINET X1/X2/X3, PROFIBUS DP (X4)', ['Display 3.45"', 'Motion: 128 axes']),
  c1500('CPU 1511C-1 PN', 'Compact', '6ES7511-1CL03-0AB0', '175 KB', '1 MB', 60, 'PROFINET IO (X1: 2 ports)', ['Onboard: AI5/AQ2 + DI16/DQ16', 'HSC: 6, PTO: 4'], io(16, 16, 5, 2)),
  c1500('CPU 1512C-1 PN', 'Compact', '6ES7512-1CM03-0AB0', '250 KB', '1 MB', 48, 'PROFINET IO (X1: 2 ports)', ['Onboard: AI5/AQ2 + DI32/DQ32', 'HSC: 6, PTO: 4'], io(32, 32, 5, 2)),
  c1500('CPU 1511F-1 PN', 'Fail-safe (F)', '6ES7511-1FL03-0AB0', '225 KB', '1 MB', 60, 'PROFINET IO (X1: 2 ports)', ['PROFIsafe', 'SIL 3 / PL e'], io(), 'S7-1500', true),
  c1500('CPU 1513F-1 PN', 'Fail-safe (F)', '6ES7513-1FM03-0AB0', '450 KB', '1.5 MB', 40, 'PROFINET IO (X1: 2 ports)', ['PROFIsafe', 'SIL 3 / PL e'], io(), 'S7-1500', true),
  c1500('CPU 1515F-2 PN', 'Fail-safe (F)', '6ES7515-2FN03-0AB0', '750 KB', '3 MB', 30, 'PROFINET X1/X2', ['PROFIsafe', 'SIL 3 / PL e'], io(), 'S7-1500', true),
  c1500('CPU 1516F-3 PN/DP', 'Fail-safe (F)', '6ES7516-3FP03-0AB0', '1.5 MB', '5 MB', 10, 'PROFINET X1/X2, DP X3', ['PROFIsafe', 'SIL 3 / PL e'], io(), 'S7-1500', true),
  c1500('CPU 1517F-3 PN/DP', 'Fail-safe (F)', '6ES7517-3FP00-0AB0', '3 MB', '8 MB', 2, 'PROFINET X1/X2, DP X3', ['PROFIsafe', 'SIL 3 / PL e'], io(), 'S7-1500', true),
  c1500('CPU 1518F-4 PN/DP', 'Fail-safe (F)', '6ES7518-4FP00-0AB0', '6 MB', '20 MB', 1, 'PROFINET X1/X2/X3, DP X4', ['PROFIsafe', 'SIL 3 / PL e'], io(), 'S7-1500', true),
  c1500('CPU 1511T-1 PN', 'Technology (T)', '6ES7511-1TL03-0AB0', '225 KB', '1 MB', 60, 'PROFINET IO (X1: 2 ports)', ['Gearing, Camming, Kinematics']),
  c1500('CPU 1515T-2 PN', 'Technology (T)', '6ES7515-2TN03-0AB0', '750 KB', '3 MB', 30, 'PROFINET X1/X2', ['Gearing, Camming, Kinematics']),
  c1500('CPU 1517T-3 PN/DP', 'Technology (T)', '6ES7517-3TP00-0AB0', '3 MB', '8 MB', 2, 'PROFINET X1/X2, DP X3', ['Gearing, Camming, Kinematics']),
  c1500('CPU 1510SP-1 PN', 'ET 200SP CPU', '6ES7510-1DK03-0AB0', '100 KB', '750 KB', 72, 'PROFINET IO (BusAdapter, 3 ports)', ['ET 200SP I/O modules', 'Distributed design'], io(), 'ET200SP'),
  c1500('CPU 1512SP-1 PN', 'ET 200SP CPU', '6ES7512-1DM03-0AB0', '200 KB', '1 MB', 48, 'PROFINET IO (BusAdapter, 3 ports)', ['ET 200SP I/O modules', 'Distributed design'], io(), 'ET200SP'),
];

// ---------------------------------------------------------------- S7-300
const c300 = (name: string, article: string, work: string, bitOp: number, interfaces: string, extras: string[], onboard: IOCount = io(), safety = false): CpuDef => ({
  id: name.replace(/[^a-zA-Z0-9]/g, '_'), family: 'S7-300', sub: onboard.di ? 'Compact (C)' : safety ? 'Fail-safe (F)' : 'Standard', name, variant: '', article,
  firmware: 'V3.3', workMem: work, loadMem: 'Micro Memory Card (up to 8 MB)', bitOpNs: bitOp, onboard, maxModules: 8,
  interfaces, supply: '24 V DC (PS 307)', extras, modFamily: 'S7-300', mBytes: 2048, safety,
});

const S7_300: CpuDef[] = [
  c300('CPU 312', '6ES7312-1AE14-0AB0', '32 KB', 100, 'MPI', ['1 rack, 8 SM']),
  c300('CPU 312C', '6ES7312-5BF04-0AB0', '64 KB', 100, 'MPI', ['Onboard DI10/DO6', 'Counters 2×10 kHz'], io(10, 6)),
  c300('CPU 313C', '6ES7313-5BG04-0AB0', '128 KB', 70, 'MPI', ['Onboard DI24/DO16/AI5/AO2', 'Counters 3×30 kHz'], io(24, 16, 5, 2)),
  c300('CPU 314', '6ES7314-1AG14-0AB0', '128 KB', 60, 'MPI', ['Up to 4 racks, 32 modules']),
  c300('CPU 314C-2 PN/DP', '6ES7314-6EH04-0AB0', '192 KB', 60, 'MPI/DP, PROFINET (2 ports)', ['Onboard DI24/DO16/AI5/AO2', 'Counters 4×60 kHz'], io(24, 16, 5, 2)),
  c300('CPU 315-2 DP', '6ES7315-2AH14-0AB0', '256 KB', 50, 'MPI, PROFIBUS DP', ['Up to 4 racks, 32 modules']),
  c300('CPU 315-2 PN/DP', '6ES7315-2EH14-0AB0', '384 KB', 50, 'MPI/DP, PROFINET (2 ports)', ['Web server', 'PN IO controller']),
  c300('CPU 317-2 PN/DP', '6ES7317-2EK14-0AB0', '1 MB', 25, 'MPI/DP, PROFINET (2 ports)', ['Web server', 'PN IO controller']),
  c300('CPU 319-3 PN/DP', '6ES7318-3EL01-0AB0', '2 MB', 4, 'MPI/DP, DP, PROFINET (2 ports)', ['Highest S7-300 performance']),
  c300('CPU 315F-2 PN/DP', '6ES7315-2FJ14-0AB0', '512 KB', 50, 'MPI/DP, PROFINET', ['Distributed Safety', 'SIL 3'], io(), true),
  c300('CPU 317F-2 PN/DP', '6ES7317-2FK14-0AB0', '1.5 MB', 25, 'MPI/DP, PROFINET', ['Distributed Safety', 'SIL 3'], io(), true),
];

// ---------------------------------------------------------------- S7-400
const c400 = (name: string, article: string, work: string, bitOp: number, interfaces: string, extras: string[]): CpuDef => ({
  id: name.replace(/[^a-zA-Z0-9]/g, '_'), family: 'S7-400', sub: name.includes('H') ? 'Redundant (H)' : 'Standard', name, variant: '', article,
  firmware: 'V7.0', workMem: work, loadMem: 'Memory Card (up to 64 MB)', bitOpNs: bitOp, onboard: io(), maxModules: 14,
  interfaces, supply: '120/230 V AC (PS 407)', extras, modFamily: 'S7-400', mBytes: 16384,
});

const S7_400: CpuDef[] = [
  c400('CPU 412-2 PN', '6ES7412-2EK07-0AB0', '1 MB', 31, 'MPI/DP, PROFINET (2 ports)', ['UR1/UR2 racks', 'Isochronous mode']),
  c400('CPU 414-3 PN/DP', '6ES7414-3EM07-0AB0', '4 MB', 18, 'MPI/DP, PROFINET, IF slot', ['Multicomputing', 'CiR (config in RUN)']),
  c400('CPU 416-3 PN/DP', '6ES7416-3ES07-0AB0', '16 MB', 12, 'MPI/DP, PROFINET, IF slot', ['Multicomputing', 'CiR (config in RUN)']),
  c400('CPU 417-4', '6ES7417-4XT05-0AB0', '32 MB', 18, 'MPI/DP, DP, 2 IF slots', ['Largest S7-400 memory']),
  c400('CPU 412-5H PN/DP', '6ES7412-5HK06-0AB0', '1 MB', 31, 'MPI/DP, DP, PN, 2 sync', ['High availability (H)', 'Redundant pair']),
  c400('CPU 416-5H PN/DP', '6ES7416-5HS06-0AB0', '16 MB', 12, 'MPI/DP, DP, PN, 2 sync', ['High availability (H)', 'Redundant pair']),
];

export const CPUS: CpuDef[] = [...S7_300, ...S7_400, ...S7_1200, ...S7_1500];
export const FAMILIES: Family[] = ['S7-300', 'S7-400', 'S7-1200', 'S7-1500'];

// ---------------------------------------------------------------- Modules
const m = (fam: ModFamily, kind: ModKind, name: string, article: string, iox: IOCount, desc: string, board = false): ModuleDef => ({
  id: `${fam}_${article}`, fam, kind, name, article, io: iox, desc, board,
});

export const MODULES: ModuleDef[] = [
  // S7-1200 signal boards
  m('S7-1200', 'DI', 'SB 1221 DI 4×24VDC', '6ES7221-3BD30-0XB0', io(4), 'Signal board, 200 kHz inputs', true),
  m('S7-1200', 'DQ', 'SB 1222 DQ 4×24VDC', '6ES7222-1BD30-0XB0', io(0, 4), 'Signal board, 200 kHz outputs', true),
  m('S7-1200', 'DIQ', 'SB 1223 DI 2/DQ 2×24VDC', '6ES7223-3BD30-0XB0', io(2, 2), 'Signal board, mixed digital', true),
  m('S7-1200', 'AI', 'SB 1231 AI 1×12bit', '6ES7231-4HA30-0XB0', io(0, 0, 1), 'Signal board, ±10V / 0-20mA', true),
  m('S7-1200', 'AQ', 'SB 1232 AQ 1×12bit', '6ES7232-4HA30-0XB0', io(0, 0, 0, 1), 'Signal board, ±10V / 0-20mA', true),
  // S7-1200 SM
  m('S7-1200', 'DI', 'SM 1221 DI 8×24VDC', '6ES7221-1BF32-0XB0', io(8), 'Sink/source inputs'),
  m('S7-1200', 'DI', 'SM 1221 DI 16×24VDC', '6ES7221-1BH32-0XB0', io(16), 'Sink/source inputs'),
  m('S7-1200', 'DQ', 'SM 1222 DQ 8×24VDC', '6ES7222-1BF32-0XB0', io(0, 8), 'Transistor 0.5 A'),
  m('S7-1200', 'DQ', 'SM 1222 DQ 8×Relay', '6ES7222-1HF32-0XB0', io(0, 8), 'Relay 2 A'),
  m('S7-1200', 'DQ', 'SM 1222 DQ 16×24VDC', '6ES7222-1BH32-0XB0', io(0, 16), 'Transistor 0.5 A'),
  m('S7-1200', 'DQ', 'SM 1222 DQ 16×Relay', '6ES7222-1HH32-0XB0', io(0, 16), 'Relay 2 A'),
  m('S7-1200', 'DIQ', 'SM 1223 DI 8/DQ 8×24VDC', '6ES7223-1BH32-0XB0', io(8, 8), 'Mixed digital'),
  m('S7-1200', 'DIQ', 'SM 1223 DI 16/DQ 16×24VDC', '6ES7223-1BL32-0XB0', io(16, 16), 'Mixed digital'),
  m('S7-1200', 'AI', 'SM 1231 AI 4×13bit', '6ES7231-4HD32-0XB0', io(0, 0, 4), '±10V, ±5V, 0-20mA, 4-20mA'),
  m('S7-1200', 'AI', 'SM 1231 AI 8×13bit', '6ES7231-4HF32-0XB0', io(0, 0, 8), '±10V, ±5V, 0-20mA, 4-20mA'),
  m('S7-1200', 'AI', 'SM 1231 RTD 4×16bit', '6ES7231-5PD32-0XB0', io(0, 0, 4), 'Pt100/Pt1000/Ni, value in 0.1 °C'),
  m('S7-1200', 'AI', 'SM 1231 TC 4×16bit', '6ES7231-5QD32-0XB0', io(0, 0, 4), 'Thermocouple J/K/T/E/R/S/N'),
  m('S7-1200', 'AQ', 'SM 1232 AQ 2×14bit', '6ES7232-4HB32-0XB0', io(0, 0, 0, 2), '±10V, 0-20mA'),
  m('S7-1200', 'AQ', 'SM 1232 AQ 4×14bit', '6ES7232-4HD32-0XB0', io(0, 0, 0, 4), '±10V, 0-20mA'),
  m('S7-1200', 'AIQ', 'SM 1234 AI 4/AQ 2', '6ES7234-4HE32-0XB0', io(0, 0, 4, 2), 'Mixed analog'),
  m('S7-1200', 'CM', 'CM 1241 RS422/485', '6ES7241-1CH32-0XB0', io(), 'Point-to-point, Modbus RTU'),
  m('S7-1200', 'CM', 'CM 1243-5 PROFIBUS DP', '6ES7243-5DX30-0XB0', io(), 'DP master'),
  m('S7-1200', 'CP', 'CP 1243-1', '6GK7243-1BX30-0XE0', io(), 'Ethernet with security'),
  // S7-1500
  m('S7-1500', 'PS', 'PS 60W 24/48/60VDC', '6ES7505-0RA00-0AB0', io(), 'System power supply (slot 0)'),
  m('S7-1500', 'DI', 'DI 16×24VDC BA', '6ES7521-1BH10-0AA0', io(16), 'Basic, 1 group'),
  m('S7-1500', 'DI', 'DI 16×24VDC HF', '6ES7521-1BH00-0AB0', io(16), 'High feature, diagnostics'),
  m('S7-1500', 'DI', 'DI 32×24VDC BA', '6ES7521-1BL10-0AA0', io(32), 'Basic'),
  m('S7-1500', 'DI', 'DI 32×24VDC HF', '6ES7521-1BL00-0AB0', io(32), 'High feature'),
  m('S7-1500', 'DI', 'DI 16×230VAC BA', '6ES7521-1FH00-0AA0', io(16), '230 V AC inputs'),
  m('S7-1500', 'DQ', 'DQ 16×24VDC/0.5A BA', '6ES7522-1BH10-0AA0', io(0, 16), 'Basic transistor'),
  m('S7-1500', 'DQ', 'DQ 32×24VDC/0.5A HF', '6ES7522-1BL01-0AB0', io(0, 32), 'High feature'),
  m('S7-1500', 'DQ', 'DQ 8×230VAC/5A ST Relay', '6ES7522-5HF00-0AB0', io(0, 8), 'Relay outputs'),
  m('S7-1500', 'DQ', 'DQ 16×230VAC/2A ST Relay', '6ES7522-5HH00-0AB0', io(0, 16), 'Relay outputs'),
  m('S7-1500', 'DIQ', 'DI 16/DQ 16×24VDC BA', '6ES7523-1BL00-0AA0', io(16, 16), 'Mixed digital'),
  m('S7-1500', 'AI', 'AI 8×U/I/RTD/TC ST', '6ES7531-7KF00-0AB0', io(0, 0, 8), 'Standard, 16 bit'),
  m('S7-1500', 'AI', 'AI 4×U/I/RTD/TC ST', '6ES7531-7QD00-0AB0', io(0, 0, 4), 'Standard, 16 bit'),
  m('S7-1500', 'AI', 'AI 8×U/I HS', '6ES7531-7NF10-0AB0', io(0, 0, 8), 'High speed 62.5 µs'),
  m('S7-1500', 'AQ', 'AQ 4×U/I ST', '6ES7532-5HD00-0AB0', io(0, 0, 0, 4), 'Standard, 16 bit'),
  m('S7-1500', 'AQ', 'AQ 2×U/I ST', '6ES7532-5NB00-0AB0', io(0, 0, 0, 2), 'Standard, 16 bit'),
  m('S7-1500', 'AQ', 'AQ 8×U/I HS', '6ES7532-5HF00-0AB0', io(0, 0, 0, 8), 'High speed'),
  m('S7-1500', 'AIQ', 'AI 4/AQ 2×U/I ST', '6ES7534-7QE00-0AB0', io(0, 0, 4, 2), 'Mixed analog'),
  m('S7-1500', 'TM', 'TM Count 2×24V', '6ES7550-1AA00-0AB0', io(), 'Technology counter 200 kHz'),
  m('S7-1500', 'CP', 'CP 1543-1', '6GK7543-1AX00-0XE0', io(), 'Industrial Ethernet, security'),
  m('S7-1500', 'CM', 'CM PtP RS422/485 HF', '6ES7541-1AB00-0AB0', io(), 'Modbus RTU / 3964(R)'),
  // ET 200SP
  m('ET200SP', 'DI', 'DI 8×24VDC ST', '6ES7131-6BF01-0BA0', io(8), 'ET 200SP standard'),
  m('ET200SP', 'DI', 'DI 16×24VDC ST', '6ES7131-6BH01-0BA0', io(16), 'ET 200SP standard'),
  m('ET200SP', 'DQ', 'DQ 8×24VDC/0.5A ST', '6ES7132-6BF01-0BA0', io(0, 8), 'ET 200SP standard'),
  m('ET200SP', 'DQ', 'DQ 16×24VDC/0.5A ST', '6ES7132-6BH01-0BA0', io(0, 16), 'ET 200SP standard'),
  m('ET200SP', 'AI', 'AI 4×I 2-/4-wire ST', '6ES7134-6GD01-0BA1', io(0, 0, 4), 'ET 200SP current input'),
  m('ET200SP', 'AI', 'AI 4×U/I 2-wire ST', '6ES7134-6HD01-0BA1', io(0, 0, 4), 'ET 200SP voltage/current'),
  m('ET200SP', 'AQ', 'AQ 4×U/I ST', '6ES7135-6HD00-0BA1', io(0, 0, 0, 4), 'ET 200SP analog output'),
  m('ET200SP', 'AQ', 'AQ 2×U/I ST', '6ES7135-6HB00-0BA1', io(0, 0, 0, 2), 'ET 200SP analog output'),
  // S7-300
  m('S7-300', 'PS', 'PS 307 5A', '6ES7307-1EA01-0AA0', io(), 'Load power supply 24 V DC (slot 1)'),
  m('S7-300', 'DI', 'SM 321 DI 16×24VDC', '6ES7321-1BH02-0AA0', io(16), 'Digital input'),
  m('S7-300', 'DI', 'SM 321 DI 32×24VDC', '6ES7321-1BL00-0AA0', io(32), 'Digital input'),
  m('S7-300', 'DQ', 'SM 322 DO 16×24VDC/0.5A', '6ES7322-1BH01-0AA0', io(0, 16), 'Digital output'),
  m('S7-300', 'DQ', 'SM 322 DO 32×24VDC/0.5A', '6ES7322-1BL00-0AA0', io(0, 32), 'Digital output'),
  m('S7-300', 'DQ', 'SM 322 DO 8×Rel. 230VAC', '6ES7322-1HF01-0AA0', io(0, 8), 'Relay output'),
  m('S7-300', 'DIQ', 'SM 323 DI 16/DO 16×24VDC', '6ES7323-1BL00-0AA0', io(16, 16), 'Mixed digital'),
  m('S7-300', 'AI', 'SM 331 AI 8×12bit', '6ES7331-7KF02-0AB0', io(0, 0, 8), 'U/I/R/RTD/TC'),
  m('S7-300', 'AI', 'SM 331 AI 2×12bit', '6ES7331-7KB02-0AB0', io(0, 0, 2), 'U/I/R/RTD/TC'),
  m('S7-300', 'AQ', 'SM 332 AO 4×12bit', '6ES7332-5HD01-0AB0', io(0, 0, 0, 4), 'U/I'),
  m('S7-300', 'AQ', 'SM 332 AO 2×12bit', '6ES7332-5HB01-0AB0', io(0, 0, 0, 2), 'U/I'),
  m('S7-300', 'AIQ', 'SM 334 AI 4/AO 2×8bit', '6ES7334-0KE00-0AB0', io(0, 0, 4, 2), 'Mixed analog'),
  m('S7-300', 'CP', 'CP 343-1 Lean', '6GK7343-1CX10-0XE0', io(), 'Industrial Ethernet'),
  m('S7-300', 'TM', 'FM 350-1 Counter', '6ES7350-1AH03-0AE0', io(), 'Counter 500 kHz'),
  // S7-400
  m('S7-400', 'PS', 'PS 407 10A', '6ES7407-0KA02-0AA0', io(), 'System power supply (slot 1)'),
  m('S7-400', 'DI', 'SM 421 DI 32×24VDC', '6ES7421-1BL01-0AA0', io(32), 'Digital input'),
  m('S7-400', 'DI', 'SM 421 DI 16×24VDC', '6ES7421-7BH01-0AB0', io(16), 'Interrupt & diagnostics'),
  m('S7-400', 'DQ', 'SM 422 DO 32×24VDC/0.5A', '6ES7422-1BL00-0AA0', io(0, 32), 'Digital output'),
  m('S7-400', 'DQ', 'SM 422 DO 16×24VDC/2A', '6ES7422-1BH11-0AA0', io(0, 16), 'Digital output 2 A'),
  m('S7-400', 'AI', 'SM 431 AI 8×13bit', '6ES7431-1KF00-0AB0', io(0, 0, 8), 'U/I/R'),
  m('S7-400', 'AI', 'SM 431 AI 16×16bit', '6ES7431-7QH00-0AB0', io(0, 0, 16), 'U/I/R/RTD/TC'),
  m('S7-400', 'AQ', 'SM 432 AO 8×13bit', '6ES7432-1HF00-0AB0', io(0, 0, 0, 8), 'U/I'),
  m('S7-400', 'CP', 'CP 443-1', '6GK7443-1EX30-0XE0', io(), 'Industrial Ethernet'),
];

export const cpuById = (id: string): CpuDef => CPUS.find(c => c.id === id) ?? CPUS.find(c => c.id === '1214C_DC_DC_DC')!;
export const moduleById = (id: string) => MODULES.find(x => x.id === id);

export interface SlotRange { first: number; last: number }

export function slotRange(cpu: CpuDef): SlotRange {
  switch (cpu.family) {
    case 'S7-1200': return { first: 2, last: 1 + cpu.maxModules };
    case 'S7-1500': return { first: 2, last: 1 + Math.min(cpu.maxModules, 31) };
    case 'S7-300': return { first: 4, last: 11 };
    case 'S7-400': return { first: 5, last: 18 };
  }
}

export interface Channel { kind: 'DI' | 'DQ' | 'AI' | 'AQ'; address: string; label: string }

export type IoKey = 'di' | 'dq' | 'ai' | 'aq';

/** One contiguous I/O area of a module (digital inputs, analog outputs, ...). */
export interface IoArea {
  key: IoKey;
  proc: 'I' | 'Q';
  label: string;
  /** effective start byte */
  start: number;
  bytes: number;
  /** number of channels */
  count: number;
  /** start byte that automatic assignment would give */
  auto: number;
  /** true when the user entered a start address */
  custom: boolean;
}

export interface ModuleAddr {
  /** 'cpu' for the CPU's onboard I/O, otherwise `slot-<n>` */
  id: string;
  slot: number | string;
  name: string;
  article: string;
  kind: string;
  iRange: string;
  qRange: string;
  channels: Channel[];
  fw: string;
  areas: IoArea[];
  conflicts: string[];
}

export const IO_AREA_LABEL: Record<IoKey, string> = { di: 'Digital inputs', dq: 'Digital outputs', ai: 'Analog inputs', aq: 'Analog outputs' };
const IO_KEYS: IoKey[] = ['di', 'dq', 'ai', 'aq'];
const procOf = (k: IoKey): 'I' | 'Q' => (k === 'di' || k === 'ai' ? 'I' : 'Q');

function digital(kind: 'DI' | 'DQ', startByte: number, count: number, prefix: string): Channel[] {
  const out: Channel[] = [];
  for (let i = 0; i < count; i++) {
    const b = startByte + Math.floor(i / 8);
    const address = `%${kind === 'DI' ? 'I' : 'Q'}${b}.${i % 8}`;
    out.push({ kind, address, label: `${prefix} ${kind}${i}` });
  }
  return out;
}
function analog(kind: 'AI' | 'AQ', startByte: number, count: number, prefix: string): Channel[] {
  const out: Channel[] = [];
  for (let i = 0; i < count; i++) {
    out.push({ kind, address: `%${kind === 'AI' ? 'I' : 'Q'}W${startByte + i * 2}`, label: `${prefix} ${kind}${i}` });
  }
  return out;
}

/** Merge adjacent / overlapping byte ranges of one process image into "a…b, c…d". */
function rangeText(areas: IoArea[], merge = true): string {
  const list = areas.filter(a => a.bytes > 0).map(a => [a.start, a.start + a.bytes - 1] as [number, number]).sort((x, y) => x[0] - y[0]);
  const merged: [number, number][] = [];
  for (const r of list) {
    const last = merged[merged.length - 1];
    if (merge && last && r[0] <= last[1] + 1) last[1] = Math.max(last[1], r[1]);
    else merged.push([r[0], r[1]]);
  }
  return merged.map(([a, b]) => `${a}…${b}`).join(', ');
}

const validStart = (v: unknown): v is number => typeof v === 'number' && Number.isFinite(v) && v >= 0;

/** Builds the areas + channels of one module from its automatic start bytes and optional custom starts. */
function buildRow(prefix: string, counts: IOCount, autos: Record<IoKey, number>, custom?: IoStart, order: IoKey[] = IO_KEYS): { areas: IoArea[]; channels: Channel[] } {
  const areas: IoArea[] = [];
  const channels: Channel[] = [];
  for (const key of order) {
    const count = counts[key];
    if (!count) continue;
    const bytes = key === 'di' || key === 'dq' ? Math.ceil(count / 8) : count * 2;
    const o = custom?.[key];
    const has = validStart(o);
    const start = has ? Math.floor(o) : autos[key];
    areas.push({ key, proc: procOf(key), label: IO_AREA_LABEL[key], start, bytes, count, auto: autos[key], custom: has });
    if (key === 'di') channels.push(...digital('DI', start, count, prefix));
    else if (key === 'dq') channels.push(...digital('DQ', start, count, prefix));
    else if (key === 'ai') channels.push(...analog('AI', start, count, prefix));
    else channels.push(...analog('AQ', start, count, prefix));
  }
  return { areas, channels };
}

/** TIA-Portal-like automatic address assignment, with optional custom start addresses per I/O area. */
export function computeAddresses(hw: HardwareConfig): ModuleAddr[] {
  const cpu = cpuById(hw.cpuId);
  const list: ModuleAddr[] = [];
  let seqI = 0, seqQ = 0;
  const finish = (id: string, slot: number | string, name: string, article: string, kind: string, fw: string, row: { areas: IoArea[]; channels: Channel[] }, merge = true) => {
    list.push({
      id, slot, name, article, kind, fw, channels: row.channels, areas: row.areas, conflicts: [],
      iRange: rangeText(row.areas.filter(a => a.proc === 'I'), merge),
      qRange: rangeText(row.areas.filter(a => a.proc === 'Q'), merge),
    });
  };

  // CPU onboard
  const ob = cpu.onboard;
  const cs = hw.cpuStart;
  if (cpu.family === 'S7-1200') {
    finish('cpu', 1, cpu.name + ' ' + cpu.variant, cpu.article, 'CPU', cpu.firmware, buildRow('CPU', ob, { di: 0, dq: 0, ai: 64, aq: 64 }, cs));
  } else if (cpu.family === 'S7-300') {
    finish('cpu', 2, cpu.name, cpu.article, 'CPU', cpu.firmware, buildRow('CPU', ob, { di: 124, dq: 124, ai: 752, aq: 752 }, cs));
  } else if (cpu.family === 'S7-1500') {
    // analog area first, digital area behind it (sequential assignment)
    const autos: Record<IoKey, number> = { ai: seqI, aq: seqQ, di: 0, dq: 0 };
    if (ob.ai) { seqI += ob.ai * 2; seqQ += ob.aq * 2; }
    autos.di = seqI; autos.dq = seqQ;
    if (ob.di) { seqI += Math.ceil(ob.di / 8); seqQ += Math.ceil(ob.dq / 8); }
    const row = buildRow('X', ob, autos, cs, ['ai', 'aq', 'di', 'dq']);
    // the S7-1500 onboard channels are labelled per interface (X10 analog, X11 digital)
    row.channels.forEach(c => { c.label = c.label.replace(/^X/, c.kind === 'AI' || c.kind === 'AQ' ? 'X10' : 'X11'); });
    finish('cpu', 1, cpu.name, cpu.article, 'CPU', cpu.firmware, row, false);
  } else {
    finish('cpu', 3, cpu.name, cpu.article, 'CPU', cpu.firmware, { areas: [], channels: [] });
  }

  const mods = [...hw.modules].sort((a, b) => a.slot - b.slot);
  for (const mi of mods) {
    const def = moduleById(mi.moduleId);
    if (!def) continue;
    const { di, dq, ai, aq } = def.io;
    const digBytesI = Math.ceil(di / 8), digBytesQ = Math.ceil(dq / 8);
    const prefix = `S${mi.slot}`;
    let autos: Record<IoKey, number>;
    if (cpu.family === 'S7-1200') {
      if (def.board) autos = { di: 4, dq: 4, ai: 80, aq: 80 };
      else {
        const i = 8 + (mi.slot - 2) * 4, a = 96 + (mi.slot - 2) * 16;
        autos = { di: i, dq: i, ai: a, aq: a };
      }
    } else if (cpu.family === 'S7-300' || cpu.family === 'S7-400') {
      const base = cpu.family === 'S7-300' ? 4 : 1;
      const d = (mi.slot - base) * 4;
      const a = cpu.family === 'S7-300' ? 256 + (mi.slot - 4) * 16 : 512 + (mi.slot - 1) * 64;
      autos = { di: d, dq: d, ai: a, aq: a };
    } else {
      // S7-1500 / ET200SP: sequential
      autos = { di: seqI, ai: seqI + digBytesI, dq: seqQ, aq: seqQ + digBytesQ };
      seqI += digBytesI + ai * 2; seqQ += digBytesQ + aq * 2;
    }
    finish(`slot-${mi.slot}`, def.board ? '1 (SB)' : mi.slot, def.name, def.article, def.kind, 'V2.2', buildRow(prefix, def.io, autos, mi.start));
  }

  // ---- conflicts: overlapping byte ranges inside one process image, or outside the image
  const who = (r: ModuleAddr) => (r.id === 'cpu' ? r.name : `${r.name} (slot ${r.slot})`);
  const add = (row: ModuleAddr, text: string) => { if (!row.conflicts.includes(text)) row.conflicts.push(text); };
  const { overlaps, outside } = findIoProblems(list);
  for (const o of outside) add(o.row, `${o.a.label}: ${o.a.start}…${o.a.start + o.a.bytes - 1} is outside the process image (0…${IO_BYTES - 1})`);
  for (const o of overlaps) {
    const pi = o.a.a.proc === 'I' ? 'input' : 'output';
    if (o.a.row === o.b.row) add(o.a.row, `${o.a.a.label} and ${o.b.a.label.toLowerCase()} overlap at ${pi} address ${o.span}`);
    else {
      add(o.a.row, `${o.a.a.label} overlap with ${who(o.b.row)} at ${pi} address ${o.span}`);
      add(o.b.row, `${o.b.a.label} overlap with ${who(o.a.row)} at ${pi} address ${o.span}`);
    }
  }
  return list;
}

interface AreaRef { row: ModuleAddr; a: IoArea }

/** Finds overlapping and out-of-range I/O areas (each overlapping pair is reported once). */
export function findIoProblems(list: ModuleAddr[]): { overlaps: { a: AreaRef; b: AreaRef; span: string }[]; outside: AreaRef[] } {
  const all: AreaRef[] = [];
  list.forEach(row => row.areas.forEach(a => all.push({ row, a })));
  const outside = all.filter(x => x.a.start + x.a.bytes > IO_BYTES);
  const overlaps: { a: AreaRef; b: AreaRef; span: string }[] = [];
  for (let x = 0; x < all.length; x++) {
    for (let y = x + 1; y < all.length; y++) {
      const A = all[x], B = all[y];
      if (A.a.proc !== B.a.proc) continue;
      const aEnd = A.a.start + A.a.bytes - 1, bEnd = B.a.start + B.a.bytes - 1;
      if (A.a.start > bEnd || B.a.start > aEnd) continue;
      const lo = Math.max(A.a.start, B.a.start), hi = Math.min(aEnd, bEnd);
      overlaps.push({ a: A, b: B, span: lo === hi ? `${lo}` : `${lo}…${hi}` });
    }
  }
  return { overlaps, outside };
}

/** One readable line per I/O address problem (used by the compiler). */
export function ioProblemMessages(list: ModuleAddr[]): string[] {
  const who = (r: ModuleAddr) => (r.id === 'cpu' ? r.name : `${r.name} (slot ${r.slot})`);
  const { overlaps, outside } = findIoProblems(list);
  const out: string[] = [];
  for (const o of outside) out.push(`${who(o.row)}: ${o.a.label.toLowerCase()} ${o.a.start}…${o.a.start + o.a.bytes - 1} are outside the process image (0…${IO_BYTES - 1})`);
  for (const o of overlaps) {
    const pi = o.a.a.proc === 'I' ? 'input' : 'output';
    out.push(`${who(o.a.row)} and ${who(o.b.row)} use the same ${pi} address ${o.span}`);
  }
  return out;
}

/** Text such as "%I0.0 … %I1.7" or "%IW64 … %IW70" for an I/O area. */
export function areaAddressText(a: IoArea, count: number): string {
  const p = a.proc;
  if (a.key === 'di' || a.key === 'dq') {
    const last = count - 1;
    return `%${p}${a.start}.0 … %${p}${a.start + Math.floor(last / 8)}.${last % 8}`;
  }
  return `%${p}W${a.start} … %${p}W${a.start + (count - 1) * 2}`;
}

export function modulesForCpu(cpu: CpuDef): ModuleDef[] {
  return MODULES.filter(x => x.fam === cpu.modFamily && (cpu.family !== 'S7-1200' || cpu.maxModules > 0 || x.board || x.kind === 'CM' || x.kind === 'CP'));
}
