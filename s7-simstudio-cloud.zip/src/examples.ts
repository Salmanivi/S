import type { Block, Elem, LadderInstr, Network, PlantDevice, Project, Tag, DataType } from './types';
import { uid } from './plc/ladder';
import { INSTR_MAP } from './catalog/instructions';

const I = (op: string, operand = '', params: Record<string, string> = {}, extra: Partial<LadderInstr> = {}): LadderInstr => {
  const def = INSTR_MAP[op];
  const p: Record<string, string> = {};
  def.pins.forEach(pin => (p[pin.name] = pin.def ?? ''));
  return { id: uid('i'), kind: 'instr', op, operand, params: { ...p, ...params }, dataType: def.defType, dataType2: def.defType2, autoType: def.types && def.types.length > 1 ? true : undefined, ...extra };
};
const P = (...branches: Elem[][]): Elem => ({ id: uid('p'), kind: 'par', branches: branches.map(items => ({ id: uid('s'), kind: 'ser', items })) });
const NW = (title: string, comment: string, ...items: Elem[]): Network => ({ id: uid('n'), title, comment, root: { id: uid('s'), kind: 'ser', items } });
const T = (name: string, dataType: DataType, address: string, comment = ''): Tag => ({ id: uid('t'), name, dataType, address, comment });
const D = (type: string, name: string, x: number, y: number, bind: Record<string, string>, cfg: PlantDevice['cfg'] = {}): PlantDevice => ({ id: uid('d'), type, name, x, y, bind, cfg });

const mainOB = (networks: Network[]): Block => ({ id: uid('b'), name: 'Main', kind: 'main', number: 1, comment: 'Main program sweep (cycle)', networks });

const props = (name = 'PLC_1') => ({ name, ip: '192.168.0.1', clockEnabled: true, clockByte: 0, sysEnabled: true, sysByte: 1, watchdogMs: 150 });

const sysTags = (): Tag[] => [
  T('Clock_10Hz', 'Bool', '%M0.0', 'Clock memory'), T('Clock_2Hz', 'Bool', '%M0.3', 'Clock memory'), T('Clock_1Hz', 'Bool', '%M0.5', 'Clock memory'),
  T('FirstScan', 'Bool', '%M1.0', 'System memory'), T('AlwaysTRUE', 'Bool', '%M1.2', 'System memory'), T('AlwaysFALSE', 'Bool', '%M1.3', 'System memory'),
];

export function emptyProject(cpuId = '1214C_DC_DC_DC', name = 'Project1'): Project {
  return {
    name,
    hardware: { cpuId, modules: [], props: props() },
    tags: sysTags(),
    blocks: [mainOB([NW('', '')])],
    watch: [],
    devices: [],
  };
}

function motorStartStop(): Project {
  return {
    name: 'Motor start/stop (self-holding)',
    hardware: { cpuId: '1214C_DC_DC_DC', modules: [], props: props() },
    tags: [
      ...sysTags(),
      T('Start_PB', 'Bool', '%I0.0', 'Start push button (NO)'),
      T('Stop_PB', 'Bool', '%I0.1', 'Stop push button (NC wired)'),
      T('Overload_OK', 'Bool', '%I0.2', 'Thermal overload relay (NC)'),
      T('Motor_K1', 'Bool', '%Q0.0', 'Main contactor K1'),
      T('Lamp_Run', 'Bool', '%Q0.1', 'Running indicator'),
      T('Lamp_Fault', 'Bool', '%Q0.2', 'Overload indicator'),
    ],
    blocks: [mainOB([
      NW('Motor self-holding circuit', 'Classic start/stop with seal-in contact. Stop and overload are NC wired → NO contacts in the program (fail-safe).',
        P([I('NO', 'Start_PB')], [I('NO', 'Motor_K1')]), I('NO', 'Stop_PB'), I('NO', 'Overload_OK'), I('OUT', 'Motor_K1')),
      NW('Run lamp', '', I('NO', 'Motor_K1'), I('OUT', 'Lamp_Run')),
      NW('Fault lamp flashing 2 Hz', 'Uses clock memory byte MB0', I('NC', 'Overload_OK'), I('NO', 'Clock_2Hz'), I('OUT', 'Lamp_Fault')),
    ])],
    watch: [{ id: uid('w'), operand: 'Motor_K1', format: 'auto', modify: '' }, { id: uid('w'), operand: 'Start_PB', format: 'auto', modify: '' }],
    devices: [
      D('label', 'Title', 40, 20, {}, { text: 'Motor control panel', size: 20 }),
      D('pushbutton', 'S1 Start', 40, 90, { out: 'Start_PB' }, { color: 'green', contact: 'NO', label: 'START' }),
      D('pushbutton', 'S0 Stop', 170, 90, { out: 'Stop_PB' }, { color: 'red', contact: 'NC', label: 'STOP' }),
      D('lamp', 'H1 Run', 300, 90, { in: 'Lamp_Run' }, { color: 'green', label: 'RUN' }),
      D('lamp', 'H2 Fault', 420, 90, { in: 'Lamp_Fault' }, { color: 'red', label: 'FAULT' }),
      D('motor', 'M1 Pump motor', 40, 250, { fwd: 'Motor_K1', ol: 'Overload_OK' }, { label: 'M1' }),
    ],
  };
}

function trafficLight(): Project {
  return {
    name: 'Traffic light (TON chain)',
    hardware: { cpuId: '1212C_DC_DC_DC', modules: [], props: props() },
    tags: [
      ...sysTags(),
      T('Run', 'Bool', '%I0.0', 'System on switch'),
      T('Red', 'Bool', '%Q0.0'), T('Yellow', 'Bool', '%Q0.1'), T('Green', 'Bool', '%Q0.2'),
    ],
    blocks: [mainOB([
      NW('Red phase timer (5 s)', 'The chain restarts when the yellow timer has elapsed.', I('NO', 'Run'), I('NC', 'T_Yellow.Q'), I('TON', '', { PT: 'T#5s' }, { instance: 'T_Red' })),
      NW('Green phase timer (4 s)', '', I('NO', 'T_Red.Q'), I('TON', '', { PT: 'T#4s' }, { instance: 'T_Green' })),
      NW('Yellow phase timer (2 s)', '', I('NO', 'T_Green.Q'), I('TON', '', { PT: 'T#2s' }, { instance: 'T_Yellow' })),
      NW('Red lamp', '', I('NO', 'Run'), I('NC', 'T_Red.Q'), I('OUT', 'Red')),
      NW('Green lamp', '', I('NO', 'T_Red.Q'), I('NC', 'T_Green.Q'), I('OUT', 'Green')),
      NW('Yellow lamp', '', I('NO', 'T_Green.Q'), I('OUT', 'Yellow')),
    ])],
    watch: [{ id: uid('w'), operand: 'T_Red.ET', format: 'auto', modify: '' }, { id: uid('w'), operand: 'T_Green.ET', format: 'auto', modify: '' }],
    devices: [
      D('switch', 'S1 Run', 40, 60, { out: 'Run' }, { label: 'SYSTEM', l0: 'OFF', l1: 'ON' }),
      D('traffic', 'Signal North', 200, 40, { red: 'Red', yellow: 'Yellow', green: 'Green' }, { label: 'North' }),
    ],
  };
}

function tankLevel(): Project {
  return {
    name: 'Tank level control (analog)',
    hardware: { cpuId: '1214C_DC_DC_DC', modules: [], props: props() },
    tags: [
      ...sysTags(),
      T('Drain_Switch', 'Bool', '%I0.0', 'Manual drain'),
      T('LSH_High', 'Bool', '%I0.1', 'High level switch'),
      T('Inlet_Valve', 'Bool', '%Q0.0'), T('Outlet_Valve', 'Bool', '%Q0.1'), T('Alarm_Lamp', 'Bool', '%Q0.2'),
      T('Level_Raw', 'Int', '%IW64', 'Level transmitter 0…27648'),
      T('Level_Norm', 'Real', '%MD10', '0.0…1.0'),
      T('Level_Pct', 'Real', '%MD14', 'Level in %'),
    ],
    blocks: [mainOB([
      NW('Normalize analog level', 'NORM_X + SCALE_X: standard Siemens analog scaling', I('NORM_X', '', { MIN: '0', VALUE: 'Level_Raw', MAX: '27648', OUT: 'Level_Norm' }, { dataType: 'Int' }), I('SCALE_X', '', { MIN: '0.0', VALUE: 'Level_Norm', MAX: '100.0', OUT: 'Level_Pct' }, { dataType: 'Real' })),
      NW('Start filling below 20 %', '', I('CMP_LT', '', { IN1: 'Level_Pct', IN2: '20.0' }, { dataType: 'Real' }), I('SET', 'Inlet_Valve')),
      NW('Stop filling above 80 %', '', P([I('CMP_GT', '', { IN1: 'Level_Pct', IN2: '80.0' }, { dataType: 'Real' })], [I('NO', 'LSH_High')]), I('RESET', 'Inlet_Valve')),
      NW('Manual drain', '', I('NO', 'Drain_Switch'), I('OUT', 'Outlet_Valve')),
      NW('High level alarm (1 Hz)', '', I('NO', 'LSH_High'), I('NO', 'Clock_1Hz'), I('OUT', 'Alarm_Lamp')),
    ])],
    watch: [{ id: uid('w'), operand: 'Level_Raw', format: 'auto', modify: '' }, { id: uid('w'), operand: 'Level_Pct', format: 'auto', modify: '' }],
    devices: [
      D('tank', 'T1 Buffer tank', 260, 40, { in: 'Inlet_Valve', out: 'Outlet_Valve', lvl: 'Level_Raw', hi: 'LSH_High' }, { label: 'T1', fill: 6, drain: 9, hiP: 92 }),
      D('switch', 'S1 Drain', 40, 40, { out: 'Drain_Switch' }, { label: 'DRAIN', l0: 'OFF', l1: 'OPEN' }),
      D('display', 'Level %', 40, 200, { in: 'Level_Pct' }, { label: 'Level', dtype: 'Real', dec: 1, unit: '%' }),
      D('lamp', 'H1 High alarm', 480, 40, { in: 'Alarm_Lamp' }, { color: 'red', label: 'HIGH' }),
      D('gauge', 'Level raw', 480, 190, { in: 'Level_Raw' }, { label: 'Level', eu: 100, unit: '%' }),
    ],
  };
}

function conveyorCounter(): Project {
  return {
    name: 'Conveyor batch counter (CTU)',
    hardware: { cpuId: '1214C_DC_DC_DC', modules: [], props: props() },
    tags: [
      ...sysTags(),
      T('Start', 'Bool', '%I0.0'), T('Stop', 'Bool', '%I0.1', 'NC'), T('Reset', 'Bool', '%I0.2'), T('Part_Sensor', 'Bool', '%I0.3', 'Photo eye at belt end'),
      T('Conveyor', 'Bool', '%Q0.0'), T('Batch_Done', 'Bool', '%Q0.1'),
      T('Count', 'Int', '%MW20', 'Current count'), T('Batch_Size', 'Int', '%MW22', 'Preset'),
    ],
    blocks: [
      { id: uid('b'), name: 'Startup', kind: 'startup', number: 100, comment: 'Executed once at STOP → RUN', networks: [
        NW('Default batch size', '', I('MOVE', '', { IN: '5', OUT1: 'Batch_Size' }, { dataType: 'Int' })),
      ] },
      mainOB([
        NW('Conveyor motor', 'Stops automatically when the batch is complete', P([I('NO', 'Start')], [I('NO', 'Conveyor')]), I('NO', 'Stop'), I('NC', 'Batch_Done'), I('OUT', 'Conveyor')),
        NW('Count parts', '', I('NO', 'Part_Sensor'), I('CTU', '', { R: 'Reset', PV: 'Batch_Size', CV: 'Count' }, { instance: 'IEC_Counter_0_DB', dataType: 'Int' }), I('OUT', 'Batch_Done')),
      ]),
    ],
    watch: [{ id: uid('w'), operand: 'Count', format: 'auto', modify: '' }, { id: uid('w'), operand: 'Batch_Size', format: 'auto', modify: '' }],
    devices: [
      D('conveyor', 'Belt 1', 40, 220, { run: 'Conveyor', sEnd: 'Part_Sensor' }, { label: 'Belt 1', auto: 2.5, remove: true, speed: 0.18 }),
      D('pushbutton', 'Start', 40, 50, { out: 'Start' }, { color: 'green', label: 'START' }),
      D('pushbutton', 'Stop', 160, 50, { out: 'Stop' }, { color: 'red', contact: 'NC', label: 'STOP' }),
      D('pushbutton', 'Reset', 280, 50, { out: 'Reset' }, { color: 'blue', label: 'RESET' }),
      D('sevenseg', 'Counter', 400, 50, { in: 'Count' }, { label: 'Parts' }),
      D('lamp', 'Done', 640, 50, { in: 'Batch_Done' }, { color: 'yellow', label: 'DONE' }),
    ],
  };
}

function starDelta(): Project {
  return {
    name: 'Star-delta starter',
    hardware: { cpuId: '1215C_DC_DC_DC', modules: [{ slot: 2, moduleId: 'S7-1200_6ES7221-1BF32-0XB0' }], props: props() },
    tags: [
      ...sysTags(),
      T('Start', 'Bool', '%I0.0'), T('Stop', 'Bool', '%I0.1', 'NC'),
      T('K1_Main', 'Bool', '%Q0.0'), T('K2_Star', 'Bool', '%Q0.1'), T('K3_Delta', 'Bool', '%Q0.2'),
    ],
    blocks: [mainOB([
      NW('Main contactor K1', '', P([I('NO', 'Start')], [I('NO', 'K1_Main')]), I('NO', 'Stop'), I('OUT', 'K1_Main')),
      NW('Changeover timer 5 s', '', I('NO', 'K1_Main'), I('NC', 'K3_Delta'), I('TON', '', { PT: 'T#5s' }, { instance: 'T_StarDelta' })),
      NW('Star contactor K2', 'Interlocked with K3', I('NO', 'K1_Main'), I('NC', 'T_StarDelta.Q'), I('NC', 'K3_Delta'), I('OUT', 'K2_Star')),
      NW('Delta contactor K3', 'Self-holding, interlocked with K2', I('NO', 'K1_Main'), P([I('NO', 'T_StarDelta.Q')], [I('NO', 'K3_Delta')]), I('NC', 'K2_Star'), I('OUT', 'K3_Delta')),
    ])],
    watch: [{ id: uid('w'), operand: 'T_StarDelta.ET', format: 'auto', modify: '' }],
    devices: [
      D('pushbutton', 'Start', 40, 40, { out: 'Start' }, { color: 'green', label: 'START' }),
      D('pushbutton', 'Stop', 160, 40, { out: 'Stop' }, { color: 'red', contact: 'NC', label: 'STOP' }),
      D('lamp', 'K1', 300, 40, { in: 'K1_Main' }, { color: 'white', label: 'K1 MAIN' }),
      D('lamp', 'K2', 410, 40, { in: 'K2_Star' }, { color: 'yellow', label: 'K2 STAR' }),
      D('lamp', 'K3', 520, 40, { in: 'K3_Delta' }, { color: 'green', label: 'K3 DELTA' }),
      D('motor', 'M1', 40, 200, { fwd: 'K1_Main' }, { label: 'M1 37 kW', ramp: 4 }),
    ],
  };
}

function cylinderSeq(): Project {
  return {
    name: 'Pneumatic sequence A+ A− (S7-1500)',
    hardware: { cpuId: 'CPU_1511C_1_PN', modules: [], props: props() },
    tags: [
      ...sysTags(),
      T('Cycle_Start', 'Bool', '%I10.0'), T('A_Retracted', 'Bool', '%I10.1', 'Reed B0'), T('A_Extended', 'Bool', '%I10.2', 'Reed B1'),
      T('A_Extend', 'Bool', '%Q4.0', 'Valve Y1'), T('Step1', 'Bool', '%M10.0'), T('Cycles', 'Int', '%MW20'),
    ],
    blocks: [mainOB([
      NW('Step 1: extend on start', '', I('NO', 'Cycle_Start'), I('NO', 'A_Retracted'), I('SET', 'Step1')),
      NW('Step 2: dwell 1 s at end position, then retract', '', I('NO', 'A_Extended'), I('TON', '', { PT: 'T#1s' }, { instance: 'T_Dwell' }), I('RESET', 'Step1')),
      NW('Valve output', '', I('NO', 'Step1'), I('OUT', 'A_Extend')),
      NW('Cycle counter', '', I('P', 'A_Extended', { M_BIT: '%M11.0' }), I('INC', '', { IN_OUT: 'Cycles' }, { dataType: 'Int' })),
    ])],
    watch: [{ id: uid('w'), operand: 'Cycles', format: 'auto', modify: '' }],
    devices: [
      D('pushbutton', 'Start', 40, 40, { out: 'Cycle_Start' }, { color: 'green', label: 'CYCLE' }),
      D('cylinder', 'Cylinder A', 180, 50, { ext: 'A_Extend', sRet: 'A_Retracted', sExt: 'A_Extended' }, { label: 'A1', time: 1.2 }),
      D('display', 'Cycles', 440, 50, { in: 'Cycles' }, { label: 'Cycles' }),
    ],
  };
}

export const EXAMPLES: { id: string; title: string; desc: string; make: () => Project }[] = [
  { id: 'motor', title: 'Motor start/stop', desc: 'Self-holding circuit, NC stop, overload, flashing fault lamp (S7-1214C)', make: motorStartStop },
  { id: 'traffic', title: 'Traffic light', desc: 'TON timer chain using instance members T_Red.Q (S7-1212C)', make: trafficLight },
  { id: 'tank', title: 'Tank level (analog)', desc: 'NORM_X / SCALE_X, comparators, SET/RESET valves (S7-1214C)', make: tankLevel },
  { id: 'conveyor', title: 'Conveyor batch counter', desc: 'CTU counter, startup OB100, 7-segment display (S7-1214C)', make: conveyorCounter },
  { id: 'stardelta', title: 'Star-delta starter', desc: 'Interlocked contactors with changeover timer (S7-1215C)', make: starDelta },
  { id: 'cylinder', title: 'Pneumatic cylinder cycle', desc: 'Edge detection, INC, dwell timer on S7-1511C compact', make: cylinderSeq },
];
