// Set at build time: true for the offline edition (the single-file build meant for APK/EXE wrappers).
// The offline edition never talks to a server, so accounts and cloud features do not exist in it.
declare const __OFFLINE__: boolean | undefined;
export const OFFLINE_BUILD: boolean = typeof __OFFLINE__ !== 'undefined' && !!__OFFLINE__;
