import { useAuth } from './auth';
import { LoginPage, RegisterPage, ForgotPage, ResetPage, VerifyPage, SetupPage, InvitePage } from './AuthPages';
import { AccountPage } from './AccountPage';
import { ProjectsPage } from './ProjectsPage';
import { TeamsPage } from './TeamsPage';
import { AdminPage } from './AdminPage';
import { TermsPage, PrivacyPage, AboutPage } from './Legal';
import { ConflictDialog, SaveToCloudDialog, HistoryDialog } from './CloudDialogs';

/** Renders the full-screen page that is currently open (account, projects, teams, admin, sign-in ...). */
export function PageHost() {
  const page = useAuth(s => s.page);
  switch (page) {
    case 'login': return <LoginPage />;
    case 'register': return <RegisterPage />;
    case 'forgot': return <ForgotPage />;
    case 'reset': return <ResetPage />;
    case 'verify': return <VerifyPage />;
    case 'setup': return <SetupPage />;
    case 'invite': return <InvitePage />;
    case 'account': return <AccountPage />;
    case 'projects': return <ProjectsPage />;
    case 'teams': return <TeamsPage />;
    case 'admin': return <AdminPage />;
    case 'about': return <AboutPage />;
    case 'terms': return <TermsPage />;
    case 'privacy': return <PrivacyPage />;
    default: return null;
  }
}

/** Dialogs that can be opened from anywhere in the app. */
export function CloudOverlays() {
  const dlg = useAuth(s => s.cloudDialog);
  const close = () => useAuth.setState({ cloudDialog: null });
  return (
    <>
      <PageHost />
      <ConflictDialog />
      {dlg === 'save' && <SaveToCloudDialog onClose={close} />}
      {dlg === 'history' && <HistoryDialog onClose={close} />}
    </>
  );
}
