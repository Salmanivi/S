import { useState } from 'react';
import { Cloud, CloudOff, RefreshCw, AlertTriangle, Lock, LogIn, FolderOpen, Users, User as UserIcon, ShieldCheck, LogOut, X, Megaphone } from 'lucide-react';
import { useAuth } from './auth';
import { useStore } from '../store';
import { useSync, saveNow } from './sync';
import { Avatar } from './ui';

export function AnnouncementBar() {
  const { config, announcementDismissed } = useAuth();
  if (!config?.announcement || announcementDismissed) return null;
  return (
    <div className="shrink-0 flex items-start gap-2 bg-accent2/15 text-ink border-b border-accent2/30 px-3 py-2 text-[13px] pt-[calc(0.5rem+env(safe-area-inset-top))]" role="status">
      <Megaphone size={15} className="shrink-0 mt-0.5 text-accent2" />
      <div className="flex-1 min-w-0 break-words">{config.announcement}</div>
      <button className="shrink-0 p-1 -m-1 text-mute hover:text-ink" aria-label="Dismiss announcement" onClick={() => useAuth.setState({ announcementDismissed: true })}><X size={15} /></button>
    </div>
  );
}

/** Sign-in button or the account menu. */
export function AccountMenu({ align = 'right' }: { align?: 'left' | 'right' }) {
  const { user, cloudAvailable, openPage, signOut } = useAuth();
  const [open, setOpen] = useState(false);
  if (!cloudAvailable) return null;
  if (!user) return <button className="btn btn-ghost" onClick={() => openPage('login')}><LogIn size={15} /><span className="hidden sm:inline">Sign in</span></button>;
  const go = (p: Parameters<typeof openPage>[0]) => { setOpen(false); openPage(p); };
  const Item = ({ icon, label, onClick, danger }: { icon: React.ReactNode; label: string; onClick: () => void; danger?: boolean }) => (
    <button role="menuitem" className={`w-full flex items-center gap-2.5 px-2.5 py-2.5 lg:py-2 rounded-md text-[13px] hover:bg-panel3 text-left ${danger ? 'text-danger' : ''}`} onClick={onClick}>{icon}{label}</button>
  );
  return (
    <div className="relative">
      <button className="btn btn-ghost !px-1.5" aria-label="Account menu" aria-haspopup="menu" aria-expanded={open} onClick={() => setOpen(o => !o)}><Avatar name={user.name} size={28} /></button>
      {open && (
        <>
          <div className="fixed inset-0 z-40" onClick={() => setOpen(false)} />
          <div role="menu" className={`absolute ${align === 'right' ? 'right-0' : 'left-0'} top-full mt-1 z-50 card p-1 w-60 shadow-2xl anim-in`}>
            <div className="px-2.5 py-2 border-b border-line mb-1"><div className="text-[13.5px] font-semibold truncate">{user.name}</div><div className="text-[12px] text-mute truncate">{user.email}</div></div>
            <Item icon={<FolderOpen size={15} />} label="My cloud projects" onClick={() => go('projects')} />
            <Item icon={<Users size={15} />} label="Teams" onClick={() => go('teams')} />
            <Item icon={<UserIcon size={15} />} label="Account" onClick={() => go('account')} />
            {user.role === 'admin' && <Item icon={<ShieldCheck size={15} />} label="Admin console" onClick={() => go('admin')} />}
            <div className="h-px bg-line my-1" />
            <Item icon={<LogOut size={15} />} label="Sign out" onClick={() => { setOpen(false); void signOut(); }} />
          </div>
        </>
      )}
    </div>
  );
}

/** Shows whether the open project is stored online and whether everything is saved. */
export function SyncChip({ compact }: { compact?: boolean }) {
  const cloud = useStore(s => s.cloud);
  const projectOpen = useStore(s => s.projectOpen);
  const { user, cloudAvailable, openPage } = useAuth();
  const sync = useSync();
  if (!cloudAvailable || !projectOpen) return null;

  const base = 'inline-flex items-center gap-1.5 rounded-md px-2 py-1.5 text-[12px] font-medium shrink-0 hover:bg-panel3 min-h-9';
  if (!cloud) {
    return (
      <button className={`${base} text-mute`} onClick={() => (user ? useAuth.setState({ cloudDialog: 'save' }) : openPage('login'))} title={user ? 'Save this project to your cloud projects' : 'Sign in to save projects online'} aria-label={user ? 'Save to cloud' : 'Sign in to save online'}>
        <CloudOff size={16} />{!compact && <span>{user ? 'Not saved online' : 'Sign in to save online'}</span>}
      </button>
    );
  }
  const { state } = sync;
  const label = cloud.readOnly ? 'View only' : state === 'saving' ? 'Saving…' : state === 'unsaved' ? 'Saving soon…' : state === 'offline' ? 'Offline' : state === 'conflict' ? 'Conflict' : state === 'error' ? 'Not saved' : 'Saved';
  const tone = cloud.readOnly ? 'text-warn' : state === 'conflict' || state === 'offline' ? 'text-warn' : state === 'error' ? 'text-danger' : state === 'saved' ? 'text-on' : 'text-mute';
  const Icon = cloud.readOnly ? Lock : state === 'saving' || state === 'unsaved' ? RefreshCw : state === 'offline' ? CloudOff : state === 'conflict' || state === 'error' ? AlertTriangle : Cloud;
  const click = () => {
    if (state === 'conflict') useSync.setState({ conflictOpen: true });
    else if (state === 'error' || state === 'offline') { useStore.getState().showToast(sync.message ?? 'Retrying…', 'info'); void saveNow(); }
    else useAuth.setState({ cloudDialog: 'history' });
  };
  return (
    <button className={`${base} ${tone}`} onClick={click} title={`${cloud.teamName ? cloud.teamName + ' · ' : ''}${label}${sync.message ? ' — ' + sync.message : ''}`} aria-label={`Cloud status: ${label}`}>
      <Icon size={16} className={state === 'saving' ? 'animate-spin' : ''} />{!compact && <span>{label}</span>}
    </button>
  );
}
