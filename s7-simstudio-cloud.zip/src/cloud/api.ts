export class ApiError extends Error {
  constructor(public status: number, public code: string, message: string, public details?: any, public requestId?: string) { super(message); }
}

type Method = 'GET' | 'POST' | 'PUT' | 'PATCH' | 'DELETE';

/** Same-origin JSON call to the serverless API. Throws ApiError (status 0 = server unreachable). */
async function call<T>(method: Method, path: string, body?: unknown, timeoutMs = 0): Promise<T> {
  let res: Response;
  const ctl = timeoutMs ? new AbortController() : null;
  const timer = ctl ? setTimeout(() => ctl.abort(), timeoutMs) : undefined;
  try {
    res = await fetch('/api' + path, {
      method,
      credentials: 'same-origin',
      headers: body !== undefined ? { 'Content-Type': 'application/json' } : undefined,
      body: body !== undefined ? JSON.stringify(body) : undefined,
      signal: ctl?.signal,
    });
  } catch {
    throw new ApiError(0, 'network', 'Cannot reach the server. Check your internet connection.');
  } finally { if (timer) clearTimeout(timer); }
  const text = await res.text();
  let json: any;
  try { json = text ? JSON.parse(text) : undefined; } catch { json = undefined; }
  // Our API always answers with JSON. A page of HTML (or nothing) means there is no API behind this address,
  // for example inside an APK/EXE wrapper whose local server returns the app for every path.
  if (res.ok && json === undefined) throw new ApiError(0, 'not_api', 'No server is available here.');
  if (!res.ok) {
    const e = json?.error;
    // an HTML page here means the API is not deployed (e.g. a static preview)
    const msg = e?.message ?? (res.status === 404 ? 'The server API is not available here.' : `Request failed (${res.status})`);
    throw new ApiError(res.status, e?.code ?? 'error', msg, e?.details, e?.requestId);
  }
  return json as T;
}

export const api = {
  get: <T = any>(p: string, timeoutMs = 0) => call<T>('GET', p, undefined, timeoutMs),
  post: <T = any>(p: string, b: unknown = {}) => call<T>('POST', p, b),
  put: <T = any>(p: string, b: unknown) => call<T>('PUT', p, b),
  patch: <T = any>(p: string, b: unknown) => call<T>('PATCH', p, b),
  del: <T = any>(p: string) => call<T>('DELETE', p),
};

export const errMsg = (e: unknown) => (e instanceof ApiError ? e.message : e instanceof Error ? e.message : 'Something went wrong');
