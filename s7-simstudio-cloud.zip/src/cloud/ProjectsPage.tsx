import { useCallback, useEffect, useRef, useState } from 'react';
import { Search, Plus, FolderOpen, Users, Cloud, Trash2, Copy, Pencil, ArrowRight, RotateCcw, EllipsisVertical, Lock } from 'lucide-react';
import { api, errMsg } from './api';
import { useAuth } from './auth';
import { useStore } from '../store';
import { Modal, confirmDiscard } from '../components/Shell';
import { openCloudProject } from './sync';
import { SaveToCloudDialog, MoveDialog } from './CloudDialogs';
import { canWrite, ROLE_LABEL, type ProjectMeta } from './types';
import { PageShell, Spinner, Alert, Badge, Field, useConfirm, useAction, timeAgo, fmtBytes } from './ui';

type Tab = 'mine' | 'team' | 'trash';

function RenameDialog({ p, onClose, onDone }: { p: ProjectMeta; onClose: () => void; onDone: () => void }) {
  const [name, setName] = useState(p.name);
  const { busy, error, run } = useAction();
  const go = () => run(async () => {
    const open = useStore.getState().cloud?.id === p.id;
    if (open) useStore.getState().mutate(x => { x.name = name.trim(); }, false);       // autosave stores it
    else await api.put(`/projects/${p.id}`, { baseRevision: p.revision, name });
    onDone();
  });
  return (
    <Modal title="Rename project" onClose={onClose}>
      <form className="p-4 space-y-3" onSubmit={e => { e.preventDefault(); void go(); }}>
        <Field label="Name"><input className="input" value={name} maxLength={120} onChange={e => setName(e.target.value)} autoFocus={!('ontouchstart' in window)} /></Field>
        {error && <Alert kind="error">{error}</Alert>}
        <div className="flex gap-2"><button type="button" className="btn flex-1 justify-center" onClick={onClose}>Cancel</button><button type="submit" className="btn btn-accent flex-1 justify-center" disabled={busy || !name.trim() || name.trim() === p.name}>Rename</button></div>
      </form>
    </Modal>
  );
}

function Row({ p, tab, openId, onOpen, onAction }: { p: ProjectMeta; tab: Tab; openId: string | null; onOpen: () => void; onAction: (a: 'rename' | 'duplicate' | 'move' | 'delete' | 'restore' | 'purge') => void }) {
  const [menu, setMenu] = useState(false);
  const ref = useRef<HTMLDivElement>(null);
  useEffect(() => {
    if (!menu) return;
    const h = (e: KeyboardEvent) => { if (e.key === 'Escape') setMenu(false); };
    window.addEventListener('keydown', h);
    return () => window.removeEventListener('keydown', h);
  }, [menu]);
  const writable = canWrite(p.role);
  const manage = p.role === 'owner' || p.role === 'admin';
  const items: [string, Parameters<typeof onAction>[0], React.ReactNode, boolean?][] = tab === 'trash'
    ? [['Restore', 'restore', <RotateCcw size={15} key="r" />], ['Delete forever', 'purge', <Trash2 size={15} key="d" />, true]]
    : [
      ...(writable ? [['Rename', 'rename', <Pencil size={15} key="e" />] as [string, 'rename', React.ReactNode]] : []),
      ['Duplicate', 'duplicate', <Copy size={15} key="c" />],
      ...(manage ? [['Move…', 'move', <ArrowRight size={15} key="m" />] as [string, 'move', React.ReactNode]] : []),
      ...(manage || p.role === 'editor' ? [['Move to trash', 'delete', <Trash2 size={15} key="t" />, true] as [string, 'delete', React.ReactNode, boolean]] : []),
    ];
  return (
    <li className={`card p-0 flex items-stretch ${openId === p.id ? '!border-accent/60' : ''}`}>
      <button className="flex-1 min-w-0 text-left p-3 flex gap-3 items-center disabled:opacity-100" onClick={onOpen} disabled={tab === 'trash'}>
        <span className={`shrink-0 w-10 h-10 rounded-lg flex items-center justify-center ${p.scope === 'team' ? 'bg-accent2/15 text-accent2' : 'bg-accent/15 text-accent'}`}>{p.scope === 'team' ? <Users size={18} /> : <FolderOpen size={18} />}</span>
        <span className="min-w-0 flex-1">
          <span className="flex items-center gap-1.5 flex-wrap"><span className="font-semibold text-[14.5px] truncate">{p.name}</span>
            {openId === p.id && <Badge tone="on">Open</Badge>}{p.role === 'viewer' && <Badge tone="warn"><Lock size={10} className="mr-0.5" />View only</Badge>}</span>
          <span className="block text-[12px] text-mute truncate">
            {p.scope === 'team' && <>{p.teamName} · </>}{tab === 'trash' && p.deletedAt ? `Deleted ${timeAgo(p.deletedAt)}` : `Edited ${timeAgo(p.updatedAt)}${p.updatedBy ? ` by ${p.updatedBy}` : ''}`} · {fmtBytes(p.sizeBytes)}
          </span>
        </span>
      </button>
      <div className="relative shrink-0 flex items-center pr-1" ref={ref}>
        <button className="btn btn-ghost btn-icon" aria-label={`Actions for ${p.name}`} aria-haspopup="menu" aria-expanded={menu} onClick={() => setMenu(m => !m)}><EllipsisVertical size={18} /></button>
        {menu && (
          <>
            <div className="fixed inset-0 z-30" onClick={() => setMenu(false)} />
            <div role="menu" className="absolute right-1 top-full mt-0.5 z-40 card p-1 w-48 shadow-2xl anim-in">
              {items.map(([label, act, icon, danger]) => (
                <button key={act} role="menuitem" className={`w-full flex items-center gap-2.5 px-2.5 py-2.5 lg:py-2 rounded-md text-[13px] hover:bg-panel3 text-left ${danger ? 'text-danger' : ''}`} onClick={() => { setMenu(false); onAction(act); }}>{icon}{label}</button>
              ))}
            </div>
          </>
        )}
      </div>
    </li>
  );
}

export function ProjectsPage() {
  const { closePage, teams, pageArg } = useAuth();
  const cloud = useStore(s => s.cloud);
  const projectOpen = useStore(s => s.projectOpen);
  const [tab, setTab] = useState<Tab>(pageArg?.tab ?? 'mine');
  const [teamFilter, setTeamFilter] = useState<string | null>(pageArg?.teamId ?? null);
  const [q, setQ] = useState('');
  const [list, setList] = useState<ProjectMeta[] | null>(null);
  const [error, setError] = useState<string | null>(null);
  const [dlg, setDlg] = useState<null | { kind: 'rename' | 'move'; p: ProjectMeta } | { kind: 'save' }>(null);
  const { ask, node } = useConfirm();
  const seq = useRef(0);

  const load = useCallback(async () => {
    const my = ++seq.current;
    try {
      const params = new URLSearchParams();
      if (tab === 'trash') params.set('trash', '1');
      if (q.trim()) params.set('q', q.trim());
      const r = await api.get<{ projects: ProjectMeta[] }>(`/projects?${params}`);
      if (my === seq.current) { setList(r.projects); setError(null); }
    } catch (e) { if (my === seq.current) setError(errMsg(e)); }
  }, [tab, q]);
  useEffect(() => { const t = setTimeout(() => { void load(); }, q ? 250 : 0); return () => clearTimeout(t); }, [load, q]);

  const shown = (list ?? []).filter(p => tab === 'trash' ? true : tab === 'mine' ? p.scope === 'personal' : p.scope === 'team' && (!teamFilter || p.teamId === teamFilter));

  const open = async (p: ProjectMeta) => { if (cloud?.id === p.id) { closePage(); return; } if (!confirmDiscard()) return; await openCloudProject(p.id); };
  const act = async (p: ProjectMeta, a: 'rename' | 'duplicate' | 'move' | 'delete' | 'restore' | 'purge') => {
    try {
      if (a === 'rename') setDlg({ kind: 'rename', p });
      else if (a === 'move') setDlg({ kind: 'move', p });
      else if (a === 'duplicate') { await api.post(`/projects/${p.id}/duplicate`, {}); useStore.getState().showToast('Duplicated', 'ok'); await load(); }
      else if (a === 'delete') {
        if (!(await ask({ title: 'Move to trash?', message: <>“{p.name}” goes to the trash. You can restore it for 30 days.</>, confirmText: 'Move to trash', danger: true }))) return;
        await api.del(`/projects/${p.id}`);
        if (useStore.getState().cloud?.id === p.id) { useStore.setState({ cloud: null, dirty: true }); useStore.getState().showToast('Moved to trash. The open copy stays here as a local project.', 'info'); }
        await load();
      } else if (a === 'restore') { await api.post(`/projects/${p.id}/restore`); useStore.getState().showToast('Restored', 'ok'); await load(); }
      else if (a === 'purge') {
        if (!(await ask({ title: 'Delete forever?', message: <>“{p.name}” and its version history will be permanently deleted. This cannot be undone.</>, confirmText: 'Delete forever', danger: true }))) return;
        await api.del(`/projects/${p.id}?permanent=1`); await load();
      }
    } catch (e) { useStore.getState().showToast(errMsg(e), 'err'); }
  };

  const tabs: [Tab, string][] = [['mine', 'My projects'], ['team', 'Teams'], ['trash', 'Trash']];
  return (
    <PageShell title="Projects" onBack={closePage} wide
      actions={projectOpen && !cloud ? <button className="btn btn-accent" onClick={() => setDlg({ kind: 'save' })}><Cloud size={15} /><span className="hidden sm:inline">Save open project</span><span className="sm:hidden">Save</span></button> : undefined}>
      <div className="flex gap-1 p-0.5 rounded-lg bg-bg border border-line text-[13px]" role="tablist">
        {tabs.map(([t, l]) => <button key={t} role="tab" aria-selected={tab === t} className={`flex-1 py-2 rounded-md font-medium ${tab === t ? 'bg-panel3 text-accent' : 'text-mute'}`} onClick={() => { setTab(t); setList(null); }}>{l}</button>)}
      </div>
      <div className="relative">
        <Search size={14} className="absolute left-3 top-1/2 -translate-y-1/2 text-mute" />
        <input className="input !pl-9" type="search" placeholder="Search projects" value={q} onChange={e => setQ(e.target.value)} aria-label="Search projects" />
      </div>
      {tab === 'team' && teams.length > 0 && (
        <div className="flex gap-1.5 overflow-x-auto pb-1 -mt-1">
          <button className={`shrink-0 px-3 py-1.5 rounded-full border text-[12.5px] ${!teamFilter ? 'border-accent text-accent bg-accent/10' : 'border-line text-mute'}`} onClick={() => setTeamFilter(null)}>All teams</button>
          {teams.map(t => <button key={t.id} className={`shrink-0 px-3 py-1.5 rounded-full border text-[12.5px] ${teamFilter === t.id ? 'border-accent text-accent bg-accent/10' : 'border-line text-mute'}`} onClick={() => setTeamFilter(t.id)}>{t.name} <span className="opacity-60">· {ROLE_LABEL[t.role]}</span></button>)}
        </div>
      )}
      {tab === 'trash' && <Alert kind="info">Projects in the trash are deleted automatically after 30 days.</Alert>}
      {error && <Alert kind="error">{error}</Alert>}
      {list === null && !error ? <Spinner /> : (
        <ul className="space-y-2">
          {shown.map(p => <Row key={p.id} p={p} tab={tab} openId={cloud?.id ?? null} onOpen={() => void open(p)} onAction={a => void act(p, a)} />)}
          {shown.length === 0 && (
            <li className="text-center py-12 text-mute text-sm space-y-3">
              <div>{q ? 'Nothing matches your search.' : tab === 'trash' ? 'The trash is empty.' : tab === 'team' ? (teams.length ? 'No team projects yet.' : 'You are not in a team yet.') : 'No projects here yet.'}</div>
              {tab === 'team' && !teams.length && <button className="btn btn-accent" onClick={() => useAuth.getState().openPage('teams')}><Users size={15} />Create or join a team</button>}
              {tab !== 'trash' && !q && projectOpen && !cloud && <button className="btn btn-accent" onClick={() => setDlg({ kind: 'save' })}><Plus size={15} />Save the open project here</button>}
              {tab !== 'trash' && !q && !projectOpen && <button className="btn btn-accent" onClick={() => { closePage(); useStore.getState().set({ dialog: 'new' }); }}><Plus size={15} />New project</button>}
            </li>
          )}
        </ul>
      )}
      {dlg?.kind === 'rename' && <RenameDialog p={dlg.p} onClose={() => setDlg(null)} onDone={() => { setDlg(null); void load(); }} />}
      {dlg?.kind === 'move' && <MoveDialog project={dlg.p} onClose={() => setDlg(null)} onDone={() => { setDlg(null); void load(); }} />}
      {dlg?.kind === 'save' && <SaveToCloudDialog onClose={() => { setDlg(null); void load(); }} />}
      {node}
    </PageShell>
  );
}
