import { useCallback, useEffect, useState } from 'react';
import { LogOut, Smartphone, Laptop, Download, Trash2, Mail, ShieldCheck } from 'lucide-react';
import { api, errMsg } from './api';
import { useAuth } from './auth';
import { useStore } from '../store';
import { PageShell, Section, Field, PasswordInput, Alert, Spinner, Avatar, Badge, useAction, timeAgo, fmtDate } from './ui';

interface SessionRow { id: string; createdAt: number; lastUsedAt: number; userAgent: string; current: boolean }

export function deviceName(ua: string): { name: string; mobile: boolean } {
  const os = /Android/.test(ua) ? 'Android' : /iPhone|iPad|iPod/.test(ua) ? 'iOS' : /Windows/.test(ua) ? 'Windows' : /Mac OS X/.test(ua) ? 'macOS' : /Linux/.test(ua) ? 'Linux' : 'Unknown system';
  const br = /Edg\//.test(ua) ? 'Edge' : /OPR\//.test(ua) ? 'Opera' : /Firefox\//.test(ua) ? 'Firefox' : /Chrome\//.test(ua) ? 'Chrome' : /Safari\//.test(ua) ? 'Safari' : 'Browser';
  return { name: `${br} on ${os}`, mobile: /Android|iPhone|iPad|iPod|Mobile/.test(ua) };
}

export function AccountPage() {
  const { user, config, closePage, signOut, openPage } = useAuth();
  const [name, setName] = useState(user?.name ?? '');
  const profile = useAction();
  const [saved, setSaved] = useState(false);

  const [cur, setCur] = useState(''); const [pw, setPw] = useState(''); const [pw2, setPw2] = useState('');
  const pwAct = useAction(); const [pwDone, setPwDone] = useState(false);

  const [sessions, setSessions] = useState<SessionRow[] | null>(null);
  const sessAct = useAction();
  const loadSessions = useCallback(async () => { try { setSessions((await api.get<{ sessions: SessionRow[] }>('/auth/sessions')).sessions); } catch (e) { useStore.getState().showToast(errMsg(e), 'err'); } }, []);
  useEffect(() => { void loadSessions(); }, [loadSessions]);

  const exp = useAction();
  const [delOpen, setDelOpen] = useState(false); const [delPw, setDelPw] = useState('');
  const del = useAction();
  const resend = useAction(); const [resent, setResent] = useState(false);

  if (!user) return null;
  const dirtyName = name.trim() !== user.name;

  const saveProfile = () => profile.run(async () => {
    const r = await api.patch<{ user: typeof user }>('/auth/profile', { name });
    useAuth.setState({ user: r.user });
    setSaved(true); setTimeout(() => setSaved(false), 2000);
  });
  const changePassword = () => pwAct.run(async () => {
    await api.post('/auth/password', { currentPassword: cur, newPassword: pw });
    setCur(''); setPw(''); setPw2(''); setPwDone(true); void loadSessions();
  });
  const revoke = (id: string) => sessAct.run(async () => { await api.del(`/auth/sessions/${id}`); await loadSessions(); });
  const revokeOthers = () => sessAct.run(async () => { const r = await api.post<{ revoked: number }>('/auth/sessions/revoke-others'); useStore.getState().showToast(`Signed out ${r.revoked} other device${r.revoked === 1 ? '' : 's'}`, 'ok'); await loadSessions(); });
  const exportData = () => exp.run(async () => {
    const data = await api.get('/auth/export');
    const blob = new Blob([JSON.stringify(data, null, 2)], { type: 'application/json' });
    const a = document.createElement('a');
    a.href = URL.createObjectURL(blob); a.download = 's7-simstudio-my-data.json'; a.click();
    setTimeout(() => URL.revokeObjectURL(a.href), 1000);
  });
  const deleteAccount = () => del.run(async () => {
    await api.post('/auth/delete-account', { password: delPw });
    useAuth.setState({ user: null, teams: [], page: null });
    if (useStore.getState().cloud) useStore.getState().closeProject();
    useStore.getState().showToast('Your account was deleted', 'ok');
  });
  const sendConfirm = () => resend.run(async () => { await api.post('/auth/resend'); setResent(true); });

  return (
    <PageShell title="Account" onBack={closePage} actions={<button className="btn btn-ghost" onClick={() => void signOut()}><LogOut size={15} />Sign out</button>}>
      <div className="card p-4 flex items-center gap-3">
        <Avatar name={user.name} size={48} />
        <div className="min-w-0">
          <div className="font-semibold truncate">{user.name}</div>
          <div className="text-[13px] text-mute truncate">{user.email}</div>
          <div className="flex gap-1.5 mt-1">{user.role === 'admin' && <Badge tone="accent">Administrator</Badge>}{user.emailVerified ? <Badge tone="on">Email confirmed</Badge> : <Badge tone="warn">Email not confirmed</Badge>}</div>
        </div>
      </div>
      {!user.emailVerified && config?.mailEnabled && (
        <Alert kind="warn">
          <div className="flex flex-wrap items-center gap-2">Please confirm your email address.
            {resent ? <span className="text-on">Sent — check your inbox.</span> : <button className="btn !py-1" disabled={resend.busy} onClick={() => void sendConfirm()}><Mail size={14} />Resend link</button>}</div>
        </Alert>
      )}

      <Section title="Profile">
        <Field label="Display name"><input className="input" value={name} maxLength={80} onChange={e => setName(e.target.value)} /></Field>
        {profile.error && <Alert kind="error">{profile.error}</Alert>}
        <button className="btn btn-accent" disabled={!dirtyName || !name.trim() || profile.busy} onClick={() => void saveProfile()}>{saved ? 'Saved ✓' : 'Save name'}</button>
      </Section>

      <Section title="Password" desc="Changing your password signs out all your other devices.">
        <form className="space-y-3" onSubmit={e => { e.preventDefault(); void changePassword(); }}>
          <Field label="Current password"><PasswordInput value={cur} onChange={setCur} /></Field>
          <Field label="New password" hint="At least 10 characters."><PasswordInput value={pw} onChange={setPw} autoComplete="new-password" /></Field>
          <Field label="Repeat new password" error={pw2 && pw2 !== pw ? 'The passwords do not match' : null}><PasswordInput value={pw2} onChange={setPw2} autoComplete="new-password" /></Field>
          {pwAct.error && <Alert kind="error">{pwAct.error}</Alert>}
          {pwDone && <Alert kind="ok">Password changed. Your other devices were signed out.</Alert>}
          <button className="btn btn-accent" type="submit" disabled={pwAct.busy || !cur || pw.length < 10 || pw !== pw2}>{pwAct.busy ? 'Saving…' : 'Change password'}</button>
        </form>
      </Section>

      <Section title="Signed-in devices" desc="Everywhere your account is currently signed in. Remove any device you do not recognise.">
        {sessions === null ? <Spinner /> : (
          <ul className="divide-y divide-line -my-1">
            {sessions.map(s => {
              const d = deviceName(s.userAgent);
              return (
                <li key={s.id} className="py-2.5 flex items-center gap-3">
                  {d.mobile ? <Smartphone size={20} className="text-mute shrink-0" /> : <Laptop size={20} className="text-mute shrink-0" />}
                  <div className="min-w-0 flex-1">
                    <div className="text-[13.5px] font-medium truncate">{d.name} {s.current && <Badge tone="on">This device</Badge>}</div>
                    <div className="text-[12px] text-mute" title={fmtDate(s.createdAt)}>Active {timeAgo(s.lastUsedAt)} · signed in {timeAgo(s.createdAt)}</div>
                  </div>
                  {!s.current && <button className="btn" disabled={sessAct.busy} onClick={() => void revoke(s.id)}>Sign out</button>}
                </li>
              );
            })}
          </ul>
        )}
        {sessions && sessions.length > 1 && <button className="btn" disabled={sessAct.busy} onClick={() => void revokeOthers()}><LogOut size={14} />Sign out all other devices</button>}
      </Section>

      <Section title="Your data" desc="Download your profile, teams and personal projects as one JSON file.">
        {exp.error && <Alert kind="error">{exp.error}</Alert>}
        <button className="btn" disabled={exp.busy} onClick={() => void exportData()}><Download size={15} />{exp.busy ? 'Preparing…' : 'Download my data'}</button>
        <div className="flex gap-3 text-[12.5px]">
          <button className="text-accent hover:underline" onClick={() => openPage('privacy')}>Privacy policy</button>
          <button className="text-accent hover:underline" onClick={() => openPage('terms')}>Terms of use</button>
        </div>
      </Section>

      {user.role === 'admin' && (
        <Section title="Administration"><button className="btn" onClick={() => openPage('admin')}><ShieldCheck size={15} />Open the admin console</button></Section>
      )}

      <Section title="Delete account" danger desc="Permanently deletes your account, your personal projects and your sessions. Teams you own are handed to another member or deleted if nobody else is in them. This cannot be undone.">
        {!delOpen ? (
          <button className="btn !text-danger !border-danger/50" onClick={() => setDelOpen(true)}><Trash2 size={15} />Delete my account…</button>
        ) : (
          <form className="space-y-3" onSubmit={e => { e.preventDefault(); void deleteAccount(); }}>
            <Field label="Confirm with your password"><PasswordInput value={delPw} onChange={setDelPw} /></Field>
            {del.error && <Alert kind="error">{del.error}</Alert>}
            <div className="flex gap-2">
              <button type="button" className="btn flex-1 justify-center" onClick={() => { setDelOpen(false); setDelPw(''); }}>Cancel</button>
              <button type="submit" className="btn flex-1 justify-center !bg-danger/15 !text-danger !border-danger/50" disabled={!delPw || del.busy}>{del.busy ? 'Deleting…' : 'Delete everything'}</button>
            </div>
          </form>
        )}
      </Section>
    </PageShell>
  );
}
