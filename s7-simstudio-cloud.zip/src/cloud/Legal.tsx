import { Mail, Phone, Copy, Check, Cloud, WifiOff } from 'lucide-react';
import { useState } from 'react';
import { useAuth } from './auth';
import { PageShell, Alert, Section, copyText } from './ui';
import { BRAND, mailHref, telHref, useContact } from '../brand';
import { OFFLINE_BUILD } from '../env';

function useOperator() {
  const c = useContact();
  return { name: c.name, email: c.email, phone: c.phone };
}
const H = ({ children }: { children: React.ReactNode }) => <h2 className="text-[15px] font-semibold mt-5 mb-1">{children}</h2>;
const P = ({ children }: { children: React.ReactNode }) => <p className="text-[13.5px] leading-relaxed text-ink/90">{children}</p>;
const UL = ({ children }: { children: React.ReactNode }) => <ul className="list-disc pl-5 space-y-1 text-[13.5px] leading-relaxed text-ink/90">{children}</ul>;

const Template = () => <Alert kind="warn"><b>Template.</b> This text is a starting point written for a small, non-commercial simulator service. The operator of this installation is responsible for checking it against the laws that apply to them and adapting it (an administrator can set the operator name and contact email in Admin → Settings).</Alert>;

export function TermsPage() {
  const { closePage } = useAuth();
  const op = useOperator();
  return (
    <PageShell title="Terms of use" onBack={closePage}>
      <Template />
      <div className="card p-4 space-y-2">
        <P>These terms apply to your use of S7 SimStudio ("the service"), provided by {op.name}.</P>
        <H>1. What the service is</H>
        <P>S7 SimStudio is an educational simulator for ladder logic and PLC concepts. It is <b>not</b> a Siemens product, it is not affiliated with or endorsed by Siemens AG, and SIMATIC, S7 and TIA Portal are trademarks of their owners.</P>
        <H>2. Not for safety-critical use</H>
        <P>Programs written or tested here must never be used to control real machines or processes without independent verification on the real equipment by qualified people. The simulation is simplified and may differ from real controllers.</P>
        <H>3. Your account</H>
        <UL><li>Give correct information and keep your password secret. You are responsible for activity under your account.</li><li>You must be allowed to enter into this agreement where you live.</li><li>Tell us if you suspect unauthorised access.</li></UL>
        <H>4. Your content</H>
        <P>You keep all rights to the projects you create. You allow the service to store, process and display them to you and to the people you choose to share them with (for example your team), only to run the service.</P>
        <H>5. Acceptable use</H>
        <UL><li>No attempts to break, overload or gain unauthorised access to the service or other accounts.</li><li>No unlawful content, no malware, no automated bulk account creation.</li><li>Respect storage limits shown in the app.</li></UL>
        <H>6. Availability and changes</H>
        <P>The service is provided "as is" without guarantees of uninterrupted availability. Features and limits may change. Please keep your own backups: you can export any project as a file at any time.</P>
        <H>7. Liability</H>
        <P>To the extent permitted by law, the operator is not liable for indirect or consequential loss, or for data loss, arising from use of the service.</P>
        <H>8. Ending use</H>
        <P>You can delete your account at any time in Account settings. The operator may suspend accounts that break these terms.</P>
        <H>9. Contact</H><P>Questions about these terms: {op.email}{op.phone ? ` · ${op.phone}` : ''}</P>
      </div>
    </PageShell>
  );
}

export function PrivacyPage() {
  const { closePage } = useAuth();
  const op = useOperator();
  return (
    <PageShell title="Privacy policy" onBack={closePage}>
      <Template />
      <div className="card p-4 space-y-2">
        <P>This explains what {op.name} does with your data when you use S7 SimStudio with an account. Using the app without an account stores nothing on the server.</P>
        <H>What we store</H>
        <UL>
          <li><b>Account:</b> your name, email address and a salted hash of your password (we never store the password itself).</li>
          <li><b>Projects:</b> the PLC projects you save to the cloud, their version history, and team membership and roles.</li>
          <li><b>Security records:</b> sign-in sessions (device type, last use), and an activity log of security-relevant events (sign-ins, changes made by administrators) including IP addresses, kept for up to 180 days.</li>
        </UL>
        <H>Cookies</H>
        <P>One cookie is used: a strictly necessary, secure session cookie that keeps you signed in. We do not use advertising or analytics cookies and we do not track you across sites. Your light/dark theme choice is kept in your browser's local storage.</P>
        <H>Who processes data for us</H>
        <UL><li>Hosting provider (Vercel) – serves the app and runs the server code.</li><li>Database provider – stores the data listed above.</li><li>Email provider – only if enabled by the operator, to send password-reset and confirmation emails.</li></UL>
        <H>Why we use it</H>
        <P>To provide the service you asked for (accounts, saving, syncing and sharing projects) and to keep it secure.</P>
        <H>Your rights</H>
        <UL><li><b>Access and portability:</b> Account → "Download my data".</li><li><b>Correction:</b> change your name in Account settings.</li><li><b>Deletion:</b> Account → "Delete account" removes your account and personal projects immediately. Backups at the database provider may persist for a short, provider-defined period.</li></UL>
        <H>Sharing</H>
        <P>Your projects are private unless you put them in a team. Team members see team projects according to their role. Administrators can see account details and project names and sizes, not project contents.</P>
        <H>Contact</H><P>Privacy questions: {op.email}{op.phone ? ` · ${op.phone}` : ''}</P>
      </div>
    </PageShell>
  );
}

function CopyBtn({ text, label }: { text: string; label: string }) {
  const [done, setDone] = useState(false);
  return <button className="btn btn-ghost btn-icon" aria-label={`Copy ${label}`} onClick={async () => { if (await copyText(text)) { setDone(true); setTimeout(() => setDone(false), 1600); } }}>{done ? <Check size={16} className="text-on" /> : <Copy size={16} />}</button>;
}

export function AboutPage() {
  const { closePage, openPage, cloudAvailable } = useAuth();
  const c = useContact();
  return (
    <PageShell title="About & contact" onBack={closePage}>
      <div className="card p-5 flex items-center gap-4">
        <div className="w-14 h-14 shrink-0 rounded-2xl bg-gradient-to-br from-accent to-accent2 flex items-center justify-center shadow-lg shadow-accent/20" aria-hidden>
          <svg width="30" height="30" viewBox="0 0 24 24" fill="none" stroke="white" strokeWidth="2.2" strokeLinecap="round"><path d="M3 4v16M21 4v16M3 12h4M9 7v10M13 7v10M17 12h4M13 12h2" /><path d="M15 9q3 3 0 6" /></svg>
        </div>
        <div className="min-w-0">
          <div className="text-xl font-bold tracking-tight">{BRAND.appName}</div>
          <div className="text-[13px] text-mute">Version {BRAND.version}</div>
          <div className="text-[13.5px] mt-1">Created by <b>{c.name}</b></div>
        </div>
      </div>

      <Section title="Contact" desc="Questions, feedback, bug reports or ideas are welcome.">
        <div className="flex items-center gap-2">
          <a className="btn flex-1 justify-start min-w-0" href={mailHref(c.email)}><Mail size={16} className="shrink-0" /><span className="truncate">{c.email}</span></a>
          <CopyBtn text={c.email} label="email address" />
        </div>
        <div className="flex items-center gap-2">
          <a className="btn flex-1 justify-start" href={telHref(c.phone)}><Phone size={16} className="shrink-0" />{c.phone}</a>
          <CopyBtn text={c.phone} label="phone number" />
        </div>
      </Section>

      <Section title="This edition">
        {OFFLINE_BUILD
          ? <div className="flex gap-3 text-[13.5px] leading-snug"><WifiOff size={18} className="shrink-0 text-accent2 mt-0.5" /><div><b>Offline edition.</b> Everything runs on your device and works without internet. Projects are kept as files (Export / Open). Accounts, cloud projects, sync and teams belong to the online version.</div></div>
          : cloudAvailable
            ? <div className="flex gap-3 text-[13.5px] leading-snug"><Cloud size={18} className="shrink-0 text-accent2 mt-0.5" /><div><b>Online version.</b> Sign in to save projects to the cloud, sync across devices and work with a team. The simulator itself also works offline once the app is installed.</div></div>
            : <div className="flex gap-3 text-[13.5px] leading-snug"><WifiOff size={18} className="shrink-0 text-accent2 mt-0.5" /><div><b>Local mode.</b> The server cannot be reached right now, so projects are kept as files (Export / Open). Accounts return when you are back online.</div></div>}
        {cloudAvailable && (
          <div className="flex gap-4 text-[13px]">
            <button className="text-accent hover:underline" onClick={() => openPage('terms')}>Terms of use</button>
            <button className="text-accent hover:underline" onClick={() => openPage('privacy')}>Privacy policy</button>
          </div>
        )}
      </Section>

      <p className="text-[12px] text-mute leading-relaxed px-1">
        {BRAND.appName} is an educational simulator. It is not a Siemens product and is not affiliated with or endorsed by Siemens AG; SIMATIC, S7 and TIA Portal are trademarks of Siemens AG. Do not use it to control real machines or processes.
      </p>
    </PageShell>
  );
}
