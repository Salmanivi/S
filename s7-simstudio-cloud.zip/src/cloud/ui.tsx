import { useCallback, useEffect, useRef, useState, type ReactNode } from 'react';
import { createPortal } from 'react-dom';
import { ArrowLeft, AlertCircle, CheckCircle2, Info, Eye, EyeOff, Copy, Check } from 'lucide-react';
import { Modal } from '../components/Modal';

export function PageShell({ title, onBack, actions, wide, children }: { title: string; onBack: () => void; actions?: ReactNode; wide?: boolean; children: ReactNode }) {
  useEffect(() => {
    const h = (e: KeyboardEvent) => { if (e.key === 'Escape' && !document.querySelector('[data-modal], [role=menu]')) onBack(); };
    window.addEventListener('keydown', h);
    return () => window.removeEventListener('keydown', h);
  }, [onBack]);
  // The page lives in a portal outside #root; while it is open the app behind it is inert, so keyboard and
  // screen-reader users cannot reach hidden controls.
  useEffect(() => {
    const root = document.getElementById('root');
    root?.setAttribute('inert', '');
    return () => root?.removeAttribute('inert');
  }, []);
  return createPortal(
    <div className="fixed inset-0 z-40 bg-bg text-ink flex flex-col" role="dialog" aria-modal="true" aria-label={title}>
      <header className="shrink-0 flex items-center gap-1 border-b border-line bg-panel pl-1 pr-2 pt-[env(safe-area-inset-top)] min-h-[3rem]">
        <button className="btn btn-ghost btn-icon" onClick={onBack} aria-label="Back"><ArrowLeft size={19} /></button>
        <h1 className="font-semibold text-[15px] truncate flex-1">{title}</h1>
        {actions}
      </header>
      <div className="flex-1 overflow-y-auto overscroll-contain">
        <div className={`mx-auto w-full ${wide ? 'max-w-5xl' : 'max-w-2xl'} p-3 sm:p-6 pb-[calc(2.5rem+env(safe-area-inset-bottom))] space-y-4`}>{children}</div>
      </div>
    </div>,
    document.body,
  );
}

export function Section({ title, desc, children, danger }: { title?: string; desc?: ReactNode; children: ReactNode; danger?: boolean }) {
  return (
    <section className={`card p-4 space-y-3 ${danger ? '!border-danger/40' : ''}`}>
      {(title || desc) && (
        <div>
          {title && <h2 className={`text-[14.5px] font-semibold ${danger ? 'text-danger' : ''}`}>{title}</h2>}
          {desc && <p className="text-[12.5px] text-mute mt-0.5 leading-snug">{desc}</p>}
        </div>
      )}
      {children}
    </section>
  );
}

export function Field({ label, hint, error, children }: { label: string; hint?: ReactNode; error?: string | null; children: ReactNode }) {
  return (
    <label className="block">
      <div className="label mb-1">{label}</div>
      {children}
      {error ? <div className="text-[12px] text-danger mt-1" role="alert">{error}</div> : hint ? <div className="text-[11.5px] text-mute mt-1 leading-snug">{hint}</div> : null}
    </label>
  );
}

export function PasswordInput({ value, onChange, autoComplete = 'current-password', placeholder, onEnter }: { value: string; onChange: (v: string) => void; autoComplete?: string; placeholder?: string; onEnter?: () => void }) {
  const [show, setShow] = useState(false);
  return (
    <div className="relative">
      <input className="input !pr-11" type={show ? 'text' : 'password'} value={value} onChange={e => onChange(e.target.value)} autoComplete={autoComplete} placeholder={placeholder}
        onKeyDown={e => { if (e.key === 'Enter' && onEnter) onEnter(); }} />
      <button type="button" className="absolute right-0 top-0 bottom-0 px-3 text-mute hover:text-ink" aria-label={show ? 'Hide password' : 'Show password'} onClick={() => setShow(s => !s)}>
        {show ? <EyeOff size={16} /> : <Eye size={16} />}
      </button>
    </div>
  );
}

export function Alert({ kind = 'info', children }: { kind?: 'info' | 'error' | 'ok' | 'warn'; children: ReactNode }) {
  const tone = { info: 'border-accent2/40 bg-accent2/10 text-ink', error: 'border-danger/40 bg-danger/10 text-danger', ok: 'border-on/40 bg-on/10 text-on', warn: 'border-warn/40 bg-warn/10 text-warn' }[kind];
  const Icon = kind === 'error' || kind === 'warn' ? AlertCircle : kind === 'ok' ? CheckCircle2 : Info;
  return <div role={kind === 'error' ? 'alert' : 'status'} className={`flex gap-2 rounded-lg border px-3 py-2 text-[13px] leading-snug ${tone}`}><Icon size={16} className="shrink-0 mt-0.5" /><div className="min-w-0">{children}</div></div>;
}

export function Spinner({ label = 'Loading…' }: { label?: string }) {
  return <div className="flex items-center justify-center gap-2 py-10 text-mute text-sm" role="status"><span className="w-4 h-4 rounded-full border-2 border-line border-t-accent animate-spin" />{label}</div>;
}

export function Avatar({ name, size = 32 }: { name: string; size?: number }) {
  const initials = name.trim().split(/\s+/).slice(0, 2).map(w => w[0]?.toUpperCase() ?? '').join('') || '?';
  let h = 0; for (const c of name) h = (h * 31 + c.charCodeAt(0)) % 360;
  return <span aria-hidden className="shrink-0 inline-flex items-center justify-center rounded-full font-semibold text-white select-none" style={{ width: size, height: size, fontSize: size * 0.38, background: `hsl(${h} 45% 42%)` }}>{initials}</span>;
}

export function Badge({ children, tone = 'mute' }: { children: ReactNode; tone?: 'mute' | 'accent' | 'on' | 'warn' | 'danger' }) {
  const t = { mute: 'bg-panel3 text-mute', accent: 'bg-accent/15 text-accent', on: 'bg-on/15 text-on', warn: 'bg-warn/15 text-warn', danger: 'bg-danger/15 text-danger' }[tone];
  return <span className={`inline-flex items-center rounded px-1.5 py-0.5 text-[10.5px] font-semibold uppercase tracking-wide ${t}`}>{children}</span>;
}

export const fmtDate = (ts: number) => new Date(ts).toLocaleString(undefined, { dateStyle: 'medium', timeStyle: 'short' });
export const fmtBytes = (n: number) => (n < 1024 ? `${n} B` : n < 1024 * 1024 ? `${(n / 1024).toFixed(n < 10240 ? 1 : 0)} KB` : `${(n / 1048576).toFixed(1)} MB`);
export function timeAgo(ts: number): string {
  const s = Math.max(0, (Date.now() - ts) / 1000);
  if (s < 45) return 'just now';
  if (s < 3600) return `${Math.round(s / 60)} min ago`;
  if (s < 86400) return `${Math.round(s / 3600)} h ago`;
  if (s < 86400 * 14) return `${Math.round(s / 86400)} d ago`;
  return new Date(ts).toLocaleDateString(undefined, { dateStyle: 'medium' });
}

export async function copyText(text: string): Promise<boolean> {
  try { await navigator.clipboard.writeText(text); return true; }
  catch {
    try {
      const t = document.createElement('textarea');
      t.value = text; t.style.position = 'fixed'; t.style.opacity = '0';
      document.body.appendChild(t); t.select();
      const ok = document.execCommand('copy');
      t.remove();
      return ok;
    } catch { return false; }
  }
}

export function CopyField({ value }: { value: string }) {
  const [done, setDone] = useState(false);
  return (
    <div className="flex gap-2">
      <input className="input font-mono !text-[12px]" readOnly value={value} onFocus={e => e.currentTarget.select()} aria-label="Link" />
      <button className="btn shrink-0" onClick={async () => { if (await copyText(value)) { setDone(true); setTimeout(() => setDone(false), 1800); } }}>{done ? <><Check size={15} />Copied</> : <><Copy size={15} />Copy</>}</button>
    </div>
  );
}

interface ConfirmOpts { title: string; message: ReactNode; confirmText?: string; danger?: boolean; requireText?: string }
/** Promise based confirmation dialog: `if (!(await ask({...}))) return;` — render `node` once in the component. */
export function useConfirm() {
  const [state, setState] = useState<(ConfirmOpts & { resolve: (v: boolean) => void }) | null>(null);
  const [typed, setTyped] = useState('');
  const ask = useCallback((o: ConfirmOpts) => new Promise<boolean>(resolve => { setTyped(''); setState({ ...o, resolve }); }), []);
  const done = (v: boolean) => { state?.resolve(v); setState(null); };
  const node = state ? (
    <Modal title={state.title} onClose={() => done(false)}>
      <div className="p-4 space-y-3 text-[13.5px] leading-relaxed">
        <div>{state.message}</div>
        {state.requireText && <input className="input" autoFocus value={typed} onChange={e => setTyped(e.target.value)} placeholder={state.requireText} aria-label="Confirmation text" />}
        <div className="flex gap-2 pt-1">
          <button className="btn flex-1 justify-center" onClick={() => done(false)}>Cancel</button>
          <button className={`btn flex-1 justify-center ${state.danger ? '!bg-danger/15 !text-danger !border-danger/50' : 'btn-accent'}`} disabled={!!state.requireText && typed.trim().toLowerCase() !== state.requireText.toLowerCase()} onClick={() => done(true)}>{state.confirmText ?? 'Confirm'}</button>
        </div>
      </div>
    </Modal>
  ) : null;
  return { ask, node };
}

/** Runs an async action with a busy flag and an error message. */
export function useAction() {
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const alive = useRef(true);
  useEffect(() => () => { alive.current = false; }, []);
  const run = useCallback(async <T,>(fn: () => Promise<T>): Promise<T | undefined> => {
    setBusy(true); setError(null);
    try { return await fn(); }
    catch (e) { if (alive.current) setError(e instanceof Error ? e.message : 'Something went wrong'); return undefined; }
    finally { if (alive.current) setBusy(false); }
  }, []);
  return { busy, error, setError, run };
}
