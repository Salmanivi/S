import { useCallback, useEffect, useState } from 'react';
import { Search, UserPlus, Ban, CheckCircle2, KeyRound, LogOut, Trash2, ShieldCheck, AlertTriangle } from 'lucide-react';
import { api, errMsg } from './api';
import { useAuth } from './auth';
import { useStore } from '../store';
import { Modal } from '../components/Shell';
import type { User } from './types';
import { PageShell, Section, Field, PasswordInput, Alert, Spinner, Avatar, Badge, CopyField, useAction, useConfirm, timeAgo, fmtDate, fmtBytes } from './ui';

type Tab = 'overview' | 'users' | 'projects' | 'teams' | 'audit' | 'settings';
const toast = (t: string, k: 'ok' | 'err' | 'info' = 'info') => useStore.getState().showToast(t, k);

// ---------------------------------------------------------------- overview
interface Stats { users: { total: number; disabled: number; admins: number; activeLast7Days: number }; projects: { total: number; trashed: number }; teams: number; storageBytes: number; last24h: { logins: number; failedLogins: number }; signups14d: { day: number; count: number }[] }
interface Health { ok: boolean; version: string; checks: Record<string, boolean | string>; adminCreated: boolean | null }

const Stat = ({ label, value, sub, warn }: { label: string; value: React.ReactNode; sub?: string; warn?: boolean }) => (
  <div className="card p-3"><div className="text-[11px] uppercase tracking-wide text-mute font-semibold">{label}</div><div className={`text-2xl font-bold mt-0.5 ${warn ? 'text-warn' : ''}`}>{value}</div>{sub && <div className="text-[11.5px] text-mute">{sub}</div>}</div>
);

function Overview() {
  const [s, setS] = useState<Stats | null>(null);
  const [h, setH] = useState<Health | null>(null);
  const [err, setErr] = useState<string | null>(null);
  useEffect(() => { api.get<Stats>('/admin/stats').then(setS).catch(e => setErr(errMsg(e))); api.get<Health>('/health').then(setH).catch(() => undefined); }, []);
  if (err) return <Alert kind="error">{err}</Alert>;
  if (!s) return <Spinner />;
  const max = Math.max(1, ...s.signups14d.map(d => d.count));
  const hints: [string, string, string][] = h ? [
    ['database', 'Database connection', 'Check DATABASE_URL in the Vercel environment variables.'],
    ['appSecret', 'APP_SECRET (32+ characters)', 'Add a long random APP_SECRET in Vercel.'],
    ['cronSecret', 'CRON_SECRET (daily cleanup)', 'Add CRON_SECRET so expired sessions and old trash are cleaned up.'],
    ['appUrl', 'APP_URL (links in emails)', 'Set APP_URL to your public address, e.g. https://your-app.vercel.app'],
    ['mail', 'Email provider', 'Optional: enables password-reset and confirmation emails.'],
  ] : [];
  return (
    <>
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-2.5">
        <Stat label="Users" value={s.users.total} sub={`${s.users.activeLast7Days} active in 7 days`} />
        <Stat label="Projects" value={s.projects.total} sub={`${s.projects.trashed} in trash`} />
        <Stat label="Teams" value={s.teams} />
        <Stat label="Storage" value={fmtBytes(s.storageBytes)} sub="projects + history" />
        <Stat label="Sign-ins (24 h)" value={s.last24h.logins} />
        <Stat label="Failed sign-ins (24 h)" value={s.last24h.failedLogins} warn={s.last24h.failedLogins > 20} />
        <Stat label="Administrators" value={s.users.admins} />
        <Stat label="Disabled accounts" value={s.users.disabled} />
      </div>
      <Section title="New accounts, last 14 days">
        <svg viewBox="0 0 280 70" className="w-full h-20" role="img" aria-label={`New accounts per day: ${s.signups14d.map(d => d.count).join(', ')}`}>
          {s.signups14d.map((d, i) => { const hgt = Math.max(2, (d.count / max) * 56); return <rect key={d.day} x={i * 20 + 2} y={62 - hgt} width="15" height={hgt} rx="2" fill="var(--c-accent)" opacity={d.count ? 0.9 : 0.25}><title>{new Date(d.day).toLocaleDateString()}: {d.count}</title></rect>; })}
        </svg>
      </Section>
      {h && (
        <Section title="Deployment health" desc={`Version ${h.version}`}>
          <ul className="space-y-1.5">
            {hints.map(([k, label, hint]) => {
              const v = h.checks[k]; const ok = v === true || v === 'ok';
              return <li key={k} className="flex gap-2 text-[13px]">{ok ? <CheckCircle2 size={16} className="text-on shrink-0 mt-0.5" /> : <AlertTriangle size={16} className={`${k === 'mail' ? 'text-mute' : 'text-warn'} shrink-0 mt-0.5`} />}<span><b className="font-medium">{label}</b>{!ok && <span className="block text-[12px] text-mute">{hint}{typeof v === 'string' && v !== 'ok' ? ` (${v})` : ''}</span>}</span></li>;
            })}
          </ul>
        </Section>
      )}
    </>
  );
}

// ---------------------------------------------------------------- users
interface UserRow extends User { projectCount: number; teamCount: number }
interface UserDetail { user: User; activeSessions: number; projects: { count: number; bytes: number }; teams: { id: string; name: string; role: string }[]; recent: { ts: number; action: string; ip: string | null }[] }

function NewUserDialog({ onClose, onDone }: { onClose: () => void; onDone: () => void }) {
  const [f, setF] = useState({ name: '', email: '', password: '', role: 'user' });
  const { busy, error, run } = useAction();
  const go = () => run(async () => { await api.post('/admin/users', f); toast('User created', 'ok'); onDone(); });
  return (
    <Modal title="Add a user" onClose={onClose}>
      <form className="p-4 space-y-3" onSubmit={e => { e.preventDefault(); void go(); }}>
        <Field label="Name"><input className="input" value={f.name} onChange={e => setF({ ...f, name: e.target.value })} /></Field>
        <Field label="Email"><input className="input" type="email" autoCapitalize="none" value={f.email} onChange={e => setF({ ...f, email: e.target.value })} /></Field>
        <Field label="Temporary password" hint="At least 10 characters. Ask the user to change it after signing in."><PasswordInput value={f.password} onChange={v => setF({ ...f, password: v })} autoComplete="new-password" /></Field>
        <Field label="Role"><select className="input" value={f.role} onChange={e => setF({ ...f, role: e.target.value })}><option value="user">User</option><option value="admin">Administrator</option></select></Field>
        {error && <Alert kind="error">{error}</Alert>}
        <div className="flex gap-2"><button type="button" className="btn flex-1 justify-center" onClick={onClose}>Cancel</button><button className="btn btn-accent flex-1 justify-center" type="submit" disabled={busy || !f.name.trim() || !f.email || f.password.length < 10}>Create</button></div>
      </form>
    </Modal>
  );
}

function UserDialog({ id, onClose, onChanged }: { id: string; onClose: () => void; onChanged: () => void }) {
  const me = useAuth(s => s.user);
  const [d, setD] = useState<UserDetail | null>(null);
  const [link, setLink] = useState<string | null>(null);
  const act = useAction();
  const { ask, node } = useConfirm();
  const load = useCallback(async () => { try { setD(await api.get<UserDetail>(`/admin/users/${id}`)); } catch (e) { toast(errMsg(e), 'err'); onClose(); } }, [id, onClose]);
  useEffect(() => { void load(); }, [load]);
  if (!d) return <Modal title="User" onClose={onClose}><Spinner /></Modal>;
  const u = d.user, self = u.id === me?.id;
  const patch = (body: object, msg: string) => act.run(async () => { await api.patch(`/admin/users/${id}`, body); toast(msg, 'ok'); await load(); onChanged(); });
  return (
    <Modal title="User" onClose={onClose}>
      <div className="p-4 space-y-4">
        <div className="flex items-center gap-3"><Avatar name={u.name} size={44} /><div className="min-w-0"><div className="font-semibold truncate">{u.name}</div><div className="text-[13px] text-mute truncate">{u.email}</div>
          <div className="flex gap-1.5 mt-1 flex-wrap">{u.role === 'admin' && <Badge tone="accent">Admin</Badge>}{u.status === 'disabled' && <Badge tone="danger">Disabled</Badge>}{u.emailVerified ? <Badge tone="on">Email confirmed</Badge> : <Badge tone="warn">Unconfirmed</Badge>}</div></div></div>
        <dl className="grid grid-cols-2 gap-x-4 gap-y-1.5 text-[13px]">
          <dt className="text-mute">Created</dt><dd>{fmtDate(u.createdAt)}</dd>
          <dt className="text-mute">Last sign-in</dt><dd>{u.lastLoginAt ? timeAgo(u.lastLoginAt) : 'Never'}</dd>
          <dt className="text-mute">Active sessions</dt><dd>{d.activeSessions}</dd>
          <dt className="text-mute">Projects</dt><dd>{d.projects.count} ({fmtBytes(d.projects.bytes)})</dd>
          <dt className="text-mute">Teams</dt><dd>{d.teams.length ? d.teams.map(t => `${t.name} (${t.role})`).join(', ') : '—'}</dd>
        </dl>
        {act.error && <Alert kind="error">{act.error}</Alert>}
        {link && <div className="space-y-1.5"><Alert kind="ok">Send this one-time link to the user. It works for 60 minutes and signs them out everywhere when used.</Alert><CopyField value={link} /></div>}
        <div className="flex flex-wrap gap-2">
          {!self && <button className="btn" disabled={act.busy} onClick={() => void patch({ role: u.role === 'admin' ? 'user' : 'admin' }, u.role === 'admin' ? 'Now a regular user' : 'Now an administrator')}><ShieldCheck size={15} />{u.role === 'admin' ? 'Remove admin' : 'Make admin'}</button>}
          {!self && (u.status === 'active'
            ? <button className="btn" disabled={act.busy} onClick={() => void patch({ status: 'disabled' }, 'Account disabled')}><Ban size={15} />Disable</button>
            : <button className="btn" disabled={act.busy} onClick={() => void patch({ status: 'active' }, 'Account enabled')}><CheckCircle2 size={15} />Enable</button>)}
          {!u.emailVerified && <button className="btn" disabled={act.busy} onClick={() => void patch({ emailVerified: true }, 'Marked as confirmed')}><CheckCircle2 size={15} />Mark email confirmed</button>}
          <button className="btn" disabled={act.busy} onClick={() => void act.run(async () => { setLink((await api.post<{ link: string }>(`/admin/users/${id}/reset-link`)).link); })}><KeyRound size={15} />Reset link</button>
          <button className="btn" disabled={act.busy} onClick={() => void act.run(async () => { const r = await api.post<{ revoked: number }>(`/admin/users/${id}/revoke-sessions`); toast(`Signed out ${r.revoked} session(s)`, 'ok'); await load(); })}><LogOut size={15} />Sign out everywhere</button>
          {!self && <button className="btn !text-danger !border-danger/50" disabled={act.busy} onClick={async () => {
            if (!(await ask({ title: 'Delete this user?', message: <>This permanently deletes <b>{u.email}</b>, their personal projects and sessions. Teams they solely own are handed over or deleted. Type the email to confirm.</>, confirmText: 'Delete user', danger: true, requireText: u.email }))) return;
            await act.run(async () => { await api.post(`/admin/users/${id}/delete`, { confirmEmail: u.email }); toast('User deleted', 'ok'); onChanged(); onClose(); });
          }}><Trash2 size={15} />Delete…</button>}
        </div>
        {d.recent.length > 0 && <div><div className="label mb-1">Recent activity</div><ul className="text-[12.5px] space-y-0.5 text-mute">{d.recent.map((e, i) => <li key={i}><span className="font-mono">{e.action}</span> · {timeAgo(e.ts)}{e.ip ? ` · ${e.ip}` : ''}</li>)}</ul></div>}
      </div>
      {node}
    </Modal>
  );
}

function Users() {
  const [q, setQ] = useState(''); const [status, setStatus] = useState(''); const [role, setRole] = useState('');
  const [rows, setRows] = useState<UserRow[] | null>(null); const [total, setTotal] = useState(0); const [err, setErr] = useState<string | null>(null);
  const [sel, setSel] = useState<string | null>(null); const [adding, setAdding] = useState(false);
  const fetchPage = useCallback(async (offset: number) => {
    const p = new URLSearchParams({ limit: '25', offset: String(offset) });
    if (q.trim()) p.set('q', q.trim()); if (status) p.set('status', status); if (role) p.set('role', role);
    return api.get<{ total: number; users: UserRow[] }>(`/admin/users?${p}`);
  }, [q, status, role]);
  const load = useCallback(async () => { try { const r = await fetchPage(0); setRows(r.users); setTotal(r.total); setErr(null); } catch (e) { setErr(errMsg(e)); } }, [fetchPage]);
  useEffect(() => { const t = setTimeout(() => { void load(); }, q ? 250 : 0); return () => clearTimeout(t); }, [load, q]);
  const more = async () => { const r = await fetchPage(rows?.length ?? 0); setRows(x => [...(x ?? []), ...r.users]); };
  return (
    <>
      <div className="flex gap-2 flex-wrap">
        <div className="relative flex-1 min-w-[180px]"><Search size={14} className="absolute left-3 top-1/2 -translate-y-1/2 text-mute" /><input className="input !pl-9" type="search" placeholder="Search name or email" value={q} onChange={e => setQ(e.target.value)} aria-label="Search users" /></div>
        <select className="input !w-auto" value={status} onChange={e => setStatus(e.target.value)} aria-label="Status filter"><option value="">Any status</option><option value="active">Active</option><option value="disabled">Disabled</option></select>
        <select className="input !w-auto" value={role} onChange={e => setRole(e.target.value)} aria-label="Role filter"><option value="">Any role</option><option value="user">Users</option><option value="admin">Admins</option></select>
        <button className="btn btn-accent" onClick={() => setAdding(true)}><UserPlus size={15} />Add</button>
      </div>
      {err && <Alert kind="error">{err}</Alert>}
      {rows === null ? <Spinner /> : (
        <>
          <div className="text-[12px] text-mute">{total} user{total === 1 ? '' : 's'}</div>
          <ul className="space-y-2">
            {rows.map(u => (
              <li key={u.id}><button className="card w-full p-3 flex items-center gap-3 text-left hover:!border-accent/50" onClick={() => setSel(u.id)}>
                <Avatar name={u.name} />
                <span className="min-w-0 flex-1"><span className="flex gap-1.5 items-center flex-wrap"><span className="font-semibold text-[14px] truncate">{u.name}</span>{u.role === 'admin' && <Badge tone="accent">Admin</Badge>}{u.status === 'disabled' && <Badge tone="danger">Disabled</Badge>}{!u.emailVerified && <Badge tone="warn">Unconfirmed</Badge>}</span>
                  <span className="block text-[12px] text-mute truncate">{u.email}</span>
                  <span className="block text-[11.5px] text-mute">{u.projectCount} project{u.projectCount === 1 ? '' : 's'} · {u.teamCount} team{u.teamCount === 1 ? '' : 's'} · {u.lastLoginAt ? `seen ${timeAgo(u.lastLoginAt)}` : 'never signed in'}</span></span>
              </button></li>
            ))}
            {rows.length === 0 && <li className="text-center text-sm text-mute py-8">No users match.</li>}
          </ul>
          {rows.length < total && <button className="btn w-full justify-center" onClick={() => void more()}>Load more</button>}
        </>
      )}
      {sel && <UserDialog id={sel} onClose={() => setSel(null)} onChanged={() => void load()} />}
      {adding && <NewUserDialog onClose={() => setAdding(false)} onDone={() => { setAdding(false); void load(); }} />}
    </>
  );
}

// ---------------------------------------------------------------- projects / teams
function Projects() {
  const [q, setQ] = useState(''); const [rows, setRows] = useState<any[] | null>(null); const [total, setTotal] = useState(0);
  const fetchPage = useCallback((offset: number) => api.get<{ total: number; projects: any[] }>(`/admin/projects?limit=25&offset=${offset}${q.trim() ? `&q=${encodeURIComponent(q.trim())}` : ''}`), [q]);
  useEffect(() => { const t = setTimeout(() => { fetchPage(0).then(r => { setRows(r.projects); setTotal(r.total); }).catch(e => toast(errMsg(e), 'err')); }, q ? 250 : 0); return () => clearTimeout(t); }, [fetchPage, q]);
  return (
    <>
      <Alert kind="info">Administrators see project names, owners and sizes only. Project contents stay private to their owners and teams.</Alert>
      <input className="input" type="search" placeholder="Search project names" value={q} onChange={e => setQ(e.target.value)} aria-label="Search projects" />
      {rows === null ? <Spinner /> : <>
        <div className="text-[12px] text-mute">{total} project{total === 1 ? '' : 's'}</div>
        <ul className="space-y-2">{rows.map(p => <li key={p.id} className="card p-3 text-[13px]"><div className="font-semibold">{p.name} {p.trashed && <Badge tone="warn">Trash</Badge>}</div><div className="text-mute text-[12px]">{p.owner} · {fmtBytes(p.sizeBytes)} · rev {p.revision} · {timeAgo(p.updatedAt)}</div></li>)}</ul>
        {rows.length < total && <button className="btn w-full justify-center" onClick={() => void fetchPage(rows.length).then(r => setRows(x => [...(x ?? []), ...r.projects]))}>Load more</button>}
      </>}
    </>
  );
}
function Teams() {
  const [rows, setRows] = useState<any[] | null>(null);
  useEffect(() => { api.get<{ teams: any[] }>('/admin/teams').then(r => setRows(r.teams)).catch(e => toast(errMsg(e), 'err')); }, []);
  if (!rows) return <Spinner />;
  return <ul className="space-y-2">{rows.map(t => <li key={t.id} className="card p-3 text-[13px]"><div className="font-semibold">{t.name}</div><div className="text-mute text-[12px]">{t.members} member(s) · {t.projects} project(s) · created {timeAgo(t.createdAt)}</div></li>)}{rows.length === 0 && <li className="text-center text-sm text-mute py-8">No teams yet.</li>}</ul>;
}

// ---------------------------------------------------------------- audit
function Audit() {
  const [prefix, setPrefix] = useState('');
  const [rows, setRows] = useState<any[] | null>(null);
  const [done, setDone] = useState(false);
  const fetchPage = useCallback((before?: number) => api.get<{ events: any[] }>(`/admin/audit?limit=50${before ? `&before=${before}` : ''}${prefix ? `&action=${prefix}` : ''}`), [prefix]);
  useEffect(() => { setRows(null); fetchPage().then(r => { setRows(r.events); setDone(r.events.length < 50); }).catch(e => toast(errMsg(e), 'err')); }, [fetchPage]);
  return (
    <>
      <div className="flex gap-1.5 overflow-x-auto pb-1">
        {[['', 'All'], ['auth.', 'Sign-ins'], ['project.', 'Projects'], ['team.', 'Teams'], ['admin.', 'Admin']].map(([p, l]) => <button key={p} className={`shrink-0 px-3 py-1.5 rounded-full border text-[12.5px] ${prefix === p ? 'border-accent text-accent bg-accent/10' : 'border-line text-mute'}`} onClick={() => setPrefix(p)}>{l}</button>)}
      </div>
      {rows === null ? <Spinner /> : (
        <ul className="space-y-1.5">
          {rows.map(e => (
            <li key={e.id} className="card px-3 py-2 text-[12.5px]">
              <div className="flex gap-2 items-baseline flex-wrap"><span className="font-mono font-semibold">{e.action}</span><span className="text-mute">{fmtDate(e.ts)}</span></div>
              <div className="text-mute break-words">{e.actor ?? 'anonymous'}{e.ip ? ` · ${e.ip}` : ''}{e.targetType ? ` · ${e.targetType} ${String(e.targetId ?? '').slice(0, 8)}` : ''}{e.meta ? ` · ${JSON.stringify(e.meta)}` : ''}</div>
            </li>
          ))}
          {rows.length === 0 && <li className="text-center text-sm text-mute py-8">Nothing recorded yet.</li>}
        </ul>
      )}
      {rows && rows.length > 0 && !done && <button className="btn w-full justify-center" onClick={() => void fetchPage(rows[rows.length - 1].ts).then(r => { setRows(x => [...(x ?? []), ...r.events]); setDone(r.events.length < 50); })}>Load older</button>}
    </>
  );
}

// ---------------------------------------------------------------- settings
function SettingsTab() {
  const [s, setS] = useState<Record<string, any> | null>(null);
  const [orig, setOrig] = useState<Record<string, any> | null>(null);
  const [saved, setSaved] = useState(false);
  const { busy, error, run } = useAction();
  useEffect(() => { api.get<{ settings: Record<string, any> }>('/admin/settings').then(r => { setS(r.settings); setOrig(r.settings); }).catch(e => toast(errMsg(e), 'err')); }, []);
  if (!s || !orig) return <Spinner />;
  const set = (k: string, v: any) => { setS({ ...s, [k]: v }); setSaved(false); };
  const changed = Object.keys(s).filter(k => JSON.stringify(s[k]) !== JSON.stringify(orig[k]));
  const save = () => run(async () => {
    const body = Object.fromEntries(changed.map(k => [k, s[k]]));
    const r = await api.put<{ settings: Record<string, any> }>('/admin/settings', body);
    setS(r.settings); setOrig(r.settings); setSaved(true);
    const cfg = await api.get('/config'); useAuth.setState({ config: cfg });
  });
  const Toggle = ({ k, label, desc }: { k: string; label: string; desc: string }) => (
    <label className="flex items-start gap-3 py-1 cursor-pointer"><input type="checkbox" className="mt-1 w-4 h-4 accent-[var(--c-accent)]" checked={!!s[k]} onChange={e => set(k, e.target.checked)} /><span className="text-[13.5px]"><b className="font-medium">{label}</b><span className="block text-[12px] text-mute">{desc}</span></span></label>
  );
  const Num = ({ k, label }: { k: string; label: string }) => <Field label={label}><input className="input" type="number" inputMode="numeric" value={s[k]} onChange={e => set(k, e.target.value === '' ? '' : Number(e.target.value))} /></Field>;
  return (
    <>
      <Section title="Access">
        <Toggle k="registrationEnabled" label="Allow new registrations" desc="When off, only administrators can create accounts." />
        <Toggle k="requireEmailVerification" label="Require confirmed email" desc="Needs an email provider (see the deployment guide). Users cannot sign in until they confirm." />
      </Section>
      <Section title="Banner and contact" desc="The banner is shown at the top of the app for everyone. Contact details appear in the legal pages.">
        <Field label="Announcement (leave empty for none)"><input className="input" maxLength={300} value={s.announcement} onChange={e => set('announcement', e.target.value)} /></Field>
        <Field label="Operator / company name"><input className="input" maxLength={120} value={s.operatorName} onChange={e => set('operatorName', e.target.value)} /></Field>
        <Field label="Contact email"><input className="input" type="email" value={s.contactEmail} onChange={e => set('contactEmail', e.target.value)} /></Field>
        <Field label="Contact phone"><input className="input" type="tel" inputMode="tel" value={s.contactPhone} onChange={e => set('contactPhone', e.target.value)} /></Field>
      </Section>
      <Section title="Limits" desc="Keep the free database from filling up.">
        <div className="grid grid-cols-2 gap-3">
          <Num k="maxPersonalProjects" label="Projects per user" /><Num k="maxTeamProjects" label="Projects per team" />
          <Num k="maxProjectKB" label="Max project size (KB)" /><Num k="versionsPerProject" label="Versions kept per project" />
          <Num k="maxTeamsPerUser" label="Teams a user may own" /><Num k="maxMembersPerTeam" label="Members per team" />
        </div>
      </Section>
      {error && <Alert kind="error">{error}</Alert>}
      <div className="flex items-center gap-3"><button className="btn btn-accent" disabled={busy || !changed.length} onClick={() => void save()}>{busy ? 'Saving…' : 'Save settings'}</button>{saved && <span className="text-on text-[13px]">Saved ✓</span>}{changed.length > 0 && <span className="text-mute text-[12px]">{changed.length} unsaved change{changed.length > 1 ? 's' : ''}</span>}</div>
    </>
  );
}

export function AdminPage() {
  const { closePage, user } = useAuth();
  const [tab, setTab] = useState<Tab>('overview');
  const tabs: [Tab, string][] = [['overview', 'Overview'], ['users', 'Users'], ['projects', 'Projects'], ['teams', 'Teams'], ['audit', 'Activity'], ['settings', 'Settings']];
  if (user?.role !== 'admin') return <PageShell title="Admin" onBack={closePage}><Alert kind="error">Administrators only.</Alert></PageShell>;
  return (
    <PageShell title="Admin console" onBack={closePage} wide>
      <div className="flex gap-1 overflow-x-auto p-0.5 rounded-lg bg-bg border border-line text-[13px]" role="tablist">
        {tabs.map(([t, l]) => <button key={t} role="tab" aria-selected={tab === t} className={`shrink-0 px-3.5 py-2 rounded-md font-medium ${tab === t ? 'bg-panel3 text-accent' : 'text-mute'}`} onClick={() => setTab(t)}>{l}</button>)}
      </div>
      {tab === 'overview' && <Overview />}{tab === 'users' && <Users />}{tab === 'projects' && <Projects />}{tab === 'teams' && <Teams />}{tab === 'audit' && <Audit />}{tab === 'settings' && <SettingsTab />}
    </PageShell>
  );
}
