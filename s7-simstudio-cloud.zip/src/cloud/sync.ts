import { create } from 'zustand';
import { useStore } from '../store';
import { api, ApiError, errMsg } from './api';
import { useAuth } from './auth';
import type { Project } from '../types';
import type { CloudBinding, ProjectMeta } from './types';

export type SyncState = 'idle' | 'saved' | 'unsaved' | 'saving' | 'offline' | 'conflict' | 'error';

interface SyncStore {
  state: SyncState;
  savedAt: number | null;
  message: string | null;
  conflictOpen: boolean;
  remote: { revision: number | null; updatedBy: string | null } | null;
}
export const useSync = create<SyncStore>(() => ({ state: 'idle', savedAt: null, message: null, conflictOpen: false, remote: null }));
const setSync = (p: Partial<SyncStore>) => useSync.setState(p);

const DEBOUNCE_MS = 1500;
const POLL_MS = 20_000;
let timer: ReturnType<typeof setTimeout> | undefined;
let retry: ReturnType<typeof setTimeout> | undefined;
let inflight = false;
let again = false;
let backoff = 5000;

const toast = (t: string, k: 'ok' | 'err' | 'info' = 'info') => useStore.getState().showToast(t, k);

function toProject(raw: any, name?: string): Project {
  if (!raw || !Array.isArray(raw.blocks) || !raw.hardware || !Array.isArray(raw.tags)) throw new Error('This project is damaged and cannot be opened');
  raw.devices ??= [];
  raw.watch ??= [];
  if (name) raw.name = name;
  return raw as Project;
}

export const bindingOf = (m: ProjectMeta): CloudBinding => ({ id: m.id, revision: m.revision, teamId: m.teamId, teamName: m.teamName, role: m.role, readOnly: m.role === 'viewer' });

/** Opens a cloud project in the editor and links it for autosave. */
export async function openCloudProject(id: string): Promise<boolean> {
  try {
    const r = await api.get<{ project: ProjectMeta; data: unknown }>(`/projects/${id}`);
    useStore.getState().loadProject(toProject(r.data, r.project.name));
    useStore.getState().bindCloud(bindingOf(r.project));
    setSync({ state: 'saved', savedAt: r.project.updatedAt, message: null, conflictOpen: false, remote: null });
    useAuth.getState().closePage();
    if (r.project.role === 'viewer') toast('Opened in view-only mode', 'info');
    return true;
  } catch (e) {
    toast(errMsg(e), 'err');
    return false;
  }
}

/** Saves the open (local) project as a new cloud project and links it. */
export async function saveToCloud(teamId: string | null, name?: string): Promise<boolean> {
  const cur = useStore.getState().project;
  const finalName = (name ?? cur.name).trim() || 'Project';
  try {
    const data = { ...cur, name: finalName };
    const r = await api.post<{ project: ProjectMeta }>('/projects', { name: finalName, data, teamId });
    useStore.setState({ project: data, dirty: false });
    useStore.getState().bindCloud(bindingOf(r.project));
    setSync({ state: 'saved', savedAt: r.project.updatedAt, message: null, conflictOpen: false, remote: null });
    toast(teamId ? 'Saved to the team' : 'Saved to your cloud projects', 'ok');
    return true;
  } catch (e) {
    toast(errMsg(e), 'err');
    return false;
  }
}

function scheduleSave(delay = DEBOUNCE_MS) {
  clearTimeout(timer);
  timer = setTimeout(() => { void saveNow(); }, delay);
}

export async function saveNow(): Promise<void> {
  clearTimeout(timer);
  clearTimeout(retry);
  const s0 = useStore.getState();
  const c = s0.cloud;
  if (!c || c.readOnly || !s0.dirty) return;
  if (useSync.getState().state === 'conflict' && useSync.getState().conflictOpen) return;
  if (inflight) { again = true; return; }
  inflight = true;
  setSync({ state: 'saving', message: null });
  const snapshot = s0.project;
  try {
    const r = await api.put<{ revision: number; updatedAt: number }>(`/projects/${c.id}`, { baseRevision: c.revision, data: snapshot, name: snapshot.name });
    // only mark clean when nothing changed while the request was in flight
    useStore.setState(st => (st.cloud && st.cloud.id === c.id ? { cloud: { ...st.cloud, revision: r.revision }, dirty: st.project === snapshot ? false : st.dirty } : {}));
    backoff = 5000;
    setSync({ state: useStore.getState().dirty ? 'unsaved' : 'saved', savedAt: r.updatedAt, message: null });
  } catch (e) {
    if (e instanceof ApiError && e.status === 409) {
      setSync({ state: 'conflict', conflictOpen: true, message: e.message, remote: { revision: e.details?.revision ?? null, updatedBy: e.details?.updatedBy ?? null } });
    } else if (e instanceof ApiError && e.status === 0) {
      setSync({ state: 'offline', message: 'Offline — your changes will be saved when the connection returns' });
      retry = setTimeout(() => { void saveNow(); }, backoff);
      backoff = Math.min(backoff * 2, 60_000);
    } else if (e instanceof ApiError && e.status === 401) {
      setSync({ state: 'error', message: 'Your session expired. Sign in again to keep saving.' });
      void useAuth.getState().refresh();
    } else if (e instanceof ApiError && e.status === 404) {
      lostAccess();
    } else if (e instanceof ApiError && (e.status >= 500 || e.status === 429)) {
      setSync({ state: 'error', message: errMsg(e) });
      retry = setTimeout(() => { void saveNow(); }, backoff);
      backoff = Math.min(backoff * 2, 60_000);
    } else {
      setSync({ state: 'error', message: errMsg(e) });
    }
  } finally {
    inflight = false;
    if (again) { again = false; scheduleSave(200); }
    else if (useSync.getState().state === 'unsaved') scheduleSave();
  }
}

function lostAccess() {
  toast('This project was deleted or you no longer have access. Your copy stays open here as a local project.', 'err');
  useStore.setState({ cloud: null, dirty: true });
  setSync({ state: 'idle', conflictOpen: false, message: null });
}

/** Replaces the open project with the latest cloud version. */
async function pullRemote(): Promise<void> {
  const c = useStore.getState().cloud;
  if (!c) return;
  const r = await api.get<{ project: ProjectMeta; data: unknown }>(`/projects/${c.id}`);
  useStore.getState().replaceProject(toProject(r.data, r.project.name));
  useStore.getState().bindCloud(bindingOf(r.project));
  setSync({ state: 'saved', savedAt: r.project.updatedAt, message: null, conflictOpen: false, remote: null });
}

export async function resolveConflict(choice: 'mine' | 'theirs' | 'copy'): Promise<void> {
  const s = useStore.getState();
  const c = s.cloud;
  if (!c) return;
  try {
    if (choice === 'theirs') {
      await pullRemote();
      toast('Loaded the latest version from the cloud', 'ok');
    } else if (choice === 'mine') {
      const m = await api.get<{ project: ProjectMeta }>(`/projects/${c.id}/meta`);
      useStore.setState(st => (st.cloud ? { cloud: { ...st.cloud, revision: m.project.revision } } : {}));
      setSync({ conflictOpen: false, state: 'unsaved' });
      await saveNow();
      toast('Your version replaced the cloud version', 'ok');
    } else {
      const name = `${s.project.name} (my copy)`;
      const data = { ...s.project, name };
      const r = await api.post<{ project: ProjectMeta }>('/projects', { name, data, teamId: c.teamId });
      useStore.setState({ project: data, dirty: false });
      useStore.getState().bindCloud(bindingOf(r.project));
      setSync({ state: 'saved', savedAt: r.project.updatedAt, conflictOpen: false, message: null, remote: null });
      toast('Saved your version as a separate project', 'ok');
    }
    setSync({ conflictOpen: false });
  } catch (e) {
    toast(errMsg(e), 'err');
  }
}

/** Looks for changes made on another device or by a teammate. */
async function poll(): Promise<void> {
  const c = useStore.getState().cloud;
  if (!c || inflight || document.visibilityState !== 'visible' || !useAuth.getState().user) return;
  try {
    const r = await api.get<{ project: ProjectMeta }>(`/projects/${c.id}/meta`);
    const cur = useStore.getState().cloud;
    if (!cur || cur.id !== c.id) return;
    if (useSync.getState().state === 'offline') setSync({ state: useStore.getState().dirty ? 'unsaved' : 'saved', message: null });
    if (r.project.role !== cur.role) useStore.getState().bindCloud({ ...cur, role: r.project.role, readOnly: r.project.role === 'viewer' });
    if (r.project.revision > cur.revision) {
      if (!useStore.getState().dirty) {
        await pullRemote();
        toast(`Updated from ${r.project.updatedBy ? r.project.updatedBy : 'another device'}`, 'info');
      } else {
        setSync({ state: 'conflict', conflictOpen: false, message: 'Changed elsewhere while you were editing', remote: { revision: r.project.revision, updatedBy: r.project.updatedBy } });
      }
    }
  } catch (e) {
    if (e instanceof ApiError && e.status === 404) lostAccess();
    else if (e instanceof ApiError && e.status === 401) void useAuth.getState().refresh();
    else if (e instanceof ApiError && e.status === 0 && useStore.getState().cloud) setSync({ state: 'offline', message: 'Offline' });
  }
}

/** True when leaving the open project cannot lose work (and starts the pending save right now). */
export function cloudAllowsSwitch(): boolean {
  const s = useStore.getState();
  if (!s.cloud) return false;
  if (!s.dirty) return true;
  const st = useSync.getState().state;
  if (st === 'unsaved' || st === 'saving') { void saveNow(); return true; }
  return false;
}

/** Re-reads the binding (role, team, revision) of the open project after it was moved or shared. */
export async function refreshBinding(): Promise<void> {
  const c = useStore.getState().cloud;
  if (!c) return;
  try {
    const m = await api.get<{ project: ProjectMeta }>(`/projects/${c.id}/meta`);
    useStore.getState().bindCloud({ ...bindingOf(m.project), revision: c.revision });
  } catch { /* the next poll reports problems */ }
}

let started = false;
export function startSync() {
  if (started) return;
  started = true;
  useStore.subscribe((s, prev) => {
    if (prev.cloud && !s.cloud) { setSync({ state: 'idle', conflictOpen: false, message: null, remote: null }); return; }
    if (s.cloud && s.dirty && (!prev.dirty || s.project !== prev.project) && useSync.getState().state !== 'conflict') {
      setSync({ state: 'unsaved' });
      scheduleSave();
    }
  });
  setInterval(() => { void poll(); }, POLL_MS);
  document.addEventListener('visibilitychange', () => { if (document.visibilityState === 'visible') void poll(); });
  window.addEventListener('online', () => { const a = useAuth.getState(); if (!a.cloudAvailable) void a.init(); if (useStore.getState().cloud) { if (useStore.getState().dirty) void saveNow(); else void poll(); } });
  window.addEventListener('offline', () => { if (useStore.getState().cloud) setSync({ state: 'offline', message: 'Offline' }); });
}

/** After a (re)login: continue saving what could not be saved while signed out. */
export function afterLogin() {
  if (useStore.getState().cloud && useStore.getState().dirty) { setSync({ state: 'unsaved', message: null }); void saveNow(); }
  else if (useStore.getState().cloud) setSync({ state: 'saved', message: null });
}

/** Loads the latest cloud version of the open project (used after restoring a version). */
export const reloadFromCloud = pullRemote;
