import { useCallback, useEffect, useState } from 'react';
import { Users, Plus, Link2, Trash2, LogOut, FolderOpen, ChevronRight, X } from 'lucide-react';
import { api, errMsg } from './api';
import { useAuth } from './auth';
import { useStore } from '../store';
import { ROLE_HELP, ROLE_LABEL, type TeamRole } from './types';
import { PageShell, Section, Field, Alert, Spinner, Avatar, Badge, CopyField, useAction, useConfirm, timeAgo, fmtDate } from './ui';

interface Member { id: string; name: string; email: string | null; role: TeamRole; joinedAt: number; me: boolean }
interface Invite { id: string; role: TeamRole; createdAt: number; expiresAt: number; maxUses: number; uses: number }
interface Detail { team: { id: string; name: string; createdAt: number }; myRole: TeamRole; members: Member[]; invites: Invite[] }

const RANK: Record<TeamRole, number> = { viewer: 1, editor: 2, admin: 3, owner: 4 };
const mayManage = (actor: TeamRole, target: TeamRole) => actor === 'owner' || (actor === 'admin' && RANK[target] <= RANK.editor);
const tone = (r: TeamRole) => (r === 'owner' ? 'accent' : r === 'admin' ? 'on' : r === 'editor' ? 'mute' : 'warn') as 'accent' | 'on' | 'mute' | 'warn';

function TeamDetail({ id, onBack }: { id: string; onBack: () => void }) {
  const { refresh, openPage } = useAuth();
  const [d, setD] = useState<Detail | null>(null);
  const [err, setErr] = useState<string | null>(null);
  const [name, setName] = useState('');
  const [role, setRole] = useState<TeamRole>('editor');
  const [days, setDays] = useState(7);
  const [uses, setUses] = useState(1);
  const [link, setLink] = useState<string | null>(null);
  const act = useAction();
  const { ask, node } = useConfirm();

  const load = useCallback(async () => {
    try { const r = await api.get<Detail>(`/teams/${id}`); setD(r); setName(r.team.name); setErr(null); }
    catch (e) { setErr(errMsg(e)); }
  }, [id]);
  useEffect(() => { void load(); }, [load]);

  if (err) return <><Alert kind="error">{err}</Alert><button className="btn" onClick={onBack}>Back to teams</button></>;
  if (!d) return <Spinner />;
  const me = d.myRole;
  const isAdmin = RANK[me] >= RANK.admin;
  const refreshAll = async () => { await load(); await refresh(); };
  const inviteRoles: TeamRole[] = me === 'owner' ? ['admin', 'editor', 'viewer'] : ['editor', 'viewer'];
  const owners = d.members.filter(m => m.role === 'owner').length;

  const rename = () => act.run(async () => { await api.patch(`/teams/${id}`, { name }); await refreshAll(); });
  const setMemberRole = (m: Member, r: TeamRole) => act.run(async () => { await api.patch(`/teams/${id}/members/${m.id}`, { role: r }); await refreshAll(); });
  const removeMember = async (m: Member) => {
    const self = m.me;
    if (!(await ask({ title: self ? 'Leave this team?' : `Remove ${m.name}?`, message: self ? 'You will lose access to the team\'s projects.' : `${m.name} will lose access to the team's projects immediately.`, confirmText: self ? 'Leave team' : 'Remove', danger: true }))) return;
    await act.run(async () => { await api.del(`/teams/${id}/members/${m.id}`); await refresh(); if (self) onBack(); else await load(); });
  };
  const createInvite = () => act.run(async () => {
    const r = await api.post<{ code: string }>(`/teams/${id}/invites`, { role, days, maxUses: uses });
    setLink(`${location.origin}/invite/${r.code}`);
    await load();
  });
  const revoke = (i: Invite) => act.run(async () => { await api.del(`/teams/${id}/invites/${i.id}`); await load(); });
  const deleteTeam = async () => {
    const n = d.members.length;
    if (!(await ask({ title: 'Delete this team?', message: <>The team, its <b>{n}</b> member link(s) and <b>all its projects</b> are deleted permanently. Type the team name to confirm.</>, confirmText: 'Delete team', danger: true, requireText: d.team.name }))) return;
    await act.run(async () => { await api.del(`/teams/${id}?deleteProjects=1`); await refresh(); useStore.getState().showToast('Team deleted', 'ok'); onBack(); });
  };

  return (
    <>
      <button className="text-[13px] text-accent hover:underline -mb-2 text-left" onClick={onBack}>← All teams</button>
      <div className="card p-4 flex items-center gap-3">
        <span className="w-12 h-12 rounded-xl bg-accent2/15 text-accent2 flex items-center justify-center shrink-0"><Users size={22} /></span>
        <div className="min-w-0 flex-1"><div className="font-bold text-lg truncate">{d.team.name}</div><div className="flex gap-1.5 items-center text-[12px] text-mute">You are <Badge tone={tone(me)}>{ROLE_LABEL[me]}</Badge> · {d.members.length} member{d.members.length === 1 ? '' : 's'}</div></div>
        <button className="btn" onClick={() => openPage('projects', { tab: 'team', teamId: id })}><FolderOpen size={15} /><span className="hidden sm:inline">Projects</span></button>
      </div>
      {act.error && <Alert kind="error">{act.error}</Alert>}

      {isAdmin && (
        <Section title="Team name">
          <form className="flex gap-2" onSubmit={e => { e.preventDefault(); void rename(); }}>
            <input className="input" value={name} maxLength={60} onChange={e => setName(e.target.value)} aria-label="Team name" />
            <button className="btn btn-accent shrink-0" type="submit" disabled={act.busy || name.trim().length < 2 || name.trim() === d.team.name}>Save</button>
          </form>
        </Section>
      )}

      <Section title="Members" desc="Roles decide what each person can do with the team's projects.">
        <ul className="divide-y divide-line -my-1">
          {d.members.map(m => {
            const editable = !m.me && mayManage(me, m.role);
            const options = (['owner', 'admin', 'editor', 'viewer'] as TeamRole[]).filter(r => mayManage(me, r));
            const canRemove = m.me ? !(m.role === 'owner' && owners <= 1) : mayManage(me, m.role);
            return (
              <li key={m.id} className="py-2.5 flex items-center gap-3 flex-wrap">
                <Avatar name={m.name} />
                <div className="min-w-0 flex-1 basis-40"><div className="text-[14px] font-medium truncate">{m.name}{m.me && <span className="text-mute font-normal"> (you)</span>}</div><div className="text-[12px] text-mute truncate">{m.email ?? `Joined ${timeAgo(m.joinedAt)}`}</div></div>
                {editable ? (
                  <select className="input !w-auto" aria-label={`Role of ${m.name}`} value={m.role} disabled={act.busy} onChange={e => void setMemberRole(m, e.target.value as TeamRole)}>
                    {options.map(r => <option key={r} value={r}>{ROLE_LABEL[r]}</option>)}
                  </select>
                ) : <Badge tone={tone(m.role)}>{ROLE_LABEL[m.role]}</Badge>}
                {canRemove && <button className="btn btn-ghost btn-icon hover:!text-danger" aria-label={m.me ? 'Leave team' : `Remove ${m.name}`} onClick={() => void removeMember(m)}>{m.me ? <LogOut size={16} /> : <X size={16} />}</button>}
              </li>
            );
          })}
        </ul>
      </Section>

      {isAdmin && (
        <Section title="Invite people" desc="Create a link and send it to a teammate. They sign in (or register) and join with the role you choose. No email needed.">
          <div className="grid grid-cols-3 gap-2">
            <Field label="Role"><select className="input" value={role} onChange={e => setRole(e.target.value as TeamRole)}>{inviteRoles.map(r => <option key={r} value={r}>{ROLE_LABEL[r]}</option>)}</select></Field>
            <Field label="Valid for"><select className="input" value={days} onChange={e => setDays(Number(e.target.value))}>{[1, 7, 14, 30].map(n => <option key={n} value={n}>{n} day{n > 1 ? 's' : ''}</option>)}</select></Field>
            <Field label="Max uses"><select className="input" value={uses} onChange={e => setUses(Number(e.target.value))}>{[1, 5, 20, 100].map(n => <option key={n} value={n}>{n}</option>)}</select></Field>
          </div>
          <p className="text-[12px] text-mute -mt-1">{ROLE_HELP[role]}.</p>
          <button className="btn btn-accent" disabled={act.busy} onClick={() => void createInvite()}><Link2 size={15} />Create invite link</button>
          {link && <div className="space-y-1.5"><Alert kind="ok">Link created. Copy it now: for security it is shown only once.</Alert><CopyField value={link} /></div>}
          {d.invites.length > 0 && (
            <div className="pt-1">
              <div className="label mb-1">Active links</div>
              <ul className="divide-y divide-line">
                {d.invites.map(i => (
                  <li key={i.id} className="py-2 flex items-center gap-2 text-[13px]">
                    <Badge tone={tone(i.role)}>{ROLE_LABEL[i.role]}</Badge>
                    <span className="text-mute flex-1 min-w-0 truncate">{i.uses}/{i.maxUses} used · expires {fmtDate(i.expiresAt)}</span>
                    <button className="btn" disabled={act.busy} onClick={() => void revoke(i)}>Revoke</button>
                  </li>
                ))}
              </ul>
            </div>
          )}
        </Section>
      )}

      <Section title="Danger zone" danger>
        <div className="flex flex-wrap gap-2">
          {!(me === 'owner' && owners <= 1) && <button className="btn !text-danger !border-danger/50" onClick={() => { const m = d.members.find(x => x.me); if (m) void removeMember(m); }}><LogOut size={15} />Leave team</button>}
          {me === 'owner' && <button className="btn !text-danger !border-danger/50" onClick={() => void deleteTeam()}><Trash2 size={15} />Delete team…</button>}
        </div>
        {me === 'owner' && owners <= 1 && <p className="text-[12px] text-mute">You are the only owner. Make another member an owner before leaving, or delete the team.</p>}
      </Section>
      {node}
    </>
  );
}

export function TeamsPage() {
  const { closePage, teams, refresh, openPage, pageArg } = useAuth();
  const [open, setOpen] = useState<string | null>(pageArg?.teamId ?? null);
  const [name, setName] = useState('');
  const [paste, setPaste] = useState('');
  const { busy, error, run } = useAction();
  useEffect(() => { void refresh(); }, [refresh]);

  const create = () => run(async () => {
    const r = await api.post<{ team: { id: string } }>('/teams', { name });
    setName(''); await refresh(); setOpen(r.team.id);
  });
  const joinWith = () => {
    const m = /([A-Za-z0-9_-]{10,100})\s*$/.exec(paste.trim().replace(/\/+$/, ''));
    if (m) openPage('invite', m[1]);
  };

  return (
    <PageShell title={open ? 'Team' : 'Teams'} onBack={closePage}>
      {open ? <TeamDetail id={open} onBack={() => { setOpen(null); void refresh(); }} /> : (
        <>
          <p className="text-[13.5px] text-mute leading-snug">Teams let you share projects: everyone sees the latest version, edits are saved for all, and roles control who can change what.</p>
          <ul className="space-y-2">
            {teams.map(t => (
              <li key={t.id}>
                <button className="card w-full p-3 flex items-center gap-3 text-left hover:!border-accent/50" onClick={() => setOpen(t.id)}>
                  <span className="w-10 h-10 rounded-lg bg-accent2/15 text-accent2 flex items-center justify-center shrink-0"><Users size={18} /></span>
                  <span className="min-w-0 flex-1"><span className="block font-semibold truncate">{t.name}</span><span className="text-[12px] text-mute">{t.memberCount} member{t.memberCount === 1 ? '' : 's'} · {t.projectCount} project{t.projectCount === 1 ? '' : 's'}</span></span>
                  <Badge tone={tone(t.role)}>{ROLE_LABEL[t.role]}</Badge><ChevronRight size={16} className="text-mute shrink-0" />
                </button>
              </li>
            ))}
            {teams.length === 0 && <li className="text-center text-sm text-mute py-6">You are not in any team yet.</li>}
          </ul>
          <Section title="Create a team">
            <form className="flex gap-2" onSubmit={e => { e.preventDefault(); void create(); }}>
              <input className="input" placeholder="Team name, e.g. Plant 3 automation" value={name} maxLength={60} onChange={e => setName(e.target.value)} aria-label="Team name" />
              <button className="btn btn-accent shrink-0" type="submit" disabled={busy || name.trim().length < 2}><Plus size={15} />Create</button>
            </form>
            {error && <Alert kind="error">{error}</Alert>}
          </Section>
          <Section title="Join with an invite link" desc="Paste the link a teammate sent you.">
            <form className="flex gap-2" onSubmit={e => { e.preventDefault(); joinWith(); }}>
              <input className="input" placeholder="https://…/invite/…" value={paste} onChange={e => setPaste(e.target.value)} aria-label="Invite link" autoCapitalize="none" autoCorrect="off" />
              <button className="btn shrink-0" type="submit" disabled={paste.trim().length < 10}>Continue</button>
            </form>
          </Section>
        </>
      )}
    </PageShell>
  );
}
