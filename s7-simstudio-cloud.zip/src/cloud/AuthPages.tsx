import { useEffect, useState } from 'react';
import { LogIn, UserPlus, Mail, Users } from 'lucide-react';
import { api, ApiError, errMsg } from './api';
import { useAuth } from './auth';
import { afterLogin } from './sync';
import { useStore } from '../store';
import type { Team, User } from './types';
import { ROLE_HELP, ROLE_LABEL, type TeamRole } from './types';
import { PageShell, Field, PasswordInput, Alert, Spinner, useAction } from './ui';

function finishAuth(user: User, teams: Team[]) {
  const a = useAuth.getState();
  a.setSession(user, teams);
  afterLogin();
  useStore.getState().showToast(`Signed in as ${user.name}`, 'ok');
  if (a.pendingInvite) {
    const code = a.pendingInvite;
    useAuth.setState({ pendingInvite: null });
    a.openPage('invite', code);
  } else a.closePage();
}

function Brand() {
  return (
    <div className="flex items-center gap-2.5 pb-1">
      <div className="w-10 h-10 rounded-xl bg-gradient-to-br from-accent to-accent2 flex items-center justify-center shadow-lg shadow-accent/20" aria-hidden>
        <svg width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="white" strokeWidth="2.2" strokeLinecap="round"><path d="M3 4v16M21 4v16M3 12h4M9 7v10M13 7v10M17 12h4M13 12h2" /><path d="M15 9q3 3 0 6" /></svg>
      </div>
      <div className="text-[17px] font-bold tracking-tight">S7 SimStudio</div>
    </div>
  );
}

const LinkBtn = ({ onClick, children }: { onClick: () => void; children: React.ReactNode }) => <button type="button" className="text-accent hover:underline font-medium" onClick={onClick}>{children}</button>;

export function LoginPage() {
  const { openPage, closePage, config, pendingInvite } = useAuth();
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const { busy, error, run } = useAction();
  const submit = () => run(async () => {
    const r = await api.post<{ user: User; teams: Team[] }>('/auth/login', { email, password });
    finishAuth(r.user, r.teams);
  });
  return (
    <PageShell title="Sign in" onBack={() => { useAuth.setState({ pendingInvite: null }); closePage(); }}>
      <div className="max-w-md mx-auto space-y-4 pt-2 sm:pt-8">
        <Brand />
        <h2 className="text-2xl font-bold tracking-tight">Welcome back</h2>
        {pendingInvite && <Alert kind="info">Sign in to accept your team invitation.</Alert>}
        <form className="space-y-3" onSubmit={e => { e.preventDefault(); void submit(); }}>
          <Field label="Email"><input className="input" type="email" autoComplete="email" inputMode="email" autoCapitalize="none" value={email} onChange={e => setEmail(e.target.value)} autoFocus={!('ontouchstart' in window)} /></Field>
          <Field label="Password"><PasswordInput value={password} onChange={setPassword} /></Field>
          {error && <Alert kind="error">{error}</Alert>}
          <button className="btn btn-accent w-full justify-center !py-3 !text-[15px]" disabled={busy || !email || !password} type="submit"><LogIn size={17} />{busy ? 'Signing in…' : 'Sign in'}</button>
        </form>
        <div className="flex flex-wrap justify-between gap-2 text-[13px] text-mute">
          <LinkBtn onClick={() => openPage('forgot')}>Forgot your password?</LinkBtn>
          {config?.registrationEnabled && <span>New here? <LinkBtn onClick={() => openPage('register')}>Create an account</LinkBtn></span>}
        </div>
      </div>
    </PageShell>
  );
}

export function RegisterPage() {
  const { openPage, closePage, config } = useAuth();
  const [name, setName] = useState('');
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [agree, setAgree] = useState(false);
  const [sent, setSent] = useState(false);
  const { busy, error, run } = useAction();
  const rules = [
    { ok: password.length >= 10, text: 'At least 10 characters' },
    { ok: !!email && !password.toLowerCase().includes(email.split('@')[0].toLowerCase()) || email.split('@')[0].length < 4, text: 'Does not contain your email name' },
  ];
  const submit = () => run(async () => {
    const r = await api.post<{ user?: User; teams?: Team[]; needsVerification?: boolean }>('/auth/register', { name, email, password });
    if (r.needsVerification) setSent(true);
    else if (r.user) finishAuth(r.user, r.teams ?? []);
  });
  if (config && !config.registrationEnabled) {
    return (
      <PageShell title="Create account" onBack={closePage}>
        <div className="max-w-md mx-auto space-y-4 pt-8"><Brand /><Alert kind="warn">Registration is closed on this server. Ask the administrator to create an account for you.</Alert><LinkBtn onClick={() => openPage('login')}>Back to sign in</LinkBtn></div>
      </PageShell>
    );
  }
  return (
    <PageShell title="Create account" onBack={closePage}>
      <div className="max-w-md mx-auto space-y-4 pt-2 sm:pt-8">
        <Brand />
        {sent ? (
          <>
            <h2 className="text-2xl font-bold tracking-tight">Check your email</h2>
            <Alert kind="ok">We sent a confirmation link to <b>{email}</b>. Open it to activate your account, then sign in.</Alert>
            <button className="btn btn-accent w-full justify-center" onClick={() => openPage('login')}>Go to sign in</button>
          </>
        ) : (
          <>
            <h2 className="text-2xl font-bold tracking-tight">Create your account</h2>
            <p className="text-[13.5px] text-mute -mt-2">Save projects in the cloud, open them on any device and work together with your team.</p>
            <form className="space-y-3" onSubmit={e => { e.preventDefault(); void submit(); }}>
              <Field label="Your name"><input className="input" autoComplete="name" value={name} maxLength={80} onChange={e => setName(e.target.value)} /></Field>
              <Field label="Email"><input className="input" type="email" autoComplete="email" inputMode="email" autoCapitalize="none" value={email} onChange={e => setEmail(e.target.value)} /></Field>
              <Field label="Password" hint={<ul className="space-y-0.5">{rules.map(r => <li key={r.text} className={r.ok ? 'text-on' : ''}>{r.ok ? '✓' : '•'} {r.text}</li>)}</ul>}>
                <PasswordInput value={password} onChange={setPassword} autoComplete="new-password" />
              </Field>
              <label className="flex items-start gap-2.5 text-[13px] leading-snug cursor-pointer">
                <input type="checkbox" className="mt-0.5 w-4 h-4 accent-[var(--c-accent)]" checked={agree} onChange={e => setAgree(e.target.checked)} />
                <span>I agree to the <LinkBtn onClick={() => openPage('terms')}>Terms of use</LinkBtn> and the <LinkBtn onClick={() => openPage('privacy')}>Privacy policy</LinkBtn>.</span>
              </label>
              {error && <Alert kind="error">{error}</Alert>}
              <button className="btn btn-accent w-full justify-center !py-3 !text-[15px]" disabled={busy || !agree || !name.trim() || !email || password.length < 10} type="submit"><UserPlus size={17} />{busy ? 'Creating…' : 'Create account'}</button>
            </form>
            <div className="text-[13px] text-mute">Already have an account? <LinkBtn onClick={() => openPage('login')}>Sign in</LinkBtn></div>
          </>
        )}
      </div>
    </PageShell>
  );
}

export function ForgotPage() {
  const { openPage, closePage, config } = useAuth();
  const [email, setEmail] = useState('');
  const [done, setDone] = useState(false);
  const { busy, error, run } = useAction();
  const submit = () => run(async () => { await api.post('/auth/forgot', { email }); setDone(true); });
  return (
    <PageShell title="Reset password" onBack={closePage}>
      <div className="max-w-md mx-auto space-y-4 pt-2 sm:pt-8">
        <Brand />
        <h2 className="text-2xl font-bold tracking-tight">Forgot your password?</h2>
        {config && !config.mailEnabled ? (
          <Alert kind="warn">Email is not set up on this server, so reset links cannot be sent. Ask your administrator for a reset link.</Alert>
        ) : done ? (
          <Alert kind="ok">If an account exists for <b>{email}</b>, a reset link is on its way. It is valid for 1 hour.</Alert>
        ) : (
          <form className="space-y-3" onSubmit={e => { e.preventDefault(); void submit(); }}>
            <p className="text-[13.5px] text-mute">Enter your email and we will send you a link to choose a new password.</p>
            <Field label="Email"><input className="input" type="email" autoComplete="email" inputMode="email" autoCapitalize="none" value={email} onChange={e => setEmail(e.target.value)} /></Field>
            {error && <Alert kind="error">{error}</Alert>}
            <button className="btn btn-accent w-full justify-center !py-3" disabled={busy || !email} type="submit"><Mail size={16} />{busy ? 'Sending…' : 'Send reset link'}</button>
          </form>
        )}
        <LinkBtn onClick={() => openPage('login')}>Back to sign in</LinkBtn>
      </div>
    </PageShell>
  );
}

export function ResetPage() {
  const { pageArg: token, openPage, closePage } = useAuth();
  const [password, setPassword] = useState('');
  const [again, setAgain] = useState('');
  const [done, setDone] = useState(false);
  const { busy, error, run } = useAction();
  const mismatch = !!again && again !== password;
  const submit = () => run(async () => { await api.post('/auth/reset', { token, password }); setDone(true); });
  return (
    <PageShell title="Choose a new password" onBack={closePage}>
      <div className="max-w-md mx-auto space-y-4 pt-2 sm:pt-8">
        <Brand />
        {done ? (
          <>
            <Alert kind="ok">Your password was changed. All devices were signed out.</Alert>
            <button className="btn btn-accent w-full justify-center" onClick={() => openPage('login')}>Sign in</button>
          </>
        ) : (
          <form className="space-y-3" onSubmit={e => { e.preventDefault(); void submit(); }}>
            <h2 className="text-2xl font-bold tracking-tight">Choose a new password</h2>
            <Field label="New password" hint="At least 10 characters."><PasswordInput value={password} onChange={setPassword} autoComplete="new-password" /></Field>
            <Field label="Repeat password" error={mismatch ? 'The passwords do not match' : null}><PasswordInput value={again} onChange={setAgain} autoComplete="new-password" /></Field>
            {error && <Alert kind="error">{error}</Alert>}
            <button className="btn btn-accent w-full justify-center !py-3" disabled={busy || password.length < 10 || password !== again} type="submit">{busy ? 'Saving…' : 'Change password'}</button>
          </form>
        )}
      </div>
    </PageShell>
  );
}

export function VerifyPage() {
  const { pageArg: token, closePage, refresh } = useAuth();
  const [state, setState] = useState<'wait' | 'ok' | 'bad'>('wait');
  const [msg, setMsg] = useState('');
  useEffect(() => {
    let live = true;
    api.post('/auth/verify', { token }).then(() => { if (live) { setState('ok'); void refresh(); } }).catch(e => { if (live) { setState('bad'); setMsg(errMsg(e)); } });
    return () => { live = false; };
  }, [token, refresh]);
  return (
    <PageShell title="Confirm email" onBack={closePage}>
      <div className="max-w-md mx-auto space-y-4 pt-8">
        <Brand />
        {state === 'wait' && <Spinner label="Confirming your email…" />}
        {state === 'ok' && <Alert kind="ok">Your email address is confirmed. You can sign in now.</Alert>}
        {state === 'bad' && <Alert kind="error">{msg}</Alert>}
        {state !== 'wait' && <button className="btn btn-accent w-full justify-center" onClick={() => (state === 'ok' && !useAuth.getState().user ? useAuth.getState().openPage('login') : closePage())}>Continue</button>}
      </div>
    </PageShell>
  );
}

export function SetupPage() {
  const { closePage } = useAuth();
  const [token, setToken] = useState('');
  const [name, setName] = useState('');
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const { busy, error, run } = useAction();
  const submit = () => run(async () => {
    const r = await api.post<{ user: User }>('/setup', { token, name, email, password });
    useAuth.getState().setSession(r.user, []);
    useAuth.setState(s => ({ config: s.config ? { ...s.config, needsSetup: false } : s.config }));
    useStore.getState().showToast('Administrator account created', 'ok');
    useAuth.getState().openPage('admin');
  });
  return (
    <PageShell title="First-time setup" onBack={closePage}>
      <div className="max-w-md mx-auto space-y-4 pt-2 sm:pt-8">
        <Brand />
        <h2 className="text-2xl font-bold tracking-tight">Create the administrator</h2>
        <Alert kind="info">Enter the <b>SETUP_TOKEN</b> you configured on the server. This page disappears as soon as the first administrator exists.</Alert>
        <form className="space-y-3" onSubmit={e => { e.preventDefault(); void submit(); }}>
          <Field label="Setup token"><PasswordInput value={token} onChange={setToken} autoComplete="off" /></Field>
          <Field label="Your name"><input className="input" autoComplete="name" value={name} maxLength={80} onChange={e => setName(e.target.value)} /></Field>
          <Field label="Email"><input className="input" type="email" autoComplete="email" inputMode="email" autoCapitalize="none" value={email} onChange={e => setEmail(e.target.value)} /></Field>
          <Field label="Password" hint="At least 10 characters."><PasswordInput value={password} onChange={setPassword} autoComplete="new-password" /></Field>
          {error && <Alert kind="error">{error}</Alert>}
          <button className="btn btn-accent w-full justify-center !py-3" disabled={busy || !token || !name.trim() || !email || password.length < 10} type="submit">{busy ? 'Creating…' : 'Create administrator'}</button>
        </form>
      </div>
    </PageShell>
  );
}

export function InvitePage() {
  const { pageArg: code, user, closePage, openPage, refresh } = useAuth();
  const [info, setInfo] = useState<{ team: { id: string; name: string }; role: TeamRole; alreadyMember: boolean } | null>(null);
  const [err, setErr] = useState<string | null>(null);
  const { busy, error, run } = useAction();
  useEffect(() => {
    if (!user) { useAuth.setState({ pendingInvite: code }); openPage('login'); return; }
    let live = true;
    api.get(`/invites/${code}`).then(r => { if (live) setInfo(r); }).catch(e => { if (live) setErr(e instanceof ApiError ? e.message : 'Could not read the invitation'); });
    return () => { live = false; };
  }, [code, user, openPage]);
  const join = () => run(async () => {
    await api.post('/invites/accept', { code });
    await refresh();
    useStore.getState().showToast(`Joined ${info?.team.name}`, 'ok');
    openPage('teams', { teamId: info?.team.id });
  });
  return (
    <PageShell title="Team invitation" onBack={closePage}>
      <div className="max-w-md mx-auto space-y-4 pt-2 sm:pt-8">
        <Brand />
        {err && <Alert kind="error">{err}</Alert>}
        {!info && !err && <Spinner />}
        {info && (
          <div className="card p-5 space-y-3 text-center">
            <Users size={28} className="mx-auto text-accent" />
            <div><div className="text-[13px] text-mute">You are invited to join</div><div className="text-xl font-bold">{info.team.name}</div></div>
            <div className="text-[13px] text-mute">as <b className="text-ink">{ROLE_LABEL[info.role]}</b> — {ROLE_HELP[info.role].toLowerCase()}</div>
            {error && <Alert kind="error">{error}</Alert>}
            {info.alreadyMember
              ? <><Alert kind="ok">You are already a member.</Alert><button className="btn btn-accent w-full justify-center" onClick={() => openPage('teams', { teamId: info.team.id })}>Open team</button></>
              : <button className="btn btn-accent w-full justify-center !py-3" disabled={busy} onClick={() => void join()}>{busy ? 'Joining…' : 'Join team'}</button>}
          </div>
        )}
      </div>
    </PageShell>
  );
}
