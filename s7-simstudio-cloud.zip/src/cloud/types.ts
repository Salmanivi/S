export type TeamRole = 'owner' | 'admin' | 'editor' | 'viewer';

export interface User { id: string; email: string; name: string; role: 'user' | 'admin'; status: 'active' | 'disabled'; emailVerified: boolean; createdAt: number; lastLoginAt: number | null }
export interface Team { id: string; name: string; role: TeamRole; memberCount: number; projectCount: number }

export interface PublicConfig {
  appName: string; version: string; registrationEnabled: boolean; requireEmailVerification: boolean; mailEnabled: boolean;
  announcement: string; operatorName: string; contactEmail: string; contactPhone: string; maxProjectKB: number; needsSetup: boolean;
}

export interface ProjectMeta {
  id: string; name: string; revision: number; sizeBytes: number; createdAt: number; updatedAt: number; deletedAt: number | null;
  scope: 'personal' | 'team'; teamId: string | null; teamName: string | null; role: TeamRole; updatedBy: string | null;
}

/** Links the open project to its cloud copy. */
export interface CloudBinding { id: string; revision: number; teamId: string | null; teamName: string | null; role: TeamRole; readOnly: boolean }

export type PageId = 'about' | 'login' | 'register' | 'forgot' | 'reset' | 'verify' | 'setup' | 'invite' | 'account' | 'projects' | 'teams' | 'admin' | 'terms' | 'privacy';

export const canWrite = (r: TeamRole) => r !== 'viewer';
export const ROLE_LABEL: Record<TeamRole, string> = { owner: 'Owner', admin: 'Admin', editor: 'Editor', viewer: 'Viewer' };
export const ROLE_HELP: Record<TeamRole, string> = {
  owner: 'Full control, including deleting the team',
  admin: 'Manage members, invites and all projects',
  editor: 'Create and edit projects',
  viewer: 'Open and simulate projects, no editing',
};
