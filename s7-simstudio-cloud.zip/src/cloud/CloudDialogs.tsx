import { useEffect, useState } from 'react';
import { Cloud, Users, History, RotateCcw, Flag, AlertTriangle } from 'lucide-react';
import { api, errMsg } from './api';
import { useAuth } from './auth';
import { useStore } from '../store';
import { Modal } from '../components/Shell';
import { saveToCloud, resolveConflict, useSync, saveNow, reloadFromCloud, refreshBinding } from './sync';
import { canWrite, ROLE_LABEL, type ProjectMeta } from './types';
import { Alert, Spinner, Field, useAction, useConfirm, fmtBytes, fmtDate } from './ui';

/** Where a project can be stored: your own space or a team you may edit in. */
export function useDestinations() {
  const teams = useAuth(s => s.teams);
  return [{ id: null as string | null, label: 'My projects (private)' }, ...teams.filter(t => canWrite(t.role)).map(t => ({ id: t.id as string | null, label: `Team: ${t.name}` }))];
}

export function SaveToCloudDialog({ onClose }: { onClose: () => void }) {
  const project = useStore(s => s.project);
  const dest = useDestinations();
  const [name, setName] = useState(project.name);
  const [teamId, setTeamId] = useState<string | null>(null);
  const { busy, run } = useAction();
  const save = () => run(async () => { if (await saveToCloud(teamId, name)) onClose(); });
  return (
    <Modal title="Save to the cloud" onClose={onClose}>
      <form className="p-4 space-y-4" onSubmit={e => { e.preventDefault(); void save(); }}>
        <p className="text-[13px] text-mute leading-snug">The project is stored on the server, saved automatically while you work and available on all your devices.</p>
        <Field label="Project name"><input className="input" value={name} maxLength={120} onChange={e => setName(e.target.value)} autoFocus={!('ontouchstart' in window)} /></Field>
        <div>
          <div className="label mb-1.5">Save in</div>
          <div className="space-y-1.5">
            {dest.map(d => (
              <label key={String(d.id)} className={`flex items-center gap-2.5 rounded-lg border px-3 py-2.5 cursor-pointer text-[13.5px] ${teamId === d.id ? 'border-accent bg-accent/10' : 'border-line'}`}>
                <input type="radio" name="dest" className="accent-[var(--c-accent)]" checked={teamId === d.id} onChange={() => setTeamId(d.id)} />
                {d.id ? <Users size={15} className="text-mute" /> : <Cloud size={15} className="text-mute" />}{d.label}
              </label>
            ))}
          </div>
        </div>
        <div className="flex gap-2">
          <button type="button" className="btn flex-1 justify-center" onClick={onClose}>Cancel</button>
          <button type="submit" className="btn btn-accent flex-1 justify-center" disabled={busy || !name.trim()}><Cloud size={15} />{busy ? 'Saving…' : 'Save'}</button>
        </div>
      </form>
    </Modal>
  );
}

/** Shown when a save was rejected because someone else changed the project in the meantime. */
export function ConflictDialog() {
  const { conflictOpen, remote } = useSync();
  const [busy, setBusy] = useState(false);
  if (!conflictOpen) return null;
  const choose = async (c: 'mine' | 'theirs' | 'copy') => { setBusy(true); await resolveConflict(c); setBusy(false); };
  return (
    <Modal title="This project changed elsewhere" onClose={() => useSync.setState({ conflictOpen: false })}>
      <div className="p-4 space-y-3 text-[13.5px] leading-relaxed">
        <Alert kind="warn">{remote?.updatedBy ? <><b>{remote.updatedBy}</b> saved a newer version</> : 'A newer version was saved on another device'} while you were editing. Choose what to keep — nothing is lost until you decide.</Alert>
        <button className="btn w-full !justify-start !py-3 text-left" disabled={busy} onClick={() => void choose('copy')}>
          <span className="block"><b className="block">Keep both</b><span className="text-mute text-[12px] font-normal">Save my version as a new project and continue with it.</span></span>
        </button>
        <button className="btn w-full !justify-start !py-3 text-left" disabled={busy} onClick={() => void choose('mine')}>
          <span className="block"><b className="block">Replace the cloud version with mine</b><span className="text-mute text-[12px] font-normal">The other changes are overwritten (they stay in version history).</span></span>
        </button>
        <button className="btn w-full !justify-start !py-3 text-left" disabled={busy} onClick={() => void choose('theirs')}>
          <span className="block"><b className="block">Use the cloud version</b><span className="text-mute text-[12px] font-normal">Discard my unsaved changes and load the latest.</span></span>
        </button>
      </div>
    </Modal>
  );
}

interface Version { id: string; revision: number; label: string | null; sizeBytes: number; createdAt: number; by: string | null }

export function HistoryDialog({ onClose }: { onClose: () => void }) {
  const cloud = useStore(s => s.cloud);
  const [versions, setVersions] = useState<Version[] | null>(null);
  const [label, setLabel] = useState('');
  const act = useAction();
  const { ask, node } = useConfirm();
  const load = async () => { if (!cloud) return; try { setVersions((await api.get<{ versions: Version[] }>(`/projects/${cloud.id}/versions`)).versions); } catch (e) { useStore.getState().showToast(errMsg(e), 'err'); } };
  useEffect(() => { void saveNow().then(load); /* make sure the newest edits are included */ // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);
  if (!cloud) return null;
  const writable = !cloud.readOnly;
  const checkpoint = () => act.run(async () => { await saveNow(); await api.post(`/projects/${cloud.id}/checkpoint`, { label: label.trim() || 'Checkpoint' }); setLabel(''); await load(); });
  const restore = async (v: Version) => {
    if (!(await ask({ title: 'Restore this version?', message: <>The project goes back to the state from <b>{fmtDate(v.createdAt)}</b>. What you have now is kept in the history as “Before restore”.</>, confirmText: 'Restore' }))) return;
    await act.run(async () => { await saveNow(); await api.post(`/projects/${cloud.id}/versions/${v.id}/restore`); await reloadFromCloud(); useStore.getState().showToast('Version restored', 'ok'); onClose(); });
  };
  return (
    <Modal title="Version history" onClose={onClose}>
      <div className="p-4 space-y-3">
        {writable && (
          <form className="flex gap-2" onSubmit={e => { e.preventDefault(); void checkpoint(); }}>
            <input className="input" placeholder="Name this version (optional)" value={label} maxLength={80} onChange={e => setLabel(e.target.value)} />
            <button className="btn btn-accent shrink-0" type="submit" disabled={act.busy}><Flag size={14} />Checkpoint</button>
          </form>
        )}
        {act.error && <Alert kind="error">{act.error}</Alert>}
        {versions === null ? <Spinner /> : versions.length === 0 ? <p className="text-sm text-mute py-4 text-center">No versions yet.</p> : (
          <ul className="divide-y divide-line">
            {versions.map(v => (
              <li key={v.id} className="py-2.5 flex items-center gap-3">
                <History size={17} className="text-mute shrink-0" />
                <div className="min-w-0 flex-1">
                  <div className="text-[13.5px] font-medium truncate">{v.label ?? 'Automatic snapshot'}</div>
                  <div className="text-[12px] text-mute">{fmtDate(v.createdAt)} · {v.by ?? 'Unknown'} · {fmtBytes(v.sizeBytes)}</div>
                </div>
                {writable && <button className="btn" disabled={act.busy} onClick={() => void restore(v)}><RotateCcw size={14} />Restore</button>}
              </li>
            ))}
          </ul>
        )}
        <p className="text-[11.5px] text-mute leading-snug">Snapshots are taken automatically at most every 15 minutes while you work; the newest {20} are kept.</p>
      </div>
      {node}
    </Modal>
  );
}

export function MoveDialog({ project, onClose, onDone }: { project: ProjectMeta; onClose: () => void; onDone: () => void }) {
  const teams = useAuth(s => s.teams).filter(t => canWrite(t.role));
  const options = [{ id: null as string | null, label: 'My projects (private)' }, ...teams.map(t => ({ id: t.id as string | null, label: `Team: ${t.name}` }))].filter(o => o.id !== project.teamId);
  const [teamId, setTeamId] = useState<string | null>(options[0]?.id ?? null);
  const { busy, error, run } = useAction();
  const go = () => run(async () => {
    await api.post(`/projects/${project.id}/move`, { teamId });
    if (useStore.getState().cloud?.id === project.id) await refreshBinding();
    useStore.getState().showToast('Project moved', 'ok');
    onDone();
  });
  return (
    <Modal title={`Move “${project.name}”`} onClose={onClose}>
      <div className="p-4 space-y-3">
        {options.length === 0 ? <Alert kind="info">Create a team first to share projects with other people.</Alert> : (
          <div className="space-y-1.5">
            {options.map(d => (
              <label key={String(d.id)} className={`flex items-center gap-2.5 rounded-lg border px-3 py-2.5 cursor-pointer text-[13.5px] ${teamId === d.id ? 'border-accent bg-accent/10' : 'border-line'}`}>
                <input type="radio" name="mv" className="accent-[var(--c-accent)]" checked={teamId === d.id} onChange={() => setTeamId(d.id)} />{d.label}
              </label>
            ))}
          </div>
        )}
        {project.scope === 'personal' && teamId && <p className="text-[12px] text-mute flex gap-1.5"><AlertTriangle size={14} className="shrink-0 mt-0.5" />Everyone in the team will be able to see this project, according to their role ({Object.values(ROLE_LABEL).join(' / ')}).</p>}
        {error && <Alert kind="error">{error}</Alert>}
        <div className="flex gap-2">
          <button className="btn flex-1 justify-center" onClick={onClose}>Cancel</button>
          <button className="btn btn-accent flex-1 justify-center" disabled={busy || options.length === 0} onClick={() => void go()}>{busy ? 'Moving…' : 'Move'}</button>
        </div>
      </div>
    </Modal>
  );
}
