import { create } from 'zustand';
import { api, ApiError } from './api';
import type { PageId, PublicConfig, Team, User } from './types';
import { useStore } from '../store';
import { OFFLINE_BUILD } from '../env';

interface AuthState {
  /** null until the first /config answer; cloudAvailable=false means there is no backend (static / offline use) */
  config: PublicConfig | null;
  cloudAvailable: boolean;
  ready: boolean;
  user: User | null;
  teams: Team[];
  page: PageId | null;
  pageArg: any;
  /** invite code waiting for the user to sign in */
  pendingInvite: string | null;
  announcementDismissed: boolean;
  /** dialogs that can be opened from anywhere */
  cloudDialog: null | 'save' | 'history';

  init: () => Promise<void>;
  refresh: () => Promise<void>;
  setSession: (user: User, teams: Team[]) => void;
  signOut: () => Promise<void>;
  openPage: (p: PageId, arg?: any) => void;
  closePage: () => void;
}

export const useAuth = create<AuthState>((set, get) => ({
  config: null, cloudAvailable: false, ready: false, user: null, teams: [], page: null, pageArg: null, pendingInvite: null, announcementDismissed: false, cloudDialog: null,

  init: async () => {
    // Offline edition, or opened from disk: there is no server. Never touch the network.
    if (OFFLINE_BUILD || location.protocol === 'file:' || !/^https?:$/.test(location.protocol)) { set({ config: null, cloudAvailable: false, ready: true }); return; }
    try {
      const config = await api.get<PublicConfig>('/config', 8000);
      // only a real answer from our API counts (shape check), anything else means "no backend here"
      if (!config || typeof config !== 'object' || typeof config.appName !== 'string' || typeof config.registrationEnabled !== 'boolean') throw new Error('not our API');
      set({ config, cloudAvailable: true });
    } catch {
      set({ config: null, cloudAvailable: false, ready: true });
      return;
    }
    try {
      const me = await api.get<{ user: User; teams: Team[] }>('/auth/me');
      set({ user: me.user, teams: me.teams });
    } catch { set({ user: null, teams: [] }); }
    set({ ready: true });

    // deep links: password reset, e-mail confirmation, team invitation
    const { pathname, searchParams } = new URL(location.href);
    const token = searchParams.get('token');
    const m = /^\/invite\/([\w-]{10,100})$/.exec(pathname);
    if (pathname === '/reset-password' && token) get().openPage('reset', token);
    else if (pathname === '/verify-email' && token) get().openPage('verify', token);
    else if (m) {
      if (get().user) get().openPage('invite', m[1]);
      else { set({ pendingInvite: m[1] }); get().openPage('login'); }
    }
    if (pathname !== '/') history.replaceState(null, '', '/');
  },

  refresh: async () => {
    try {
      const me = await api.get<{ user: User; teams: Team[] }>('/auth/me');
      set({ user: me.user, teams: me.teams });
    } catch (e) {
      if (e instanceof ApiError && e.status === 401) set({ user: null, teams: [] });
    }
  },

  setSession: (user, teams) => set({ user, teams }),

  signOut: async () => {
    try { await api.post('/auth/logout'); } catch { /* the cookie is cleared server side; ignore network errors */ }
    set({ user: null, teams: [], page: null });
    // never leave a private cloud project on screen after signing out
    if (useStore.getState().cloud) useStore.getState().closeProject();
  },

  openPage: (page, pageArg = null) => set({ page, pageArg }),
  closePage: () => set({ page: null, pageArg: null }),
}));

/** Sends the user to the sign-in page when an action needs an account. */
export function requireLogin(): boolean {
  const a = useAuth.getState();
  if (a.user) return true;
  a.openPage('login');
  return false;
}
