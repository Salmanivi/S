import { useEffect, useState } from 'react';
import { FolderTree, PenLine, Cpu, Tags, Eye, Factory, Gauge, PanelRightClose, PanelRightOpen, ListTree, SlidersHorizontal } from 'lucide-react';
import { useStore, startLoops } from './store';
import { TopBar, PhoneTopBar, ProjectTree, InfoPanel, InfoSheet, Toast, ExamplesDialog, HelpDialog } from './components/Shell';
import { LadderEditor, TagDatalists, useEditorShortcuts } from './components/ladder/LadderEditor';
import { InstructionPalette, PropertiesPanel } from './components/TaskCards';
import { SimPanel } from './components/SimPanel';
import { DeviceConfig, CpuCatalogDialog } from './components/DeviceConfig';
import { TagTable, WatchTable } from './components/Tables';
import { PlantView } from './components/PlantView';
import { StartScreen, NewProjectDialog } from './components/StartScreen';
import { Sheet, useIsPhone } from './components/Sheet';
import { useAuth } from './cloud/auth';
import { startSync } from './cloud/sync';
import { CloudOverlays } from './cloud/CloudShell';
import { AnnouncementBar } from './cloud/Chrome';
import { runtime } from './plc/runtime';

function TaskCard() {
  const tab = useStore(s => s.rightTab);
  const view = useStore(s => s.view);
  const st = useStore.getState;
  const showEditorTabs = view === 'block';
  const cur = showEditorTabs ? tab : 'sim';
  return (
    <div className="flex flex-col h-full min-h-0 bg-panel">
      <div className="flex border-b border-line px-1 shrink-0">
        {showEditorTabs && <button className={`tab flex items-center gap-1 ${cur === 'instr' ? 'tab-active' : ''}`} onClick={() => st().set({ rightTab: 'instr' })}><ListTree size={13} />Instructions</button>}
        {showEditorTabs && <button className={`tab flex items-center gap-1 ${cur === 'props' ? 'tab-active' : ''}`} onClick={() => st().set({ rightTab: 'props' })}><SlidersHorizontal size={13} />Properties</button>}
        <button className={`tab flex items-center gap-1 ${cur === 'sim' ? 'tab-active' : ''}`} onClick={() => st().set({ rightTab: 'sim' })}><Cpu size={13} />PLCSIM</button>
      </div>
      <div className="flex-1 min-h-0">
        {cur === 'instr' && <InstructionPalette />}
        {cur === 'props' && <PropertiesPanel />}
        {cur === 'sim' && <SimPanel />}
      </div>
    </div>
  );
}

function MainView() {
  const view = useStore(s => s.view);
  switch (view) {
    case 'device': return <DeviceConfig />;
    case 'tags': return <TagTable />;
    case 'watch': return <WatchTable />;
    case 'plant': return <PlantView />;
    default: return <LadderEditor />;
  }
}

const VIEW_NAV = {
  block: { icon: <PenLine size={22} />, label: 'Editor' },
  device: { icon: <Cpu size={22} />, label: 'Device' },
  tags: { icon: <Tags size={22} />, label: 'Tags' },
  watch: { icon: <Eye size={22} />, label: 'Watch' },
  plant: { icon: <Factory size={22} />, label: 'Plant' },
} as const;

function NavItem({ id, icon, label, tab, badge }: { id: 'tree' | 'main' | 'sim'; icon: React.ReactNode; label: string; tab: string; badge?: boolean }) {
  const on = tab === id;
  return (
    <button onClick={() => useStore.getState().set({ mobileTab: id })} aria-current={on ? 'page' : undefined}
      className={`relative flex-1 flex flex-col items-center justify-center gap-0.5 h-14 text-[11px] font-medium [@media(max-height:480px)]:h-11 [@media(max-height:480px)]:flex-row [@media(max-height:480px)]:gap-2 ${on ? 'text-accent' : 'text-mute'}`}>
      {on && <span className="absolute top-0 h-0.5 w-10 rounded-full bg-accent" />}
      <span className="relative">{icon}{badge && <span className="absolute -top-0.5 -right-1.5 w-2 h-2 rounded-full bg-on shadow-[0_0_6px_var(--c-on)]" />}</span>
      {label}
    </button>
  );
}

function MobileNav() {
  const tab = useStore(s => s.mobileTab);
  const view = useStore(s => s.view);
  useStore(s => Math.floor(s.tick / 5));
  const cur = VIEW_NAV[view as keyof typeof VIEW_NAV] ?? VIEW_NAV.block;
  return (
    <nav className="lg:hidden shrink-0 flex border-t border-line bg-panel pb-[env(safe-area-inset-bottom)]" aria-label="Main navigation">
      <NavItem tab={tab} id="tree" icon={<FolderTree size={22} />} label="Project" />
      <NavItem tab={tab} id="main" icon={cur.icon} label={cur.label} />
      <NavItem tab={tab} id="sim" icon={<Gauge size={22} />} label="Simulate" badge={runtime.mode === 'RUN'} />
    </nav>
  );
}

function PhoneSheets() {
  const sheet = useStore(s => s.sheet);
  const st = useStore.getState;
  const close = () => st().set({ sheet: null });
  if (sheet === 'instr') return <Sheet title="Add instruction" tall onClose={close}><InstructionPalette inSheet /></Sheet>;
  if (sheet === 'props') return <Sheet title="Properties" onClose={close}><PropertiesPanel /></Sheet>;
  if (sheet === 'info') return <InfoSheet />;
  return null;
}

function Dialogs() {
  const dialog = useStore(s => s.dialog);
  return (
    <>
      {dialog === 'examples' && <ExamplesDialog />}
      {dialog === 'new' && <NewProjectDialog />}
      {dialog === 'cpu' && <CpuCatalogDialog />}
      {dialog === 'help' && <HelpDialog />}
      <Toast />
    </>
  );
}

export default function App() {
  const theme = useStore(s => s.theme);
  const projectOpen = useStore(s => s.projectOpen);
  const mobileTab = useStore(s => s.mobileTab);
  const view = useStore(s => s.view);
  const phone = useIsPhone();
  const [rightOpen, setRightOpen] = useState(true);
  useEditorShortcuts();

  useEffect(() => { startLoops(); startSync(); void useAuth.getState().init(); }, []);
  useEffect(() => {
    document.documentElement.classList.toggle('light', theme === 'light');
    document.documentElement.classList.toggle('dark', theme === 'dark');
    document.querySelector('meta[name=theme-color]')?.setAttribute('content', theme === 'dark' ? '#0d1218' : '#e9eef3');
  }, [theme]);

  // nothing is stored automatically, so warn before the page is closed with unsaved work
  useEffect(() => {
    const h = (e: BeforeUnloadEvent) => {
      const s = useStore.getState();
      if (s.projectOpen && s.dirty) { e.preventDefault(); e.returnValue = ''; }
    };
    window.addEventListener('beforeunload', h);
    return () => window.removeEventListener('beforeunload', h);
  }, []);

  if (!projectOpen) {
    return (
      <div className="h-[100dvh] bg-bg text-ink overflow-hidden flex flex-col">
        <AnnouncementBar />
        <div className="flex-1 min-h-0"><StartScreen /></div>
        <Dialogs />
        <CloudOverlays />
      </div>
    );
  }

  return (
    <div className="h-[100dvh] flex flex-col bg-bg text-ink overflow-hidden">
      <AnnouncementBar />
      <TopBar />
      <PhoneTopBar />
      <div className="flex-1 flex min-h-0">
        <aside className="hidden lg:flex w-60 xl:w-64 shrink-0 border-r border-line bg-panel flex-col"><ProjectTree /></aside>

        <main className="flex-1 min-w-0 flex flex-col relative">
          <div className={`flex-1 min-h-0 ${mobileTab !== 'main' ? 'hidden lg:block' : ''}`}><MainView /></div>
          {mobileTab === 'tree' && <div className="flex-1 min-h-0 lg:hidden bg-panel"><ProjectTree /></div>}
          {mobileTab === 'sim' && <div className="flex-1 min-h-0 lg:hidden bg-panel"><SimPanel /></div>}
          <div className="hidden lg:block"><InfoPanel /></div>
          <button onClick={() => setRightOpen(o => !o)} className="hidden lg:flex absolute right-2 bottom-11 z-20 btn btn-icon shadow-lg" title={rightOpen ? 'Hide task cards' : 'Show task cards'}>
            {rightOpen ? <PanelRightClose size={15} /> : <PanelRightOpen size={15} />}
          </button>
        </main>

        {rightOpen && (
          <aside className={`hidden lg:flex ${view === 'plant' ? 'w-72' : 'w-[300px] xl:w-[320px]'} shrink-0 border-l border-line flex-col`}><TaskCard /></aside>
        )}
      </div>
      <MobileNav />
      <TagDatalists />
      {phone && <PhoneSheets />}
      <Dialogs />
      <CloudOverlays />
    </div>
  );
}
