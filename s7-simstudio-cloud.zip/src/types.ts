export type DataType =
  | 'Bool' | 'Byte' | 'Word' | 'DWord'
  | 'SInt' | 'USInt' | 'Int' | 'UInt' | 'DInt' | 'UDInt'
  | 'Real' | 'Time';

export const ALL_TYPES: DataType[] = ['Bool', 'Byte', 'Word', 'DWord', 'SInt', 'USInt', 'Int', 'UInt', 'DInt', 'UDInt', 'Real', 'Time'];

export interface Tag {
  id: string;
  name: string;
  dataType: DataType;
  address: string;
  comment: string;
}

export interface LadderInstr {
  id: string;
  kind: 'instr';
  op: string;
  operand: string;
  params: Record<string, string>;
  dataType?: DataType;
  dataType2?: DataType;
  /** When true the data type(s) are detected from the operands (kept in sync on every change). */
  autoType?: boolean;
  instance?: string;
}

export interface SeriesNode {
  id: string;
  kind: 'ser';
  items: Elem[];
}

export interface ParallelNode {
  id: string;
  kind: 'par';
  branches: SeriesNode[];
}

export type Elem = LadderInstr | ParallelNode;

export interface Network {
  id: string;
  title: string;
  comment: string;
  root: SeriesNode;
}

export type BlockKind = 'main' | 'startup' | 'cyclic' | 'fc';

export interface Block {
  id: string;
  name: string;
  kind: BlockKind;
  number: number;
  cycleMs?: number;
  comment: string;
  networks: Network[];
}

/** Start byte of each I/O area. A missing value means "assign automatically". */
export interface IoStart { di?: number; dq?: number; ai?: number; aq?: number }

export interface ModuleInstance {
  slot: number;
  moduleId: string;
  /** Custom I/O start addresses (byte). */
  start?: IoStart;
}

export interface CpuProps {
  name: string;
  ip: string;
  clockEnabled: boolean;
  clockByte: number;
  sysEnabled: boolean;
  sysByte: number;
  watchdogMs: number;
}

export interface HardwareConfig {
  cpuId: string;
  modules: ModuleInstance[];
  props: CpuProps;
  /** Custom start addresses for the CPU's onboard I/O. */
  cpuStart?: IoStart;
}

export interface WatchRow {
  id: string;
  operand: string;
  format: 'auto' | 'dec' | 'hex' | 'bin' | 'bool';
  modify: string;
}

export interface PlantDevice {
  id: string;
  type: string;
  name: string;
  x: number;
  y: number;
  bind: Record<string, string>;
  cfg: Record<string, string | number | boolean>;
}

export interface Project {
  name: string;
  hardware: HardwareConfig;
  tags: Tag[];
  blocks: Block[];
  watch: WatchRow[];
  devices: PlantDevice[];
}

export type View = 'device' | 'tags' | 'block' | 'watch' | 'plant';

export interface CompileMsg {
  level: 'error' | 'warning' | 'info';
  blockId?: string;
  networkId?: string;
  elemId?: string;
  text: string;
}
