import type { DataType, PlantDevice } from '../types';
import type { Ref, ResolveResult } from '../plc/resolve';
import { runtime } from '../plc/runtime';

export interface BindDef { key: string; label: string; dir: 'toPlc' | 'fromPlc'; kind: 'bool' | 'word'; optional?: boolean }
export interface CfgDef { key: string; label: string; type: 'color' | 'number' | 'text' | 'bool' | 'select'; options?: string[]; def: string | number | boolean }
export interface DeviceDef { type: string; name: string; category: string; w: number; h: number; binds: BindDef[]; cfg: CfgDef[]; desc: string }

const COLORS = ['green', 'red', 'yellow', 'blue', 'white', 'orange'];
const b = (key: string, label: string, dir: 'toPlc' | 'fromPlc', optional = false): BindDef => ({ key, label, dir, kind: 'bool', optional });
const w = (key: string, label: string, dir: 'toPlc' | 'fromPlc', optional = false): BindDef => ({ key, label, dir, kind: 'word', optional });

export const DEVICE_DEFS: DeviceDef[] = [
  // ---------------- command devices
  { type: 'pushbutton', name: 'Push button', category: 'Command devices', w: 110, h: 130, desc: 'Momentary push button (NO / NC contact), optional illumination.',
    binds: [b('out', 'Contact → input', 'toPlc'), b('lamp', 'Illumination ← output', 'fromPlc', true)],
    cfg: [{ key: 'color', label: 'Color', type: 'select', options: COLORS.concat(['black']), def: 'green' }, { key: 'contact', label: 'Contact', type: 'select', options: ['NO', 'NC'], def: 'NO' }, { key: 'label', label: 'Legend', type: 'text', def: 'START' }] },
  { type: 'switch', name: 'Selector switch (2-pos)', category: 'Command devices', w: 110, h: 130, desc: 'Maintained 2-position selector / toggle switch.',
    binds: [b('out', 'Contact → input', 'toPlc')],
    cfg: [{ key: 'label', label: 'Legend', type: 'text', def: 'AUTO' }, { key: 'l0', label: 'Pos 0 text', type: 'text', def: 'OFF' }, { key: 'l1', label: 'Pos 1 text', type: 'text', def: 'ON' }] },
  { type: 'selector3', name: 'Selector switch (3-pos)', category: 'Command devices', w: 120, h: 130, desc: '3-position selector (e.g. HAND–OFF–AUTO).',
    binds: [b('left', 'Left position → input', 'toPlc'), b('right', 'Right position → input', 'toPlc')],
    cfg: [{ key: 'label', label: 'Legend', type: 'text', def: 'MODE' }, { key: 'lL', label: 'Left text', type: 'text', def: 'HAND' }, { key: 'lR', label: 'Right text', type: 'text', def: 'AUTO' }] },
  { type: 'estop', name: 'Emergency stop', category: 'Command devices', w: 120, h: 140, desc: 'Latching mushroom E-stop with NC contact (input = 1 when healthy). Twist (click again) to release.',
    binds: [b('out', 'NC contact → input', 'toPlc')], cfg: [] },
  { type: 'keyswitch', name: 'Key switch', category: 'Command devices', w: 110, h: 130, desc: 'Maintained key-operated switch.',
    binds: [b('out', 'Contact → input', 'toPlc')], cfg: [{ key: 'label', label: 'Legend', type: 'text', def: 'ENABLE' }] },
  { type: 'pot', name: 'Potentiometer / setpoint', category: 'Command devices', w: 170, h: 120, desc: 'Analog value 0…27648 written to an input word (IW) or memory word.',
    binds: [w('out', 'Analog value → word', 'toPlc')], cfg: [{ key: 'label', label: 'Label', type: 'text', def: 'Setpoint' }, { key: 'max', label: 'Raw max', type: 'number', def: 27648 }, { key: 'eu', label: 'Engineering max', type: 'number', def: 100 }, { key: 'unit', label: 'Unit', type: 'text', def: '%' }] },
  { type: 'numinput', name: 'Numeric entry (HMI)', category: 'Command devices', w: 170, h: 100, desc: 'HMI-style numeric input field writing an Int value.',
    binds: [w('out', 'Value → word', 'toPlc')], cfg: [{ key: 'label', label: 'Label', type: 'text', def: 'Preset' }, { key: 'min', label: 'Min', type: 'number', def: -32768 }, { key: 'max', label: 'Max', type: 'number', def: 32767 }] },

  // ---------------- sensors
  { type: 'sensor', name: 'Sensor (prox / photo)', category: 'Sensors', w: 120, h: 110, desc: 'Inductive, capacitive or photoelectric sensor. Click to simulate a target.',
    binds: [b('out', 'Signal → input', 'toPlc')], cfg: [{ key: 'kind', label: 'Type', type: 'select', options: ['Inductive', 'Capacitive', 'Photoelectric'], def: 'Inductive' }, { key: 'contact', label: 'Output', type: 'select', options: ['NO', 'NC'], def: 'NO' }, { key: 'label', label: 'Label', type: 'text', def: 'B1' }] },
  { type: 'limit', name: 'Limit switch', category: 'Sensors', w: 110, h: 110, desc: 'Roller lever limit switch. Click to actuate (toggle).',
    binds: [b('out', 'Contact → input', 'toPlc')], cfg: [{ key: 'contact', label: 'Contact', type: 'select', options: ['NO', 'NC'], def: 'NO' }, { key: 'label', label: 'Label', type: 'text', def: 'S1' }] },

  // ---------------- indicators
  { type: 'lamp', name: 'Pilot lamp', category: 'Indicators', w: 100, h: 120, desc: 'Indicator lamp driven by a PLC output.',
    binds: [b('in', 'Lamp ← output', 'fromPlc')], cfg: [{ key: 'color', label: 'Color', type: 'select', options: COLORS, def: 'green' }, { key: 'label', label: 'Legend', type: 'text', def: 'RUN' }] },
  { type: 'stack', name: 'Signal tower', category: 'Indicators', w: 90, h: 200, desc: 'Stack light with red, yellow, green, blue and buzzer.',
    binds: [b('red', 'Red ← output', 'fromPlc', true), b('yellow', 'Yellow ← output', 'fromPlc', true), b('green', 'Green ← output', 'fromPlc', true), b('blue', 'Blue ← output', 'fromPlc', true), b('buzz', 'Buzzer ← output', 'fromPlc', true)], cfg: [] },
  { type: 'buzzer', name: 'Horn / buzzer', category: 'Indicators', w: 100, h: 110, desc: 'Acoustic alarm (visual only).',
    binds: [b('in', 'Horn ← output', 'fromPlc')], cfg: [{ key: 'label', label: 'Label', type: 'text', def: 'ALARM' }] },
  { type: 'traffic', name: 'Traffic light', category: 'Indicators', w: 80, h: 190, desc: 'Red / yellow / green traffic signal.',
    binds: [b('red', 'Red ← output', 'fromPlc'), b('yellow', 'Yellow ← output', 'fromPlc'), b('green', 'Green ← output', 'fromPlc')], cfg: [{ key: 'label', label: 'Label', type: 'text', def: 'North' }] },
  { type: 'sevenseg', name: '7-segment display', category: 'Indicators', w: 200, h: 100, desc: 'Shows an integer value on 4 digits.',
    binds: [w('in', 'Value ← word', 'fromPlc')], cfg: [{ key: 'label', label: 'Label', type: 'text', def: 'Count' }, { key: 'color', label: 'Color', type: 'select', options: ['red', 'green', 'blue', 'amber'], def: 'red' }] },
  { type: 'display', name: 'Numeric display (HMI)', category: 'Indicators', w: 180, h: 100, desc: 'HMI I/O field showing a value with scaling and unit.',
    binds: [w('in', 'Value ← word/dword', 'fromPlc')], cfg: [{ key: 'label', label: 'Label', type: 'text', def: 'Value' }, { key: 'dtype', label: 'Data type', type: 'select', options: ['Int', 'UInt', 'DInt', 'Real', 'Time'], def: 'Int' }, { key: 'factor', label: 'Factor', type: 'number', def: 1 }, { key: 'dec', label: 'Decimals', type: 'number', def: 0 }, { key: 'unit', label: 'Unit', type: 'text', def: '' }] },
  { type: 'gauge', name: 'Analog gauge', category: 'Indicators', w: 170, h: 160, desc: 'Analog meter; raw 0…27648 scaled to engineering units.',
    binds: [w('in', 'Analog ← word', 'fromPlc')], cfg: [{ key: 'label', label: 'Label', type: 'text', def: 'Pressure' }, { key: 'max', label: 'Raw max', type: 'number', def: 27648 }, { key: 'eu', label: 'Engineering max', type: 'number', def: 10 }, { key: 'unit', label: 'Unit', type: 'text', def: 'bar' }] },
  { type: 'bargraph', name: 'Bar graph', category: 'Indicators', w: 90, h: 180, desc: 'Vertical bar indicator for an analog value.',
    binds: [w('in', 'Analog ← word', 'fromPlc')], cfg: [{ key: 'label', label: 'Label', type: 'text', def: 'Level' }, { key: 'max', label: 'Raw max', type: 'number', def: 27648 }] },

  // ---------------- actuators
  { type: 'motor', name: 'Motor (DOL / reversing)', category: 'Actuators', w: 150, h: 140, desc: '3-phase motor with contactor, optional reverse, feedback and thermal overload (NC).',
    binds: [b('fwd', 'Run / forward ← output', 'fromPlc'), b('rev', 'Reverse ← output', 'fromPlc', true), b('fb', 'Running feedback → input', 'toPlc', true), b('ol', 'Overload OK (NC) → input', 'toPlc', true)],
    cfg: [{ key: 'label', label: 'Label', type: 'text', def: 'M1' }, { key: 'ramp', label: 'Ramp time (s)', type: 'number', def: 1 }] },
  { type: 'vfd', name: 'Frequency drive (VFD)', category: 'Actuators', w: 190, h: 150, desc: 'Drive with run command, analog speed setpoint (QW 0…27648) and actual speed feedback (IW).',
    binds: [b('run', 'Run ← output', 'fromPlc'), b('rev', 'Reverse ← output', 'fromPlc', true), w('sp', 'Speed setpoint ← word', 'fromPlc', true), w('act', 'Actual speed → word', 'toPlc', true), b('rdy', 'Running → input', 'toPlc', true)],
    cfg: [{ key: 'label', label: 'Label', type: 'text', def: 'G1' }, { key: 'rpm', label: 'Max speed (rpm)', type: 'number', def: 1500 }, { key: 'ramp', label: 'Ramp time (s)', type: 'number', def: 3 }] },
  { type: 'pump', name: 'Pump', category: 'Actuators', w: 130, h: 120, desc: 'Centrifugal pump with optional running feedback.',
    binds: [b('run', 'Run ← output', 'fromPlc'), b('fb', 'Running → input', 'toPlc', true)], cfg: [{ key: 'label', label: 'Label', type: 'text', def: 'P1' }] },
  { type: 'fan', name: 'Fan', category: 'Actuators', w: 120, h: 120, desc: 'Ventilation fan.',
    binds: [b('run', 'Run ← output', 'fromPlc')], cfg: [{ key: 'label', label: 'Label', type: 'text', def: 'Fan' }] },
  { type: 'valve', name: 'Solenoid valve', category: 'Actuators', w: 120, h: 120, desc: 'On/off valve with optional open feedback.',
    binds: [b('open', 'Open ← output', 'fromPlc'), b('fb', 'Open feedback → input', 'toPlc', true)], cfg: [{ key: 'label', label: 'Label', type: 'text', def: 'Y1' }, { key: 'time', label: 'Stroke time (s)', type: 'number', def: 0.5 }] },
  { type: 'cylinder', name: 'Pneumatic cylinder', category: 'Actuators', w: 230, h: 110, desc: 'Single (spring return) or double acting cylinder with reed switches.',
    binds: [b('ext', 'Extend (Y+) ← output', 'fromPlc'), b('ret', 'Retract (Y−) ← output', 'fromPlc', true), b('sRet', 'Retracted B0 → input', 'toPlc', true), b('sExt', 'Extended B1 → input', 'toPlc', true)],
    cfg: [{ key: 'label', label: 'Label', type: 'text', def: 'A1' }, { key: 'time', label: 'Stroke time (s)', type: 'number', def: 1 }] },
  { type: 'gate', name: 'Gate / door', category: 'Actuators', w: 220, h: 140, desc: 'Motorised gate with open/close commands and limit switches.',
    binds: [b('open', 'Open ← output', 'fromPlc'), b('close', 'Close ← output', 'fromPlc'), b('lsO', 'Open limit → input', 'toPlc', true), b('lsC', 'Closed limit → input', 'toPlc', true)],
    cfg: [{ key: 'label', label: 'Label', type: 'text', def: 'Gate' }, { key: 'time', label: 'Travel time (s)', type: 'number', def: 5 }] },
  { type: 'heater', name: 'Heater + temperature', category: 'Actuators', w: 160, h: 150, desc: 'Heating element with thermal model. Temperature as RTD value (0.1 °C) or 0…27648.',
    binds: [b('heat', 'Heater ← output', 'fromPlc'), w('temp', 'Temperature → word', 'toPlc', true), b('tstat', 'Thermostat → input', 'toPlc', true)],
    cfg: [{ key: 'label', label: 'Label', type: 'text', def: 'E1' }, { key: 'mode', label: 'Scaling', type: 'select', options: ['RTD 0.1°C', '0-27648 = 0-200°C'], def: 'RTD 0.1°C' }, { key: 'power', label: 'Heat rate (°C/s)', type: 'number', def: 2 }, { key: 'tset', label: 'Thermostat (°C)', type: 'number', def: 60 }] },

  // ---------------- process
  { type: 'tank', name: 'Tank with level', category: 'Process', w: 180, h: 230, desc: 'Tank with inlet/outlet valves, analog level transmitter and level switches.',
    binds: [b('in', 'Inlet valve ← output', 'fromPlc'), b('out', 'Outlet valve ← output', 'fromPlc', true), w('aq', 'Proportional inlet ← word', 'fromPlc', true), w('lvl', 'Level 0…27648 → word', 'toPlc', true), b('lo', 'Low level LSL → input', 'toPlc', true), b('hi', 'High level LSH → input', 'toPlc', true)],
    cfg: [{ key: 'label', label: 'Label', type: 'text', def: 'T1' }, { key: 'fill', label: 'Fill rate (%/s)', type: 'number', def: 8 }, { key: 'drain', label: 'Drain rate (%/s)', type: 'number', def: 6 }, { key: 'loP', label: 'Low switch (%)', type: 'number', def: 15 }, { key: 'hiP', label: 'High switch (%)', type: 'number', def: 85 }, { key: 'liquid', label: 'Liquid', type: 'select', options: ['water', 'oil', 'chemical'], def: 'water' }] },
  { type: 'conveyor', name: 'Conveyor + parts', category: 'Process', w: 340, h: 130, desc: 'Belt conveyor with part feeder and photo-eyes at entry, middle and end.',
    binds: [b('run', 'Motor forward ← output', 'fromPlc'), b('rev', 'Motor reverse ← output', 'fromPlc', true), b('sIn', 'Entry sensor → input', 'toPlc', true), b('sMid', 'Middle sensor → input', 'toPlc', true), b('sEnd', 'End sensor → input', 'toPlc', true)],
    cfg: [{ key: 'label', label: 'Label', type: 'text', def: 'Conveyor 1' }, { key: 'speed', label: 'Speed (belt/s)', type: 'number', def: 0.15 }, { key: 'auto', label: 'Auto feed (s, 0=off)', type: 'number', def: 0 }, { key: 'remove', label: 'Remove parts at end', type: 'bool', def: false }] },
  { type: 'label', name: 'Text label / area', category: 'Process', w: 200, h: 60, desc: 'Annotation for structuring large plants.',
    binds: [], cfg: [{ key: 'text', label: 'Text', type: 'text', def: 'Area 1' }, { key: 'size', label: 'Font size', type: 'number', def: 18 }] },
];

export const DEVICE_MAP: Record<string, DeviceDef> = Object.fromEntries(DEVICE_DEFS.map(d => [d.type, d]));
export const DEVICE_CATEGORIES = Array.from(new Set(DEVICE_DEFS.map(d => d.category)));

export interface PlantSt {
  pressed?: boolean; on?: boolean; pos?: number; value?: number; speed?: number; angle?: number;
  level?: number; temp?: number; items?: number[]; feedT?: number; trip?: boolean; rpm?: number; dir?: number; t?: number;
}

export const plantState = new Map<string, PlantSt>();
export const getSt = (id: string): PlantSt => {
  let s = plantState.get(id);
  if (!s) { s = {}; plantState.set(id, s); }
  return s;
};

export const plantCtx: { devices: PlantDevice[]; resolve: (s: string) => ResolveResult } = {
  devices: [],
  resolve: () => ({ k: 'none' }),
};

const num = (v: unknown, d: number) => { const n = typeof v === 'number' ? v : parseFloat(String(v)); return Number.isFinite(n) ? n : d; };
export const cfgOf = (dev: PlantDevice, key: string) => {
  if (dev.cfg[key] !== undefined) return dev.cfg[key];
  return DEVICE_MAP[dev.type]?.cfg.find(c => c.key === key)?.def;
};

function makeIO(dev: PlantDevice) {
  const ref = (key: string): Ref | null => {
    const s = dev.bind[key];
    if (!s || !s.trim()) return null;
    const r = plantCtx.resolve(s);
    return r.k === 'mem' || r.k === 'inst' ? r : null;
  };
  return {
    has: (key: string) => !!ref(key),
    getB: (key: string) => { const r = ref(key); if (!r) return false; const v = runtime.readPhys(r, 'Bool'); return typeof v === 'boolean' ? v : v !== 0; },
    getN: (key: string, dt: DataType = 'Int') => { const r = ref(key); if (!r) return 0; const v = runtime.readPhys(r, r.k === 'mem' && r.a.size === 'D' && dt !== 'Real' && dt !== 'DInt' && dt !== 'UDInt' && dt !== 'Time' ? 'DInt' : dt); return typeof v === 'boolean' ? (v ? 1 : 0) : v; },
    setB: (key: string, v: boolean) => { const r = ref(key); if (r && r.k === 'mem' && r.a.size === 'X') runtime.modify(r, 'Bool', v); },
    setN: (key: string, v: number) => { const r = ref(key); if (r && r.k === 'mem' && r.a.size !== 'X') runtime.modify(r, r.a.size === 'W' ? 'Int' : r.a.size === 'B' ? 'Byte' : 'DInt', v); },
  };
}

const approach = (cur: number, target: number, step: number) => (cur < target ? Math.min(target, cur + step) : Math.max(target, cur - step));

export function stepPlant(dtMs: number) {
  const dt = dtMs / 1000;
  for (const dev of plantCtx.devices) {
    const st = getSt(dev.id);
    const io = makeIO(dev);
    const c = (k: string, d: number) => num(cfgOf(dev, k), d);
    switch (dev.type) {
      case 'pushbutton': io.setB('out', cfgOf(dev, 'contact') === 'NC' ? !st.pressed : !!st.pressed); break;
      case 'switch': case 'keyswitch': io.setB('out', !!st.on); break;
      case 'selector3': io.setB('left', st.pos === -1); io.setB('right', st.pos === 1); break;
      case 'estop': io.setB('out', !st.pressed); break;
      case 'sensor': case 'limit': io.setB('out', cfgOf(dev, 'contact') === 'NC' ? !st.on : !!st.on); break;
      case 'pot': io.setN('out', Math.round((st.value ?? 0) * c('max', 27648))); break;
      case 'numinput': io.setN('out', Math.round(st.value ?? 0)); break;
      case 'motor': {
        const f = io.getB('fwd'), r = io.getB('rev');
        const target = st.trip ? 0 : f && !r ? 1 : r && !f ? -1 : 0;
        st.speed = approach(st.speed ?? 0, target, dt / Math.max(0.05, c('ramp', 1)));
        st.angle = ((st.angle ?? 0) + (st.speed ?? 0) * dt * 720) % 360;
        io.setB('fb', Math.abs(st.speed ?? 0) > 0.05);
        io.setB('ol', !st.trip);
        break;
      }
      case 'vfd': {
        const run = io.getB('run'), rev = io.getB('rev');
        const max = c('rpm', 1500);
        const sp = io.has('sp') ? Math.max(0, Math.min(1, io.getN('sp') / 27648)) : 1;
        const target = run && !st.trip ? (rev ? -1 : 1) * sp * max : 0;
        st.rpm = approach(st.rpm ?? 0, target, (max * dt) / Math.max(0.05, c('ramp', 3)));
        st.angle = ((st.angle ?? 0) + (st.rpm ?? 0) * dt * 0.8) % 360;
        io.setN('act', Math.round((Math.abs(st.rpm ?? 0) / max) * 27648));
        io.setB('rdy', Math.abs(st.rpm ?? 0) > 1);
        break;
      }
      case 'pump': case 'fan': {
        const run = io.getB('run');
        st.speed = approach(st.speed ?? 0, run ? 1 : 0, dt * 1.5);
        st.angle = ((st.angle ?? 0) + (st.speed ?? 0) * dt * 900) % 360;
        io.setB('fb', (st.speed ?? 0) > 0.3);
        break;
      }
      case 'valve': {
        st.pos = approach(st.pos ?? 0, io.getB('open') ? 1 : 0, dt / Math.max(0.05, c('time', 0.5)));
        io.setB('fb', (st.pos ?? 0) >= 0.99);
        break;
      }
      case 'cylinder': {
        const ext = io.getB('ext');
        const dbl = io.has('ret');
        const ret = io.getB('ret');
        let target = st.pos ?? 0;
        if (dbl) { if (ext && !ret) target = 1; else if (ret && !ext) target = 0; }
        else target = ext ? 1 : 0;
        st.pos = approach(st.pos ?? 0, target, dt / Math.max(0.05, c('time', 1)));
        io.setB('sRet', (st.pos ?? 0) <= 0.01);
        io.setB('sExt', (st.pos ?? 0) >= 0.99);
        break;
      }
      case 'gate': {
        const o = io.getB('open'), cl = io.getB('close');
        const step = dt / Math.max(0.1, c('time', 5));
        st.dir = o && !cl ? 1 : cl && !o ? -1 : 0;
        st.pos = Math.max(0, Math.min(1, (st.pos ?? 0) + (st.dir ?? 0) * step));
        io.setB('lsO', (st.pos ?? 0) >= 0.995);
        io.setB('lsC', (st.pos ?? 0) <= 0.005);
        break;
      }
      case 'heater': {
        const amb = 20;
        const T = st.temp ?? amb;
        const heat = io.getB('heat');
        const nt = T + ((heat ? c('power', 2) : 0) - 0.01 * (T - amb)) * dt;
        st.temp = Math.max(amb - 5, Math.min(400, nt));
        const mode = String(cfgOf(dev, 'mode'));
        io.setN('temp', mode.startsWith('RTD') ? Math.round(st.temp * 10) : Math.round(Math.max(0, Math.min(1, st.temp / 200)) * 27648));
        io.setB('tstat', st.temp >= c('tset', 60));
        break;
      }
      case 'tank': {
        let L = st.level ?? 0;
        let inflow = io.getB('in') ? c('fill', 8) : 0;
        if (io.has('aq')) inflow += (Math.max(0, Math.min(27648, io.getN('aq'))) / 27648) * c('fill', 8);
        const outflow = io.getB('out') ? c('drain', 6) * (L > 0 ? 1 : 0) : 0;
        L = Math.max(0, Math.min(100, L + (inflow - outflow) * dt));
        st.level = L;
        st.t = (st.t ?? 0) + dt;
        io.setN('lvl', Math.round((L / 100) * 27648));
        io.setB('lo', L >= c('loP', 15));
        io.setB('hi', L >= c('hiP', 85));
        break;
      }
      case 'conveyor': {
        const items = st.items ?? (st.items = []);
        const run = io.getB('run'), rev = io.getB('rev');
        const v = (run && !rev ? 1 : rev && !run ? -1 : 0) * c('speed', 0.15);
        st.speed = v;
        st.angle = ((st.angle ?? 0) + v * dt * 900) % 360;
        const auto = c('auto', 0);
        if (auto > 0) {
          st.feedT = (st.feedT ?? 0) + dt;
          if (st.feedT >= auto) { st.feedT = 0; if (!items.some(p => p < 0.12)) items.push(0.02); }
        }
        const GAP = 0.09;
        items.sort((a, b2) => a - b2);
        if (v > 0) {
          for (let i = items.length - 1; i >= 0; i--) {
            const limit = i === items.length - 1 ? (cfgOf(dev, 'remove') ? 1.2 : 0.97) : items[i + 1] - GAP;
            items[i] = Math.min(limit, items[i] + v * dt);
          }
        } else if (v < 0) {
          for (let i = 0; i < items.length; i++) {
            const limit = i === 0 ? 0.02 : items[i - 1] + GAP;
            items[i] = Math.max(limit, items[i] + v * dt);
          }
        }
        st.items = items.filter(p => p <= 1.0);
        const near = (x: number) => st.items!.some(p => Math.abs(p - x) < 0.035);
        io.setB('sIn', near(0.06));
        io.setB('sMid', near(0.5));
        io.setB('sEnd', near(0.95));
        break;
      }
    }
  }
}
