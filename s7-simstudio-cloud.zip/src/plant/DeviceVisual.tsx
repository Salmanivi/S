import type { DataType, PlantDevice } from '../types';
import { cfgOf, getSt, plantCtx } from './devices';
import { runtime } from '../plc/runtime';
import { formatValue } from '../plc/values';

const LAMP: Record<string, string> = { green: '#34d374', red: '#ff4b4b', yellow: '#ffd23f', blue: '#3b9bff', white: '#f4f7fb', orange: '#ff9a2e', black: '#2b2f35', amber: '#ffb020' };

export function rb(dev: PlantDevice, key: string): boolean {
  const s = dev.bind[key];
  if (!s) return false;
  const r = plantCtx.resolve(s);
  if (r.k !== 'mem' && r.k !== 'inst') return false;
  const v = runtime.readPhys(r, 'Bool');
  return v === true || v === 1;
}
export function rn(dev: PlantDevice, key: string, dt: DataType = 'Int'): number | null {
  const s = dev.bind[key];
  if (!s) return null;
  const r = plantCtx.resolve(s);
  if (r.k !== 'mem' && r.k !== 'inst') return null;
  let t = dt;
  if (r.k === 'mem') {
    if (r.a.size === 'D' && (t === 'Int' || t === 'UInt')) t = 'DInt';
    if (r.a.size === 'W' && (t === 'DInt' || t === 'Real' || t === 'Time')) t = 'Int';
    if (r.a.size === 'B') t = 'Byte';
  }
  const v = runtime.readPhys(r, t);
  return typeof v === 'boolean' ? (v ? 1 : 0) : v;
}
const c = (dev: PlantDevice, k: string) => cfgOf(dev, k);
const cn = (dev: PlantDevice, k: string, d: number) => { const v = Number(cfgOf(dev, k)); return Number.isFinite(v) ? v : d; };

function Glow({ cx, cy, r, color, on }: { cx: number; cy: number; r: number; color: string; on: boolean }) {
  return (
    <g>
      {on && <circle cx={cx} cy={cy} r={r * 1.9} fill={color} opacity={0.22} />}
      <circle cx={cx} cy={cy} r={r} fill={on ? color : '#2a3038'} stroke="#11161b" strokeWidth={2} />
      <circle cx={cx - r * 0.3} cy={cy - r * 0.35} r={r * 0.35} fill="#fff" opacity={on ? 0.45 : 0.08} />
    </g>
  );
}

function SevenSeg({ x, y, ch, color, h = 44 }: { x: number; y: number; ch: string; color: string; h?: number }) {
  const map: Record<string, string> = { '0': 'abcdef', '1': 'bc', '2': 'abged', '3': 'abgcd', '4': 'fgbc', '5': 'afgcd', '6': 'afgedc', '7': 'abc', '8': 'abcdefg', '9': 'abfgcd', '-': 'g', ' ': '', E: 'afged', r: 'eg', O: 'abcdef', F: 'afge', L: 'fed' };
  const on = map[ch] ?? '';
  const w = h * 0.55, t = h * 0.1, hh = h / 2;
  const segs: Record<string, [number, number, number, number]> = {
    a: [t, 0, w - 2 * t, t], d: [t, h - t, w - 2 * t, t], g: [t, hh - t / 2, w - 2 * t, t],
    f: [0, t, t, hh - 1.5 * t], b: [w - t, t, t, hh - 1.5 * t], e: [0, hh + t / 2, t, hh - 1.5 * t], c: [w - t, hh + t / 2, t, hh - 1.5 * t],
  };
  return <g transform={`translate(${x},${y})`}>{Object.entries(segs).map(([k, [sx, sy, sw, sh]]) => <rect key={k} x={sx} y={sy} width={sw} height={sh} rx={t / 2} fill={on.includes(k) ? color : color} opacity={on.includes(k) ? 1 : 0.08} />)}</g>;
}

export function DeviceVisual({ dev, w, h }: { dev: PlantDevice; w: number; h: number }) {
  const st = getSt(dev.id);
  const cx = w / 2;
  switch (dev.type) {
    case 'pushbutton': {
      const col = LAMP[String(c(dev, 'color'))] ?? '#34d374';
      const lit = rb(dev, 'lamp');
      const p = !!st.pressed;
      return (
        <svg width={w} height={h}>
          <circle cx={cx} cy={h / 2 - 8} r={34} fill="#20262d" stroke="#3b444e" strokeWidth={3} />
          <circle cx={cx} cy={h / 2 - 8} r={28} fill="#14181d" />
          {lit && <circle cx={cx} cy={h / 2 - 8} r={40} fill={col} opacity={0.25} />}
          <circle cx={cx} cy={h / 2 - 8 + (p ? 1.5 : 0)} r={p ? 21 : 23} fill={col} opacity={lit || p ? 1 : 0.85} stroke="#0008" strokeWidth={2} />
          <circle cx={cx - 6} cy={h / 2 - 15} r={7} fill="#fff" opacity={p ? 0.1 : 0.3} />
          <rect x={cx - 34} y={h - 26} width={68} height={16} rx={3} fill="#e8ecef" />
          <text x={cx} y={h - 14} textAnchor="middle" fontSize={9.5} fontWeight={700} fill="#1b2026">{String(c(dev, 'label'))}</text>
          <text x={w - 8} y={14} textAnchor="end" fontSize={9} fill="var(--c-mute)">{String(c(dev, 'contact'))}</text>
        </svg>
      );
    }
    case 'switch': case 'keyswitch': {
      const on = !!st.on;
      const isKey = dev.type === 'keyswitch';
      return (
        <svg width={w} height={h}>
          <text x={cx - 26} y={20} textAnchor="middle" fontSize={9} fill={!on ? 'var(--c-ink)' : 'var(--c-mute)'} fontWeight={700}>{isKey ? '0' : String(c(dev, 'l0'))}</text>
          <text x={cx + 26} y={20} textAnchor="middle" fontSize={9} fill={on ? 'var(--c-on)' : 'var(--c-mute)'} fontWeight={700}>{isKey ? 'I' : String(c(dev, 'l1'))}</text>
          <circle cx={cx} cy={h / 2 - 2} r={30} fill="#20262d" stroke="#3b444e" strokeWidth={3} />
          <g transform={`rotate(${on ? 45 : -45} ${cx} ${h / 2 - 2})`} style={{ transition: 'transform .15s' }}>
            {isKey ? (
              <><rect x={cx - 6} y={h / 2 - 26} width={12} height={34} rx={3} fill="#c9a43a" /><circle cx={cx} cy={h / 2 - 22} r={7} fill="#c9a43a" /></>
            ) : (
              <><rect x={cx - 7} y={h / 2 - 30} width={14} height={56} rx={6} fill="#111" /><rect x={cx - 2} y={h / 2 - 28} width={4} height={14} rx={2} fill="#fff" /></>
            )}
          </g>
          <rect x={cx - 34} y={h - 22} width={68} height={15} rx={3} fill="#e8ecef" />
          <text x={cx} y={h - 11} textAnchor="middle" fontSize={9} fontWeight={700} fill="#1b2026">{String(c(dev, 'label'))}</text>
        </svg>
      );
    }
    case 'selector3': {
      const pos = st.pos ?? 0;
      return (
        <svg width={w} height={h}>
          <text x={cx - 34} y={22} textAnchor="middle" fontSize={8.5} fill={pos === -1 ? 'var(--c-on)' : 'var(--c-mute)'} fontWeight={700}>{String(c(dev, 'lL'))}</text>
          <text x={cx} y={14} textAnchor="middle" fontSize={8.5} fill={pos === 0 ? 'var(--c-ink)' : 'var(--c-mute)'} fontWeight={700}>0</text>
          <text x={cx + 34} y={22} textAnchor="middle" fontSize={8.5} fill={pos === 1 ? 'var(--c-on)' : 'var(--c-mute)'} fontWeight={700}>{String(c(dev, 'lR'))}</text>
          <circle cx={cx} cy={h / 2} r={28} fill="#20262d" stroke="#3b444e" strokeWidth={3} />
          <g transform={`rotate(${pos * 45} ${cx} ${h / 2})`} style={{ transition: 'transform .15s' }}>
            <rect x={cx - 7} y={h / 2 - 27} width={14} height={54} rx={6} fill="#111" /><rect x={cx - 2} y={h / 2 - 25} width={4} height={13} rx={2} fill="#fff" />
          </g>
          <rect x={cx - 34} y={h - 20} width={68} height={14} rx={3} fill="#e8ecef" />
          <text x={cx} y={h - 10} textAnchor="middle" fontSize={8.5} fontWeight={700} fill="#1b2026">{String(c(dev, 'label'))}</text>
        </svg>
      );
    }
    case 'estop': {
      const p = !!st.pressed;
      return (
        <svg width={w} height={h}>
          <circle cx={cx} cy={h / 2 - 6} r={44} fill="#ffd21f" stroke="#c9a20a" strokeWidth={2} />
          <text x={cx} y={h / 2 - 38} textAnchor="middle" fontSize={7} fontWeight={800} fill="#5a4600">EMERGENCY STOP</text>
          <circle cx={cx} cy={h / 2 - 4} r={p ? 26 : 29} fill={p ? '#a51b1b' : '#e02424'} stroke="#6d0d0d" strokeWidth={3} />
          <circle cx={cx - 8} cy={h / 2 - 13} r={8} fill="#fff" opacity={p ? 0.08 : 0.28} />
          <text x={cx} y={h - 8} textAnchor="middle" fontSize={9} fontWeight={700} fill={p ? 'var(--c-danger)' : 'var(--c-mute)'}>{p ? 'PRESSED — click to release' : 'NC · healthy'}</text>
        </svg>
      );
    }
    case 'sensor': {
      const on = !!st.on;
      const kind = String(c(dev, 'kind'));
      const out = rb(dev, 'out') || (cfgOf(dev, 'contact') === 'NC' ? !on : on);
      return (
        <svg width={w} height={h}>
          <rect x={10} y={h / 2 - 13} width={52} height={26} rx={4} fill="#4b5560" stroke="#222" />
          <rect x={62} y={h / 2 - 10} width={8} height={20} fill={kind === 'Photoelectric' ? '#d33' : kind === 'Capacitive' ? '#36c' : '#e8a020'} />
          <circle cx={20} cy={h / 2 - 7} r={3.5} fill={out ? '#ffbf1f' : '#3a3f45'} />
          {kind === 'Photoelectric' && <line x1={70} y1={h / 2} x2={w - 10} y2={h / 2} stroke="#ff3b3b" strokeWidth={on ? 1 : 2} strokeDasharray={on ? '3 3' : undefined} opacity={0.7} />}
          {on && <rect x={82} y={h / 2 - 16} width={24} height={32} rx={3} fill="#9aa6b3" stroke="#59636e" />}
          <text x={10} y={16} fontSize={9.5} fontWeight={700} fill="var(--c-ink)">{String(c(dev, 'label'))}</text>
          <text x={10} y={h - 8} fontSize={8.5} fill="var(--c-mute)">{kind} · {String(c(dev, 'contact'))}{on ? ' · target' : ''}</text>
        </svg>
      );
    }
    case 'limit': {
      const on = !!st.on;
      return (
        <svg width={w} height={h}>
          <rect x={cx - 18} y={h / 2 - 4} width={36} height={30} rx={3} fill="#c7cdd3" stroke="#555" />
          <g transform={`rotate(${on ? -28 : 0} ${cx} ${h / 2})`} style={{ transition: 'transform .12s' }}>
            <rect x={cx - 2} y={h / 2 - 34} width={4} height={34} fill="#333" /><circle cx={cx} cy={h / 2 - 34} r={7} fill="#222" stroke="#666" />
          </g>
          <circle cx={cx + 11} cy={h / 2 + 6} r={3} fill={on ? '#ffbf1f' : '#555'} />
          <text x={8} y={14} fontSize={9.5} fontWeight={700} fill="var(--c-ink)">{String(c(dev, 'label'))}</text>
          <text x={w - 8} y={14} textAnchor="end" fontSize={8.5} fill="var(--c-mute)">{String(c(dev, 'contact'))}</text>
        </svg>
      );
    }
    case 'lamp': {
      const col = LAMP[String(c(dev, 'color'))] ?? '#34d374';
      const on = rb(dev, 'in');
      return (
        <svg width={w} height={h}>
          <circle cx={cx} cy={h / 2 - 10} r={30} fill="#20262d" stroke="#3b444e" strokeWidth={3} />
          <Glow cx={cx} cy={h / 2 - 10} r={20} color={col} on={on} />
          <rect x={cx - 32} y={h - 24} width={64} height={15} rx={3} fill="#e8ecef" />
          <text x={cx} y={h - 13} textAnchor="middle" fontSize={9} fontWeight={700} fill="#1b2026">{String(c(dev, 'label'))}</text>
        </svg>
      );
    }
    case 'stack': {
      const segs: [string, string][] = [['red', '#ff4b4b'], ['yellow', '#ffd23f'], ['green', '#34d374'], ['blue', '#3b9bff']];
      const buzz = rb(dev, 'buzz');
      return (
        <svg width={w} height={h}>
          {segs.map(([k, col], i) => { const on = rb(dev, k); return (
            <g key={k}>{on && <rect x={cx - 26} y={10 + i * 34} width={52} height={32} rx={6} fill={col} opacity={0.25} />}
              <rect x={cx - 18} y={12 + i * 34} width={36} height={30} rx={4} fill={on ? col : col} opacity={on ? 1 : 0.18} stroke="#0006" /></g>); })}
          <rect x={cx - 18} y={148} width={36} height={14} rx={2} fill={buzz ? '#e5e7ea' : '#5b636c'} className={buzz ? 'anim-blink' : ''} />
          <rect x={cx - 4} y={162} width={8} height={h - 168} fill="#7b848e" />
        </svg>
      );
    }
    case 'buzzer': {
      const on = rb(dev, 'in');
      return (
        <svg width={w} height={h}>
          <path d={`M${cx - 22} ${h / 2 - 18}h12l16-12v44l-16-12h-12z`} fill={on ? '#ff6b3d' : '#5b636c'} />
          {on && [0, 1, 2].map(i => <path key={i} d={`M${cx + 12 + i * 8} ${h / 2 - 16 - i * 4}q10 ${16 + i * 4} 0 ${32 + i * 8}`} fill="none" stroke="#ff6b3d" strokeWidth={2} className="anim-blink" />)}
          <text x={cx} y={h - 8} textAnchor="middle" fontSize={9} fontWeight={700} fill={on ? '#ff6b3d' : 'var(--c-mute)'}>{String(c(dev, 'label'))}</text>
        </svg>
      );
    }
    case 'traffic': {
      return (
        <svg width={w} height={h}>
          <rect x={cx - 24} y={6} width={48} height={136} rx={10} fill="#1c2127" stroke="#3b444e" strokeWidth={2} />
          <Glow cx={cx} cy={30} r={15} color="#ff4b4b" on={rb(dev, 'red')} />
          <Glow cx={cx} cy={74} r={15} color="#ffc21f" on={rb(dev, 'yellow')} />
          <Glow cx={cx} cy={118} r={15} color="#34d374" on={rb(dev, 'green')} />
          <rect x={cx - 3} y={142} width={6} height={h - 160} fill="#59626c" />
          <text x={cx} y={h - 4} textAnchor="middle" fontSize={9} fill="var(--c-mute)">{String(c(dev, 'label'))}</text>
        </svg>
      );
    }
    case 'sevenseg': {
      const v = rn(dev, 'in') ?? 0;
      const col = LAMP[String(c(dev, 'color'))] ?? '#ff4b4b';
      let s = v < -999 || v > 9999 ? '----' : String(Math.trunc(v)).padStart(4, ' ');
      if (s.length > 4) s = s.slice(-4);
      return (
        <svg width={w} height={h}>
          <rect x={6} y={6} width={w - 12} height={h - 26} rx={6} fill="#0b0d0f" stroke="#2a2f35" />
          {s.split('').map((ch, i) => <SevenSeg key={i} x={22 + i * 41} y={14} ch={ch} color={col} h={46} />)}
          <text x={cx} y={h - 6} textAnchor="middle" fontSize={9} fill="var(--c-mute)">{String(c(dev, 'label'))}</text>
        </svg>
      );
    }
    case 'display': {
      const dt = String(c(dev, 'dtype')) as DataType;
      const raw = rn(dev, 'in', dt);
      const f = cn(dev, 'factor', 1), dec = Math.max(0, Math.min(6, cn(dev, 'dec', 0)));
      const txt = raw === null ? '####' : dt === 'Time' ? formatValue(raw, 'Time') : (raw * f).toFixed(dec);
      return (
        <svg width={w} height={h}>
          <text x={10} y={14} fontSize={9.5} fill="var(--c-mute)">{String(c(dev, 'label'))}</text>
          <rect x={8} y={22} width={w - 16} height={h - 32} rx={6} fill="var(--c-bg)" stroke="var(--c-line)" />
          <text x={w - 18} y={h / 2 + 16} textAnchor="end" fontSize={24} fontFamily="var(--font-mono)" fill="var(--c-accent)">{txt}<tspan fontSize={12} fill="var(--c-mute)"> {String(c(dev, 'unit'))}</tspan></text>
        </svg>
      );
    }
    case 'gauge': {
      const raw = rn(dev, 'in') ?? 0;
      const max = cn(dev, 'max', 27648), eu = cn(dev, 'eu', 10);
      const frac = Math.max(0, Math.min(1, raw / max));
      const ang = -120 + frac * 240;
      const r = 54, gy = h / 2 + 6;
      const arc = (a0: number, a1: number) => { const p = (a: number) => [cx + r * Math.sin((a * Math.PI) / 180), gy - r * Math.cos((a * Math.PI) / 180)]; const [x0, y0] = p(a0), [x1, y1] = p(a1); return `M${x0} ${y0}A${r} ${r} 0 ${a1 - a0 > 180 ? 1 : 0} 1 ${x1} ${y1}`; };
      return (
        <svg width={w} height={h}>
          <path d={arc(-120, 120)} stroke="var(--c-line)" strokeWidth={10} fill="none" strokeLinecap="round" />
          <path d={arc(-120, Math.max(-119.9, ang))} stroke="var(--c-accent2)" strokeWidth={10} fill="none" strokeLinecap="round" />
          <path d={arc(72, 120)} stroke="var(--c-danger)" strokeWidth={3} fill="none" opacity={0.7} />
          <g transform={`rotate(${ang} ${cx} ${gy})`} style={{ transition: 'transform .1s linear' }}><path d={`M${cx - 3} ${gy}L${cx} ${gy - r + 8}L${cx + 3} ${gy}z`} fill="var(--c-ink)" /></g>
          <circle cx={cx} cy={gy} r={6} fill="var(--c-ink)" />
          <text x={cx} y={gy + 26} textAnchor="middle" fontSize={15} fontFamily="var(--font-mono)" fill="var(--c-ink)">{(frac * eu).toFixed(eu >= 100 ? 0 : 2)}<tspan fontSize={10} fill="var(--c-mute)"> {String(c(dev, 'unit'))}</tspan></text>
          <text x={cx} y={14} textAnchor="middle" fontSize={9.5} fill="var(--c-mute)">{String(c(dev, 'label'))}</text>
        </svg>
      );
    }
    case 'bargraph': {
      const raw = rn(dev, 'in') ?? 0;
      const frac = Math.max(0, Math.min(1, raw / cn(dev, 'max', 27648)));
      const bh = h - 44;
      return (
        <svg width={w} height={h}>
          <rect x={cx - 14} y={10} width={28} height={bh} rx={5} fill="var(--c-bg)" stroke="var(--c-line)" />
          <rect x={cx - 11} y={13 + (bh - 6) * (1 - frac)} width={22} height={(bh - 6) * frac} rx={3} fill={frac > 0.9 ? 'var(--c-danger)' : 'var(--c-accent)'} />
          <text x={cx} y={h - 20} textAnchor="middle" fontSize={11} fontFamily="var(--font-mono)" fill="var(--c-ink)">{(frac * 100).toFixed(0)}%</text>
          <text x={cx} y={h - 6} textAnchor="middle" fontSize={9} fill="var(--c-mute)">{String(c(dev, 'label'))}</text>
        </svg>
      );
    }
    case 'motor': {
      const sp = st.speed ?? 0;
      const running = Math.abs(sp) > 0.05;
      return (
        <svg width={w} height={h}>
          <rect x={20} y={28} width={86} height={58} rx={10} fill="#3d6e8f" stroke="#1d3a4d" strokeWidth={2} />
          {[0, 1, 2, 3, 4, 5].map(i => <rect key={i} x={26 + i * 13} y={30} width={6} height={54} fill="#2d5671" />)}
          <rect x={106} y={50} width={18} height={14} fill="#9aa4ad" />
          <g transform={`rotate(${st.angle ?? 0} 124 57)`}><rect x={121} y={38} width={6} height={38} rx={2} fill="#cfd5da" /></g>
          <rect x={44} y={16} width={30} height={14} rx={2} fill="#2b4e65" />
          <text x={63} y={64} textAnchor="middle" fontSize={11} fontWeight={700} fill="#e6f0f7">{String(c(dev, 'label'))}</text>
          <text x={8} y={h - 8} fontSize={9.5} fontWeight={700} fill={st.trip ? 'var(--c-danger)' : running ? 'var(--c-on)' : 'var(--c-mute)'}>{st.trip ? 'OVERLOAD TRIP' : running ? (sp > 0 ? `RUN FWD ${Math.round(sp * 100)}%` : `RUN REV ${Math.round(-sp * 100)}%`) : 'STOPPED'}</text>
          <circle cx={w - 14} cy={14} r={5} fill={running ? 'var(--c-on)' : '#444'} />
        </svg>
      );
    }
    case 'vfd': {
      const rpm = st.rpm ?? 0;
      return (
        <svg width={w} height={h}>
          <rect x={8} y={8} width={70} height={h - 30} rx={5} fill="#2f353c" stroke="#15191d" />
          <rect x={14} y={16} width={58} height={26} rx={2} fill="#0d2a1f" />
          <text x={68} y={34} textAnchor="end" fontSize={12} fontFamily="var(--font-mono)" fill="#5df2a5">{Math.round(Math.abs(rpm))}</text>
          <text x={18} y={56} fontSize={8} fill="#aab">rpm {rpm < -1 ? 'REV' : rpm > 1 ? 'FWD' : ''}</text>
          <circle cx={43} cy={78} r={9} fill={Math.abs(rpm) > 1 ? '#3ddc84' : '#444'} />
          <rect x={96} y={30} width={70} height={50} rx={8} fill="#3d6e8f" stroke="#1d3a4d" />
          <g transform={`rotate(${st.angle ?? 0} 131 55)`}><path d="M131 35v40M111 55h40" stroke="#d6e2ea" strokeWidth={4} strokeLinecap="round" /></g>
          <text x={8} y={h - 8} fontSize={9.5} fontWeight={700} fill="var(--c-ink)">{String(c(dev, 'label'))} · {(Math.abs(rpm) / cn(dev, 'rpm', 1500) * 50).toFixed(1)} Hz</text>
        </svg>
      );
    }
    case 'pump': case 'fan': {
      const sp = st.speed ?? 0;
      const isFan = dev.type === 'fan';
      return (
        <svg width={w} height={h}>
          <circle cx={cx} cy={h / 2 - 8} r={34} fill={isFan ? '#283038' : '#3d6e8f'} stroke={sp > 0.3 ? 'var(--c-on)' : '#1d3a4d'} strokeWidth={3} />
          <g transform={`rotate(${st.angle ?? 0} ${cx} ${h / 2 - 8})`}>
            {(isFan ? [0, 90, 180, 270] : [0, 120, 240]).map(a => <path key={a} transform={`rotate(${a} ${cx} ${h / 2 - 8})`} d={isFan ? `M${cx} ${h / 2 - 8}q-10 -14 0 -28q10 14 0 28z` : `M${cx} ${h / 2 - 8}l-5 -24h10z`} fill="#d6e2ea" />)}
          </g>
          {!isFan && <path d={`M${cx + 28} ${h / 2 - 30}h26v12h-18`} fill="#3d6e8f" stroke="#1d3a4d" />}
          <text x={cx} y={h - 6} textAnchor="middle" fontSize={9.5} fontWeight={700} fill={sp > 0.3 ? 'var(--c-on)' : 'var(--c-mute)'}>{String(c(dev, 'label'))}</text>
        </svg>
      );
    }
    case 'valve': {
      const pos = st.pos ?? 0;
      const col = pos > 0.5 ? 'var(--c-on)' : 'var(--c-mute)';
      return (
        <svg width={w} height={h}>
          <rect x={4} y={h / 2 - 2} width={w - 8} height={14} fill="#59636e" opacity={0.5} />
          <path d={`M${cx - 26} ${h / 2 - 12}L${cx + 26} ${h / 2 + 22}V${h / 2 - 12}L${cx - 26} ${h / 2 + 22}z`} fill={pos > 0.5 ? 'var(--c-on)' : '#3b444e'} fillOpacity={0.25 + pos * 0.6} stroke={col} strokeWidth={2} />
          <line x1={cx} y1={h / 2 + 5} x2={cx} y2={h / 2 - 22} stroke={col} strokeWidth={2} />
          <rect x={cx - 14} y={h / 2 - 38} width={28} height={18} rx={2} fill="#2f353c" stroke={col} />
          <text x={cx} y={h / 2 - 25} textAnchor="middle" fontSize={8} fill="#ccc">M</text>
          <text x={cx} y={h - 6} textAnchor="middle" fontSize={9.5} fontWeight={700} fill={col}>{String(c(dev, 'label'))} {pos > 0.99 ? 'OPEN' : pos < 0.01 ? 'CLOSED' : '…'}</text>
        </svg>
      );
    }
    case 'cylinder': {
      const pos = st.pos ?? 0;
      const bx = 14, bw = 110, rodMax = 80;
      return (
        <svg width={w} height={h}>
          <rect x={bx} y={h / 2 - 22} width={bw} height={36} rx={4} fill="#b9c2cb" stroke="#58626c" />
          <rect x={bx + 8 + pos * (bw - 30)} y={h / 2 - 20} width={10} height={32} fill="#6b7580" />
          <rect x={bx + 18 + pos * (bw - 30)} y={h / 2 - 7} width={bw - 18 + rodMax * pos - pos * (bw - 30)} height={6} fill="#dfe5ea" stroke="#7d8790" />
          <rect x={bx + bw + rodMax * pos - 2} y={h / 2 - 14} width={10} height={22} rx={2} fill="#7d8790" />
          <circle cx={bx + 14} cy={h / 2 - 28} r={4} fill={pos <= 0.01 ? '#ffbf1f' : '#3a3f45'} />
          <circle cx={bx + bw - 14} cy={h / 2 - 28} r={4} fill={pos >= 0.99 ? '#ffbf1f' : '#3a3f45'} />
          <text x={bx + 14} y={h / 2 + 30} textAnchor="middle" fontSize={8} fill="var(--c-mute)">B0</text>
          <text x={bx + bw - 14} y={h / 2 + 30} textAnchor="middle" fontSize={8} fill="var(--c-mute)">B1</text>
          <text x={w - 8} y={14} textAnchor="end" fontSize={9.5} fontWeight={700} fill="var(--c-ink)">{String(c(dev, 'label'))} · {Math.round(pos * 100)}%</text>
        </svg>
      );
    }
    case 'gate': {
      const pos = st.pos ?? 0;
      const gw = w - 40;
      return (
        <svg width={w} height={h}>
          <rect x={14} y={14} width={gw + 12} height={h - 44} fill="none" stroke="#59636e" strokeWidth={4} />
          <rect x={20 + pos * gw * 0.9} y={20} width={gw * (1 - pos * 0.9)} height={h - 56} fill="#8794a0" opacity={0.9} />
          {Array.from({ length: 6 }).map((_, i) => <line key={i} x1={20 + pos * gw * 0.9} x2={20 + gw} y1={30 + i * ((h - 70) / 6)} y2={30 + i * ((h - 70) / 6)} stroke="#5e6a75" />)}
          <circle cx={20} cy={h - 20} r={4} fill={pos <= 0.005 ? '#ffbf1f' : '#3a3f45'} />
          <circle cx={w - 20} cy={h - 20} r={4} fill={pos >= 0.995 ? '#ffbf1f' : '#3a3f45'} />
          <text x={cx} y={h - 16} textAnchor="middle" fontSize={9.5} fontWeight={700} fill={st.dir ? 'var(--c-on)' : 'var(--c-mute)'}>{String(c(dev, 'label'))} {st.dir === 1 ? '▶ opening' : st.dir === -1 ? '◀ closing' : pos >= 0.995 ? 'OPEN' : pos <= 0.005 ? 'CLOSED' : 'stopped'}</text>
        </svg>
      );
    }
    case 'heater': {
      const T = st.temp ?? 20;
      const heat = rb(dev, 'heat');
      const frac = Math.max(0, Math.min(1, (T - 0) / 200));
      return (
        <svg width={w} height={h}>
          <path d={`M14 ${h / 2 - 10}${Array.from({ length: 6 }).map((_, i) => `q8 ${i % 2 ? 22 : -22} 16 0`).join('')}`} fill="none" stroke={heat ? '#ff6a2a' : '#6b7580'} strokeWidth={5} strokeLinecap="round" />
          {heat && <path d={`M14 ${h / 2 - 10}${Array.from({ length: 6 }).map((_, i) => `q8 ${i % 2 ? 22 : -22} 16 0`).join('')}`} fill="none" stroke="#ffb02a" strokeWidth={12} opacity={0.25} />}
          <rect x={w - 34} y={14} width={14} height={h - 50} rx={7} fill="var(--c-bg)" stroke="var(--c-line)" />
          <rect x={w - 31} y={17 + (h - 56) * (1 - frac)} width={8} height={(h - 56) * frac} rx={4} fill="#ff4b4b" />
          <circle cx={w - 27} cy={h - 30} r={9} fill="#ff4b4b" />
          <text x={10} y={h - 8} fontSize={12} fontFamily="var(--font-mono)" fill="var(--c-ink)">{T.toFixed(1)} °C</text>
          <text x={10} y={16} fontSize={9.5} fontWeight={700} fill={heat ? '#ff6a2a' : 'var(--c-mute)'}>{String(c(dev, 'label'))} {heat ? 'HEATING' : ''}</text>
        </svg>
      );
    }
    case 'tank': {
      const L = st.level ?? 0;
      const tx = 30, ty = 30, tw = w - 70, th = h - 70;
      const liquid = String(c(dev, 'liquid'));
      const col = liquid === 'oil' ? '#c99a2e' : liquid === 'chemical' ? '#7bd65a' : '#3c9cf0';
      const inOn = rb(dev, 'in') || (rn(dev, 'aq') ?? 0) > 0, outOn = rb(dev, 'out');
      const lo = cn(dev, 'loP', 15), hi = cn(dev, 'hiP', 85);
      const ly = (p: number) => ty + th - (th * p) / 100;
      const wave = Math.sin((st.t ?? 0) * 3) * 2;
      return (
        <svg width={w} height={h}>
          <path d={`M4 14H${tx + 24}V${ty + 4}`} stroke={inOn ? col : '#59636e'} strokeWidth={6} fill="none" />
          <rect x={14} y={6} width={14} height={16} rx={2} fill={inOn ? 'var(--c-on)' : '#3b444e'} />
          {inOn && <rect x={tx + 21} y={ty + 4} width={6} height={th - 4 - (th * L) / 100} fill={col} opacity={0.6} />}
          <rect x={tx} y={ty} width={tw} height={th} rx={8} fill="var(--c-bg)" stroke="#7b8792" strokeWidth={2.5} />
          <clipPath id={`tk${dev.id}`}><rect x={tx + 2} y={ty + 2} width={tw - 4} height={th - 4} rx={7} /></clipPath>
          <g clipPath={`url(#tk${dev.id})`}>
            <path d={`M${tx} ${ly(L) + wave}q${tw / 4} -4 ${tw / 2} 0t${tw / 2} 0V${ty + th}H${tx}z`} fill={col} opacity={0.75} />
          </g>
          <line x1={tx + tw} x2={tx + tw + 10} y1={ly(hi)} y2={ly(hi)} stroke="var(--c-warn)" strokeWidth={2} />
          <line x1={tx + tw} x2={tx + tw + 10} y1={ly(lo)} y2={ly(lo)} stroke="var(--c-warn)" strokeWidth={2} />
          <circle cx={tx + tw + 16} cy={ly(hi)} r={4} fill={L >= hi ? 'var(--c-warn)' : '#3a3f45'} />
          <circle cx={tx + tw + 16} cy={ly(lo)} r={4} fill={L >= lo ? 'var(--c-warn)' : '#3a3f45'} />
          <text x={tx + tw + 23} y={ly(hi) + 3} fontSize={8} fill="var(--c-mute)">H</text>
          <text x={tx + tw + 23} y={ly(lo) + 3} fontSize={8} fill="var(--c-mute)">L</text>
          <text x={tx + tw / 2} y={ty + th / 2} textAnchor="middle" fontSize={18} fontWeight={700} fontFamily="var(--font-mono)" fill="var(--c-ink)">{L.toFixed(1)}%</text>
          <text x={tx + tw / 2} y={ty + th / 2 + 16} textAnchor="middle" fontSize={9.5} fill="var(--c-mute)">{String(c(dev, 'label'))}</text>
          <path d={`M${tx + tw / 2} ${ty + th}V${h - 18}H${w - 4}`} stroke={outOn && L > 0 ? col : '#59636e'} strokeWidth={6} fill="none" />
          <rect x={tx + tw / 2 + 14} y={h - 26} width={14} height={16} rx={2} fill={outOn ? 'var(--c-on)' : '#3b444e'} />
        </svg>
      );
    }
    case 'conveyor': {
      const items = st.items ?? [];
      const bx = 14, bw = w - 28, by = h / 2 - 2;
      const xOf = (p: number) => bx + p * bw;
      const sens: [string, number][] = [['sIn', 0.06], ['sMid', 0.5], ['sEnd', 0.95]];
      const running = Math.abs(st.speed ?? 0) > 0;
      return (
        <svg width={w} height={h}>
          <rect x={bx - 8} y={by} width={bw + 16} height={18} rx={9} fill="#2b3138" stroke="#59636e" />
          {Array.from({ length: Math.floor(bw / 22) + 1 }).map((_, i) => (
            <g key={i} transform={`rotate(${st.angle ?? 0} ${bx + i * 22} ${by + 9})`}><circle cx={bx + i * 22} cy={by + 9} r={6} fill="#6b7580" /><line x1={bx + i * 22 - 5} y1={by + 9} x2={bx + i * 22 + 5} y2={by + 9} stroke="#3a4048" strokeWidth={2} /></g>
          ))}
          {sens.map(([k, p]) => dev.bind[k] ? (
            <g key={k}>
              <line x1={xOf(p)} y1={by - 34} x2={xOf(p)} y2={by} stroke="#ff3b3b" strokeDasharray="2 3" opacity={0.6} />
              <rect x={xOf(p) - 5} y={by - 42} width={10} height={8} rx={2} fill="#444c55" />
              <circle cx={xOf(p)} cy={by - 46} r={3} fill={rb(dev, k) || items.some(q => Math.abs(q - p) < 0.035) ? '#ffbf1f' : '#3a3f45'} />
            </g>
          ) : null)}
          {items.map((p, i) => (
            <rect key={i} x={xOf(p) - 13} y={by - 24} width={26} height={24} rx={3} fill="#c9925a" stroke="#8a5e33" className="cursor-pointer"
              onClick={e => { e.stopPropagation(); st.items = items.filter((_, k) => k !== i); }} />
          ))}
          <text x={bx} y={h - 6} fontSize={9.5} fontWeight={700} fill={running ? 'var(--c-on)' : 'var(--c-mute)'}>{String(c(dev, 'label'))} {running ? ((st.speed ?? 0) > 0 ? '▶' : '◀') : '■'} · parts: {items.length}</text>
        </svg>
      );
    }
    case 'label':
      return <div className="h-full flex items-center px-2 font-semibold text-ink whitespace-nowrap" style={{ fontSize: cn(dev, 'size', 18) }}>{String(c(dev, 'text'))}</div>;
  }
  return null;
}
