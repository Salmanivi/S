import { OFFLINE_BUILD } from './env';

/** Registers the service worker (online web build only) so the app opens offline and can be installed. */
export function registerServiceWorker() {
  if (OFFLINE_BUILD || !('serviceWorker' in navigator)) return;
  const secure = location.protocol === 'https:' || location.hostname === 'localhost' || location.hostname === '127.0.0.1';
  if (!secure) return;
  window.addEventListener('load', () => { navigator.serviceWorker.register('/sw.js').catch(() => { /* optional feature */ }); });
}
