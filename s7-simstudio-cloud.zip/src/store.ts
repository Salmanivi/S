import { create } from 'zustand';
import type { Block, CompileMsg, Elem, Network, Project, View } from './types';
import type { CloudBinding } from './cloud/types';
import { emptyProject } from './examples';
import { compileProject } from './plc/compiler';
import { runtime } from './plc/runtime';
import { INSTR_MAP } from './catalog/instructions';
import { isOutputLike, collectInstances, cloneElem, findElem, findParallelOf, findSeries, newInstr, newNetwork, newSeries, normalize, uid } from './plc/ladder';
import { makeResolver } from './plc/resolve';
import { cpuById } from './catalog/hardware';
import { plantCtx, stepPlant, plantState } from './plant/devices';
import { applyAutoTypes } from './plc/autotype';

// The app always starts with no project open and never restores one: only display preferences are remembered.
const LS_OLD_PROJECT = 's7sim.project.v1';
const LS_UI = 's7sim.ui.v2';

/** True on phone-sized screens (the layout below the `lg` breakpoint). */
export const isPhone = () => typeof window !== 'undefined' && window.matchMedia('(max-width: 1023px)').matches;

export interface Selection { netId: string | null; elemId: string | null }

interface State {
  project: Project;
  view: View;
  activeBlockId: string;
  sel: Selection;
  armed: string | null;
  monitoring: boolean;
  theme: 'dark' | 'light';
  msgs: CompileMsg[];
  version: number;
  downloadedVersion: number;
  past: Project[];
  future: Project[];
  tick: number;
  zoom: number;
  clipboard: { kind: 'net'; net: Network } | { kind: 'elem'; elem: Elem } | null;
  mobileTab: 'tree' | 'main' | 'sim' | 'info';
  infoOpen: boolean;
  infoTab: 'compile' | 'diag';
  toast: { text: string; kind: 'ok' | 'err' | 'info'; id: number } | null;
  plantEdit: boolean;
  plantSel: string | null;
  dialog: null | 'examples' | 'cpu' | 'about' | 'help' | 'new';
  rightTab: 'instr' | 'props' | 'sim';
  /** a project is open (false = start screen) */
  projectOpen: boolean;
  /** link to the cloud copy of the open project (null = local only) */
  cloud: CloudBinding | null;
  /** unsaved changes since the project was opened or last exported */
  dirty: boolean;
  /** bottom sheet on phones */
  sheet: null | 'instr' | 'props' | 'info';

  mutate: (fn: (p: Project) => void, program?: boolean) => void;
  undo: () => void;
  redo: () => void;
  setView: (v: View, blockId?: string) => void;
  select: (s: Selection) => void;
  arm: (op: string | null) => void;
  insertInstr: (op: string, seriesId?: string, index?: number) => void;
  deleteSelected: () => void;
  branchSelected: () => void;
  addBranchToParallel: () => void;
  moveSelected: (dir: -1 | 1) => void;
  addNetwork: (afterId?: string) => void;
  copy: () => void;
  paste: () => void;
  compile: () => boolean;
  download: () => void;
  setMode: (m: 'RUN' | 'STOP') => void;
  loadProject: (p: Project, msg?: string) => void;
  closeProject: () => void;
  replaceProject: (p: Project) => void;
  bindCloud: (c: CloudBinding | null) => void;
  markSaved: () => void;
  runSmart: () => void;
  openProps: () => void;
  moveNetwork: (dir: -1 | 1) => void;
  showToast: (text: string, kind?: 'ok' | 'err' | 'info') => void;
  set: (p: Partial<State>) => void;
}

function loadUi(): { theme: 'dark' | 'light'; zoom: number } {
  const def = { theme: 'light' as const, zoom: 1 };
  try {
    const raw = localStorage.getItem(LS_UI);
    if (raw) { const o = JSON.parse(raw); return { theme: o.theme === 'dark' ? 'dark' : 'light', zoom: typeof o.zoom === 'number' ? o.zoom : def.zoom }; }
  } catch { /* ignore */ }
  return def;
}
// forget anything an earlier version stored
try { localStorage.removeItem(LS_OLD_PROJECT); } catch { /* ignore */ }

export function buildResolver(p: Project) {
  return makeResolver({ tags: p.tags, instances: collectInstances(p.blocks), mBytes: cpuById(p.hardware.cpuId).mBytes });
}

let resolverCache: { p: Project | null; r: ReturnType<typeof buildResolver> | null } = { p: null, r: null };
export function getResolver(p: Project) {
  if (resolverCache.p !== p || !resolverCache.r) resolverCache = { p, r: buildResolver(p) };
  return resolverCache.r!;
}

function syncPlant(p: Project) {
  plantCtx.devices = p.devices;
  plantCtx.resolve = getResolver(p).resolve;
}

// placeholder behind the start screen; never shown
const initial = emptyProject();
const ui = loadUi();
syncPlant(initial);
runtime.plantStep = stepPlant;

const activeBlockOf = (p: Project, net?: string) => {
  if (net) { const b = p.blocks.find(b2 => b2.networks.some(n => n.id === net)); if (b) return b; }
  return p.blocks.find(b => b.kind === 'main') ?? p.blocks[0];
};

function resetRuntime() {
  runtime.setMode('STOP');
  runtime.memoryReset();
  runtime.physIn.fill(0);
  runtime.diag = [];
  plantState.clear();
}

export const useStore = create<State>((set, get) => ({
  project: initial,
  view: 'block',
  activeBlockId: activeBlockOf(initial).id,
  sel: { netId: activeBlockOf(initial).networks[0]?.id ?? null, elemId: null },
  armed: null,
  monitoring: false,
  theme: ui.theme,
  msgs: [],
  version: 1,
  downloadedVersion: 0,
  past: [],
  future: [],
  tick: 0,
  zoom: ui.zoom,
  clipboard: null,
  mobileTab: 'main',
  infoOpen: false,
  infoTab: 'compile',
  toast: null,
  plantEdit: false,
  plantSel: null,
  dialog: null,
  rightTab: 'instr',
  projectOpen: false,
  cloud: null,
  dirty: false,
  sheet: null,

  set: p => set(p as State),

  mutate: (fn, program = true) => {
    if (get().cloud?.readOnly) { get().showToast('View-only: you cannot change this project', 'err'); return; }
    const old = get().project;
    const next = structuredClone(old);
    fn(next);
    applyAutoTypes(next);
    syncPlant(next);
    set(s => ({
      project: next,
      past: [...s.past.slice(-79), old],
      future: [],
      version: program ? s.version + 1 : s.version,
      dirty: true,
    }));
  },

  undo: () => {
    const { past, project, future } = get();
    if (!past.length) return;
    const prev = past[past.length - 1];
    syncPlant(prev);
    set(s => ({ project: prev, past: past.slice(0, -1), future: [project, ...future].slice(0, 80), version: s.version + 1, dirty: true }));
  },
  redo: () => {
    const { past, project, future } = get();
    if (!future.length) return;
    const nxt = future[0];
    syncPlant(nxt);
    set(s => ({ project: nxt, future: future.slice(1), past: [...past, project], version: s.version + 1, dirty: true }));
  },

  setView: (v, blockId) => {
    const s = get();
    if (v === 'block' && blockId) {
      const b = s.project.blocks.find(x => x.id === blockId);
      set({ view: v, activeBlockId: blockId, sel: { netId: b?.networks[0]?.id ?? null, elemId: null }, mobileTab: 'main' });
    } else set({ view: v, mobileTab: 'main' });
  },

  select: sel => set({ sel }),
  arm: op => set({ armed: op }),

  insertInstr: (op, seriesId, index) => {
    const s = get();
    const block = s.project.blocks.find(b => b.id === s.activeBlockId);
    if (!block) return;
    let newId = '';
    let netId = s.sel.netId;
    s.mutate(p => {
      const b = p.blocks.find(x => x.id === s.activeBlockId)!;
      const instr = newInstr(op, p.blocks);
      newId = instr.id;
      if (seriesId) {
        for (const n of b.networks) {
          const ser = findSeries(n.root, seriesId);
          if (ser) { ser.items.splice(index ?? ser.items.length, 0, instr); netId = n.id; return; }
        }
      }
      // insert after selection or at end of active network
      let net = b.networks.find(n => n.id === s.sel.netId) ?? b.networks[b.networks.length - 1];
      if (!net) { net = newNetwork(); b.networks.push(net); }
      netId = net.id;
      if (s.sel.elemId) {
        const f = findElem(net.root, s.sel.elemId);
        if (f) { f.parent.items.splice(f.index + 1, 0, instr); return; }
      }
      // contacts / comparators go before the trailing coil, outputs are appended
      const items = net.root.items;
      const shape = INSTR_MAP[op]?.shape;
      if (items.length && (shape === 'contact' || shape === 'cmp') && isOutputLike(items[items.length - 1])) items.splice(items.length - 1, 0, instr);
      else items.push(instr);
    });
    set({ sel: { netId, elemId: newId }, armed: null });
  },

  deleteSelected: () => {
    const s = get();
    if (!s.sel.elemId) {
      if (s.sel.netId) {
        s.mutate(p => {
          const b = p.blocks.find(x => x.id === s.activeBlockId)!;
          b.networks = b.networks.filter(n => n.id !== s.sel.netId);
          if (b.networks.length === 0) b.networks.push(newNetwork());
        });
        set({ sel: { netId: null, elemId: null } });
      }
      return;
    }
    s.mutate(p => {
      const b = p.blocks.find(x => x.id === s.activeBlockId)!;
      for (const n of b.networks) {
        const f = findElem(n.root, s.sel.elemId!);
        if (f) { f.parent.items.splice(f.index, 1); normalize(n.root); return; }
      }
    });
    set({ sel: { netId: s.sel.netId, elemId: null } });
  },

  branchSelected: () => {
    const s = get();
    if (!s.sel.elemId) { s.showToast('Select an element first, then open a branch around it', 'info'); return; }
    let newSel = '';
    s.mutate(p => {
      const b = p.blocks.find(x => x.id === s.activeBlockId)!;
      for (const n of b.networks) {
        const f = findElem(n.root, s.sel.elemId!);
        if (f) {
          const el = f.parent.items[f.index];
          const op = s.armed ?? (el.kind === 'instr' && (el.op === 'OUT' || el.op === 'SET' || el.op === 'RESET' || el.op === 'NEG') ? 'OUT' : 'NO');
          const ins = newInstr(op, p.blocks);
          newSel = ins.id;
          f.parent.items[f.index] = { id: uid('p'), kind: 'par', branches: [newSeries([el]), newSeries([ins])] };
          return;
        }
      }
    });
    set({ sel: { netId: s.sel.netId, elemId: newSel }, armed: null });
  },

  addBranchToParallel: () => {
    const s = get();
    if (!s.sel.elemId) return;
    let newSel = '';
    s.mutate(p => {
      const b = p.blocks.find(x => x.id === s.activeBlockId)!;
      for (const n of b.networks) {
        const f = findElem(n.root, s.sel.elemId!);
        if (!f) continue;
        const par = findParallelOf(n.root, f.parent.id);
        const ins = newInstr(s.armed ?? 'NO', p.blocks);
        newSel = ins.id;
        if (par) par.branches.push(newSeries([ins]));
        else {
          const el = f.parent.items[f.index];
          f.parent.items[f.index] = { id: uid('p'), kind: 'par', branches: [newSeries([el]), newSeries([ins])] };
        }
        return;
      }
    });
    set({ sel: { netId: s.sel.netId, elemId: newSel }, armed: null });
  },

  moveSelected: dir => {
    const s = get();
    if (!s.sel.elemId) return;
    s.mutate(p => {
      const b = p.blocks.find(x => x.id === s.activeBlockId)!;
      for (const n of b.networks) {
        const f = findElem(n.root, s.sel.elemId!);
        if (f) {
          const j = f.index + dir;
          if (j < 0 || j >= f.parent.items.length) return;
          const arr = f.parent.items;
          [arr[f.index], arr[j]] = [arr[j], arr[f.index]];
          return;
        }
      }
    });
  },

  addNetwork: afterId => {
    const s = get();
    const nw = newNetwork();
    s.mutate(p => {
      const b = p.blocks.find(x => x.id === s.activeBlockId)!;
      const idx = afterId ? b.networks.findIndex(n => n.id === afterId) : -1;
      if (idx >= 0) b.networks.splice(idx + 1, 0, nw); else b.networks.push(nw);
    });
    set({ sel: { netId: nw.id, elemId: null } });
  },

  copy: () => {
    const s = get();
    const b = s.project.blocks.find(x => x.id === s.activeBlockId);
    if (!b) return;
    const net = b.networks.find(n => n.id === s.sel.netId);
    if (!net) return;
    if (s.sel.elemId) {
      const f = findElem(net.root, s.sel.elemId);
      if (f) { set({ clipboard: { kind: 'elem', elem: structuredClone(f.parent.items[f.index]) } }); s.showToast('Element copied', 'info'); }
    } else { set({ clipboard: { kind: 'net', net: structuredClone(net) } }); s.showToast('Network copied', 'info'); }
  },

  paste: () => {
    const s = get();
    const cb = s.clipboard;
    if (!cb) return;
    let selId = '';
    let netSel = s.sel.netId;
    s.mutate(p => {
      const b = p.blocks.find(x => x.id === s.activeBlockId)!;
      if (cb.kind === 'net') {
        const nn: Network = { ...structuredClone(cb.net), id: uid('n'), root: cloneElem(cb.net.root, p.blocks) };
        const idx = b.networks.findIndex(n => n.id === s.sel.netId);
        b.networks.splice(idx >= 0 ? idx + 1 : b.networks.length, 0, nn);
        netSel = nn.id;
      } else {
        const el = cloneElem(cb.elem, p.blocks);
        selId = el.id;
        const net = b.networks.find(n => n.id === s.sel.netId) ?? b.networks[0];
        if (!net) return;
        const f = s.sel.elemId ? findElem(net.root, s.sel.elemId) : null;
        if (f) f.parent.items.splice(f.index + 1, 0, el); else net.root.items.push(el);
        netSel = net.id;
      }
    });
    set({ sel: { netId: netSel, elemId: selId || null } });
  },

  compile: () => {
    const { program, msgs } = compileProject(get().project);
    const phone = isPhone();
    set(phone ? { msgs, infoTab: 'compile', sheet: program ? get().sheet : 'info' } : { msgs, infoOpen: true, infoTab: 'compile' });
    get().showToast(program ? 'Compilation successful' : phone ? 'Compilation failed — see the messages' : 'Compilation failed — see Info › Compile', program ? 'ok' : 'err');
    return !!program;
  },

  download: () => {
    const s = get();
    const { program, msgs } = compileProject(s.project);
    set({ msgs });
    if (!program) {
      set(isPhone() ? { infoTab: 'compile', sheet: 'info' } : { infoOpen: true, infoTab: 'compile' });
      s.showToast('Download aborted: the program contains errors', 'err');
      return;
    }
    runtime.load(program);
    set({ downloadedVersion: s.version });
    s.showToast(`Downloaded to ${cpuById(s.project.hardware.cpuId).name}`, 'ok');
  },

  setMode: m => {
    const s = get();
    if (m === 'RUN' && !runtime.prog) {
      s.download();
      if (!runtime.prog) return;
    }
    runtime.setMode(m);
    if (m === 'RUN' && !s.monitoring) set({ monitoring: true });
    set({ tick: s.tick + 1 });
  },

  loadProject: (p, msg) => {
    resetRuntime();
    applyAutoTypes(p);
    syncPlant(p);
    const b = activeBlockOf(p);
    set(s => ({
      project: p, past: [], future: [], version: s.version + 1, downloadedVersion: 0, msgs: [],
      view: 'block', activeBlockId: b.id, sel: { netId: isPhone() ? null : (b.networks[0]?.id ?? null), elemId: null }, monitoring: false, dialog: null,
      projectOpen: true, cloud: null, dirty: false, sheet: null, mobileTab: 'main', infoOpen: false, armed: null, plantSel: null, plantEdit: false,
    }));
    if (msg) get().showToast(msg, 'ok');
  },

  closeProject: () => {
    resetRuntime();
    const blank = emptyProject();
    syncPlant(blank);
    set(s => ({
      project: blank, past: [], future: [], version: s.version + 1, downloadedVersion: 0, msgs: [],
      view: 'block', sel: { netId: null, elemId: null }, monitoring: false, dialog: null, sheet: null,
      projectOpen: false, cloud: null, dirty: false, mobileTab: 'main', armed: null,
    }));
  },

  /** Applies a project that arrived from the cloud (another device) without resetting the view. */
  replaceProject: (p) => {
    applyAutoTypes(p);
    syncPlant(p);
    set(s => {
      const keep = p.blocks.some(b => b.id === s.activeBlockId);
      const b = keep ? p.blocks.find(x => x.id === s.activeBlockId)! : activeBlockOf(p);
      return { project: p, past: [], future: [], version: s.version + 1, dirty: false, activeBlockId: b.id, sel: { netId: null, elemId: null }, armed: null };
    });
  },

  bindCloud: (c) => set({ cloud: c }),

  markSaved: () => set({ dirty: false }),

  // one tap on phones: compile + download when needed, then RUN
  runSmart: () => {
    const s = get();
    if (!runtime.prog || s.version !== s.downloadedVersion) {
      s.download();
      if (get().downloadedVersion !== s.version) return;
    }
    get().setMode('RUN');
  },

  openProps: () => {
    if (isPhone()) set({ rightTab: 'props', sheet: 'props' });
    else set({ rightTab: 'props' });
  },

  moveNetwork: dir => {
    const s = get();
    const netId = s.sel.netId;
    if (!netId) return;
    s.mutate(p => {
      const b = p.blocks.find(x => x.id === s.activeBlockId);
      if (!b) return;
      const k = b.networks.findIndex(n => n.id === netId), j = k + dir;
      if (k < 0 || j < 0 || j >= b.networks.length) return;
      [b.networks[k], b.networks[j]] = [b.networks[j], b.networks[k]];
    });
  },

  showToast: (text, kind = 'info') => {
    const id = Date.now();
    set({ toast: { text, kind, id } });
    setTimeout(() => { if (get().toast?.id === id) set({ toast: null }); }, 2600);
  },
}));

useStore.subscribe((s, prev) => {
  if (s.theme !== prev.theme || s.zoom !== prev.zoom) {
    try { localStorage.setItem(LS_UI, JSON.stringify({ theme: s.theme, zoom: s.zoom })); } catch { /* ignore */ }
  }
});

// ------------------------------------------------------------- run loop
let started = false;
export function startLoops() {
  if (started) return;
  started = true;
  setInterval(() => runtime.tick(), 10);
  setInterval(() => useStore.setState(s => ({ tick: s.tick + 1 })), 60);
}

export const newBlockOf = (kind: Block['kind'], p: Project): Block => {
  const nums = p.blocks.filter(b => (kind === 'fc') === (b.kind === 'fc')).map(b => b.number);
  let number = kind === 'fc' ? 1 : kind === 'cyclic' ? 30 : kind === 'startup' ? 100 : 1;
  while (nums.includes(number)) number++;
  const name = kind === 'fc' ? `Block_${number}` : kind === 'cyclic' ? `Cyclic interrupt${number > 30 ? '_' + (number - 30) : ''}` : kind === 'startup' ? 'Startup' : `Main_${number}`;
  return { id: uid('b'), name, kind, number, cycleMs: kind === 'cyclic' ? 100 : undefined, comment: '', networks: [newNetwork()] };
};

export { emptyProject };
