import type { DataType, LadderInstr, Project } from '../types';
import { INSTR_MAP, type InstrDef, type PinDef } from '../catalog/instructions';
import { cpuById } from '../catalog/hardware';
import { makeResolver, compatible, type ResolveResult } from './resolve';
import { collectInstances, walk } from './ladder';
import { inRange, sizeOfType, type Size } from './values';

/** Instructions that offer more than one data type can detect it automatically. */
export const isAutoTypable = (d: InstrDef | undefined): d is InstrDef => !!d && !!d.types && d.types.length > 1;

// which concrete type to prefer for a given operand size when nothing else is known
const BY_SIZE: Record<Size, DataType[]> = {
  X: ['Bool'],
  B: ['Byte', 'USInt', 'SInt'],
  W: ['Int', 'Word', 'UInt'],
  D: ['DInt', 'DWord', 'UDInt', 'Real'],
};

const pickBySize = (size: Size, allowed: DataType[]): DataType | null => BY_SIZE[size].find(t => allowed.includes(t)) ?? null;

/** Map a detected type onto one the instruction supports (Word → Int, Time → DInt, ...). */
function toAllowed(t: DataType, allowed: DataType[]): DataType | null {
  if (allowed.includes(t)) return t;
  return BY_SIZE[sizeOfType(t)].find(a => allowed.includes(a) && compatible(t, a)) ?? null;
}

type Resolve = (s: string) => ResolveResult;

function detect(i: LadderInstr, pins: PinDef[], allowed: DataType[], fallback: DataType, resolve: Resolve): DataType {
  let strong: DataType | undefined;   // declared type of a tag / instance member
  let weakConst: DataType | undefined; // Real or Time constant
  let weakSize: Size | undefined;      // untyped absolute address (%MW10)
  let bigInt = false;                  // integer constant that does not fit the default type

  // inputs first, outputs last
  const ordered = [...pins.filter(p => p.dir === 'in'), ...pins.filter(p => p.dir === 'out')];
  for (const pd of ordered) {
    const s = (i.params[pd.name] ?? '').trim();
    if (!s) continue;
    const r = resolve(s);
    if (r.k === 'mem') { if (r.typed) strong ??= r.tt; else weakSize ??= r.a.size; }
    else if (r.k === 'inst') strong ??= r.tt;
    else if (r.k === 'const') {
      if (r.ck === 'real') weakConst ??= 'Real';
      else if (r.ck === 'time') weakConst ??= 'Time';
      else if (r.ck === 'int' && typeof r.v === 'number' && !inRange(r.v, fallback)) bigInt = true;
    }
  }
  const conv = (t?: DataType) => (t ? toAllowed(t, allowed) : null);
  return conv(strong)
    ?? conv(weakConst)
    ?? (weakSize ? pickBySize(weakSize, allowed) : null)
    ?? (bigInt && allowed.includes('DInt') ? 'DInt' : null)
    ?? fallback;
}

/** The data type(s) an instruction gets when its type is detected automatically. */
export function detectTypes(i: LadderInstr, resolve: Resolve): { dt: DataType; dt2?: DataType } | null {
  const d = INSTR_MAP[i.op];
  if (!isAutoTypable(d)) return null;
  const dtPins = d.pins.filter(p => p.typed && !p.typed2);
  const dt = detect(i, dtPins, d.types!, d.defType ?? 'Int', resolve);
  if (!d.types2) return { dt };
  const dt2 = detect(i, d.pins.filter(p => p.typed2), d.types2, d.defType2 ?? 'Int', resolve);
  return { dt, dt2 };
}

/**
 * Re-detects the data types of every instruction that has autoType switched on and stores them
 * in dataType / dataType2. Mutates the project, returns true when something changed.
 */
export function applyAutoTypes(p: Project): boolean {
  const autos: LadderInstr[] = [];
  for (const b of p.blocks) for (const n of b.networks) walk(n.root, i => { if (i.autoType && isAutoTypable(INSTR_MAP[i.op])) autos.push(i); });
  if (!autos.length) return false;

  const instances = collectInstances(p.blocks);
  const mBytes = cpuById(p.hardware.cpuId).mBytes;
  let changed = false;

  const run = (list: LadderInstr[], counterTypes?: Map<string, DataType>) => {
    if (!list.length) return;
    const { resolve } = makeResolver({ tags: p.tags, instances, counterTypes, mBytes });
    for (const i of list) {
      const t = detectTypes(i, resolve);
      if (!t) continue;
      if (i.dataType !== t.dt) { i.dataType = t.dt; changed = true; }
      if (t.dt2 && i.dataType2 !== t.dt2) { i.dataType2 = t.dt2; changed = true; }
    }
  };

  // counters first: their type decides what "C1.CV" means for everybody else
  run(autos.filter(i => INSTR_MAP[i.op].instance === 'counter'));
  const counterTypes = new Map<string, DataType>();
  for (const b of p.blocks) for (const n of b.networks) walk(n.root, i => {
    if (INSTR_MAP[i.op]?.instance === 'counter' && i.instance) counterTypes.set(i.instance, i.dataType ?? 'Int');
  });
  run(autos.filter(i => INSTR_MAP[i.op].instance !== 'counter'), counterTypes);
  return changed;
}
