import type { DataType, Tag } from '../types';
import { parseAddress, sizeOfType, sizeBytes, type Area, type Size } from './values';

/** Find next free address in an area for the given type (avoids overlap with existing tags). */
export function nextFreeAddress(tags: Tag[], dt: DataType, area: Area = 'M'): string {
  const used = new Set<string>(); // "byte.bit" for bits; bytes for words
  const usedBytes = new Set<number>();
  for (const t of tags) {
    const a = parseAddress(t.address);
    if (!a || a.area !== area) continue;
    if (a.size === 'X') { used.add(`${a.byte}.${a.bit}`); usedBytes.add(a.byte); }
    else for (let k = 0; k < sizeBytes(a.size); k++) usedBytes.add(a.byte + k);
  }
  const size = sizeOfType(dt);
  if (size === 'X') {
    const start = area === 'M' ? 10 : 0;
    for (let b = start; b < 8000; b++) {
      for (let bit = 0; bit < 8; bit++) {
        if (!used.has(`${b}.${bit}`) && (used.size === 0 || !isWordByte(tags, area, b))) return `%${area}${b}.${bit}`;
      }
    }
  }
  const n = sizeBytes(size);
  const start = area === 'M' ? 100 : area === 'I' ? 64 : 64;
  for (let b = start; b < 8000; b += n) {
    let free = true;
    for (let k = 0; k < n; k++) if (usedBytes.has(b + k)) free = false;
    if (free) return `%${area}${size}${b}`;
  }
  return `%${area}${size}${start}`;
}

function isWordByte(tags: Tag[], area: Area, byte: number) {
  return tags.some(t => {
    const a = parseAddress(t.address);
    return a && a.area === area && a.size !== 'X' && byte >= a.byte && byte < a.byte + sizeBytes(a.size);
  });
}

export function uniqueTagName(tags: Tag[], base = 'Tag'): string {
  let k = 1;
  while (tags.some(t => t.name.toLowerCase() === `${base}_${k}`.toLowerCase())) k++;
  return `${base}_${k}`;
}

/** Data type a tag gets automatically when its address has a different size (%MW10 → Int, %MD10 → DInt ...). */
export function tagTypeForSize(s: Size): DataType {
  return s === 'X' ? 'Bool' : s === 'B' ? 'Byte' : s === 'W' ? 'Int' : 'DInt';
}
