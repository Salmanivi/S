import type { Block, BlockKind, CompileMsg, DataType, Project, SeriesNode, LadderInstr } from '../types';
import { INSTR_MAP, type PinDef } from '../catalog/instructions';
import { cpuById, computeAddresses, ioProblemMessages } from '../catalog/hardware';
import { makeResolver, compatible, type Ref } from './resolve';
import { isOutputLike, walk } from './ladder';
import { parseAddress, sizeOfType, inRange, normalizeAddress, typeRange } from './values';

export interface CInstr { k: 'i'; id: string; op: string; dt: DataType; dt2: DataType; refs: Record<string, Ref>; inst?: string; call?: string }
export interface CSer { k: 's'; id: string; items: (CInstr | CPar)[] }
export interface CPar { k: 'p'; id: string; branches: CSer[] }
export interface CBlock { id: string; name: string; kind: BlockKind; cycleMs: number; nets: CSer[] }
export interface CProgram {
  blocks: CBlock[];
  byName: Record<string, CBlock>;
  instances: Map<string, string>;
  counterTypes: Map<string, DataType>;
  mBytes: number;
  clock: { enabled: boolean; byte: number };
  sys: { enabled: boolean; byte: number };
  cpuName: string;
}

export function blockLabel(b: Block) {
  const t = b.kind === 'fc' ? 'FC' : 'OB';
  return `${b.name} [${t}${b.number}]`;
}

export function compileProject(p: Project): { program: CProgram | null; msgs: CompileMsg[] } {
  const msgs: CompileMsg[] = [];
  const cpu = cpuById(p.hardware.cpuId);
  const err = (text: string, loc: Partial<CompileMsg> = {}) => msgs.push({ level: 'error', text, ...loc });
  const warn = (text: string, loc: Partial<CompileMsg> = {}) => msgs.push({ level: 'warning', text, ...loc });

  // ---------------------------------------------------------- tag table
  const names = new Set<string>();
  const hwAddrs = new Set<string>();
  const hwRows = computeAddresses(p.hardware);
  hwRows.forEach(m => m.channels.forEach(c => hwAddrs.add(c.address)));
  ioProblemMessages(hwRows).forEach(t => err(`Device configuration: ${t}`));
  for (const t of p.tags) {
    const n = t.name.trim();
    if (!n) { err('Tag table: a tag has no name'); continue; }
    if (!/^[A-Za-z_][\w ]*$/.test(n)) err(`Tag table: invalid tag name "${n}"`);
    if (names.has(n.toLowerCase())) err(`Tag table: tag name "${n}" is used more than once`);
    names.add(n.toLowerCase());
    const a = parseAddress(t.address);
    if (!a) { err(`Tag table: "${n}" has an invalid address "${t.address}"`); continue; }
    if (sizeOfType(t.dataType) !== a.size) err(`Tag table: data type ${t.dataType} of "${n}" does not match address ${normalizeAddress(t.address)}`);
    if ((a.area === 'I' || a.area === 'Q') && a.size === 'X' && !hwAddrs.has(normalizeAddress(t.address)))
      warn(`Tag table: address ${normalizeAddress(t.address)} of "${n}" is not assigned to any configured module`);
    if ((a.area === 'I' || a.area === 'Q') && a.size === 'W' && !hwAddrs.has(normalizeAddress(t.address)))
      warn(`Tag table: address ${normalizeAddress(t.address)} of "${n}" is not assigned to any configured analog channel`);
  }

  // ---------------------------------------------------------- instances
  const instances = new Map<string, string>();
  const instUse = new Map<string, number>();
  const counterTypes = new Map<string, DataType>();
  for (const b of p.blocks) for (const nw of b.networks) walk(nw.root, i => {
    const d = INSTR_MAP[i.op];
    if (!d?.instance) return;
    const name = (i.instance ?? '').trim();
    if (!name) { err(`${d.title}: instance data block is missing`, { blockId: b.id, networkId: nw.id, elemId: i.id }); return; }
    const prev = instances.get(name);
    if (prev && prev !== d.instance) err(`Instance "${name}" is used both as a timer and as a counter`, { blockId: b.id, networkId: nw.id, elemId: i.id });
    instances.set(name, d.instance);
    instUse.set(name, (instUse.get(name) ?? 0) + 1);
    if (d.instance === 'counter') counterTypes.set(name, i.dataType ?? 'Int');
  });
  instUse.forEach((n, name) => { if (n > 1) warn(`Instance "${name}" is called ${n} times — each timer/counter should have its own instance`); });

  const { resolve } = makeResolver({ tags: p.tags, instances, counterTypes, mBytes: cpu.mBytes });

  // ---------------------------------------------------------- blocks
  const blockNames = new Set<string>();
  for (const b of p.blocks) {
    if (blockNames.has(b.name.toLowerCase())) err(`Block name "${b.name}" is used more than once`);
    blockNames.add(b.name.toLowerCase());
  }
  if (!p.blocks.some(b => b.kind === 'main')) err('No program cycle OB (Main [OB1]) found');

  const findBlock = (name: string) => p.blocks.find(x => x.name.toLowerCase() === name.trim().replace(/"/g, '').toLowerCase());

  const cblocks: CBlock[] = [];
  for (const b of p.blocks) {
    const nets: CSer[] = [];
    b.networks.forEach((nw, ni) => {
      const loc = (elemId?: string): Partial<CompileMsg> => ({ blockId: b.id, networkId: nw.id, elemId });
      const where = `${blockLabel(b)} › Network ${ni + 1}`;
      if (nw.root.items.length > 0) {
        const last = nw.root.items[nw.root.items.length - 1];
        if (!isOutputLike(last)) err(`${where}: the network is not terminated — add a coil or box at the end of the rung`, loc(last.id));
      }
      const compileInstr = (i: LadderInstr): CInstr => {
        const d = INSTR_MAP[i.op];
        const refs: Record<string, Ref> = {};
        const dt: DataType = i.dataType ?? d.defType ?? 'Int';
        const dt2: DataType = i.dataType2 ?? d.defType2 ?? 'Int';
        const label = d.title || d.label;
        const E = (t: string) => err(`${where}: ${label}: ${t}`, loc(i.id));
        const W = (t: string) => warn(`${where}: ${label}: ${t}`, loc(i.id));

        const resolveBit = (s: string, what: string, opts: { write?: boolean; optional?: boolean; allowConst?: boolean; mOnly?: boolean }): Ref => {
          if (!s.trim()) {
            if (!opts.optional) E(`${what} is missing (<??.?>)`);
            return { k: 'none' };
          }
          const r = resolve(s);
          if (r.k === 'err') { E(r.msg); return { k: 'none' }; }
          if (r.k === 'const') {
            if (r.ck !== 'bool' || !opts.allowConst || opts.write) E(`${what}: constant "${s}" is not permitted here, a Bool variable is required`);
            return r.k === 'const' && r.ck === 'bool' ? r : { k: 'none' };
          }
          if (r.k === 'mem') {
            if (r.a.size !== 'X') { E(`${what}: data type mismatch — "${s}" is ${r.tt}, Bool required`); return { k: 'none' }; }
            if (opts.write && r.a.area === 'I') W(`${what}: writing to input "${s}" — it will be overwritten by the process image`);
            if (opts.mOnly && r.a.area !== 'M') W(`edge memory bit "${s}" should be located in bit memory (M)`);
            return r;
          }
          if (r.k === 'inst') {
            if (r.tt !== 'Bool') { E(`${what}: "${s}" is ${r.tt}, Bool required`); return { k: 'none' }; }
            if (opts.write) { E(`${what}: instance members are read-only`); return { k: 'none' }; }
            return r;
          }
          return r;
        };

        const resolveNum = (s: string, pd: PinDef, want: DataType): Ref => {
          const what = pd.name;
          if (!s.trim()) {
            if (!(pd.optional || pd.dir === 'out')) E(`parameter ${what} is missing (<???>)`);
            else if (pd.dir === 'out' && !pd.optional) W(`output ${what} is not connected`);
            return { k: 'none' };
          }
          const r = resolve(s);
          if (r.k === 'err') { E(r.msg); return { k: 'none' }; }
          if (r.k === 'const') {
            if (pd.dir === 'out') { E(`${what}: a constant cannot be used as an output`); return { k: 'none' }; }
            if (want === 'Bool') { if (r.ck !== 'bool') E(`${what}: Bool constant (TRUE/FALSE) required`); return r; }
            if (r.ck === 'bool') { E(`${what}: Bool constant not permitted for ${want}`); return { k: 'none' }; }
            if (want === 'Time' && r.ck !== 'time' && r.ck !== 'int') { E(`${what}: Time constant required (e.g. T#5s)`); return { k: 'none' }; }
            if (want !== 'Time' && r.ck === 'time') { E(`${what}: Time constant not permitted for ${want}`); return { k: 'none' }; }
            if (want !== 'Real' && r.ck === 'real') { E(`${what}: Real constant "${s}" not permitted for ${want}`); return { k: 'none' }; }
            if (want !== 'Real' && typeof r.v === 'number' && !inRange(r.v, want)) { const [lo, hi] = typeRange(want); E(`${what}: constant ${s} is out of range for ${want} (${lo}…${hi})`); }
            return r;
          }
          if (r.k === 'mem') {
            if (pd.dir === 'out' && r.a.area === 'I') W(`${what}: writing to input area "${s}"`);
            if (r.a.size !== sizeOfType(want)) { E(`${what}: data type mismatch — "${s}" (${r.tt}) is not compatible with ${want}`); return { k: 'none' }; }
            if (r.typed && !compatible(r.tt, want)) { E(`${what}: data type mismatch — "${s}" is ${r.tt}, ${want} required`); return { k: 'none' }; }
            return r;
          }
          if (r.k === 'inst') {
            if (pd.dir === 'out') { E(`${what}: instance members are read-only`); return { k: 'none' }; }
            if (!compatible(r.tt, want)) { E(`${what}: "${s}" is ${r.tt}, ${want} required`); return { k: 'none' }; }
            return r;
          }
          return r;
        };

        const resolveIntN = (s: string, what: string): Ref => {
          if (!s.trim()) { E(`parameter ${what} is missing`); return { k: 'none' }; }
          const r = resolve(s);
          if (r.k === 'err') { E(r.msg); return { k: 'none' }; }
          if (r.k === 'const' && r.ck !== 'int') { E(`${what}: integer constant required`); return { k: 'none' }; }
          if (r.k === 'mem' && r.a.size === 'X') { E(`${what}: integer required`); return { k: 'none' }; }
          return r;
        };

        // operand (top)
        if (d.op === 'RT') {
          const name = i.operand.trim().replace(/"/g, '');
          if (!name) E('timer instance operand is missing');
          else if (instances.get(name) !== 'timer') E(`"${name}" is not an IEC timer instance`);
          return { k: 'i', id: i.id, op: i.op, dt, dt2, refs, inst: name };
        }
        if (d.operand) {
          const write = d.shape === 'coil' || d.op === 'SR' || d.op === 'RS';
          refs.operand = resolveBit(i.operand, 'operand', { write });
        }
        let call: string | undefined;
        for (const pd of d.pins) {
          const s = i.params[pd.name] ?? '';
          if (pd.kind === 'block') {
            const target = findBlock(s);
            if (!s.trim()) E('no block selected');
            else if (!target) E(`block "${s}" does not exist`);
            else if (target.kind !== 'fc') E(`"${target.name}" is an organization block and cannot be called`);
            else if (target.id === b.id) E('a block cannot call itself (recursion)');
            else call = target.name;
            continue;
          }
          if (pd.kind === 'bool') {
            refs[pd.name] = resolveBit(s, pd.name, { write: pd.dir === 'out', optional: pd.optional || pd.dir === 'out', allowConst: pd.dir === 'in', mOnly: pd.name === 'M_BIT' });
            continue;
          }
          if (pd.kind === 'int') { refs[pd.name] = resolveIntN(s, pd.name); continue; }
          const want: DataType = pd.kind === 'time' ? 'Time' : pd.kind === 'real' ? 'Real' : pd.typed2 ? dt2 : pd.typed ? dt : 'Int';
          refs[pd.name] = resolveNum(s, pd, want);
        }
        if (d.op === 'CONV' && dt === dt2) W('source and destination type are identical');
        return { k: 'i', id: i.id, op: i.op, dt, dt2, refs, inst: i.instance?.trim(), call };
      };

      const compileSer = (s: SeriesNode): CSer => ({
        k: 's', id: s.id,
        items: s.items.map(it => {
          if (it.kind === 'instr') {
            if (!INSTR_MAP[it.op]) { err(`${where}: unknown instruction ${it.op}`, loc(it.id)); return { k: 'i', id: it.id, op: 'NOT', dt: 'Int', dt2: 'Int', refs: {} } as CInstr; }
            return compileInstr(it);
          }
          it.branches.forEach(br => { if (br.items.length === 0) warn(`${where}: empty branch (short circuit)`, loc(it.id)); });
          return { k: 'p', id: it.id, branches: it.branches.map(br => compileSer(br)) } as CPar;
        }),
      });
      nets.push(compileSer(nw.root));
    });
    cblocks.push({ id: b.id, name: b.name, kind: b.kind, cycleMs: Math.max(1, b.cycleMs ?? 100), nets });
  }

  const errors = msgs.filter(m => m.level === 'error').length;
  const warnings = msgs.filter(m => m.level === 'warning').length;
  msgs.push({ level: errors ? 'error' : 'info', text: `Compiling finished (errors: ${errors}; warnings: ${warnings})` });
  if (errors) return { program: null, msgs };

  const byName: Record<string, CBlock> = {};
  cblocks.forEach(cb => (byName[cb.name] = cb));
  const hp = p.hardware.props;
  const hasSys = cpu.family === 'S7-1200' || cpu.family === 'S7-1500';
  return {
    program: {
      blocks: cblocks, byName, instances, counterTypes, mBytes: cpu.mBytes,
      clock: { enabled: hp.clockEnabled, byte: hp.clockByte },
      sys: { enabled: hasSys && hp.sysEnabled, byte: hp.sysByte },
      cpuName: cpu.name,
    },
    msgs,
  };
}
