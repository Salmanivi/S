import type { DataType } from '../types';
import type { CBlock, CInstr, CPar, CProgram, CSer } from './compiler';
import type { Ref } from './resolve';
import { IO_BYTES, coerce, inRange, sizeOfType } from './values';

export interface TimerSt { IN: boolean; Q: boolean; PT: number; ET: number; start: number; running: boolean; prevIN: boolean }
export interface CounterSt { CU: boolean; CD: boolean; R: boolean; LD: boolean; QU: boolean; QD: boolean; PV: number; CV: number; prevCU: boolean; prevCD: boolean }
export interface DiagEntry { t: number; time: string; text: string; level: 'info' | 'warn' | 'error' }

const MAX_M = 16384;
const CLOCK_PERIODS = [100, 200, 400, 500, 800, 1000, 1600, 2000];

const halfEven = (x: number) => {
  const r = Math.round(x);
  return Math.abs(x % 1) === 0.5 && r % 2 !== 0 ? r - 1 : r;
};

export class Runtime {
  mode: 'STOP' | 'RUN' = 'STOP';
  error = false;
  I = new Uint8Array(IO_BYTES);
  Q = new Uint8Array(IO_BYTES);
  M = new Uint8Array(MAX_M);
  physIn = new Uint8Array(IO_BYTES);
  physOut = new Uint8Array(IO_BYTES);
  private dv = { I: new DataView(this.I.buffer), Q: new DataView(this.Q.buffer), M: new DataView(this.M.buffer) };
  timers = new Map<string, TimerSt>();
  counters = new Map<string, CounterSt>();
  edges = new Map<string, boolean>();
  power = new Map<string, [boolean, boolean]>();
  enoErr = new Set<string>();
  prog: CProgram | null = null;
  simTime = 0;
  dt = 0;
  firstScan = true;
  cyclicAcc = new Map<string, number>();
  scanCount = 0;
  cycle = { last: 0, min: 0, max: 0, exec: 0 };
  diag: DiagEntry[] = [];
  downloadedAt = 0;
  private callDepth = 0;
  private lastTick = 0;
  speed = 1;
  plantStep: ((dt: number) => void) | null = null;

  log(text: string, level: DiagEntry['level'] = 'info') {
    const d = new Date();
    this.diag.unshift({ t: Date.now(), time: d.toLocaleTimeString(), text, level });
    if (this.diag.length > 200) this.diag.pop();
  }

  load(p: CProgram) {
    const wasRun = this.mode === 'RUN';
    this.prog = p;
    this.downloadedAt = Date.now();
    // keep instance data that still exists (download in RUN like S7-1500)
    for (const k of Array.from(this.timers.keys())) if (!p.instances.has(k)) this.timers.delete(k);
    for (const k of Array.from(this.counters.keys())) if (!p.instances.has(k)) this.counters.delete(k);
    this.log(`Download to device completed (${p.blocks.length} block${p.blocks.length > 1 ? 's' : ''})`);
    if (wasRun) this.log('Program changes applied in RUN');
  }

  setMode(m: 'STOP' | 'RUN') {
    if (m === this.mode) return;
    if (m === 'RUN') {
      if (!this.prog) { this.log('Startup refused: no program loaded — download first', 'error'); this.error = true; return; }
      this.error = false;
      // warm restart: non-retentive data initialised
      this.M.fill(0); this.Q.fill(0);
      this.timers.clear(); this.counters.clear(); this.edges.clear(); this.cyclicAcc.clear();
      this.firstScan = true;
      this.cycle = { last: 0, min: 0, max: 0, exec: 0 };
      this.scanCount = 0;
      this.log('Operating mode transition STOP → STARTUP → RUN');
    } else {
      this.physOut.fill(0);
      this.log('Operating mode transition RUN → STOP (requested by user)', 'warn');
    }
    this.mode = m;
  }

  memoryReset() {
    this.mode = 'STOP';
    this.prog = null;
    this.I.fill(0); this.Q.fill(0); this.M.fill(0); this.physOut.fill(0);
    this.timers.clear(); this.counters.clear(); this.edges.clear(); this.power.clear();
    this.error = false;
    this.log('Memory reset (MRES) executed — user program deleted', 'warn');
  }

  // ------------------------------------------------------------ tick
  tick() {
    const now = performance.now();
    if (!this.lastTick) this.lastTick = now;
    let dt = Math.min(200, now - this.lastTick) * this.speed;
    this.lastTick = now;
    if (dt <= 0) dt = 1;
    if (this.mode === 'RUN' && this.prog) {
      const t0 = performance.now();
      this.scan(dt);
      const exec = performance.now() - t0;
      this.cycle.exec = exec;
      this.cycle.last = dt / this.speed;
      this.cycle.min = this.cycle.min === 0 ? this.cycle.last : Math.min(this.cycle.min, this.cycle.last);
      this.cycle.max = Math.max(this.cycle.max, this.cycle.last);
    } else {
      this.physOut.fill(0);
      this.I.set(this.physIn);
    }
    this.plantStep?.(dt);
  }

  scan(dt: number) {
    const p = this.prog!;
    this.dt = dt;
    this.simTime += dt;
    this.I.set(this.physIn);
    this.writeSystemBits(p);
    if (this.firstScan) for (const b of p.blocks) if (b.kind === 'startup') this.runBlock(b);
    for (const b of p.blocks) if (b.kind === 'main') this.runBlock(b);
    for (const b of p.blocks) if (b.kind === 'cyclic') {
      let acc = (this.cyclicAcc.get(b.id) ?? 0) + dt;
      let n = 0;
      while (acc >= b.cycleMs && n < 20) { this.runBlock(b); acc -= b.cycleMs; n++; }
      if (n >= 20) acc = 0;
      this.cyclicAcc.set(b.id, acc);
    }
    this.physOut.set(this.Q);
    this.firstScan = false;
    this.scanCount++;
  }

  private writeSystemBits(p: CProgram) {
    if (p.clock.enabled && p.clock.byte < p.mBytes) {
      let v = 0;
      CLOCK_PERIODS.forEach((per, i) => { if (this.simTime % per >= per / 2) v |= 1 << i; });
      this.M[p.clock.byte] = v;
    }
    if (p.sys.enabled && p.sys.byte < p.mBytes) {
      let v = 0;
      if (this.firstScan) v |= 1 | 2;
      v |= 4;
      this.M[p.sys.byte] = v;
    }
  }

  runBlock(b: CBlock) {
    for (const n of b.nets) this.evalSer(n, true);
  }

  private evalSer(s: CSer, pin: boolean): boolean {
    let p = pin;
    for (const it of s.items) p = it.k === 'p' ? this.evalPar(it, p) : this.exec(it, p);
    return p;
  }

  private evalPar(par: CPar, pin: boolean): boolean {
    let out = false;
    for (const b of par.branches) out = this.evalSer(b, pin) || out;
    this.power.set(par.id, [pin, out]);
    return out;
  }

  // ------------------------------------------------------------ memory access
  private usePhys = false;
  private pdv = { I: new DataView(this.physIn.buffer), Q: new DataView(this.physOut.buffer) };
  private view(area: 'I' | 'Q' | 'M') {
    if (this.usePhys && area !== 'M') return this.pdv[area];
    return this.dv[area];
  }

  readRef(r: Ref | undefined, dt: DataType): number | boolean {
    if (!r || r.k === 'none') return dt === 'Bool' ? false : 0;
    if (r.k === 'const') return dt === 'Bool' ? Boolean(r.v) : typeof r.v === 'boolean' ? (r.v ? 1 : 0) : r.v;
    if (r.k === 'inst') {
      if (r.ikind === 'timer') {
        const t = this.timers.get(r.inst);
        if (!t) return r.tt === 'Bool' ? false : 0;
        return (t as unknown as Record<string, number | boolean>)[r.member];
      }
      const c = this.counters.get(r.inst);
      if (!c) return r.tt === 'Bool' ? false : 0;
      return (c as unknown as Record<string, number | boolean>)[r.member];
    }
    const a = r.a;
    const v = this.view(a.area);
    if (a.size === 'X') return ((v.getUint8(a.byte) >> a.bit) & 1) === 1;
    const t = sizeOfType(dt) === a.size ? dt : r.tt;
    if (a.size === 'B') return t === 'SInt' ? v.getInt8(a.byte) : v.getUint8(a.byte);
    if (a.size === 'W') return t === 'Int' ? v.getInt16(a.byte) : v.getUint16(a.byte);
    if (t === 'Real') return v.getFloat32(a.byte);
    if (t === 'DWord' || t === 'UDInt') return v.getUint32(a.byte);
    return v.getInt32(a.byte);
  }

  private b(r: Ref | undefined): boolean { const v = this.readRef(r, 'Bool'); return typeof v === 'boolean' ? v : v !== 0; }
  private n(r: Ref | undefined, dt: DataType): number { const v = this.readRef(r, dt); return typeof v === 'boolean' ? (v ? 1 : 0) : v; }

  writeRef(r: Ref | undefined, dt: DataType, val: number | boolean) {
    if (!r || r.k !== 'mem') return;
    const a = r.a;
    const v = this.view(a.area);
    if (a.size === 'X') {
      const bv = typeof val === 'boolean' ? val : val !== 0;
      const byte = v.getUint8(a.byte);
      v.setUint8(a.byte, bv ? byte | (1 << a.bit) : byte & ~(1 << a.bit));
      return;
    }
    const t = sizeOfType(dt) === a.size ? dt : r.tt;
    const c = coerce(val, t) as number;
    if (a.size === 'B') { if (t === 'SInt') v.setInt8(a.byte, c); else v.setUint8(a.byte, c); return; }
    if (a.size === 'W') { if (t === 'Int') v.setInt16(a.byte, c); else v.setUint16(a.byte, c); return; }
    if (t === 'Real') v.setFloat32(a.byte, c);
    else if (t === 'DWord' || t === 'UDInt') v.setUint32(a.byte, c >>> 0);
    else v.setInt32(a.byte, c | 0);
  }

  private edge(ci: CInstr, cur: boolean): boolean {
    const mb = ci.refs.M_BIT;
    let prev: boolean;
    if (mb && mb.k === 'mem') { prev = this.b(mb); this.writeRef(mb, 'Bool', cur); }
    else { prev = this.edges.get(ci.id) ?? false; this.edges.set(ci.id, cur); }
    return prev;
  }

  private timerSt(name: string): TimerSt {
    let t = this.timers.get(name);
    if (!t) { t = { IN: false, Q: false, PT: 0, ET: 0, start: 0, running: false, prevIN: false }; this.timers.set(name, t); }
    return t;
  }
  private counterSt(name: string): CounterSt {
    let c = this.counters.get(name);
    if (!c) { c = { CU: false, CD: false, R: false, LD: false, QU: false, QD: true, PV: 0, CV: 0, prevCU: false, prevCD: false }; this.counters.set(name, c); }
    return c;
  }

  // ------------------------------------------------------------ instruction execution
  private exec(ci: CInstr, pin: boolean): boolean {
    const out = this.execInner(ci, pin);
    this.power.set(ci.id, [pin, out]);
    return out;
  }

  private math(ci: CInstr, pin: boolean, f: (dt: DataType) => number | null): boolean {
    if (!pin) return false;
    const r = f(ci.dt);
    if (r === null) { this.enoErr.add(ci.id); return false; }
    let ok = true;
    if (ci.dt !== 'Real' && !inRange(r, ci.dt)) ok = false;
    if (ci.dt === 'Real' && !Number.isFinite(r)) ok = false;
    this.writeRef(ci.refs.OUT, ci.dt, r);
    if (!ok) this.enoErr.add(ci.id); else this.enoErr.delete(ci.id);
    return ok;
  }

  private bitsOf(dt: DataType) { return dt === 'Byte' ? 8 : dt === 'Word' ? 16 : 32; }
  private mask(v: number, dt: DataType) { return dt === 'Byte' ? v & 0xff : dt === 'Word' ? v & 0xffff : v >>> 0; }

  private execInner(ci: CInstr, pin: boolean): boolean {
    const R = ci.refs;
    const dt = ci.dt;
    switch (ci.op) {
      case 'NO': return pin && this.b(R.operand);
      case 'NC': return pin && !this.b(R.operand);
      case 'NOT': return !pin;
      case 'P': { const cur = this.b(R.operand); const prev = this.edge(ci, cur); return pin && cur && !prev; }
      case 'N': { const cur = this.b(R.operand); const prev = this.edge(ci, cur); return pin && !cur && prev; }
      case 'OUT': this.writeRef(R.operand, 'Bool', pin); return pin;
      case 'NEG': this.writeRef(R.operand, 'Bool', !pin); return pin;
      case 'SET': if (pin) this.writeRef(R.operand, 'Bool', true); return pin;
      case 'RESET': if (pin) this.writeRef(R.operand, 'Bool', false); return pin;
      case 'SET_BF': case 'RESET_BF': {
        if (pin && R.operand?.k === 'mem') {
          const n = Math.max(0, Math.min(256, this.n(R.N, 'Int')));
          const a = R.operand.a;
          for (let k = 0; k < n; k++) {
            const bitIdx = a.bit + k;
            const ref: Ref = { k: 'mem', a: { area: a.area, size: 'X', byte: a.byte + Math.floor(bitIdx / 8), bit: bitIdx % 8 }, tt: 'Bool', typed: false };
            if (ref.a.byte < (a.area === 'M' ? (this.prog?.mBytes ?? MAX_M) : IO_BYTES)) this.writeRef(ref, 'Bool', ci.op === 'SET_BF');
          }
        }
        return pin;
      }
      case 'PCOIL': { const prev = this.edge(ci, pin); this.writeRef(R.operand, 'Bool', pin && !prev); return pin; }
      case 'NCOIL': { const prev = this.edge(ci, pin); this.writeRef(R.operand, 'Bool', !pin && prev); return pin; }
      case 'SR': { let s = this.b(R.operand); if (pin) s = true; if (this.b(R.R1)) s = false; this.writeRef(R.operand, 'Bool', s); return s; }
      case 'RS': { let s = this.b(R.operand); if (pin) s = false; if (this.b(R.S1)) s = true; this.writeRef(R.operand, 'Bool', s); return s; }
      case 'P_TRIG': { const prev = this.edge(ci, pin); return pin && !prev; }
      case 'N_TRIG': { const prev = this.edge(ci, pin); return !pin && prev; }

      case 'TON': case 'TOF': case 'TP': case 'TONR': return this.timer(ci, pin);
      case 'RT': { if (pin && ci.inst) { const t = this.timerSt(ci.inst); Object.assign(t, { Q: false, ET: 0, running: false, start: this.simTime, prevIN: false }); } return pin; }

      case 'CTU': case 'CTD': case 'CTUD': return this.counter(ci, pin);

      case 'CMP_EQ': case 'CMP_NE': case 'CMP_GT': case 'CMP_LT': case 'CMP_GE': case 'CMP_LE': {
        if (!pin) return false;
        const a = this.n(R.IN1, dt), b = this.n(R.IN2, dt);
        switch (ci.op) {
          case 'CMP_EQ': return a === b;
          case 'CMP_NE': return a !== b;
          case 'CMP_GT': return a > b;
          case 'CMP_LT': return a < b;
          case 'CMP_GE': return a >= b;
          default: return a <= b;
        }
      }
      case 'IN_RANGE': case 'OUT_RANGE': {
        if (!pin) return false;
        const mn = this.n(R.MIN, dt), v = this.n(R.VAL, dt), mx = this.n(R.MAX, dt);
        const inside = v >= mn && v <= mx;
        return ci.op === 'IN_RANGE' ? inside : !inside;
      }

      case 'ADD': return this.math(ci, pin, t => this.n(R.IN1, t) + this.n(R.IN2, t));
      case 'SUB': return this.math(ci, pin, t => this.n(R.IN1, t) - this.n(R.IN2, t));
      case 'MUL': return this.math(ci, pin, t => (t === 'Real' ? this.n(R.IN1, t) * this.n(R.IN2, t) : Number(BigInt(Math.trunc(this.n(R.IN1, t))) * BigInt(Math.trunc(this.n(R.IN2, t))))));
      case 'DIV': return this.math(ci, pin, t => {
        const a = this.n(R.IN1, t), b = this.n(R.IN2, t);
        if (t === 'Real') return a / b;
        if (b === 0) return null;
        return Math.trunc(a / b);
      });
      case 'MOD': return this.math(ci, pin, t => { const b = this.n(R.IN2, t); return b === 0 ? null : this.n(R.IN1, t) % b; });
      case 'MIN': return this.math(ci, pin, t => Math.min(this.n(R.IN1, t), this.n(R.IN2, t)));
      case 'MAX': return this.math(ci, pin, t => Math.max(this.n(R.IN1, t), this.n(R.IN2, t)));
      case 'NEG_M': return this.math(ci, pin, t => -this.n(R.IN, t));
      case 'ABS': return this.math(ci, pin, t => Math.abs(this.n(R.IN, t)));
      case 'SQRT': return this.math(ci, pin, () => { const v = this.n(R.IN, 'Real'); return v < 0 ? NaN : Math.sqrt(v); });
      case 'SQR': return this.math(ci, pin, () => { const v = this.n(R.IN, 'Real'); return v * v; });
      case 'LIMIT': {
        if (!pin) return false;
        const mn = this.n(R.MN, dt), v = this.n(R.IN, dt), mx = this.n(R.MX, dt);
        if (mn > mx) { this.writeRef(R.OUT, dt, v); return false; }
        this.writeRef(R.OUT, dt, Math.min(mx, Math.max(mn, v)));
        return true;
      }
      case 'INC': case 'DEC': {
        if (!pin) return false;
        const v = this.n(R.IN_OUT, dt) + (ci.op === 'INC' ? 1 : -1);
        this.writeRef(R.IN_OUT, dt, v);
        return inRange(v, dt);
      }
      case 'MOVE': if (!pin) return false; this.writeRef(R.OUT1, dt, this.readRef(R.IN, dt)); return true;
      case 'SWAP': {
        if (!pin) return false;
        const v = this.n(R.IN, dt);
        const s = dt === 'Word' ? ((v & 0xff) << 8) | ((v >> 8) & 0xff)
          : (((v & 0xff) << 24) | ((v & 0xff00) << 8) | ((v >>> 8) & 0xff00) | ((v >>> 24) & 0xff)) >>> 0;
        this.writeRef(R.OUT, dt, s); return true;
      }
      case 'CONV': {
        if (!pin) return false;
        let v = this.n(R.IN, dt);
        if (dt === 'Real' && ci.dt2 !== 'Real') v = halfEven(v);
        const ok = ci.dt2 === 'Real' || inRange(v, ci.dt2);
        this.writeRef(R.OUT, ci.dt2, v);
        return ok;
      }
      case 'ROUND': case 'TRUNC': case 'CEIL': case 'FLOOR': {
        if (!pin) return false;
        const x = this.n(R.IN, 'Real');
        const v = ci.op === 'ROUND' ? halfEven(x) : ci.op === 'TRUNC' ? Math.trunc(x) : ci.op === 'CEIL' ? Math.ceil(x) : Math.floor(x);
        this.writeRef(R.OUT, dt, v);
        return inRange(v, dt);
      }
      case 'NORM_X': {
        if (!pin) return false;
        const mn = this.n(R.MIN, dt), v = this.n(R.VALUE, dt), mx = this.n(R.MAX, dt);
        if (mx === mn) return false;
        this.writeRef(R.OUT, 'Real', (v - mn) / (mx - mn));
        return v >= mn && v <= mx;
      }
      case 'SCALE_X': {
        if (!pin) return false;
        const mn = this.n(R.MIN, dt), v = this.n(R.VALUE, 'Real'), mx = this.n(R.MAX, dt);
        let o = v * (mx - mn) + mn;
        if (dt !== 'Real') o = halfEven(o);
        this.writeRef(R.OUT, dt, o);
        return v >= 0 && v <= 1 && (dt === 'Real' || inRange(o, dt));
      }
      case 'W_AND': case 'W_OR': case 'W_XOR': {
        if (!pin) return false;
        const a = this.n(R.IN1, dt), b = this.n(R.IN2, dt);
        const v = ci.op === 'W_AND' ? a & b : ci.op === 'W_OR' ? a | b : a ^ b;
        this.writeRef(R.OUT, dt, this.mask(v, dt)); return true;
      }
      case 'INV': if (!pin) return false; this.writeRef(R.OUT, dt, this.mask(~this.n(R.IN, dt), dt)); return true;
      case 'SHL': case 'SHR': case 'ROL': case 'ROR': {
        if (!pin) return false;
        const bits = this.bitsOf(dt);
        const v = this.mask(this.n(R.IN, dt), dt);
        let n = Math.max(0, this.n(R.N, 'Int'));
        let o: number;
        if (ci.op === 'SHL') o = n >= bits ? 0 : this.mask(n >= 32 ? 0 : v * 2 ** n, dt);
        else if (ci.op === 'SHR') o = n >= bits ? 0 : Math.floor(v / 2 ** n);
        else {
          n %= bits;
          const hi = ci.op === 'ROL' ? v * 2 ** n : Math.floor(v / 2 ** n);
          const lo = ci.op === 'ROL' ? Math.floor(v / 2 ** (bits - n)) : v * 2 ** (bits - n);
          o = this.mask((hi % 2 ** bits) + (lo % 2 ** bits), dt);
          o = this.mask(o, dt);
        }
        this.writeRef(R.OUT, dt, o); return true;
      }
      case 'CALL': {
        if (!pin) return false;
        const blk = ci.call ? this.prog?.byName[ci.call] : undefined;
        if (blk && this.callDepth < 16) { this.callDepth++; this.runBlock(blk); this.callDepth--; }
        return true;
      }
    }
    return pin;
  }

  private timer(ci: CInstr, IN: boolean): boolean {
    const t = this.timerSt(ci.inst ?? ci.id);
    const PT = Math.max(0, this.n(ci.refs.PT, 'Time'));
    t.PT = PT;
    const now = this.simTime;
    switch (ci.op) {
      case 'TON':
        if (IN) { if (!t.prevIN) t.start = now; t.ET = Math.min(now - t.start, PT); t.Q = t.ET >= PT; }
        else { t.ET = 0; t.Q = false; }
        break;
      case 'TOF':
        if (IN) { t.Q = true; t.ET = 0; t.running = false; }
        else {
          if (t.prevIN) { t.start = now; t.running = true; }
          if (t.running) { t.ET = Math.min(now - t.start, PT); if (t.ET >= PT) { t.Q = false; t.running = false; } }
        }
        break;
      case 'TP':
        if (IN && !t.prevIN && !t.running) { t.start = now; t.running = true; t.Q = PT > 0; }
        if (t.running) { t.ET = Math.min(now - t.start, PT); if (t.ET >= PT) { t.Q = false; t.running = false; } }
        if (!t.running && !IN) t.ET = 0;
        break;
      case 'TONR': {
        const r = this.b(ci.refs.R);
        if (r) { t.ET = 0; t.Q = false; }
        else { if (IN) t.ET = Math.min(t.ET + this.dt, PT); t.Q = t.ET >= PT && PT >= 0 && (t.ET > 0 || PT === 0); }
        break;
      }
    }
    t.IN = IN; t.prevIN = IN;
    if (ci.refs.ET) this.writeRef(ci.refs.ET, 'Time', t.ET);
    return t.Q;
  }

  private counter(ci: CInstr, pin: boolean): boolean {
    const c = this.counterSt(ci.inst ?? ci.id);
    const R = ci.refs;
    const dt = ci.dt;
    const [lo, hi] = [dt === 'SInt' ? -128 : dt === 'Int' ? -32768 : dt === 'DInt' ? -2147483648 : 0, dt === 'SInt' ? 127 : dt === 'USInt' ? 255 : dt === 'Int' ? 32767 : dt === 'UInt' ? 65535 : dt === 'DInt' ? 2147483647 : 4294967295];
    c.PV = this.n(R.PV, dt);
    const r = this.b(R.R), ld = this.b(R.LD);
    c.R = r; c.LD = ld;
    if (ci.op === 'CTU') {
      c.CU = pin;
      if (r) c.CV = 0; else if (pin && !c.prevCU && c.CV < hi) c.CV++;
      c.prevCU = pin;
      c.QU = c.CV >= c.PV; c.QD = c.CV <= 0;
      this.writeRef(R.CV, dt, c.CV);
      return c.QU;
    }
    if (ci.op === 'CTD') {
      c.CD = pin;
      if (ld) c.CV = c.PV; else if (pin && !c.prevCD && c.CV > lo) c.CV--;
      c.prevCD = pin;
      c.QD = c.CV <= 0; c.QU = c.CV >= c.PV;
      this.writeRef(R.CV, dt, c.CV);
      return c.QD;
    }
    const cd = this.b(R.CD);
    c.CU = pin; c.CD = cd;
    if (r) c.CV = 0;
    else if (ld) c.CV = c.PV;
    else {
      if (pin && !c.prevCU && c.CV < hi) c.CV++;
      if (cd && !c.prevCD && c.CV > lo) c.CV--;
    }
    c.prevCU = pin; c.prevCD = cd;
    c.QU = c.CV >= c.PV; c.QD = c.CV <= 0;
    this.writeRef(R.CV, dt, c.CV);
    this.writeRef(R.QD, 'Bool', c.QD);
    return c.QU;
  }

  // ------------------------------------------------------------ external access (sim panel / plant / watch table)
  /** Write a value: inputs go to the physical input image, everything else directly into memory */
  modify(r: Ref, dt: DataType, val: number | boolean) {
    if (r.k !== 'mem') return;
    if (r.a.area === 'I') {
      this.usePhys = true;
      this.writeRef(r, dt, val);
      this.usePhys = false;
      if (this.mode !== 'RUN') this.I.set(this.physIn);
    } else this.writeRef(r, dt, val);
  }

  /** Read physical-side value: Q from physical outputs, I from physical inputs */
  readPhys(r: Ref, dt: DataType): number | boolean {
    this.usePhys = true;
    const v = this.readRef(r, dt);
    this.usePhys = false;
    return v;
  }
}

export const runtime = new Runtime();
