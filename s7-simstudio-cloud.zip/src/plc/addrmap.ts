import type { Project } from '../types';
import { formatAddress, parseAddress, sizeBytes } from './values';
import { walk } from './ladder';

/**
 * Shifts every absolute address of one process image (I or Q) that lies completely inside
 * the byte range [lo, hi] by `delta` bytes. Used when the start address of an I/O area changes,
 * so tags, watch rows, plant bindings and ladder operands keep pointing at the same channels.
 * Returns how many tags were moved.
 */
export function shiftAddresses(p: Project, proc: 'I' | 'Q', lo: number, hi: number, delta: number): number {
  if (delta === 0) return 0;
  const shift = (raw: string): string | null => {
    const a = parseAddress(raw);
    if (!a || a.area !== proc) return null;
    if (a.byte < lo || a.byte + sizeBytes(a.size) - 1 > hi) return null;
    const nb = a.byte + delta;
    if (nb < 0) return null;
    return formatAddress({ ...a, byte: nb });
  };

  let tags = 0;
  for (const t of p.tags) {
    const n = shift(t.address);
    if (n) { t.address = n; tags++; }
  }
  for (const w of p.watch) { const n = shift(w.operand); if (n) w.operand = n; }
  for (const d of p.devices) for (const k of Object.keys(d.bind)) { const n = shift(d.bind[k]); if (n) d.bind[k] = n; }
  for (const b of p.blocks) for (const nw of b.networks) walk(nw.root, i => {
    const n = shift(i.operand);
    if (n) i.operand = n;
    for (const k of Object.keys(i.params)) { const m = shift(i.params[k]); if (m) i.params[k] = m; }
  });
  return tags;
}

/** How many tags would be moved by shiftAddresses (without changing anything). */
export function countShiftable(p: Project, proc: 'I' | 'Q', lo: number, hi: number): number {
  let n = 0;
  for (const t of p.tags) {
    const a = parseAddress(t.address);
    if (a && a.area === proc && a.byte >= lo && a.byte + sizeBytes(a.size) - 1 <= hi) n++;
  }
  return n;
}
