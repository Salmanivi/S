import type { DataType } from '../types';

export type Area = 'I' | 'Q' | 'M';
export type Size = 'X' | 'B' | 'W' | 'D';

export interface Addr { area: Area; size: Size; byte: number; bit: number }

export const IO_BYTES = 2048;

export function parseAddress(raw: string): Addr | null {
  const s = raw.trim().replace(/^%/, '').toUpperCase();
  const m = /^([IQM])([BWDX])?(\d{1,5})(?:\.(\d+))?$/.exec(s);
  if (!m) return null;
  const area = m[1] as Area;
  let size = (m[2] as Size | undefined) ?? 'X';
  const byte = parseInt(m[3], 10);
  const hasBit = m[4] !== undefined;
  if (size === 'X') {
    if (!hasBit) return null;
    const bit = parseInt(m[4]!, 10);
    if (bit > 7) return null;
    return { area, size, byte, bit };
  }
  if (hasBit) return null;
  size = size as Size;
  return { area, size, byte, bit: 0 };
}

export function formatAddress(a: Addr): string {
  return a.size === 'X' ? `%${a.area}${a.byte}.${a.bit}` : `%${a.area}${a.size}${a.byte}`;
}

export function normalizeAddress(raw: string): string {
  const a = parseAddress(raw);
  return a ? formatAddress(a) : raw.trim();
}

export function sizeOfType(dt: DataType): Size {
  switch (dt) {
    case 'Bool': return 'X';
    case 'Byte': case 'SInt': case 'USInt': return 'B';
    case 'Word': case 'Int': case 'UInt': return 'W';
    default: return 'D';
  }
}

export const sizeBytes = (s: Size) => (s === 'X' || s === 'B' ? 1 : s === 'W' ? 2 : 4);

export function defaultTypeForSize(s: Size): DataType {
  return s === 'X' ? 'Bool' : s === 'B' ? 'Byte' : s === 'W' ? 'Word' : 'DWord';
}

export const isIntType = (dt: DataType) => ['SInt', 'USInt', 'Int', 'UInt', 'DInt', 'UDInt', 'Byte', 'Word', 'DWord', 'Time'].includes(dt);
export const isBitString = (dt: DataType) => ['Byte', 'Word', 'DWord'].includes(dt);

export function typeRange(dt: DataType): [number, number] {
  switch (dt) {
    case 'SInt': return [-128, 127];
    case 'USInt': case 'Byte': return [0, 255];
    case 'Int': return [-32768, 32767];
    case 'UInt': case 'Word': return [0, 65535];
    case 'DInt': case 'Time': return [-2147483648, 2147483647];
    case 'UDInt': case 'DWord': return [0, 4294967295];
    case 'Real': return [-3.402823e38, 3.402823e38];
    default: return [0, 1];
  }
}

/** Wrap/convert a JS number into the value domain of a PLC type (like a real CPU would store it). */
export function coerce(v: number | boolean, dt: DataType): number | boolean {
  if (dt === 'Bool') return typeof v === 'boolean' ? v : v !== 0;
  let n = typeof v === 'boolean' ? (v ? 1 : 0) : v;
  if (!Number.isFinite(n)) n = dt === 'Real' ? n : 0;
  switch (dt) {
    case 'Real': return Math.fround(n);
    case 'SInt': return ((Math.trunc(n) << 24) >> 24);
    case 'USInt': case 'Byte': return Math.trunc(n) & 0xff;
    case 'Int': return ((Math.trunc(n) << 16) >> 16);
    case 'UInt': case 'Word': return Math.trunc(n) & 0xffff;
    case 'DInt': case 'Time': return Math.trunc(n) | 0;
    case 'UDInt': case 'DWord': return Math.trunc(n) >>> 0;
  }
  return n;
}

export function inRange(v: number, dt: DataType) {
  const [lo, hi] = typeRange(dt);
  return v >= lo && v <= hi;
}

// ------------------------------------------------------------- constants
export type ConstKind = 'bool' | 'int' | 'real' | 'time';
export interface ConstVal { value: number | boolean; ckind: ConstKind }

export function parseTime(raw: string): number | null {
  const s = raw.trim().toUpperCase().replace(/^(T|TIME)#/, '');
  if (!s) return null;
  const neg = s.startsWith('-');
  const body = neg ? s.slice(1) : s;
  const re = /(\d+(?:\.\d+)?)(MS|D|H|M|S)_?/g;
  let total = 0, consumed = 0, mt: RegExpExecArray | null;
  while ((mt = re.exec(body))) {
    const n = parseFloat(mt[1]);
    const u = mt[2];
    total += u === 'MS' ? n : u === 'S' ? n * 1000 : u === 'M' ? n * 60000 : u === 'H' ? n * 3600000 : n * 86400000;
    consumed += mt[0].length;
  }
  if (consumed !== body.length || consumed === 0) return null;
  return Math.round(neg ? -total : total);
}

export function parseConstant(raw: string): ConstVal | null {
  const s = raw.trim();
  if (!s) return null;
  const u = s.toUpperCase();
  if (u === 'TRUE' || u === 'FALSE') return { value: u === 'TRUE', ckind: 'bool' };
  if (/^(T|TIME)#/i.test(s)) {
    const t = parseTime(s);
    return t === null ? null : { value: t, ckind: 'time' };
  }
  let m = /^(?:[A-Z]+#)?16#([0-9A-F_]+)$/i.exec(s);
  if (m) return { value: parseInt(m[1].replace(/_/g, ''), 16), ckind: 'int' };
  m = /^(?:[A-Z]+#)?2#([01_]+)$/i.exec(s);
  if (m) return { value: parseInt(m[1].replace(/_/g, ''), 2), ckind: 'int' };
  m = /^(?:[A-Z]+#)?8#([0-7_]+)$/i.exec(s);
  if (m) return { value: parseInt(m[1].replace(/_/g, ''), 8), ckind: 'int' };
  if (/^[+-]?\d+$/.test(s)) return { value: parseInt(s, 10), ckind: 'int' };
  if (/^[+-]?(\d+\.\d*|\.\d+|\d+)(e[+-]?\d+)?$/i.test(s)) return { value: parseFloat(s), ckind: 'real' };
  return null;
}

export function formatTime(ms: number): string {
  if (ms === 0) return 'T#0ms';
  const neg = ms < 0;
  let r = Math.abs(Math.round(ms));
  const d = Math.floor(r / 86400000); r -= d * 86400000;
  const h = Math.floor(r / 3600000); r -= h * 3600000;
  const mi = Math.floor(r / 60000); r -= mi * 60000;
  const s = Math.floor(r / 1000); r -= s * 1000;
  const parts: string[] = [];
  if (d) parts.push(`${d}d`);
  if (h) parts.push(`${h}h`);
  if (mi) parts.push(`${mi}m`);
  if (s) parts.push(`${s}s`);
  if (r) parts.push(`${r}ms`);
  return `T#${neg ? '-' : ''}${parts.join('_')}`;
}

export function formatValue(v: number | boolean | undefined, dt: DataType | undefined, fmt: 'auto' | 'dec' | 'hex' | 'bin' | 'bool' = 'auto'): string {
  if (v === undefined) return '';
  if (typeof v === 'boolean') {
    if (fmt === 'dec' || fmt === 'hex' || fmt === 'bin') return v ? '1' : '0';
    return v ? 'TRUE' : 'FALSE';
  }
  const t = dt ?? 'Int';
  const width = t === 'Byte' || t === 'SInt' || t === 'USInt' ? 2 : t === 'Word' || t === 'Int' || t === 'UInt' ? 4 : 8;
  if (fmt === 'hex' || (fmt === 'auto' && isBitString(t))) {
    const u = width === 2 ? v & 0xff : width === 4 ? v & 0xffff : v >>> 0;
    return `16#${u.toString(16).toUpperCase().padStart(width, '0')}`;
  }
  if (fmt === 'bin') {
    const u = width === 2 ? v & 0xff : width === 4 ? v & 0xffff : v >>> 0;
    return `2#${u.toString(2).padStart(width * 4, '0').replace(/(\d{4})(?=\d)/g, '$1_')}`;
  }
  if (fmt === 'bool') return v ? 'TRUE' : 'FALSE';
  if (t === 'Time' && fmt === 'auto') return formatTime(v);
  if (t === 'Real') {
    if (!Number.isFinite(v)) return String(v);
    const a = Math.abs(v);
    if (a !== 0 && (a >= 1e7 || a < 1e-4)) return v.toExponential(4);
    return String(parseFloat(v.toPrecision(7)));
  }
  return String(v);
}
