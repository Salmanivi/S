import type { Elem, LadderInstr, Network, ParallelNode, SeriesNode, Block } from '../types';
import { INSTR_MAP } from '../catalog/instructions';

let counter = 0;
export const uid = (p = 'e') => `${p}${Date.now().toString(36)}${(counter++).toString(36)}${Math.random().toString(36).slice(2, 6)}`;

export const newSeries = (items: Elem[] = []): SeriesNode => ({ id: uid('s'), kind: 'ser', items });
export const newNetwork = (title = ''): Network => ({ id: uid('n'), title, comment: '', root: newSeries() });

export function collectInstances(blocks: Block[]): Map<string, string> {
  const map = new Map<string, string>();
  for (const b of blocks) for (const n of b.networks) walk(n.root, i => { if (i.instance) map.set(i.instance, INSTR_MAP[i.op]?.instance ?? ''); });
  return map;
}

export function nextInstanceName(blocks: Block[], kind: 'timer' | 'counter'): string {
  const used = collectInstances(blocks);
  const base = kind === 'timer' ? 'IEC_Timer_0_DB' : 'IEC_Counter_0_DB';
  if (!used.has(base)) return base;
  for (let i = 1; ; i++) {
    const n = kind === 'timer' ? `IEC_Timer_0_DB_${i}` : `IEC_Counter_0_DB_${i}`;
    if (!used.has(n)) return n;
  }
}

export function newInstr(op: string, blocks: Block[]): LadderInstr {
  const def = INSTR_MAP[op];
  const params: Record<string, string> = {};
  for (const p of def.pins) params[p.name] = p.def ?? '';
  return {
    id: uid('i'), kind: 'instr', op, operand: '', params,
    dataType: def.defType, dataType2: def.defType2,
    autoType: def.types && def.types.length > 1 ? true : undefined,
    instance: def.instance ? nextInstanceName(blocks, def.instance) : undefined,
  };
}

export function walk(s: SeriesNode, fn: (i: LadderInstr, parent: SeriesNode) => void) {
  for (const it of s.items) {
    if (it.kind === 'instr') fn(it, s);
    else for (const b of it.branches) walk(b, fn);
  }
}

export function findElem(s: SeriesNode, id: string): { parent: SeriesNode; index: number } | null {
  for (let i = 0; i < s.items.length; i++) {
    const it = s.items[i];
    if (it.id === id) return { parent: s, index: i };
    if (it.kind === 'par') for (const b of it.branches) { const r = findElem(b, id); if (r) return r; }
  }
  return null;
}

export function findSeries(s: SeriesNode, id: string): SeriesNode | null {
  if (s.id === id) return s;
  for (const it of s.items) if (it.kind === 'par') for (const b of it.branches) { const r = findSeries(b, id); if (r) return r; }
  return null;
}

export function findParallelOf(s: SeriesNode, seriesId: string): ParallelNode | null {
  for (const it of s.items) if (it.kind === 'par') {
    if (it.branches.some(b => b.id === seriesId)) return it;
    for (const b of it.branches) { const r = findParallelOf(b, seriesId); if (r) return r; }
  }
  return null;
}

export function getInstr(s: SeriesNode, id: string): LadderInstr | null {
  const f = findElem(s, id);
  if (!f) return null;
  const it = f.parent.items[f.index];
  return it.kind === 'instr' ? it : null;
}

/** Remove empty branches & flatten single-branch parallels */
export function normalize(s: SeriesNode): void {
  const out: Elem[] = [];
  for (const it of s.items) {
    if (it.kind === 'par') {
      it.branches.forEach(normalize);
      it.branches = it.branches.filter(b => b.items.length > 0);
      if (it.branches.length === 0) continue;
      if (it.branches.length === 1) { out.push(...it.branches[0].items); continue; }
      out.push(it);
    } else out.push(it);
  }
  s.items = out;
}

export function cloneElem<T extends Elem | SeriesNode>(e: T, blocks?: Block[]): T {
  const c = JSON.parse(JSON.stringify(e)) as T;
  const re = (x: Elem | SeriesNode) => {
    x.id = uid(x.kind === 'ser' ? 's' : x.kind === 'par' ? 'p' : 'i');
    if (x.kind === 'ser') x.items.forEach(re);
    else if (x.kind === 'par') x.branches.forEach(re);
    else if (x.instance && blocks) {
      const kind = INSTR_MAP[x.op]?.instance;
      if (kind) x.instance = nextInstanceName(blocks, kind);
    }
  };
  re(c);
  return c;
}

export const isOutputLike = (e: Elem): boolean => {
  if (e.kind === 'par') return e.branches.every(b => b.items.length > 0 && isOutputLike(b.items[b.items.length - 1]));
  const d = INSTR_MAP[e.op];
  return d?.shape === 'coil' || (d?.shape === 'box' && d.op !== 'IN_RANGE' && d.op !== 'OUT_RANGE');
};

// ---------------------------------------------------------------- layout
export const G = {
  WIRE: 54,
  CW: 92,          // contact / coil width
  CH: 96,
  BOX_W: 104,
  BOX_MARGIN: 90,
  PIN: 22,
  PAD: 16,
  EMPTY_W: 64,
  MIN_W: 700,
};

export interface LInstr { kind: 'instr'; el: LadderInstr; w: number; h: number }
export interface LSer { kind: 'ser'; el: SeriesNode; w: number; h: number; xs: number[]; items: (LInstr | LPar)[]; open: boolean }
export interface LPar { kind: 'par'; el: ParallelNode; w: number; h: number; ys: number[]; branches: LSer[]; open: boolean }

export function boxRows(i: LadderInstr): { ins: string[]; outs: string[]; rows: number } {
  const d = INSTR_MAP[i.op];
  const ins = d.pins.filter(p => p.dir === 'in' && p.kind !== 'block').map(p => p.name);
  const outs = d.pins.filter(p => p.dir === 'out').map(p => p.name);
  return { ins, outs, rows: 1 + Math.max(ins.length, outs.length) };
}

function layoutInstr(i: LadderInstr): LInstr {
  const d = INSTR_MAP[i.op];
  if (!d) return { kind: 'instr', el: i, w: G.CW, h: G.CH };
  if (d.shape === 'box') {
    const { rows } = boxRows(i);
    const h = Math.max(G.CH, G.WIRE + (rows - 1) * G.PIN + 30);
    return { kind: 'instr', el: i, w: G.BOX_W + 2 * G.BOX_MARGIN, h };
  }
  if (d.shape === 'coil' && (d.op === 'SET_BF' || d.op === 'RESET_BF')) return { kind: 'instr', el: i, w: G.CW + 20, h: G.CH };
  return { kind: 'instr', el: i, w: G.CW, h: G.CH };
}

export function layoutSeries(s: SeriesNode, open: boolean, minW = 0): LSer {
  if (s.items.length === 0) return { kind: 'ser', el: s, w: Math.max(G.EMPTY_W, minW), h: G.CH * 0.75, xs: [], items: [], open };
  const items = s.items.map((it, idx) => {
    const isLast = idx === s.items.length - 1;
    return it.kind === 'instr' ? layoutInstr(it) : layoutPar(it, open && isLast);
  });
  const xs: number[] = [];
  let x = 0;
  for (const it of items) { xs.push(x); x += it.w; }
  let w = x;
  if (minW > w && items.length > 0) {
    const last = s.items[s.items.length - 1];
    if (open && isOutputLike(last)) xs[xs.length - 1] += minW - w;
    w = minW;
  }
  const h = Math.max(...items.map(i => i.h));
  return { kind: 'ser', el: s, w, h, xs, items, open };
}

function layoutPar(p: ParallelNode, open: boolean): LPar {
  const pre = p.branches.map(b => layoutSeries(b, open));
  const maxW = Math.max(...pre.map(b => b.w));
  // re-layout with stretch so open-ended coils align right
  const branches = open ? p.branches.map(b => layoutSeries(b, open, maxW)) : pre;
  const ys: number[] = [];
  let y = 0;
  for (const b of branches) { ys.push(y); y += b.h; }
  return { kind: 'par', el: p, w: maxW + G.PAD * (open ? 1 : 2), h: y, ys, branches, open };
}

export function layoutNetwork(n: Network, minW: number = G.MIN_W): LSer {
  return layoutSeries(n.root, true, minW);
}
