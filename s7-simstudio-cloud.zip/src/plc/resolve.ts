import type { DataType, Tag } from '../types';
import { type Addr, type ConstKind, IO_BYTES, parseAddress, parseConstant, defaultTypeForSize, sizeOfType, sizeBytes } from './values';

export type Ref =
  | { k: 'mem'; a: Addr; tt: DataType; name?: string; typed: boolean }
  | { k: 'inst'; inst: string; member: string; tt: DataType; ikind: 'timer' | 'counter' }
  | { k: 'const'; v: number | boolean; ck: ConstKind }
  | { k: 'none' };

export type ResolveResult = Ref | { k: 'err'; msg: string };

const TIMER_MEMBERS: Record<string, DataType> = { IN: 'Bool', Q: 'Bool', PT: 'Time', ET: 'Time' };
const COUNTER_MEMBERS: Record<string, DataType> = { CU: 'Bool', CD: 'Bool', R: 'Bool', LD: 'Bool', QU: 'Bool', QD: 'Bool', Q: 'Bool', PV: 'Int', CV: 'Int' };

export interface ResolverCtx {
  tags: Tag[];
  instances: Map<string, string>; // name -> 'timer' | 'counter'
  counterTypes?: Map<string, DataType>;
  mBytes: number;
}

export function unquote(s: string) {
  return s.trim().replace(/"/g, '');
}

export function makeResolver(ctx: ResolverCtx) {
  const tagMap = new Map<string, Tag>();
  for (const t of ctx.tags) tagMap.set(t.name.trim().toLowerCase(), t);
  const instMap = new Map<string, { name: string; kind: string }>();
  ctx.instances.forEach((kind, name) => instMap.set(name.toLowerCase(), { name, kind }));
  const cache = new Map<string, ResolveResult>();

  const checkBounds = (a: Addr): string | null => {
    const end = a.byte + sizeBytes(a.size) - 1;
    const lim = a.area === 'M' ? ctx.mBytes : IO_BYTES;
    if (end >= lim) return `Address ${a.area}${a.size === 'X' ? '' : a.size}${a.byte} is outside the ${a.area === 'M' ? 'bit memory' : 'process image'} range of this CPU (0…${lim - 1})`;
    return null;
  };

  function resolve(raw: string): ResolveResult {
    const s0 = (raw ?? '').trim();
    if (!s0) return { k: 'none' };
    const hit = cache.get(s0);
    if (hit) return hit;
    const r = doResolve(s0);
    cache.set(s0, r);
    return r;
  }

  function doResolve(s0: string): ResolveResult {
    const s = unquote(s0);
    // tag
    const tag = tagMap.get(s.toLowerCase());
    if (tag) {
      const a = parseAddress(tag.address);
      if (!a) return { k: 'err', msg: `Tag "${tag.name}" has an invalid address "${tag.address}"` };
      const b = checkBounds(a);
      if (b) return { k: 'err', msg: b };
      return { k: 'mem', a, tt: tag.dataType, name: tag.name, typed: true };
    }
    // absolute address
    const a = parseAddress(s);
    if (a) {
      const b = checkBounds(a);
      if (b) return { k: 'err', msg: b };
      return { k: 'mem', a, tt: defaultTypeForSize(a.size), typed: false };
    }
    // instance member
    const dot = s.lastIndexOf('.');
    if (dot > 0) {
      const iname = s.slice(0, dot).toLowerCase();
      const member = s.slice(dot + 1).toUpperCase();
      const inst = instMap.get(iname);
      if (inst) {
        const table = inst.kind === 'timer' ? TIMER_MEMBERS : COUNTER_MEMBERS;
        let tt = table[member];
        if (!tt) return { k: 'err', msg: `"${inst.name}" has no member "${member}"` };
        if ((member === 'PV' || member === 'CV') && ctx.counterTypes?.get(inst.name)) tt = ctx.counterTypes.get(inst.name)!;
        return { k: 'inst', inst: inst.name, member: member === 'Q' && inst.kind === 'counter' ? 'QU' : member, tt, ikind: inst.kind as 'timer' | 'counter' };
      }
    }
    const c = parseConstant(s);
    if (c) return { k: 'const', v: c.value, ck: c.ckind };
    if (/^[A-Za-z_][\w ]*$/.test(s)) return { k: 'err', msg: `Tag "${s}" is not defined in the PLC tag table` };
    return { k: 'err', msg: `Invalid operand "${s0}"` };
  }

  return { resolve, tagMap };
}

export function refType(r: Ref, hint?: DataType): DataType | undefined {
  if (r.k === 'mem') {
    if (hint && sizeOfType(hint) === r.a.size && (!r.typed || r.tt === hint || compatible(r.tt, hint))) return hint;
    return r.tt;
  }
  if (r.k === 'inst') return r.tt;
  if (r.k === 'const') return r.ck === 'bool' ? 'Bool' : r.ck === 'time' ? 'Time' : r.ck === 'real' ? 'Real' : hint ?? 'Int';
  return undefined;
}

/** Implicit conversion compatibility (simplified TIA rules) */
export function compatible(from: DataType, to: DataType): boolean {
  if (from === to) return true;
  const int16 = ['Int', 'Word', 'UInt'];
  const int32 = ['DInt', 'DWord', 'UDInt', 'Time'];
  const int8 = ['Byte', 'SInt', 'USInt'];
  if (int16.includes(from) && int16.includes(to)) return true;
  if (int32.includes(from) && int32.includes(to)) return true;
  if (int8.includes(from) && int8.includes(to)) return true;
  return false;
}
