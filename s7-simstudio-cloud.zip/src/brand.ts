import { useAuth } from './cloud/auth';

/**
 * Who made the app and how to reach them. These are the built-in defaults: they are shown even in the offline
 * edition (no server). On an online installation the administrator can override name, email and phone in
 * Admin → Settings; an empty setting falls back to the values below.
 */
export const BRAND = {
  appName: 'S7 SimStudio',
  version: '1.1.0',
  author: 'Salman',
  email: 'salmanino.ahmedino@gmail.com',
  phone: '+20 11 54390240',
} as const;

export const telHref = (p: string) => 'tel:' + p.replace(/[^\d+]/g, '');
export const mailHref = (m: string) => 'mailto:' + m;

/** Contact details to display (server settings win, built-in defaults otherwise). */
export function useContact() {
  const c = useAuth(s => s.config);
  return { name: c?.operatorName || BRAND.author, email: c?.contactEmail || BRAND.email, phone: c?.contactPhone || BRAND.phone };
}
