import { useEffect } from 'react';
import { X } from 'lucide-react';

export function Modal({ title, children, onClose, wide }: { title: string; children: React.ReactNode; onClose: () => void; wide?: boolean }) {
  useEffect(() => {
    const h = (e: KeyboardEvent) => { if (e.key === 'Escape') { e.stopPropagation(); onClose(); } };
    window.addEventListener('keydown', h);
    return () => window.removeEventListener('keydown', h);
  }, [onClose]);
  return (
    <div className="fixed inset-0 z-50 bg-black/55 backdrop-blur-sm flex items-end sm:items-center justify-center sm:p-6" onClick={onClose} role="dialog" aria-modal="true" aria-label={title} data-modal>
      <div className={`card w-full ${wide ? 'sm:max-w-4xl' : 'sm:max-w-2xl'} max-h-[88vh] flex flex-col anim-in rounded-b-none sm:rounded-b-xl`} onClick={e => e.stopPropagation()}>
        <div className="flex items-center px-4 py-3 border-b border-line"><div className="font-semibold text-sm">{title}</div><button className="ml-auto btn btn-ghost btn-icon" onClick={onClose} aria-label="Close"><X size={16} /></button></div>
        <div className="overflow-y-auto">{children}</div>
      </div>
    </div>
  );
}
