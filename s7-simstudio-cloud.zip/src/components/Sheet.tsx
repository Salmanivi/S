import { useEffect, useState } from 'react';
import { X } from 'lucide-react';

const PHONE_QUERY = '(max-width: 1023px)';

/** True on phone / small-tablet screens (below the `lg` breakpoint). */
export function useIsPhone(): boolean {
  const [match, setMatch] = useState(() => (typeof window !== 'undefined' ? window.matchMedia(PHONE_QUERY).matches : false));
  useEffect(() => {
    const mq = window.matchMedia(PHONE_QUERY);
    const on = () => setMatch(mq.matches);
    mq.addEventListener('change', on);
    on();
    return () => mq.removeEventListener('change', on);
  }, []);
  return match;
}

/** Bottom sheet for phones: slides up, closes on backdrop tap, respects the home-indicator safe area. */
export function Sheet({ title, onClose, children, tall, headerExtra }: {
  title: string;
  onClose: () => void;
  children: React.ReactNode;
  /** fixed 85% height; the content manages its own scrolling */
  tall?: boolean;
  headerExtra?: React.ReactNode;
}) {
  useEffect(() => {
    const h = (e: KeyboardEvent) => { if (e.key === 'Escape') onClose(); };
    window.addEventListener('keydown', h);
    return () => window.removeEventListener('keydown', h);
  }, [onClose]);

  return (
    <div className="fixed inset-0 z-[55] flex flex-col justify-end" role="dialog" aria-modal="true" aria-label={title}>
      <div className="absolute inset-0 bg-black/50" onClick={onClose} />
      <div className={`relative card !rounded-b-none !rounded-t-2xl flex flex-col shadow-2xl anim-sheet ${tall ? 'h-[85dvh]' : 'max-h-[85dvh]'}`}>
        <div className="shrink-0 pt-2" onClick={onClose}><div className="mx-auto h-1 w-10 rounded-full bg-line" /></div>
        <div className="shrink-0 flex items-center gap-2 pl-4 pr-1.5 pt-1 pb-1.5 border-b border-line">
          <div className="font-semibold text-[15px] truncate">{title}</div>
          <div className="flex-1" />
          {headerExtra}
          <button className="btn btn-ghost btn-icon" onClick={onClose} aria-label="Close"><X size={18} /></button>
        </div>
        <div className={`flex-1 min-h-0 safe-b ${tall ? 'overflow-hidden' : 'overflow-y-auto overscroll-contain'}`}>{children}</div>
      </div>
    </div>
  );
}
