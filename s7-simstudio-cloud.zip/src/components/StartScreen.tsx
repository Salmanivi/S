import { useEffect, useMemo, useRef, useState } from 'react';
import { FilePlus2, FolderOpen, HelpCircle, ArrowRight, Cloud, Users, ShieldCheck, Lock } from 'lucide-react';
import { useStore } from '../store';
import { EXAMPLES, emptyProject } from '../examples';
import { CPUS, FAMILIES, type Family } from '../catalog/hardware';
import { Modal, ThemeButton, openProjectFile } from './Shell';
import { useAuth } from '../cloud/auth';
import { BRAND, useContact } from '../brand';
import { api } from '../cloud/api';
import { AccountMenu } from '../cloud/Chrome';
import { openCloudProject, saveToCloud } from '../cloud/sync';
import { canWrite, type ProjectMeta } from '../cloud/types';
import { timeAgo } from '../cloud/ui';

/** A static ladder rung: the app's signature shape, drawn with the same symbols as the editor. */
function Rung() {
  return (
    <svg viewBox="0 0 360 64" className="w-full max-w-[360px] h-auto" role="img" aria-label="A ladder logic rung: two contacts in series driving a coil" fill="none" strokeLinecap="round">
      <g stroke="var(--c-mute)" strokeWidth="2">
        <path d="M6 6v52M354 6v52" />
        <path d="M6 32h90M112 32h56M184 32h84M292 32h62" />
        <path d="M96 22v20M112 22v20" />
        <path d="M168 22v20M184 22v20M166 44l20-24" />
      </g>
      <g stroke="var(--c-accent)" strokeWidth="2.4">
        <path d="M272 20q-9 12 0 24M288 20q9 12 0 24" />
      </g>
      <g fill="var(--c-mute)" fontFamily="var(--font-mono)" fontSize="9" textAnchor="middle" stroke="none">
        <text x="104" y="16">Start</text>
        <text x="176" y="16">Stop</text>
        <text x="280" y="16" fill="var(--c-accent)">Motor</text>
      </g>
    </svg>
  );
}

/** Sign-in prompt, first-time setup banner, or the user's recent cloud projects. */
function CloudStrip() {
  const { user, config, cloudAvailable, ready, openPage } = useAuth();
  const [recent, setRecent] = useState<ProjectMeta[] | null>(null);
  useEffect(() => {
    if (!user) { setRecent(null); return; }
    let live = true;
    api.get<{ projects: ProjectMeta[] }>('/projects').then(r => { if (live) setRecent(r.projects.slice(0, 5)); }).catch(() => { if (live) setRecent([]); });
    return () => { live = false; };
  }, [user]);
  if (!cloudAvailable || !ready) return null;
  return (
    <>
      {config?.needsSetup && (
        <section className="mt-8 card p-4 !border-accent/50 flex gap-3 items-center flex-wrap">
          <ShieldCheck size={22} className="text-accent shrink-0" />
          <div className="flex-1 min-w-[200px]"><div className="font-semibold text-[14px]">Finish setting up your server</div><div className="text-[12.5px] text-mute">Create the administrator account (needs the SETUP_TOKEN you configured).</div></div>
          <button className="btn btn-accent" onClick={() => openPage('setup')}>Create administrator</button>
        </section>
      )}
      {!user ? (
        <section className="mt-8 card p-4 flex gap-3 items-center flex-wrap">
          <Cloud size={22} className="text-accent2 shrink-0" />
          <div className="flex-1 min-w-[220px]"><div className="font-semibold text-[14px]">Save online and work together</div><div className="text-[12.5px] text-mute">Sign in to keep projects in the cloud, open them on any device and share them with a team.</div></div>
          <div className="flex gap-2"><button className="btn btn-accent" onClick={() => openPage('login')}>Sign in</button>{config?.registrationEnabled && <button className="btn" onClick={() => openPage('register')}>Create account</button>}</div>
        </section>
      ) : (
        <section className="mt-10" aria-labelledby="cloud-h">
          <div className="flex items-center gap-2 mb-2.5"><h2 id="cloud-h" className="label flex-1">Your cloud projects</h2>
            <button className="btn btn-ghost !py-1" onClick={() => openPage('projects')}>All projects</button>
            <button className="btn btn-ghost !py-1" onClick={() => openPage('teams')}><Users size={14} />Teams</button></div>
          {recent === null ? <div className="text-[13px] text-mute py-3">Loading…</div> : recent.length === 0 ? (
            <div className="text-[13px] text-mute card p-4">No cloud projects yet. Create a project below and choose “My projects” as its location, or save an example from the editor.</div>
          ) : (
            <ul className="grid sm:grid-cols-2 gap-2.5">
              {recent.map(p => (
                <li key={p.id}><button className="group w-full text-left rounded-xl border border-line bg-panel hover:border-accent/60 hover:bg-panel2 p-3.5 transition-colors" onClick={() => void openCloudProject(p.id)}>
                  <div className="flex items-center gap-2"><span className="text-[14px] font-semibold flex-1 truncate">{p.name}</span>{p.role === 'viewer' && <Lock size={13} className="text-warn" aria-label="View only" />}<ArrowRight size={15} className="text-mute group-hover:text-accent transition-colors" /></div>
                  <div className="text-[12px] text-mute mt-1 truncate">{p.scope === 'team' ? `${p.teamName} · ` : ''}Edited {timeAgo(p.updatedAt)}{p.updatedBy ? ` by ${p.updatedBy}` : ''}</div>
                </button></li>
              ))}
            </ul>
          )}
        </section>
      )}
    </>
  );
}

export function StartScreen() {
  const st = useStore.getState;
  const fileRef = useRef<HTMLInputElement>(null);
  const { cloudAvailable, openPage } = useAuth();
  const contact = useContact();

  return (
    <div className="h-full overflow-y-auto bg-bg">
      <div className="mx-auto max-w-3xl px-4 sm:px-6 pt-[calc(0.75rem+env(safe-area-inset-top))] pb-[calc(2.5rem+env(safe-area-inset-bottom))]">
        <header className="flex items-center gap-2">
          <div className="w-8 h-8 rounded-lg bg-gradient-to-br from-accent to-accent2 flex items-center justify-center shadow-lg shadow-accent/20" aria-hidden>
            <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="white" strokeWidth="2.2" strokeLinecap="round"><path d="M3 4v16M21 4v16M3 12h4M9 7v10M13 7v10M17 12h4M13 12h2" /><path d="M15 9q3 3 0 6" /></svg>
          </div>
          <div className="text-[14px] font-bold tracking-tight">S7 SimStudio</div>
          <div className="flex-1" />
          <ThemeButton />
          <button className="btn btn-ghost btn-icon" aria-label="Quick guide" title="Quick guide" onClick={() => st().set({ dialog: 'help' })}><HelpCircle size={16} /></button>
          <AccountMenu />
        </header>

        <main>
          <section className="mt-10 sm:mt-16">
            <Rung />
            <h1 className="mt-6 text-[28px] sm:text-4xl font-bold tracking-tight leading-tight">Siemens S7 ladder simulator</h1>
            <p className="mt-3 text-mute text-[15px] leading-relaxed max-w-xl">
              Write ladder logic, run it on a simulated S7-300, S7-400, S7-1200 or S7-1500 CPU, and test it against a virtual machine.
            </p>
            <div className="mt-6 flex flex-col sm:flex-row gap-2.5">
              <button className="btn btn-accent justify-center !text-[15px] !py-3 sm:!px-6" onClick={() => st().set({ dialog: 'new' })}><FilePlus2 size={17} />New project</button>
              <button className="btn justify-center !text-[15px] !py-3 sm:!px-6" onClick={() => fileRef.current?.click()}><FolderOpen size={17} />Open project file</button>
            </div>
            <input ref={fileRef} type="file" accept=".json,application/json" className="hidden" onChange={e => { const f = e.target.files?.[0]; if (f) openProjectFile(f); e.target.value = ''; }} />
          </section>

          <CloudStrip />

          <section className="mt-12" aria-labelledby="ex-h">
            <h2 id="ex-h" className="label mb-2.5">Or start from an example</h2>
            <div className="grid sm:grid-cols-2 gap-2.5">
              {EXAMPLES.map(ex => (
                <button key={ex.id} onClick={() => st().loadProject(ex.make(), `Example “${ex.title}” opened — press Run to start`)}
                  className="group text-left rounded-xl border border-line bg-panel hover:border-accent/60 hover:bg-panel2 p-3.5 transition-colors">
                  <div className="flex items-center gap-2">
                    <div className="text-[14px] font-semibold text-ink flex-1">{ex.title}</div>
                    <ArrowRight size={15} className="text-mute group-hover:text-accent transition-colors" />
                  </div>
                  <div className="text-[12.5px] text-mute mt-1 leading-snug">{ex.desc}</div>
                </button>
              ))}
            </div>
          </section>

          <p className="mt-10 text-[12px] text-mute leading-relaxed max-w-xl">
            {cloudAvailable
              ? <>Projects are only stored online when you save them to your account. Without an account, use <b className="text-ink/80">Export project</b> to keep your work as a file and <b className="text-ink/80">Open project file</b> to continue later.</>
              : <>Nothing is saved automatically. Use <b className="text-ink/80">Export project</b> in the project menu to keep your work as a file, and <b className="text-ink/80">Open project file</b> to continue later.</>}
          </p>
          <nav className="mt-4 flex flex-wrap items-center gap-x-4 gap-y-1 text-[12px] text-mute" aria-label="About">
            <span>Created by <b className="text-ink/80">{contact.name}</b></span>
            <button className="hover:text-accent hover:underline" onClick={() => openPage('about')}>About &amp; contact</button>
            {cloudAvailable && <button className="hover:text-accent hover:underline" onClick={() => openPage('terms')}>Terms</button>}
            {cloudAvailable && <button className="hover:text-accent hover:underline" onClick={() => openPage('privacy')}>Privacy</button>}
            <span>v{BRAND.version}</span>
          </nav>
        </main>
      </div>
    </div>
  );
}

/** Name + CPU picker for a new project */
export function NewProjectDialog() {
  const st = useStore.getState;
  const [name, setName] = useState('Project1');
  const [fam, setFam] = useState<Family>('S7-1200');
  const list = useMemo(() => CPUS.filter(c => c.family === fam), [fam]);
  const [cpuId, setCpuId] = useState('1214C_DC_DC_DC');
  const cpu = list.find(c => c.id === cpuId) ?? list[0];
  const { user, teams, cloudAvailable } = useAuth();
  const dests = [{ id: 'local', label: 'This device only (not saved)' }, { id: 'me', label: 'My cloud projects' }, ...teams.filter(t => canWrite(t.role)).map(t => ({ id: t.id, label: `Team: ${t.name}` }))];
  const [dest, setDest] = useState(user ? 'me' : 'local');

  const create = async () => {
    const p = emptyProject(cpu.id, name.trim() || 'Project1');
    st().loadProject(p, `Project “${p.name}” created`);
    if (cloudAvailable && user && dest !== 'local') await saveToCloud(dest === 'me' ? null : dest, p.name);
  };

  return (
    <Modal title="New project" onClose={() => st().set({ dialog: null })}>
      <div className="p-4 space-y-4">
        <label className="block">
          <div className="label mb-1">Project name</div>
          <input className="input" value={name} onChange={e => setName(e.target.value)} onKeyDown={e => e.key === 'Enter' && void create()} autoFocus={!('ontouchstart' in window)} />
        </label>
        <div>
          <div className="label mb-1">CPU family</div>
          <div className="grid grid-cols-4 gap-1 p-0.5 rounded-lg bg-bg border border-line text-[12px]">
            {FAMILIES.map(f => (
              <button key={f} onClick={() => { setFam(f); setCpuId(CPUS.find(c => c.family === f)!.id); }} aria-pressed={fam === f}
                className={`py-2 rounded-md font-medium ${fam === f ? 'bg-panel3 text-accent' : 'text-mute'}`}>{f.replace('S7-', '')}</button>
            ))}
          </div>
        </div>
        <label className="block">
          <div className="label mb-1">CPU</div>
          <select className="input" value={cpu.id} onChange={e => setCpuId(e.target.value)}>
            {list.map(c => <option key={c.id} value={c.id}>{c.name} {c.variant}</option>)}
          </select>
          <div className="mt-1.5 text-[11.5px] text-mute leading-snug">{cpu.article} · {cpu.workMem} work memory · onboard I/O: DI {cpu.onboard.di} / DQ {cpu.onboard.dq} / AI {cpu.onboard.ai} / AQ {cpu.onboard.aq}</div>
        </label>
        {cloudAvailable && user && (
          <label className="block">
            <div className="label mb-1">Save in</div>
            <select className="input" value={dest} onChange={e => setDest(e.target.value)}>{dests.map(d => <option key={d.id} value={d.id}>{d.label}</option>)}</select>
          </label>
        )}
        <div className="flex gap-2 pt-1">
          <button className="btn flex-1 justify-center" onClick={() => st().set({ dialog: null })}>Cancel</button>
          <button className="btn btn-accent flex-1 justify-center" onClick={() => void create()}><FilePlus2 size={15} />Create project</button>
        </div>
      </div>
    </Modal>
  );
}
