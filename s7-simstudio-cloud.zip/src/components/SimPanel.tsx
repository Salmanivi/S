import { useMemo, useState } from 'react';
import { Play, Square, RotateCcw, Download, Gauge, Cpu, Plug } from 'lucide-react';
import { useStore, getResolver } from '../store';
import { runtime } from '../plc/runtime';
import { cpuById, computeAddresses, type Channel } from '../catalog/hardware';
import { parseAddress, normalizeAddress } from '../plc/values';
import { DEVICE_MAP } from '../plant/devices';

function readBit(buf: Uint8Array, addr: string) {
  const a = parseAddress(addr);
  if (!a) return false;
  return ((buf[a.byte] >> a.bit) & 1) === 1;
}
function readWord(buf: Uint8Array, addr: string) {
  const a = parseAddress(addr);
  if (!a) return 0;
  const v = (buf[a.byte] << 8) | buf[a.byte + 1];
  return v > 32767 ? v - 65536 : v;
}

export function CpuFaceplate({ compact = false }: { compact?: boolean }) {
  const project = useStore(s => s.project);
  useStore(s => s.tick);
  const cpu = cpuById(project.hardware.cpuId);
  const run = runtime.mode === 'RUN';
  const err = runtime.error;
  const is1500 = cpu.family === 'S7-1500';
  const is1200 = cpu.family === 'S7-1200';
  const Led = ({ on, color, label, blink }: { on: boolean; color: string; label: string; blink?: boolean }) => (
    <div className="flex items-center gap-1.5">
      <span className={`w-2.5 h-2.5 rounded-full ${blink && on ? 'anim-blink' : ''}`} style={{ background: on ? color : '#3a434e', boxShadow: on ? `0 0 8px ${color}` : 'none' }} />
      <span className="text-[9px] font-semibold tracking-wider text-white/70">{label}</span>
    </div>
  );
  return (
    <div className={`relative rounded-xl overflow-hidden border border-black/40 shadow-lg ${is1500 ? 'bg-gradient-to-b from-[#2a2f36] to-[#16191d]' : is1200 ? 'bg-gradient-to-b from-[#3b4148] to-[#262b31]' : 'bg-gradient-to-b from-[#454b52] to-[#2d3237]'}`}>
      <div className="absolute inset-x-0 top-0 h-1.5" style={{ background: is1200 ? '#00a19a' : is1500 ? '#009999' : '#7c8a96' }} />
      <div className="p-3 pt-4 flex gap-3">
        <div className="flex flex-col gap-1.5 pt-0.5">
          <Led on={run} color="#2ee66b" label="RUN" />
          <Led on={!run} color="#f5b324" label="STOP" />
          <Led on={err} color="#ff4d4d" label="ERROR" blink />
          <Led on={false} color="#f5b324" label="MAINT" />
        </div>
        <div className="flex-1 min-w-0">
          <div className="text-[10px] font-bold tracking-[0.2em] text-white/50">SIEMENS</div>
          <div className="text-[13px] font-semibold text-white truncate">{cpu.name} {cpu.variant}</div>
          <div className="text-[10px] font-mono text-white/50 truncate">{cpu.article} · FW {cpu.firmware}</div>
          {is1500 && !compact && (
            <div className="mt-2 rounded-md bg-[#0b1d24] border border-[#21424d] px-2 py-1.5 font-mono text-[10px] text-[#7fe3d6]">
              <div>{project.hardware.props.name} · {run ? 'RUN' : 'STOP'}</div>
              <div className="text-[#4f9c92]">{project.hardware.props.ip}</div>
            </div>
          )}
          {!is1500 && !compact && <div className="mt-1.5 text-[10px] text-white/40 font-mono">{project.hardware.props.name} · {project.hardware.props.ip}</div>}
        </div>
      </div>
    </div>
  );
}

function ChannelRow({ ch, tagName, plant }: { ch: Channel; tagName?: string; plant?: string }) {
  const [, force] = useState(0);
  const isIn = ch.kind === 'DI' || ch.kind === 'AI';
  const buf = isIn ? runtime.physIn : runtime.physOut;
  const res = getResolver(useStore.getState().project);
  const setBit = (v: boolean) => {
    const r = res.resolve(ch.address);
    if (r.k === 'mem') runtime.modify(r, 'Bool', v);
    force(x => x + 1);
  };
  if (ch.kind === 'DI' || ch.kind === 'DQ') {
    const on = readBit(buf, ch.address);
    return (
      <div className="flex items-center gap-2 py-1 max-lg:py-2 px-2 rounded-md hover:bg-panel3/60">
        <span className="w-2.5 h-2.5 rounded-full shrink-0 transition-all" style={{ background: on ? (isIn ? 'var(--c-on)' : 'var(--c-warn)') : 'var(--c-line)', boxShadow: on ? `0 0 7px ${isIn ? 'var(--c-on)' : 'var(--c-warn)'}` : 'none' }} />
        <span className="font-mono text-[11px] max-lg:text-[13px] text-ink w-14 max-lg:w-16 shrink-0">{ch.address}</span>
        <span className="text-[11px] max-lg:text-[13px] text-mute truncate flex-1" title={tagName}>{tagName ?? ''}</span>
        {plant && <span className="text-[9px] px-1 rounded bg-accent2/15 text-accent2 shrink-0" title={`Driven by plant device: ${plant}`}><Plug size={9} className="inline" /> {plant}</span>}
        {isIn && !plant && (
          <div className="flex items-center gap-1 shrink-0">
            <button className="text-[9px] max-lg:text-[12px] max-lg:font-semibold px-1.5 max-lg:px-3 py-0.5 max-lg:py-2 rounded border border-line text-mute hover:text-ink active:bg-on/20 select-none touch-none"
              onPointerDown={e => { e.currentTarget.setPointerCapture(e.pointerId); setBit(true); }} onPointerUp={() => setBit(false)} onPointerCancel={() => setBit(false)}>PUSH</button>
            <button onClick={() => setBit(!on)} role="switch" aria-checked={on} className={`relative w-8 h-[18px] max-lg:w-12 max-lg:h-7 rounded-full transition-colors ${on ? 'bg-on/80' : 'bg-line'}`} aria-label={`Toggle ${ch.address}`}>
              <span className={`absolute top-0.5 w-3.5 h-3.5 max-lg:w-6 max-lg:h-6 rounded-full bg-white shadow transition-all ${on ? 'left-4 max-lg:left-[22px]' : 'left-0.5'}`} />
            </button>
          </div>
        )}
      </div>
    );
  }
  const v = readWord(buf, ch.address);
  return (
    <div className="py-1.5 px-2 rounded-md hover:bg-panel3/60">
      <div className="flex items-center gap-2">
        <Gauge size={12} className={isIn ? 'text-accent2' : 'text-warn'} />
        <span className="font-mono text-[11px] text-ink w-14 shrink-0">{ch.address}</span>
        <span className="text-[11px] text-mute truncate flex-1">{tagName ?? ''}</span>
        {plant && <span className="text-[9px] px-1 rounded bg-accent2/15 text-accent2"><Plug size={9} className="inline" /> {plant}</span>}
        <span className="font-mono text-[11px] text-on w-12 text-right">{v}</span>
      </div>
      {isIn && !plant ? (
        <input type="range" min={0} max={27648} step={1} value={Math.max(0, v)} className="w-full accent-[var(--c-accent2)] h-1.5"
          onChange={e => { const r = res.resolve(ch.address); if (r.k === 'mem') runtime.modify(r, 'Int', parseInt(e.target.value)); force(x => x + 1); }} />
      ) : (
        <div className="h-1.5 mt-1 rounded-full bg-line overflow-hidden"><div className="h-full bg-warn/80" style={{ width: `${Math.max(0, Math.min(100, (v / 27648) * 100))}%` }} /></div>
      )}
    </div>
  );
}

export function SimPanel() {
  const project = useStore(s => s.project);
  useStore(s => s.tick);
  const version = useStore(s => s.version);
  const dl = useStore(s => s.downloadedVersion);
  const st = useStore.getState;
  const mods = useMemo(() => computeAddresses(project.hardware), [project.hardware]);
  const tagByAddr = useMemo(() => {
    const m = new Map<string, string>();
    project.tags.forEach(t => m.set(normalizeAddress(t.address), t.name));
    return m;
  }, [project.tags]);
  const plantBound = useMemo(() => {
    const m = new Map<string, string>();
    const res = getResolver(project);
    for (const d of project.devices) {
      const def = DEVICE_MAP[d.type];
      def?.binds.forEach(b => {
        if (b.dir !== 'toPlc') return;
        const s = d.bind[b.key];
        if (!s) return;
        const r = res.resolve(s);
        if (r.k === 'mem') m.set(r.a.size === 'X' ? `%${r.a.area}${r.a.byte}.${r.a.bit}` : `%${r.a.area}${r.a.size}${r.a.byte}`, d.name);
      });
    }
    return m;
  }, [project]);
  const [filter, setFilter] = useState<'all' | 'in' | 'out'>('all');
  const run = runtime.mode === 'RUN';
  const outOfSync = runtime.prog && version !== dl;

  return (
    <div className="flex flex-col h-full min-h-0">
      <div className="p-3 space-y-2.5 border-b border-line shrink-0">
        <CpuFaceplate />
        <div className="grid grid-cols-3 gap-1.5">
          <button onClick={() => st().setMode('RUN')} className={`btn justify-center ${run ? '!bg-on/20 !text-on !border-on/40' : ''}`}><Play size={14} />RUN</button>
          <button onClick={() => st().setMode('STOP')} className={`btn justify-center ${!run ? '!bg-warn/15 !text-warn !border-warn/40' : ''}`}><Square size={13} />STOP</button>
          <button onClick={() => { if (confirm('Memory reset (MRES)? The program in the simulated CPU is deleted.')) { runtime.memoryReset(); st().set({ downloadedVersion: 0 }); } }} className="btn justify-center"><RotateCcw size={13} />MRES</button>
        </div>
        <button onClick={() => st().download()} className={`btn w-full justify-center ${outOfSync || !runtime.prog ? 'btn-accent anim-ring' : ''}`}><Download size={14} />Download to device {outOfSync ? '(changes pending)' : !runtime.prog ? '(no program)' : ''}</button>
        <div className="grid grid-cols-3 gap-1.5 text-center">
          <Stat label="Cycle" value={run ? `${runtime.cycle.last.toFixed(1)} ms` : '—'} />
          <Stat label="Max" value={run ? `${runtime.cycle.max.toFixed(1)} ms` : '—'} />
          <Stat label="Scans" value={run ? runtime.scanCount.toLocaleString() : '—'} />
        </div>
        <div className="flex items-center gap-2 text-[11px] text-mute">
          <Cpu size={12} />Sim speed
          {[0.5, 1, 2, 5].map(sp => (
            <button key={sp} onClick={() => { runtime.speed = sp; st().set({ tick: st().tick + 1 }); }} className={`px-1.5 py-0.5 max-lg:px-3 max-lg:py-1.5 rounded ${runtime.speed === sp ? 'bg-accent/20 text-accent' : 'hover:text-ink'}`}>{sp}×</button>
          ))}
        </div>
      </div>
      <div className="flex items-center gap-1 px-2 pt-2">
        <span className="label px-1 flex-1">Onboard & module I/O</span>
        {(['all', 'in', 'out'] as const).map(f => (
          <button key={f} onClick={() => setFilter(f)} className={`text-[10px] max-lg:text-[12px] px-1.5 py-0.5 max-lg:px-3 max-lg:py-1.5 rounded ${filter === f ? 'bg-panel3 text-ink' : 'text-mute'}`}>{f.toUpperCase()}</button>
        ))}
      </div>
      <div className="flex-1 min-h-0 overflow-y-auto overscroll-contain p-2 space-y-2">
        {mods.filter(m => m.channels.length).map(m => {
          const chs = m.channels.filter(c => filter === 'all' || (filter === 'in' ? c.kind === 'DI' || c.kind === 'AI' : c.kind === 'DQ' || c.kind === 'AQ'));
          if (!chs.length) return null;
          return (
            <div key={String(m.slot)} className="rounded-lg border border-line bg-panel2/50">
              <div className="px-2 py-1.5 text-[11px] font-semibold text-ink border-b border-line flex justify-between"><span className="truncate">{m.name}</span><span className="text-mute font-normal">slot {m.slot}</span></div>
              <div className="p-1">{chs.map(c => <ChannelRow key={c.address} ch={c} tagName={tagByAddr.get(c.address)} plant={plantBound.get(c.address)} />)}</div>
            </div>
          );
        })}
        {mods.every(m => !m.channels.length) && <div className="text-xs text-mute p-3">This CPU has no onboard I/O. Add signal modules in Device configuration.</div>}
      </div>
    </div>
  );
}

function Stat({ label, value }: { label: string; value: string }) {
  return (
    <div className="rounded-lg bg-panel2 border border-line py-1.5">
      <div className="text-[9px] uppercase tracking-wider text-mute">{label}</div>
      <div className="text-[12px] font-mono text-ink">{value}</div>
    </div>
  );
}
