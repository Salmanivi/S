import { useRef, useState } from 'react';
import { Cpu, FileCode2, Tags, Eye, Factory, Plus, Trash2, Play, Square, Download, Hammer, Glasses, Sun, Moon, FolderOpen, Save, FilePlus2, BookOpen, HelpCircle, ChevronDown, ChevronUp, AlertCircle, AlertTriangle, CheckCircle2, Info, X, Boxes, Timer, Zap, EllipsisVertical, Cloud, FolderOpen as FolderCloud, History, LogIn, Users, User as UserIcon, ShieldCheck } from 'lucide-react';
import { useStore, newBlockOf } from '../store';
import { runtime } from '../plc/runtime';
import { cpuById } from '../catalog/hardware';
import { blockLabel } from '../plc/compiler';
import { EXAMPLES } from '../examples';
import type { Project, BlockKind } from '../types';
import { Sheet } from './Sheet';
import { cloudAllowsSwitch } from '../cloud/sync';
import { useAuth } from '../cloud/auth';
import { useContact, mailHref, telHref } from '../brand';
import { AccountMenu, SyncChip } from '../cloud/Chrome';

export function Logo() {
  return (
    <div className="flex items-center gap-2 shrink-0">
      <div className="w-8 h-8 rounded-lg bg-gradient-to-br from-accent to-accent2 flex items-center justify-center shadow-lg shadow-accent/20">
        <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="white" strokeWidth="2.2" strokeLinecap="round"><path d="M3 4v16M21 4v16M3 12h4M9 7v10M13 7v10M9 12h0M17 12h4M13 12h2" /><path d="M15 9q3 3 0 6" /></svg>
      </div>
      <div className="leading-tight hidden sm:block">
        <div className="text-[13px] font-bold tracking-tight">S7 SimStudio</div>
        <div className="text-[9.5px] text-mute -mt-0.5">LAD · PLCSIM · Plant</div>
      </div>
    </div>
  );
}

export function exportProject(p: Project) {
  const blob = new Blob([JSON.stringify(p, null, 2)], { type: 'application/json' });
  const a = document.createElement('a');
  a.href = URL.createObjectURL(blob);
  a.download = `${p.name.replace(/[^\w-]+/g, '_') || 'project'}.s7sim.json`;
  a.click();
  setTimeout(() => URL.revokeObjectURL(a.href), 1000);
  useStore.getState().markSaved();
}

/** Ask before replacing a project that has unsaved changes. */
export function confirmDiscard(): boolean {
  const s = useStore.getState();
  if (!s.projectOpen || !s.dirty) return true;
  if (cloudAllowsSwitch()) return true;
  return confirm('This project has unsaved changes. Replace it anyway?\n\nUse “Export project” first if you want to keep it.');
}

export function openProjectFile(f: File) {
  const st = useStore.getState();
  if (!confirmDiscard()) return;
  const rd = new FileReader();
  rd.onload = () => {
    try {
      const p = JSON.parse(String(rd.result)) as Project;
      if (!p.blocks || !p.hardware || !Array.isArray(p.tags)) throw new Error('bad');
      p.devices = p.devices ?? []; p.watch = p.watch ?? [];
      st.loadProject(p, `Project “${p.name}” opened`);
    } catch { st.showToast('This file is not a valid S7 SimStudio project', 'err'); }
  };
  rd.readAsText(f);
}

export function ThemeButton({ className = '' }: { className?: string }) {
  const theme = useStore(s => s.theme);
  return (
    <button className={`btn btn-ghost btn-icon ${className}`} title={theme === 'dark' ? 'Switch to light mode' : 'Switch to dark mode'} aria-label={theme === 'dark' ? 'Switch to light mode' : 'Switch to dark mode'}
      onClick={() => useStore.getState().set({ theme: theme === 'dark' ? 'light' : 'dark' })}>{theme === 'dark' ? <Sun size={16} /> : <Moon size={16} />}</button>
  );
}

/** Project name button with the New / Open / Examples / Export / Close menu. */
export function ProjectMenu() {
  const project = useStore(s => s.project);
  const dirty = useStore(s => s.dirty);
  const cloud = useStore(s => s.cloud);
  const { user, cloudAvailable, openPage } = useAuth();
  const st = useStore.getState;
  const fileRef = useRef<HTMLInputElement>(null);
  const [menu, setMenu] = useState(false);
  const close = () => setMenu(false);
  return (
    <div className="relative min-w-0">
      <button className="btn btn-ghost !px-2 max-w-full" onClick={() => setMenu(m => !m)} aria-haspopup="menu" aria-expanded={menu}>
        <span className="truncate max-w-[150px] sm:max-w-[200px] text-[13px] font-medium">{project.name}</span>
        {dirty && <span className="w-1.5 h-1.5 rounded-full bg-accent shrink-0" title="Unsaved changes" />}
        <ChevronDown size={13} className="shrink-0" />
      </button>
      {menu && (
        <>
          <div className="fixed inset-0 z-40" onClick={close} />
          <div className="absolute left-0 top-full mt-1 z-50 card p-1 w-64 shadow-2xl anim-in" role="menu">
            <MenuItem icon={<FilePlus2 size={15} />} label="New project…" onClick={() => { close(); if (confirmDiscard()) st().set({ dialog: 'new' }); }} />
            <MenuItem icon={<BookOpen size={15} />} label="Example projects…" onClick={() => { close(); st().set({ dialog: 'examples' }); }} />
            <MenuItem icon={<FolderOpen size={15} />} label="Open project file…" onClick={() => { close(); fileRef.current?.click(); }} />
            <MenuItem icon={<Save size={15} />} label="Export project (.json)" onClick={() => { close(); exportProject(project); }} />
            <MenuItem icon={<X size={15} />} label="Close project" onClick={() => { close(); if (confirmDiscard()) st().closeProject(); }} />
            {cloudAvailable && (
              <>
                <div className="h-px bg-line my-1" />
                {user ? (
                  <>
                    {!cloud && <MenuItem icon={<Cloud size={15} />} label="Save to cloud…" onClick={() => { close(); useAuth.setState({ cloudDialog: 'save' }); }} />}
                    {cloud && <MenuItem icon={<History size={15} />} label="Version history…" onClick={() => { close(); useAuth.setState({ cloudDialog: 'history' }); }} />}
                    <MenuItem icon={<FolderCloud size={15} />} label="Cloud projects…" onClick={() => { close(); openPage('projects'); }} />
                  </>
                ) : <MenuItem icon={<LogIn size={15} />} label="Sign in to save online…" onClick={() => { close(); openPage('login'); }} />}
              </>
            )}
            <div className="h-px bg-line my-1" />
            <div className="px-2 pt-1 pb-2">
              <div className="label mb-1">Project name</div>
              <input className="input" defaultValue={project.name} onBlur={e => { const v = e.target.value.trim() || 'Project'; if (v !== project.name) st().mutate(p => { p.name = v; }, false); }}
                onKeyDown={e => { if (e.key === 'Enter') (e.target as HTMLInputElement).blur(); }} />
            </div>
          </div>
        </>
      )}
      <input ref={fileRef} type="file" accept=".json,application/json" className="hidden" onChange={e => { const f = e.target.files?.[0]; if (f) openProjectFile(f); e.target.value = ''; }} />
    </div>
  );
}

function RunButtons({ compact }: { compact?: boolean }) {
  const st = useStore.getState;
  const run = runtime.mode === 'RUN';
  const pad = compact ? 'px-3' : 'px-2 sm:px-2.5';
  return (
    <div className="flex items-center rounded-lg border border-line overflow-hidden shrink-0">
      <button title="RUN" aria-label="Run" onClick={() => (compact ? st().runSmart() : st().setMode('RUN'))} className={`${pad} py-1.5 min-h-9 text-xs font-semibold flex items-center gap-1 ${run ? 'bg-on/20 text-on' : 'text-mute hover:bg-panel3'}`}><Play size={13} />{!compact && <span className="hidden sm:inline">RUN</span>}</button>
      <button title="STOP" aria-label="Stop" onClick={() => st().setMode('STOP')} className={`${pad} py-1.5 min-h-9 text-xs font-semibold flex items-center gap-1 border-l border-line ${!run ? 'bg-warn/15 text-warn' : 'text-mute hover:bg-panel3'}`}><Square size={12} />{!compact && <span className="hidden sm:inline">STOP</span>}</button>
    </div>
  );
}

/** Desktop top bar */
export function TopBar() {
  const project = useStore(s => s.project);
  const monitoring = useStore(s => s.monitoring);
  const version = useStore(s => s.version);
  const dl = useStore(s => s.downloadedVersion);
  useStore(s => Math.floor(s.tick / 5));
  const st = useStore.getState;
  const cpu = cpuById(project.hardware.cpuId);
  const pending = !runtime.prog || version !== dl;

  return (
    <header className="hidden lg:flex h-12 shrink-0 items-center gap-2 px-3 border-b border-line bg-panel z-30">
      <Logo />
      <ProjectMenu />
      <SyncChip />
      <div className="flex-1" />
      <div className="hidden xl:flex items-center gap-1 text-[11px] text-mute mr-1">
        <Cpu size={13} />{cpu.name} {cpu.variant}
      </div>
      <button className="btn" title="Compile (Ctrl+B)" onClick={() => st().compile()}><Hammer size={14} /><span>Compile</span></button>
      <button className={`btn ${pending ? 'btn-accent' : ''}`} title="Download to device (Ctrl+L)" onClick={() => st().download()}><Download size={14} /><span>Download</span></button>
      <button className={`btn ${monitoring ? 'btn-accent' : ''}`} title="Monitoring on/off" onClick={() => st().set({ monitoring: !monitoring })}><Glasses size={14} /><span className="hidden xl:inline">{monitoring ? 'Online' : 'Go online'}</span></button>
      <RunButtons />
      <ThemeButton />
      <button className="btn btn-ghost btn-icon" title="Help" aria-label="Help" onClick={() => st().set({ dialog: 'help' })}><HelpCircle size={16} /></button>
      <AccountMenu />
    </header>
  );
}

/** Phone top bar: project menu on the left, the few actions you use constantly on the right */
export function PhoneTopBar() {
  const monitoring = useStore(s => s.monitoring);
  const version = useStore(s => s.version);
  const dl = useStore(s => s.downloadedVersion);
  const theme = useStore(s => s.theme);
  const { user, cloudAvailable, openPage } = useAuth();
  useStore(s => Math.floor(s.tick / 5));
  const st = useStore.getState;
  const [more, setMore] = useState(false);
  const pending = !runtime.prog || version !== dl;
  const run = runtime.mode === 'RUN';

  return (
    <header className="lg:hidden shrink-0 flex items-center gap-0.5 pl-1.5 pr-1 pb-1 pt-[calc(0.25rem+env(safe-area-inset-top))] border-b border-line bg-panel z-30">
      <div className="w-8 h-8 shrink-0 rounded-lg bg-gradient-to-br from-accent to-accent2 flex items-center justify-center mr-0.5" aria-hidden>
        <svg width="17" height="17" viewBox="0 0 24 24" fill="none" stroke="white" strokeWidth="2.2" strokeLinecap="round"><path d="M3 4v16M21 4v16M3 12h4M9 7v10M13 7v10M9 12h0M17 12h4M13 12h2" /><path d="M15 9q3 3 0 6" /></svg>
      </div>
      <div className="flex-1 min-w-0"><ProjectMenu /></div>
      <SyncChip compact />
      <button className={`btn btn-icon ${monitoring ? 'btn-accent' : 'btn-ghost'}`} aria-label={monitoring ? 'Monitoring on' : 'Monitoring off'} aria-pressed={monitoring} onClick={() => st().set({ monitoring: !monitoring })}><Glasses size={18} /></button>
      <button className={`btn btn-icon relative ${pending ? 'btn-accent' : 'btn-ghost'}`} aria-label="Download to device" onClick={() => st().download()}>
        <Download size={18} />{pending && <span className="absolute top-1.5 right-1.5 w-2 h-2 rounded-full bg-accent2 ring-2 ring-panel" />}
      </button>
      <button className={`btn !px-3 font-semibold ${run ? '!bg-warn/15 !text-warn !border-warn/40' : '!bg-on/15 !text-on !border-on/40'}`} aria-label={run ? 'Stop' : 'Run'}
        onClick={() => (run ? st().setMode('STOP') : st().runSmart())}>{run ? <><Square size={13} />Stop</> : <><Play size={14} />Run</>}</button>
      <div className="relative">
        <button className="btn btn-ghost btn-icon" aria-label="More" aria-haspopup="menu" aria-expanded={more} onClick={() => setMore(m => !m)}><EllipsisVertical size={18} /></button>
        {more && (
          <>
            <div className="fixed inset-0 z-40" onClick={() => setMore(false)} />
            <div className="absolute right-0 top-full mt-1 z-50 card p-1 w-56 shadow-2xl anim-in" role="menu">
              <MenuItem icon={<Hammer size={15} />} label="Compile" onClick={() => { setMore(false); st().compile(); }} />
              <MenuItem icon={<Info size={15} />} label="Messages" onClick={() => { setMore(false); st().set({ sheet: 'info' }); }} />
              {cloudAvailable && (user ? (
                <>
                  <MenuItem icon={<FolderCloud size={15} />} label="Cloud projects" onClick={() => { setMore(false); openPage('projects'); }} />
                  <MenuItem icon={<Users size={15} />} label="Teams" onClick={() => { setMore(false); openPage('teams'); }} />
                  <MenuItem icon={<UserIcon size={15} />} label={`Account (${user.name})`} onClick={() => { setMore(false); openPage('account'); }} />
                  {user.role === 'admin' && <MenuItem icon={<ShieldCheck size={15} />} label="Admin console" onClick={() => { setMore(false); openPage('admin'); }} />}
                </>
              ) : <MenuItem icon={<LogIn size={15} />} label="Sign in" onClick={() => { setMore(false); openPage('login'); }} />)}
              <MenuItem icon={theme === 'dark' ? <Sun size={15} /> : <Moon size={15} />} label={theme === 'dark' ? 'Light mode' : 'Dark mode'} onClick={() => { setMore(false); st().set({ theme: theme === 'dark' ? 'light' : 'dark' }); }} />
              <MenuItem icon={<HelpCircle size={15} />} label="Quick guide" onClick={() => { setMore(false); st().set({ dialog: 'help' }); }} />
            </div>
          </>
        )}
      </div>
    </header>
  );
}

function MenuItem({ icon, label, onClick }: { icon: React.ReactNode; label: string; onClick: () => void }) {
  return <button role="menuitem" onClick={onClick} className="w-full flex items-center gap-2.5 px-2.5 py-2.5 lg:py-2 rounded-md text-[13px] hover:bg-panel3 text-left">{icon}{label}</button>;
}

const blockIcon = (k: BlockKind) => k === 'fc' ? <Boxes size={14} className="text-accent2" /> : k === 'cyclic' ? <Timer size={14} className="text-warn" /> : k === 'startup' ? <Zap size={14} className="text-on" /> : <FileCode2 size={14} className="text-accent" />;

export function ProjectTree() {
  const project = useStore(s => s.project);
  const view = useStore(s => s.view);
  const activeBlockId = useStore(s => s.activeBlockId);
  const st = useStore.getState;
  const [addMenu, setAddMenu] = useState(false);
  const cpu = cpuById(project.hardware.cpuId);

  const Row = ({ icon, label, active, onClick, right, indent = 0 }: { icon: React.ReactNode; label: string; active?: boolean; onClick: () => void; right?: React.ReactNode; indent?: number }) => (
    <div onClick={onClick} style={{ paddingLeft: 8 + indent * 14 }}
      className={`group flex items-center gap-2 pr-2 py-1.5 max-lg:py-2.5 rounded-md cursor-pointer text-[12.5px] max-lg:text-[14px] ${active ? 'bg-accent/15 text-accent' : 'text-ink/90 hover:bg-panel3'}`}>
      {icon}<span className="truncate flex-1">{label}</span>{right}
    </div>
  );

  const addBlock = (k: BlockKind) => {
    const b = newBlockOf(k, project);
    st().mutate(p => { p.blocks.push(b); });
    st().setView('block', b.id);
    setAddMenu(false);
  };

  return (
    <div className="flex flex-col h-full min-h-0">
      <div className="px-3 py-2.5 border-b border-line">
        <div className="label">Project tree</div>
      </div>
      <div className="flex-1 overflow-y-auto p-1.5 space-y-0.5">
        <div className="px-2 py-1.5 text-[12px] font-semibold text-ink flex items-center gap-2"><Cpu size={14} className="text-accent" /><span className="truncate">{project.hardware.props.name} [{cpu.name.replace('CPU ', '')}{cpu.variant ? ' ' + cpu.variant : ''}]</span></div>
        <Row indent={1} icon={<Cpu size={14} className="text-mute" />} label="Device configuration" active={view === 'device'} onClick={() => st().setView('device')} />
        <div className="relative">
          <Row indent={1} icon={<FileCode2 size={14} className="text-mute" />} label="Program blocks" onClick={() => setAddMenu(m => !m)}
            right={<Plus size={14} className="text-mute group-hover:text-accent" />} />
          {addMenu && (
            <div className="mx-2 my-1 card p-1 anim-in">
              <button className="w-full text-left text-[12px] max-lg:text-[14px] px-2 py-1.5 max-lg:py-2.5 rounded hover:bg-panel3 flex items-center gap-2" onClick={() => addBlock('fc')}><Boxes size={13} className="text-accent2" />Function (FC)</button>
              <button className="w-full text-left text-[12px] max-lg:text-[14px] px-2 py-1.5 max-lg:py-2.5 rounded hover:bg-panel3 flex items-center gap-2" onClick={() => addBlock('cyclic')}><Timer size={13} className="text-warn" />Cyclic interrupt (OB30)</button>
              <button className="w-full text-left text-[12px] max-lg:text-[14px] px-2 py-1.5 max-lg:py-2.5 rounded hover:bg-panel3 flex items-center gap-2 disabled:opacity-40" disabled={project.blocks.some(b => b.kind === 'startup')} onClick={() => addBlock('startup')}><Zap size={13} className="text-on" />Startup (OB100)</button>
            </div>
          )}
        </div>
        {[...project.blocks].sort((a, b) => (a.kind === 'fc' ? 1 : 0) - (b.kind === 'fc' ? 1 : 0) || a.number - b.number).map(b => (
          <Row key={b.id} indent={2} icon={blockIcon(b.kind)} label={blockLabel(b)} active={view === 'block' && activeBlockId === b.id}
            onClick={() => st().setView('block', b.id)}
            right={b.kind !== 'main' ? <button aria-label={`Delete ${b.name}`} className="opacity-0 group-hover:opacity-100 [@media(hover:none)]:opacity-100 text-mute hover:text-danger max-lg:p-2" onClick={e => { e.stopPropagation(); if (confirm(`Delete block ${b.name}?`)) { st().mutate(p => { p.blocks = p.blocks.filter(x => x.id !== b.id); }); if (activeBlockId === b.id) st().setView('block', project.blocks.find(x => x.kind === 'main')?.id); } }}><Trash2 size={12} /></button> : undefined} />
        ))}
        <Row indent={1} icon={<Tags size={14} className="text-mute" />} label="PLC tags" active={view === 'tags'} onClick={() => st().setView('tags')} right={<span className="text-[10px] text-mute">{project.tags.length}</span>} />
        <Row indent={1} icon={<Eye size={14} className="text-mute" />} label="Watch table_1" active={view === 'watch'} onClick={() => st().setView('watch')} right={<span className="text-[10px] text-mute">{project.watch.length}</span>} />
        <div className="h-2" />
        <div className="px-2 py-1.5 text-[12px] font-semibold text-ink flex items-center gap-2"><Factory size={14} className="text-accent2" />Simulation</div>
        <Row indent={1} icon={<Factory size={14} className="text-mute" />} label="Plant / HMI view" active={view === 'plant'} onClick={() => st().setView('plant')} right={<span className="text-[10px] text-mute">{project.devices.length}</span>} />
      </div>
      <div className="p-2 border-t border-line flex items-center gap-1">
        <button className="btn btn-ghost !text-[11px] flex-1 justify-center" onClick={() => st().set({ dialog: 'examples' })}><BookOpen size={13} />Examples</button>
        <button className="btn btn-ghost !text-[11px] flex-1 justify-center lg:hidden" onClick={() => exportProject(project)}><Save size={13} />Export</button>
      </div>
    </div>
  );
}

/** Compile messages / diagnostics list (used by the desktop panel and the phone sheet). */
export function InfoList({ tab, onPick }: { tab: 'compile' | 'diag'; onPick?: () => void }) {
  const msgs = useStore(s => s.msgs);
  const project = useStore(s => s.project);
  useStore(s => Math.floor(s.tick / 10));
  const st = useStore.getState;
  const errs = msgs.filter(m => m.level === 'error').length;

  const goto = (m: (typeof msgs)[number]) => {
    if (m.blockId && project.blocks.some(b => b.id === m.blockId)) {
      st().set({ view: 'block', activeBlockId: m.blockId, sel: { netId: m.networkId ?? null, elemId: m.elemId ?? null }, mobileTab: 'main' });
      onPick?.();
    } else if (m.text.startsWith('Tag table')) { st().setView('tags'); onPick?.(); }
    else if (m.text.startsWith('Device configuration')) { st().setView('device'); onPick?.(); }
  };

  if (tab === 'compile') {
    return msgs.length ? (
      <>{msgs.map((m, i) => {
        const clickable = !!m.blockId || m.text.startsWith('Tag') || m.text.startsWith('Device configuration');
        return (
          <div key={i} onClick={() => goto(m)} className={`flex items-start gap-2 px-3 py-1.5 max-lg:py-2.5 border-b border-line/60 ${clickable ? 'cursor-pointer hover:bg-panel2' : ''}`}>
            {m.level === 'error' ? <AlertCircle size={13} className="text-danger mt-0.5 shrink-0" /> : m.level === 'warning' ? <AlertTriangle size={13} className="text-warn mt-0.5 shrink-0" /> : <CheckCircle2 size={13} className={`${errs ? 'text-danger' : 'text-on'} mt-0.5 shrink-0`} />}
            <span className={m.level === 'info' ? 'font-semibold' : ''}>{m.text}</span>
          </div>
        );
      })}</>
    ) : <div className="p-4 text-mute">Compile the project (Ctrl+B) to see messages.</div>;
  }
  return runtime.diag.length ? (
    <>{runtime.diag.map((d, i) => (
      <div key={i} className="flex items-start gap-3 px-3 py-1.5 max-lg:py-2 border-b border-line/60">
        <span className="font-mono text-mute shrink-0">{d.time}</span>
        {d.level === 'error' ? <AlertCircle size={13} className="text-danger mt-0.5 shrink-0" /> : d.level === 'warn' ? <AlertTriangle size={13} className="text-warn mt-0.5 shrink-0" /> : <Info size={13} className="text-accent2 mt-0.5 shrink-0" />}
        <span>{d.text}</span>
      </div>
    ))}</>
  ) : <div className="p-4 text-mute">Diagnostics buffer is empty.</div>;
}

/** Number of compile errors / warnings (for badges) */
export function useMsgCounts() {
  const msgs = useStore(s => s.msgs);
  const real = msgs.filter(m => !m.text.startsWith('Compiling finished'));   // the summary line is not an error of its own
  return { errs: real.filter(m => m.level === 'error').length, warns: real.filter(m => m.level === 'warning').length };
}

export function InfoPanel() {
  const open = useStore(s => s.infoOpen);
  const tab = useStore(s => s.infoTab);
  const msgs = useStore(s => s.msgs);
  useStore(s => Math.floor(s.tick / 10));
  const st = useStore.getState;
  const { errs, warns } = useMsgCounts();

  return (
    <div className={`shrink-0 border-t border-line bg-panel flex flex-col ${open ? 'h-56' : ''}`}>
      <div className="flex items-center gap-1 px-2 h-8 shrink-0 cursor-pointer select-none" onClick={() => st().set({ infoOpen: !open })}>
        <span className="label mr-2">Inspector</span>
        <button className={`tab !py-1.5 ${tab === 'compile' && open ? 'tab-active' : ''}`} onClick={e => { e.stopPropagation(); st().set({ infoTab: 'compile', infoOpen: true }); }}>Compile</button>
        <button className={`tab !py-1.5 ${tab === 'diag' && open ? 'tab-active' : ''}`} onClick={e => { e.stopPropagation(); st().set({ infoTab: 'diag', infoOpen: true }); }}>Diagnostics</button>
        <div className="flex-1" />
        {msgs.length > 0 && <span className="flex items-center gap-2 text-[11px] mr-2"><span className="flex items-center gap-1 text-danger"><AlertCircle size={12} />{errs}</span><span className="flex items-center gap-1 text-warn"><AlertTriangle size={12} />{warns}</span></span>}
        <span className={`text-[10.5px] px-1.5 py-0.5 rounded font-semibold mr-1 ${runtime.mode === 'RUN' ? 'bg-on/15 text-on' : 'bg-warn/15 text-warn'}`}>{runtime.mode}</span>
        {open ? <ChevronDown size={15} className="text-mute" /> : <ChevronUp size={15} className="text-mute" />}
      </div>
      {open && <div className="flex-1 overflow-y-auto border-t border-line text-xs"><InfoList tab={tab} /></div>}
    </div>
  );
}

/** Phone: compile messages + diagnostics in a bottom sheet */
export function InfoSheet() {
  const tab = useStore(s => s.infoTab);
  const st = useStore.getState;
  const { errs, warns } = useMsgCounts();
  const close = () => st().set({ sheet: null });
  return (
    <Sheet title="Messages" onClose={close} tall
      headerExtra={<span className="flex items-center gap-2.5 text-[12px] mr-1"><span className="flex items-center gap-1 text-danger"><AlertCircle size={13} />{errs}</span><span className="flex items-center gap-1 text-warn"><AlertTriangle size={13} />{warns}</span></span>}>
      <div className="h-full flex flex-col">
        <div className="shrink-0 flex border-b border-line">
          <button className={`tab flex-1 ${tab === 'compile' ? 'tab-active' : ''}`} onClick={() => st().set({ infoTab: 'compile' })}>Compile</button>
          <button className={`tab flex-1 ${tab === 'diag' ? 'tab-active' : ''}`} onClick={() => st().set({ infoTab: 'diag' })}>Diagnostics</button>
        </div>
        <div className="flex-1 overflow-y-auto text-[13px]"><InfoList tab={tab} onPick={close} /></div>
        <div className="shrink-0 p-2 border-t border-line"><button className="btn w-full justify-center" onClick={() => st().compile()}><Hammer size={14} />Compile again</button></div>
      </div>
    </Sheet>
  );
}

export function Toast() {
  const t = useStore(s => s.toast);
  if (!t) return null;
  return (
    <div key={t.id} className="fixed top-[calc(3.6rem+env(safe-area-inset-top))] lg:top-auto lg:bottom-6 left-1/2 -translate-x-1/2 z-[70] anim-in max-w-[92vw] pointer-events-none">
      <div className={`flex items-center gap-2 px-4 py-2.5 rounded-xl shadow-2xl border text-[13px] backdrop-blur bg-panel/95 ${t.kind === 'ok' ? 'border-on/40 text-on' : t.kind === 'err' ? 'border-danger/50 text-danger' : 'border-line text-ink'}`}>
        {t.kind === 'ok' ? <CheckCircle2 size={16} /> : t.kind === 'err' ? <AlertCircle size={16} /> : <Info size={16} />}{t.text}
      </div>
    </div>
  );
}

export { Modal } from './Modal';
import { Modal } from './Modal';

export function ExamplesDialog() {
  const st = useStore.getState;
  return (
    <Modal title="Example projects" onClose={() => st().set({ dialog: null })}>
      <div className="p-3 grid sm:grid-cols-2 gap-2">
        {EXAMPLES.map(ex => (
          <button key={ex.id} onClick={() => { if (confirmDiscard()) st().loadProject(ex.make(), `Example “${ex.title}” opened — press Run to start`); }}
            className="text-left rounded-xl border border-line bg-panel2 hover:border-accent/60 hover:bg-panel3 p-3 transition-colors">
            <div className="text-sm font-semibold text-ink">{ex.title}</div>
            <div className="text-[11.5px] text-mute mt-1 leading-snug">{ex.desc}</div>
          </button>
        ))}
        <button onClick={() => { if (confirmDiscard()) st().set({ dialog: 'new' }); }} className="text-left rounded-xl border border-dashed border-line hover:border-accent/60 p-3">
          <div className="text-sm font-semibold text-ink">Empty project</div>
          <div className="text-[11.5px] text-mute mt-1">Choose a name and a CPU, start with a blank Main [OB1]</div>
        </button>
      </div>
    </Modal>
  );
}

export function HelpDialog() {
  const st = useStore.getState;
  const contact = useContact();
  const K = ({ k }: { k: string }) => <kbd className="px-1.5 py-0.5 rounded border border-line bg-panel2 font-mono text-[10.5px]">{k}</kbd>;
  return (
    <Modal title="Quick guide" wide onClose={() => st().set({ dialog: null })}>
      <div className="p-5 grid md:grid-cols-2 gap-6 text-[12.5px] leading-relaxed">
        <div className="space-y-3">
          <h3 className="font-semibold text-accent">Workflow (same as TIA Portal)</h3>
          <ol className="list-decimal pl-5 space-y-1 text-ink/90">
            <li><b>Device configuration</b>: choose your CPU (S7-300/400/1200/1500) and insert signal modules. Addresses are assigned automatically; tap a module’s <b>I/O addresses</b> to set its own start address.</li>
            <li><b>PLC tags</b>: declare symbols (e.g. <code>Start_PB</code> at <code>%I0.0</code>). Typing an absolute address in LAD auto-creates <code>Tag_n</code>.</li>
            <li><b>Program blocks</b>: build networks in Main [OB1]. Click an instruction to insert it after the selection, or use “Place with ⊕” / drag & drop. On a phone, tap <b>＋ Instruction</b>.</li>
            <li>Click any <span className="text-danger font-mono">&lt;??.?&gt;</span> operand to type a tag, address, constant (<code>T#5s</code>, <code>16#FF</code>, <code>2.5</code>) or instance member (<code>T1.Q</code>). Compare, math and move instructions detect their <b>data type automatically</b> from the operands (e.g. <code>T#5s</code> → Time); choose a type by hand in Properties to override.</li>
            <li><b>Compile</b> → <b>Download</b> → <b>RUN</b>. Turn on monitoring (glasses) to see power flow: green = energized, blue dashed = not energized.</li>
            <li>Drive inputs from PLCSIM I/O switches, watch table, or the <b>Plant view</b> with real machine devices.</li>
          </ol>
          <h3 className="font-semibold text-accent pt-2">Behaviour details</h3>
          <ul className="list-disc pl-5 space-y-1 text-ink/90">
            <li>Process image: inputs are read at cycle start, outputs written at cycle end. In STOP all outputs are 0.</li>
            <li>STOP→RUN performs a warm restart: non-retentive bit memory, timers and counters are reset; OB100 runs once; FirstScan is TRUE in the first cycle.</li>
            <li>IEC timers (TP/TON/TOF/TONR) and counters (CTU/CTD/CTUD) use instance DBs with members <code>.Q .ET .CV .QU .QD</code>.</li>
            <li>Data types are checked like TIA (Int, DInt, Real, Word, Time …). Overflow and division by zero set ENO = 0.</li>
            <li>Analog values use the Siemens range 0…27648 — use NORM_X + SCALE_X.</li>
          </ul>
        </div>
        <div className="space-y-3">
          <h3 className="font-semibold text-accent">Keyboard shortcuts</h3>
          <div className="grid grid-cols-[auto_1fr] gap-x-3 gap-y-1.5 items-center">
            <K k="Ctrl+B" /><span>Compile</span>
            <K k="Ctrl+L" /><span>Download to device</span>
            <K k="Ctrl+S" /><span>Export project file</span>
            <K k="Ctrl+Z / Ctrl+Y" /><span>Undo / Redo</span>
            <K k="Ctrl+C / Ctrl+V" /><span>Copy / paste element or network</span>
            <K k="Del" /><span>Delete selected element</span>
            <K k="Esc" /><span>Cancel placement</span>
            <K k="F2" /><span>Show properties</span>
            <K k="Double-click" /><span>Element properties</span>
          </div>
          <h3 className="font-semibold text-accent pt-2">Addressing</h3>
          <div className="font-mono text-[11.5px] space-y-1 text-ink/90">
            <div>%I0.0  %Q0.0  %M10.3 <span className="text-mute">— Bool</span></div>
            <div>%IB0  %MB5 <span className="text-mute">— Byte</span></div>
            <div>%IW64  %QW96  %MW20 <span className="text-mute">— Word / Int</span></div>
            <div>%MD30 <span className="text-mute">— DWord / DInt / Real / Time</span></div>
            <div>T#1m30s  T#500ms <span className="text-mute">— Time constants</span></div>
            <div>16#00FF  2#1010  -15  3.14 <span className="text-mute">— literals</span></div>
          </div>
          <h3 className="font-semibold text-accent pt-2">Plant simulation</h3>
          <p className="text-ink/90">Switch to <b>Edit</b> mode to add and arrange devices, bind each signal to a tag (or press <b>Auto-wire</b>), then go back to <b>Operate</b> and press buttons, trip overloads, add parts on conveyors. Simulation speed can be raised to 5× in PLCSIM.</p>
          <p className="text-mute text-[11px]">Projects are stored online only when you <b>save them to your account</b> (they are then saved automatically and sync across your devices). Without an account, use <b>Export project</b> to keep a file and <b>Open project file</b> to load it again. Not affiliated with Siemens AG; SIMATIC, S7 and TIA Portal are trademarks of Siemens AG.</p>
          <div className="pt-2 border-t border-line text-[12px] flex flex-wrap items-center gap-x-3 gap-y-1">
            <span className="text-mute">Created by <b className="text-ink/80">{contact.name}</b></span>
            <a className="text-accent hover:underline" href={mailHref(contact.email)}>{contact.email}</a>
            <a className="text-accent hover:underline" href={telHref(contact.phone)}>{contact.phone}</a>
            <button className="text-accent hover:underline" onClick={() => { st().set({ dialog: null }); useAuth.getState().openPage('about'); }}>About &amp; contact</button>
          </div>
        </div>
      </div>
    </Modal>
  );
}
