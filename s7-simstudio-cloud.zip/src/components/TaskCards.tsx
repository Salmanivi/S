import { useMemo, useState } from 'react';
import { Search, ChevronDown, ChevronRight, Star, MousePointerClick, Crosshair, Trash2, GitBranch, ArrowLeft, ArrowRight, Info, Wand2 } from 'lucide-react';
import { CATEGORIES, FAVORITES, INSTRUCTIONS, INSTR_MAP } from '../catalog/instructions';
import { useStore } from '../store';
import { InstrIcon } from './ladder/InstrIcon';
import { getInstr } from '../plc/ladder';
import type { DataType, LadderInstr } from '../types';
import { commitOperand, pinTypeFor } from './ladder/LadderNetwork';
import { monitorValue } from './ladder/monitor';
import { formatValue } from '../plc/values';
import { getResolver } from '../store';
import { nextFreeAddress } from '../plc/tags';
import { runtime } from '../plc/runtime';
import { isAutoTypable } from '../plc/autotype';

function Item({ op, armed, use }: { op: string; armed: string | null; use: (op: string) => void }) {
  const st = useStore.getState;
    const d = INSTR_MAP[op];
    return (
      <div draggable
        onDragStart={e => { e.dataTransfer.setData('text/plain', op); e.dataTransfer.effectAllowed = 'copy'; st().arm(op); }}
        onDragEnd={() => setTimeout(() => st().arm(null), 50)}
        onClick={() => use(op)} title={d.desc}
        className={`flex items-center gap-2.5 px-2.5 py-1.5 max-lg:py-2.5 rounded-md cursor-pointer text-[12.5px] max-lg:text-[14px] transition-colors ${armed === op ? 'bg-accent/20 text-accent' : 'hover:bg-panel3 text-ink'}`}>
        <span className={armed === op ? 'text-accent' : 'text-mute'}><InstrIcon op={op} size={30} /></span>
        <span className="truncate flex-1">{d.label}</span>
        <span className="text-[10px] font-mono text-mute">{d.title || d.symbol || ''}</span>
      </div>
    );
  }

export function InstructionPalette({ inSheet = false }: { inSheet?: boolean }) {
  const [q, setQ] = useState('');
  const [open, setOpen] = useState<Record<string, boolean>>({ 'Bit logic operations': true, 'Timer operations': true });
  const [mode, setMode] = useState<'sel' | 'place'>('sel');
  const armed = useStore(s => s.armed);
  const view = useStore(s => s.view);
  const st = useStore.getState;

  const filtered = useMemo(() => {
    const t = q.trim().toLowerCase();
    if (!t) return null;
    return INSTRUCTIONS.filter(d => `${d.op} ${d.label} ${d.title} ${d.keywords ?? ''} ${d.category}`.toLowerCase().includes(t));
  }, [q]);

  const use = (op: string) => {
    if (view !== 'block') st().setView('block', st().activeBlockId);
    if (mode === 'place') st().arm(armed === op ? null : op);
    else { st().insertInstr(op); st().set({ mobileTab: 'main' }); }
    // on a phone the sheet gets out of the way as soon as something was chosen
    if (inSheet) st().set({ sheet: null });
  };

  return (
    <div className="flex flex-col h-full min-h-0">
      <div className="p-2.5 space-y-2 border-b border-line shrink-0">
        <div className="relative">
          <Search size={14} className="absolute left-2.5 top-1/2 -translate-y-1/2 text-mute" />
          <input value={q} onChange={e => setQ(e.target.value)} placeholder="Search instructions (TON, ADD, edge…)" className="input !pl-8" type="search" enterKeyHint="search" />
        </div>
        <div className="grid grid-cols-2 gap-1 p-0.5 rounded-lg bg-bg border border-line text-[11px]">
          <button onClick={() => { setMode('sel'); st().arm(null); }} className={`flex items-center justify-center gap-1 py-1 max-lg:py-2 rounded-md ${mode === 'sel' ? 'bg-panel3 text-ink' : 'text-mute'}`}><MousePointerClick size={12} />At selection</button>
          <button onClick={() => setMode('place')} className={`flex items-center justify-center gap-1 py-1 max-lg:py-2 rounded-md ${mode === 'place' ? 'bg-panel3 text-accent' : 'text-mute'}`}><Crosshair size={12} />Place with ⊕</button>
        </div>
        {armed && <div className="text-[11px] text-accent flex items-center justify-between">Tap a ⊕ marker in the network to place <b>{INSTR_MAP[armed]?.title || INSTR_MAP[armed]?.label}</b><button className="underline" onClick={() => st().arm(null)}>cancel</button></div>}
      </div>
      <div className="flex-1 min-h-0 overflow-y-auto overscroll-contain p-1.5">
        {filtered ? (
          filtered.length ? filtered.map(d => <Item key={d.op} op={d.op} armed={armed} use={use} />) : <div className="text-xs text-mute p-3">No instruction found.</div>
        ) : (
          <>
            <div className="px-2 pt-1 pb-1.5 label flex items-center gap-1"><Star size={11} />Favorites</div>
            <div className="flex flex-wrap gap-1 px-1.5 pb-2">
              {FAVORITES.map(op => (
                <button key={op} title={INSTR_MAP[op].label} onClick={() => use(op)} draggable
                  onDragStart={e => { e.dataTransfer.setData('text/plain', op); st().arm(op); }} onDragEnd={() => setTimeout(() => st().arm(null), 50)}
                  className={`rounded-md border border-line px-1 py-1 max-lg:px-1.5 max-lg:py-1.5 ${armed === op ? 'bg-accent/20 text-accent border-accent/50' : 'bg-panel2 text-ink hover:bg-panel3'}`}>
                  <InstrIcon op={op} size={34} />
                </button>
              ))}
              <button title="Open branch around selected element" onClick={() => st().branchSelected()} className="rounded-md border border-line px-2 py-1 bg-panel2 hover:bg-panel3 text-ink"><GitBranch size={18} /></button>
            </div>
            {CATEGORIES.map(cat => (
              <div key={cat} className="mb-0.5">
                <button onClick={() => setOpen(o => ({ ...o, [cat]: !o[cat] }))} className="w-full flex items-center gap-1.5 px-2 py-1.5 max-lg:py-2.5 text-[12px] max-lg:text-[13.5px] font-semibold text-ink/90 hover:bg-panel3 rounded-md">
                  {open[cat] ? <ChevronDown size={14} /> : <ChevronRight size={14} />}{cat}
                  <span className="ml-auto text-[10px] text-mute font-normal">{INSTRUCTIONS.filter(d => d.category === cat).length}</span>
                </button>
                {open[cat] && <div className="pl-2">{INSTRUCTIONS.filter(d => d.category === cat).map(d => <Item key={d.op} op={d.op} armed={armed} use={use} />)}</div>}
              </div>
            ))}
          </>
        )}
      </div>
    </div>
  );
}

// ------------------------------------------------------------------ Properties
function OperandField({ field, value, label, hint, list = 'dl-tags', instr, online }: { field: string; value: string; label: string; hint?: DataType; list?: string; instr: LadderInstr; online: boolean }) {
  const project = useStore(s => s.project);
  const mutate = useStore(s => s.mutate);
  const st = useStore.getState;
  const res = getResolver(project);
    const r = value.trim() ? res.resolve(value) : null;
    const err = r && r.k === 'err' ? r.msg : null;
    const undefinedTag = err && err.includes('not defined');
    const mv = online ? monitorValue(project, value, hint) : null;
    return (
      <Field label={label} extra={hint ? <span className="font-mono text-[10px] text-accent">{hint}</span> : undefined}>
        <div className="flex gap-1">
          <input key={`${instr.id}-${field}-${value}`} className={`input font-mono ${err ? '!border-danger/70' : ''}`} defaultValue={value} list={list}
            placeholder={hint === 'Bool' ? '<??.?>' : '<???>'}
            onBlur={e => { if (e.target.value !== value) commitOperand(instr.id, field, e.target.value); }}
            onKeyDown={e => { if (e.key === 'Enter') (e.target as HTMLInputElement).blur(); }} />
          {mv && <span className="shrink-0 self-center text-[11px] font-mono text-on px-1">{formatValue(mv.v, mv.dt)}</span>}
        </div>
        {err && (
          <div className="mt-1 text-[11px] text-danger flex items-start gap-1">
            <span className="flex-1">{err}</span>
            {undefinedTag && (
              <button className="btn !py-0.5 !px-1.5 !text-[10px] btn-accent" onClick={() => {
                const name = value.trim().replace(/"/g, '');
                const dt: DataType = hint ?? 'Int';
                mutate(p => { p.tags.push({ id: `t${Date.now().toString(36)}`, name, dataType: dt, address: nextFreeAddress(p.tags, dt), comment: 'auto-defined' }); }, true);
                st().showToast(`Tag "${name}" defined`, 'ok');
              }}><Wand2 size={11} />Define tag</button>
            )}
          </div>
        )}
      </Field>
    );
  }

export function PropertiesPanel() {
  const project = useStore(s => s.project);
  const sel = useStore(s => s.sel);
  const blockId = useStore(s => s.activeBlockId);
  const monitoring = useStore(s => s.monitoring);
  useStore(s => (s.monitoring ? s.tick : 0));
  const mutate = useStore(s => s.mutate);
  const st = useStore.getState;
  const block = project.blocks.find(b => b.id === blockId);
  const net = block?.networks.find(n => n.id === sel.netId);
  const instr = net && sel.elemId ? getInstr(net.root, sel.elemId) : null;

  if (!block) return <div className="p-4 text-sm text-mute">No block open.</div>;

  const setInstr = (fn: (i: LadderInstr) => void) => mutate(p => {
    const b = p.blocks.find(x => x.id === blockId);
    const n = b?.networks.find(x => x.id === sel.netId);
    const i = n && sel.elemId ? getInstr(n.root, sel.elemId) : null;
    if (i) fn(i);
  });

  if (!instr) {
    return (
      <div className="p-3 space-y-3 text-sm overflow-y-auto h-full">
        <div className="label">Block properties</div>
        <Field label="Name"><input className="input" value={block.name} onChange={e => mutate(p => { const b = p.blocks.find(x => x.id === blockId); if (b) b.name = e.target.value; })} /></Field>
        <Field label="Type / number"><div className="input !bg-panel2 text-mute">{block.kind === 'fc' ? 'FC' : 'OB'} {block.number} — {block.kind === 'main' ? 'Program cycle' : block.kind === 'startup' ? 'Startup' : block.kind === 'cyclic' ? 'Cyclic interrupt' : 'Function'}</div></Field>
        {block.kind === 'cyclic' && (
          <Field label="Cycle time (ms)"><input type="number" min={1} max={60000} className="input" value={block.cycleMs ?? 100} onChange={e => mutate(p => { const b = p.blocks.find(x => x.id === blockId); if (b) b.cycleMs = Math.max(1, parseInt(e.target.value) || 100); })} /></Field>
        )}
        <Field label="Comment"><textarea className="input" rows={3} value={block.comment} onChange={e => mutate(p => { const b = p.blocks.find(x => x.id === blockId); if (b) b.comment = e.target.value; }, false)} /></Field>
        <div className="rounded-lg border border-line bg-panel2 p-3 text-xs text-mute leading-relaxed flex gap-2">
          <Info size={15} className="shrink-0 text-accent2 mt-0.5" />
          <div>Select an instruction in a network to edit its operands, data type and parameters. Double-click an element to jump here.</div>
        </div>
      </div>
    );
  }

  const d = INSTR_MAP[instr.op];
  const online = monitoring && runtime.mode === 'RUN';
  return (
    <div className="p-3 space-y-3 text-sm overflow-y-auto h-full">
      <div className="flex items-start gap-3">
        <div className="rounded-lg bg-panel2 border border-line p-2 text-accent"><InstrIcon op={instr.op} size={40} /></div>
        <div className="min-w-0">
          <div className="font-semibold text-ink">{d.label}</div>
          <div className="text-[11px] text-mute leading-snug">{d.desc}</div>
        </div>
      </div>
      <div className="flex flex-wrap gap-1">
        <button className="btn !text-[11px]" onClick={() => st().moveSelected(-1)}><ArrowLeft size={12} />Left</button>
        <button className="btn !text-[11px]" onClick={() => st().moveSelected(1)}><ArrowRight size={12} />Right</button>
        <button className="btn !text-[11px]" onClick={() => st().branchSelected()}><GitBranch size={12} />Branch</button>
        <button className="btn !text-[11px] hover:!text-danger" onClick={() => st().deleteSelected()}><Trash2 size={12} />Delete</button>
      </div>

      {(d.operand || instr.op === 'RT') && (
        <OperandField instr={instr} online={online} field="operand" value={instr.operand} label={instr.op === 'RT' ? 'Timer instance' : 'Operand'} hint={instr.op === 'RT' ? undefined : 'Bool'} list={instr.op === 'RT' ? 'dl-instances' : 'dl-tags'} />
      )}
      {d.instance && (
        <Field label="Instance data block (single instance)">
          <input key={`${instr.id}-inst-${instr.instance}`} className="input font-mono" defaultValue={instr.instance ?? ''}
            onBlur={e => { const v = e.target.value.trim(); if (v && v !== instr.instance) setInstr(i => { i.instance = v; }); }}
            onKeyDown={e => { if (e.key === 'Enter') (e.target as HTMLInputElement).blur(); }} />
          <div className="text-[10.5px] text-mute mt-1">Members: {d.instance === 'timer' ? '.Q  .ET  .PT  .IN' : '.CV  .QU  .QD  .PV'}</div>
        </Field>
      )}
      {d.types && (
        <div>
          <div className="grid grid-cols-2 gap-2">
            <Field label={d.types2 ? 'Source type' : 'Data type'} extra={instr.autoType ? <span className="font-mono text-[10px] text-accent">auto</span> : undefined}>
              <select className="input" value={instr.autoType ? 'auto' : (instr.dataType ?? d.defType)} onChange={e => setInstr(i => {
                if (e.target.value === 'auto') i.autoType = true;
                else { i.autoType = false; i.dataType = e.target.value as DataType; }
              })}>
                {isAutoTypable(d) && <option value="auto">Auto · {instr.dataType ?? d.defType}</option>}
                {d.types.map(t => <option key={t} value={t}>{t}</option>)}
              </select>
            </Field>
            {d.types2 && (
              <Field label="Destination type" extra={instr.autoType ? <span className="font-mono text-[10px] text-accent">auto</span> : undefined}>
                <select className="input" value={instr.autoType ? 'auto' : (instr.dataType2 ?? d.defType2)} onChange={e => setInstr(i => {
                  if (e.target.value === 'auto') i.autoType = true;
                  else { i.autoType = false; i.dataType2 = e.target.value as DataType; }
                })}>
                  <option value="auto">Auto · {instr.dataType2 ?? d.defType2}</option>
                  {d.types2.map(t => <option key={t} value={t}>{t}</option>)}
                </select>
              </Field>
            )}
          </div>
          {instr.autoType && <div className="text-[10.5px] text-mute mt-1 leading-snug">Detected from the operands — a Time tag or <span className="font-mono">T#5s</span> gives Time, <span className="font-mono">3.5</span> gives Real. Pick a type to set it by hand.</div>}
        </div>
      )}
      {d.pins.map(pd => pd.kind === 'block' ? (
        <Field key={pd.name} label="Called block (FC)">
          <select className="input" value={instr.params.BLOCK ?? ''} onChange={e => setInstr(i => { i.params.BLOCK = e.target.value; })}>
            <option value="">— select FC —</option>
            {project.blocks.filter(b => b.kind === 'fc' && b.id !== blockId).map(b => <option key={b.id} value={b.name}>{b.name} [FC{b.number}]</option>)}
          </select>
        </Field>
      ) : (
        <OperandField instr={instr} online={online} key={pd.name} field={pd.name} value={instr.params[pd.name] ?? ''} label={`${pd.name} ${pd.dir === 'out' ? '(output)' : ''}${pd.optional ? ' · optional' : ''}`} hint={pinTypeFor(instr, pd.name) ?? (pd.kind === 'int' ? 'Int' : undefined)} />
      ))}
      {online && d.instance === 'timer' && instr.instance && runtime.timers.get(instr.instance) && (
        <div className="rounded-lg border border-line p-2 text-[11px] font-mono grid grid-cols-2 gap-1">
          {(['IN', 'Q', 'PT', 'ET'] as const).map(k => { const t = runtime.timers.get(instr.instance!)!; const v = t[k]; return <div key={k}><span className="text-mute">{k}:</span> <span className="text-on">{typeof v === 'boolean' ? (v ? 'TRUE' : 'FALSE') : formatValue(v, 'Time')}</span></div>; })}
        </div>
      )}
      {online && d.instance === 'counter' && instr.instance && runtime.counters.get(instr.instance) && (
        <div className="rounded-lg border border-line p-2 text-[11px] font-mono grid grid-cols-2 gap-1">
          {(['CV', 'PV', 'QU', 'QD'] as const).map(k => { const c = runtime.counters.get(instr.instance!)!; const v = c[k]; return <div key={k}><span className="text-mute">{k}:</span> <span className="text-on">{typeof v === 'boolean' ? (v ? 'TRUE' : 'FALSE') : v}</span></div>; })}
        </div>
      )}
    </div>
  );
}

export function Field({ label, children, extra }: { label: string; children: React.ReactNode; extra?: React.ReactNode }) {
  return (
    <label className="block">
      <div className="flex items-center justify-between mb-1"><span className="label">{label}</span>{extra}</div>
      {children}
    </label>
  );
}
