import { useEffect } from 'react';
import { Plus, GitBranch, GitMerge, ArrowLeft, ArrowRight, ArrowUp, ArrowDown, Copy, ClipboardPaste, Trash2, Undo2, Redo2, ZoomIn, ZoomOut, Glasses, AlertTriangle, Download, SlidersHorizontal } from 'lucide-react';
import { useStore } from '../../store';
import { LadderNetwork } from './LadderNetwork';
import { collectInstances } from '../../plc/ladder';
import { blockLabel } from '../../plc/compiler';
import { runtime } from '../../plc/runtime';
import { INSTR_MAP } from '../../catalog/instructions';
import { exportProject, useMsgCounts } from '../Shell';

export function TagDatalists() {
  const project = useStore(s => s.project);
  const inst = collectInstances(project.blocks);
  const members: string[] = [];
  inst.forEach((kind, name) => {
    (kind === 'timer' ? ['Q', 'ET'] : ['CV', 'QU', 'QD']).forEach(m => members.push(`${name}.${m}`));
  });
  return (
    <>
      <datalist id="dl-tags">
        {project.tags.map(t => <option key={t.id} value={t.name}>{`${t.address} · ${t.dataType}`}</option>)}
        {members.map(m => <option key={m} value={m} />)}
      </datalist>
      <datalist id="dl-instances">{Array.from(inst.keys()).map(n => <option key={n} value={n} />)}</datalist>
      <datalist id="dl-blocks">{project.blocks.filter(b => b.kind === 'fc').map(b => <option key={b.id} value={b.name} />)}</datalist>
    </>
  );
}

export function useEditorShortcuts() {
  useEffect(() => {
    const h = (e: KeyboardEvent) => {
      const s = useStore.getState();
      const tgt = e.target as HTMLElement;
      const typing = tgt && (tgt.tagName === 'INPUT' || tgt.tagName === 'TEXTAREA' || tgt.tagName === 'SELECT' || tgt.isContentEditable);
      const mod = e.ctrlKey || e.metaKey;
      if (e.key === 'Escape' && s.dialog) { s.set({ dialog: null }); return; }
      if (!s.projectOpen) return;
      if (mod && e.key.toLowerCase() === 'z' && !typing) { e.preventDefault(); if (e.shiftKey) s.redo(); else s.undo(); return; }
      if (mod && e.key.toLowerCase() === 'y' && !typing) { e.preventDefault(); s.redo(); return; }
      if (mod && e.key.toLowerCase() === 'b') { e.preventDefault(); s.compile(); return; }
      if (mod && e.key.toLowerCase() === 'l') { e.preventDefault(); s.download(); return; }
      if (mod && e.key.toLowerCase() === 's') { e.preventDefault(); exportProject(s.project); s.showToast('Project exported as a file', 'ok'); return; }
      if (typing || s.view !== 'block') return;
      if (e.key === 'Escape') { s.arm(null); return; }
      if (e.key === 'Delete' || e.key === 'Backspace') { if (s.sel.elemId) { e.preventDefault(); s.deleteSelected(); } return; }
      if (mod && e.key.toLowerCase() === 'c') { s.copy(); return; }
      if (mod && e.key.toLowerCase() === 'v') { s.paste(); return; }
      if (e.key === 'F2') { s.openProps(); return; }
      if (e.shiftKey && e.key === 'F2') { s.insertInstr('NO'); return; }
    };
    window.addEventListener('keydown', h);
    return () => window.removeEventListener('keydown', h);
  }, []);
}

function TB({ icon, label, onClick, disabled, active }: { icon: React.ReactNode; label: string; onClick: () => void; disabled?: boolean; active?: boolean }) {
  return (
    <button title={label} onClick={onClick} disabled={disabled}
      className={`btn btn-ghost btn-icon ${active ? '!text-accent !bg-accent/15' : ''}`}>{icon}</button>
  );
}

function ActionBtn({ icon, label, onClick, disabled, danger }: { icon: React.ReactNode; label: string; onClick: () => void; disabled?: boolean; danger?: boolean }) {
  return (
    <button onClick={e => { e.stopPropagation(); onClick(); }} disabled={disabled}
      className={`shrink-0 min-w-[60px] flex flex-col items-center justify-center gap-0.5 px-1 py-2 rounded-lg text-[11px] font-medium active:bg-panel3 disabled:opacity-35 ${danger ? 'text-danger' : 'text-ink'}`}>
      {icon}{label}
    </button>
  );
}

/** Phone only: the floating "add instruction" button and the action bar for the current selection. */
function PhoneActions() {
  const sel = useStore(s => s.sel);
  const clip = useStore(s => s.clipboard);
  const armed = useStore(s => s.armed);
  const st = useStore.getState;
  const hasElem = !!sel.elemId;
  const hasNet = !!sel.netId;
  return (
    <div className="lg:hidden absolute inset-x-0 bottom-0 z-20 pointer-events-none flex flex-col items-end gap-2 p-2.5" onClick={e => e.stopPropagation()}>
      {!armed && (
        <button className="pointer-events-auto btn !rounded-full !pl-3.5 !pr-4 !py-3 !bg-accent !text-[#06211e] !border-transparent !font-semibold !text-[14.5px] shadow-xl shadow-black/30"
          onClick={() => st().set({ sheet: 'instr' })}><Plus size={19} strokeWidth={2.6} />Instruction</button>
      )}
      {hasNet && (
        <div className="pointer-events-auto w-full card !rounded-xl shadow-2xl flex overflow-x-auto px-1" role="toolbar" aria-label={hasElem ? 'Selected element' : 'Selected network'}>
          {hasElem ? (
            <>
              <ActionBtn icon={<SlidersHorizontal size={20} />} label="Edit" onClick={() => st().openProps()} />
              <ActionBtn icon={<GitBranch size={20} />} label="Branch" onClick={() => st().branchSelected()} />
              <ActionBtn icon={<ArrowLeft size={20} />} label="Left" onClick={() => st().moveSelected(-1)} />
              <ActionBtn icon={<ArrowRight size={20} />} label="Right" onClick={() => st().moveSelected(1)} />
              <ActionBtn icon={<Copy size={20} />} label="Copy" onClick={() => st().copy()} />
              {clip && <ActionBtn icon={<ClipboardPaste size={20} />} label="Paste" onClick={() => st().paste()} />}
              <ActionBtn icon={<Trash2 size={20} />} label="Delete" danger onClick={() => st().deleteSelected()} />
            </>
          ) : (
            <>
              <ActionBtn icon={<Plus size={20} />} label="Network" onClick={() => st().addNetwork(sel.netId ?? undefined)} />
              <ActionBtn icon={<ArrowUp size={20} />} label="Up" onClick={() => st().moveNetwork(-1)} />
              <ActionBtn icon={<ArrowDown size={20} />} label="Down" onClick={() => st().moveNetwork(1)} />
              <ActionBtn icon={<Copy size={20} />} label="Copy" onClick={() => st().copy()} />
              {clip && <ActionBtn icon={<ClipboardPaste size={20} />} label="Paste" onClick={() => st().paste()} />}
              <ActionBtn icon={<Trash2 size={20} />} label="Delete" danger onClick={() => st().deleteSelected()} />
            </>
          )}
        </div>
      )}
    </div>
  );
}

export function LadderEditor() {
  const project = useStore(s => s.project);
  const blockId = useStore(s => s.activeBlockId);
  const sel = useStore(s => s.sel);
  const zoom = useStore(s => s.zoom);
  const monitoring = useStore(s => s.monitoring);
  const past = useStore(s => s.past.length);
  const future = useStore(s => s.future.length);
  const clip = useStore(s => s.clipboard);
  const version = useStore(s => s.version);
  const dl = useStore(s => s.downloadedVersion);
  const armed = useStore(s => s.armed);
  useStore(s => (s.monitoring ? Math.floor(s.tick / 8) : 0));
  const { errs } = useMsgCounts();
  const st = useStore.getState;
  const block = project.blocks.find(b => b.id === blockId) ?? project.blocks[0];
  if (!block) return null;
  const outOfSync = runtime.prog && dl !== version;
  const hasSel = !!sel.elemId;
  const zoomBy = (d: number) => st().set({ zoom: Math.min(1.8, Math.max(0.5, +(zoom + d).toFixed(2))) });

  return (
    <div className="flex flex-col h-full min-h-0 relative">
      {/* desktop toolbar */}
      <div className="hidden lg:flex items-center gap-1 px-2 py-1 border-b border-line bg-panel overflow-x-auto shrink-0">
        <TB icon={<Plus size={16} />} label="Insert network" onClick={() => st().addNetwork(sel.netId ?? undefined)} />
        <div className="w-px h-5 bg-line mx-1" />
        <TB icon={<GitBranch size={16} />} label="Open branch around selection" onClick={() => st().branchSelected()} disabled={!hasSel} />
        <TB icon={<GitMerge size={16} />} label="Add parallel branch" onClick={() => st().addBranchToParallel()} disabled={!hasSel} />
        <TB icon={<ArrowLeft size={16} />} label="Move element left" onClick={() => st().moveSelected(-1)} disabled={!hasSel} />
        <TB icon={<ArrowRight size={16} />} label="Move element right" onClick={() => st().moveSelected(1)} disabled={!hasSel} />
        <div className="w-px h-5 bg-line mx-1" />
        <TB icon={<Copy size={16} />} label="Copy (Ctrl+C)" onClick={() => st().copy()} disabled={!sel.netId} />
        <TB icon={<ClipboardPaste size={16} />} label="Paste (Ctrl+V)" onClick={() => st().paste()} disabled={!clip} />
        <TB icon={<Trash2 size={16} />} label="Delete (Del)" onClick={() => st().deleteSelected()} disabled={!sel.netId} />
        <div className="w-px h-5 bg-line mx-1" />
        <TB icon={<Undo2 size={16} />} label="Undo (Ctrl+Z)" onClick={() => st().undo()} disabled={!past} />
        <TB icon={<Redo2 size={16} />} label="Redo (Ctrl+Y)" onClick={() => st().redo()} disabled={!future} />
        <div className="w-px h-5 bg-line mx-1" />
        <TB icon={<ZoomOut size={16} />} label="Zoom out" onClick={() => zoomBy(-0.1)} />
        <button className="text-[11px] text-mute w-10 text-center" onClick={() => st().set({ zoom: 1 })}>{Math.round(zoom * 100)}%</button>
        <TB icon={<ZoomIn size={16} />} label="Zoom in" onClick={() => zoomBy(0.1)} />
        <div className="flex-1" />
        <button onClick={() => st().set({ monitoring: !monitoring })} title="Monitoring on/off"
          className={`btn !text-xs ${monitoring ? 'btn-accent' : ''}`}><Glasses size={15} /><span className="hidden sm:inline">{monitoring ? 'Monitoring' : 'Monitor'}</span></button>
      </div>

      {/* phone strip */}
      <div className="lg:hidden flex items-center gap-0.5 pl-3 pr-1 border-b border-line bg-panel shrink-0">
        <div className="flex-1 min-w-0 py-1.5">
          <div className="text-[14px] font-semibold truncate">{blockLabel(block)}</div>
        </div>
        <button className="btn btn-ghost btn-icon" aria-label="Undo" disabled={!past} onClick={() => st().undo()}><Undo2 size={18} /></button>
        <button className="btn btn-ghost btn-icon" aria-label="Redo" disabled={!future} onClick={() => st().redo()}><Redo2 size={18} /></button>
        <button className="btn btn-ghost btn-icon" aria-label="Zoom out" onClick={() => zoomBy(-0.15)}><ZoomOut size={18} /></button>
        <button className="btn btn-ghost btn-icon" aria-label="Zoom in" onClick={() => zoomBy(0.15)}><ZoomIn size={18} /></button>
        <button className="btn btn-ghost btn-icon relative" aria-label="Messages" onClick={() => st().set({ sheet: 'info' })}>
          <AlertTriangle size={18} />{errs > 0 && <span className="absolute top-1 right-1 min-w-[16px] h-4 px-1 rounded-full bg-danger text-white text-[10px] font-bold flex items-center justify-center">{errs}</span>}
        </button>
      </div>

      {armed && (
        <div className="lg:hidden flex items-center gap-2 px-3 py-2 bg-accent/15 text-accent text-[13px] border-b border-accent/30 shrink-0">
          <span className="flex-1">Tap a <b>⊕</b> in a network to place <b>{INSTR_MAP[armed]?.title || INSTR_MAP[armed]?.label}</b></span>
          <button className="btn !py-1 !text-[12px]" onClick={() => st().arm(null)}>Cancel</button>
        </div>
      )}
      {monitoring && outOfSync && (
        <div className="flex items-center gap-2 px-3 py-1.5 bg-warn/10 text-warn text-xs border-b border-warn/30">
          <AlertTriangle size={14} />Online and offline versions differ — download to apply your changes.
          <button className="btn !py-0.5 !text-[11px] ml-auto" onClick={() => st().download()}><Download size={12} />Download</button>
        </div>
      )}
      <div className="flex-1 overflow-y-auto overscroll-contain p-2 sm:p-3 space-y-2.5" onClick={() => st().select({ netId: null, elemId: null })}>
        <div className="hidden lg:flex items-baseline gap-3 px-1">
          <h2 className="text-sm font-semibold text-ink">{blockLabel(block)}</h2>
          <span className="text-xs text-mute truncate">{block.comment}</span>
        </div>
        {block.networks.map((n, i) => <LadderNetwork key={n.id} net={n} index={i} total={block.networks.length} />)}
        <button className="w-full border border-dashed border-line rounded-xl py-3 max-lg:py-4 text-xs max-lg:text-[13px] text-mute hover:text-accent hover:border-accent/50 transition-colors"
          onClick={e => { e.stopPropagation(); st().addNetwork(); }}>+ Add network</button>
        <div className="h-24 max-lg:h-48" />
      </div>
      <PhoneActions />
    </div>
  );
}
