import { useEffect, useMemo, useRef, useState, type ReactNode, type MouseEvent as RMouseEvent } from 'react';
import { useIsPhone } from '../Sheet';
import { ChevronDown, ChevronRight, Copy, Plus, Trash2, ArrowUp, ArrowDown, AlertCircle } from 'lucide-react';
import type { DataType, LadderInstr, Network, Project, Tag } from '../../types';
import { useStore } from '../../store';
import { G, boxRows, layoutNetwork, type LInstr, type LPar, type LSer } from '../../plc/ladder';
import { INSTR_MAP } from '../../catalog/instructions';
import { runtime } from '../../plc/runtime';
import { formatValue, parseAddress, formatAddress, normalizeAddress, sizeOfType, defaultTypeForSize } from '../../plc/values';
import { monitorValue, operandState } from './monitor';

const LEFT = 12;
const trunc = (s: string, n: number) => (s.length > n ? s.slice(0, n - 1) + '…' : s);

interface EditState { elemId: string; field: string; left: number; top: number; width: number; value: string }

function displayOperand(p: Project, s: string): { main: string; addr: string } {
  const t = s.trim();
  if (!t) return { main: '', addr: '' };
  const tag = p.tags.find(x => x.name.toLowerCase() === t.replace(/"/g, '').toLowerCase());
  if (tag) return { main: `"${tag.name}"`, addr: normalizeAddress(tag.address) };
  const a = parseAddress(t);
  if (a) return { main: formatAddress(a), addr: '' };
  if (/^[A-Za-z_]\w*\.[A-Za-z]+$/.test(t)) return { main: `"${t.split('.')[0]}".${t.split('.')[1].toUpperCase()}`, addr: '' };
  return { main: t, addr: '' };
}

export function pinTypeFor(i: LadderInstr, pinName: string): DataType | undefined {
  const d = INSTR_MAP[i.op];
  const pd = d.pins.find(p => p.name === pinName);
  if (!pd) return 'Bool';
  if (pd.kind === 'bool') return 'Bool';
  if (pd.kind === 'time') return 'Time';
  if (pd.kind === 'real') return 'Real';
  if (pd.typed2) return i.dataType2 ?? d.defType2;
  if (pd.typed) return i.dataType ?? d.defType;
  return undefined;
}

export function commitOperand(elemId: string, field: string, raw: string) {
  const st = useStore.getState();
  let v = raw.trim();
  let created: string | null = null;
  st.mutate(p => {
    let target: LadderInstr | null = null;
    const find = (items: Network['root']['items']): void => {
      for (const it of items) {
        if (target) return;
        if (it.kind === 'instr') { if (it.id === elemId) target = it; }
        else it.branches.forEach(b => find(b.items));
      }
    };
    for (const b of p.blocks) for (const n of b.networks) find(n.root.items);
    if (!target) return;
    const instr = target as LadderInstr;
    const isAddrField = field !== 'instance' && field !== 'BLOCK' && instr.op !== 'RT';
    const addr = isAddrField ? parseAddress(v) : null;
    if (addr) {
      const norm = formatAddress(addr);
      let tag: Tag | undefined = p.tags.find(t => normalizeAddress(t.address) === norm);
      if (!tag) {
        const want = field === 'operand' ? 'Bool' : pinTypeFor(instr, field);
        const dt: DataType = addr.size === 'X' ? 'Bool' : want && sizeOfType(want) === addr.size ? want : defaultTypeForSize(addr.size);
        let k = 1;
        while (p.tags.some(t => t.name.toLowerCase() === `tag_${k}`)) k++;
        tag = { id: `t${Date.now().toString(36)}${k}`, name: `Tag_${k}`, dataType: dt, address: norm, comment: '' };
        p.tags.push(tag);
        created = tag.name;
      }
      v = tag.name;
    }
    if (field === 'operand') instr.operand = v;
    else if (field === 'instance') instr.instance = v;
    else instr.params[field] = v;
  });
  if (created) st.showToast(`Tag "${created}" created in the PLC tag table`, 'info');
}

const wireColor = (online: boolean, on: boolean | undefined) => (!online ? 'var(--c-wire)' : on ? 'var(--c-on)' : 'var(--c-off)');
function Wire({ x1, y1, x2, y2, on, online }: { x1: number; y1: number; x2: number; y2: number; on?: boolean; online: boolean }) {
  return <line x1={x1} y1={y1} x2={x2} y2={y2} stroke={wireColor(online, on)} strokeWidth={online && on ? 2.6 : 1.6} strokeDasharray={online && !on ? '5 4' : undefined} strokeLinecap="round" />;
}

function Marker({ x, y, seriesId, idx, onInsert }: { x: number; y: number; seriesId: string; idx: number; onInsert: (e: RMouseEvent | React.DragEvent, s: string, i: number) => void }) {
  return (
    <g className="cursor-pointer" onClick={e => onInsert(e, seriesId, idx)}
      onDragOver={e => { e.preventDefault(); }} onDrop={e => onInsert(e, seriesId, idx)}>
      <circle cx={x} cy={y} r={22} fill="transparent" />
      <circle cx={x} cy={y} r={9} fill="var(--c-accent)" opacity={0.95} />
      <path d={`M${x - 4} ${y}H${x + 4}M${x} ${y - 4}V${y + 4}`} stroke="var(--c-bg)" strokeWidth={2} strokeLinecap="round" />
    </g>
  );
}

function OperandText({ x, y, anchor, i, field, value, placeholder, size = 10.5, project, onEdit }: { x: number; y: number; anchor: 'start' | 'middle' | 'end'; i: LadderInstr; field: string; value: string; placeholder: string; size?: number; project: Project; onEdit: (e: RMouseEvent, id: string, field: string, value: string) => void }) {
  const empty = !value.trim();
  const disp = displayOperand(project, value);
  const shown = empty ? placeholder : trunc(disp.main, anchor === 'middle' ? 19 : 13);
  // invisible, generously sized hit area so the label is easy to tap with a finger
  const w = Math.max(46, shown.length * size * 0.62 + 14), h = 22;
  const hx = anchor === 'middle' ? x - w / 2 : anchor === 'end' ? x - w + 4 : x - 4;
  return (
    <g onClick={e => onEdit(e, i.id, field, value)} className="cursor-text">
      <rect x={hx} y={y - h + 7} width={w} height={h} rx={4} fill="transparent" />
      <text x={x} y={y} textAnchor={anchor} fontSize={size} className="ladder-text select-none" fill={empty ? 'var(--c-danger)' : 'var(--c-ink)'}>
        <title>{value || 'click to enter operand'}</title>
        {shown}
      </text>
    </g>
  );
}

export function LadderNetwork({ net, index, total }: { net: Network; index: number; total: number }) {
  const project = useStore(s => s.project);
  const sel = useStore(s => s.sel);
  const armed = useStore(s => s.armed);
  const monitoring = useStore(s => s.monitoring);
  const zoom = useStore(s => s.zoom);
  const msgs = useStore(s => s.msgs);
  const blockId = useStore(s => s.activeBlockId);
  useStore(s => (s.monitoring ? s.tick : 0));
  const [collapsed, setCollapsed] = useState(false);
  const [edit, setEdit] = useState<EditState | null>(null);
  const [showComment, setShowComment] = useState(!!net.comment);
  const boxRef = useRef<HTMLDivElement>(null);
  const phone = useIsPhone();
  const [boxW, setBoxW] = useState(0);

  // on phones the rung is laid out compactly (coil right behind the contacts) and scaled to fit the screen width
  const layout = useMemo(() => layoutNetwork(net, phone ? 0 : G.MIN_W), [net, phone]);
  useEffect(() => {
    const el = boxRef.current;
    if (!el || typeof ResizeObserver === 'undefined') return;
    const ro = new ResizeObserver(() => setBoxW(el.clientWidth));
    ro.observe(el);
    setBoxW(el.clientWidth);
    return () => ro.disconnect();
  }, [collapsed]);
  const errIds = useMemo(() => new Set(msgs.filter(m => m.level === 'error' && m.networkId === net.id && m.elemId).map(m => m.elemId!)), [msgs, net.id]);
  const netErrors = msgs.filter(m => m.level === 'error' && m.networkId === net.id).length;

  const online = monitoring && !!runtime.prog && runtime.mode === 'RUN';
  const pw = (id: string) => (online ? runtime.power.get(id) : undefined);
  const selected = sel.netId === net.id;

  const st = useStore.getState;
  const selectElem = (id: string | null, e?: RMouseEvent) => {
    e?.stopPropagation();
    // phone: tapping the element that is already selected opens its properties (there is no double-click on a touch screen)
    if (phone && id && st().sel.elemId === id && !st().armed) { st().openProps(); return; }
    st().select({ netId: net.id, elemId: id });
  };

  const startEdit = (e: RMouseEvent, elemId: string, field: string, value: string) => {
    e.stopPropagation();
    if (st().armed) return;
    const host = boxRef.current;
    if (!host) return;
    const r = (e.currentTarget as Element).getBoundingClientRect();
    const h = host.getBoundingClientRect();
    const width = Math.max(140, r.width + 30);
    st().select({ netId: net.id, elemId });
    setEdit({ elemId, field, left: r.left - h.left + host.scrollLeft + r.width / 2 - width / 2, top: r.top - h.top + host.scrollTop - 4, width, value });
  };

  const insertAt = (e: RMouseEvent | React.DragEvent, seriesId: string, idx: number) => {
    e.stopPropagation();
    const op = st().armed;
    if (op) st().insertInstr(op, seriesId, idx);
  };

  // ---------------------------------------------------------- drawing helpers
  const valueText = (x: number, y: number, anchor: 'start' | 'middle' | 'end', s: string | undefined, hint?: DataType) => {
    if (!online || !s) return null;
    const mv = monitorValue(project, s, hint);
    if (!mv || typeof mv.v === 'boolean') return null;
    return <text x={x} y={y} textAnchor={anchor} fontSize={9} className="ladder-text" fill="var(--c-on)">{trunc(formatValue(mv.v, mv.dt), 14)}</text>;
  };

  // ---------------------------------------------------------- element renderers
  function renderInstr(li: LInstr, key: string): ReactNode {
    const i = li.el;
    const d = INSTR_MAP[i.op];
    const p = pw(i.id);
    const pin = p?.[0], out = p?.[1];
    const W = G.WIRE;
    const isSel = sel.elemId === i.id;
    const hasErr = errIds.has(i.id);
    const body: ReactNode[] = [];
    if (!d) return null;

    if (d.shape === 'contact' || d.shape === 'coil') {
      const w = li.w, cx = w / 2;
      const opState = online && d.operand ? operandState(project, i.operand) : null;
      const closed = d.shape === 'contact'
        ? (i.op === 'NC' ? opState === false : i.op === 'NOT' ? out === true : opState === true)
        : opState === true;
      const symColor = online ? (d.shape === 'contact' ? (closed ? 'var(--c-on)' : 'var(--c-off)') : (closed ? 'var(--c-on)' : 'var(--c-off)')) : 'var(--c-ink)';
      const half = i.op === 'SET_BF' || i.op === 'RESET_BF' ? 22 : 12;
      body.push(<Wire online={online} key="w1" x1={0} y1={W} x2={cx - half} y2={W} on={pin} />);
      body.push(<Wire online={online} key="w2" x1={cx + half} y1={W} x2={w} y2={W} on={out} />);
      if (d.shape === 'contact') {
        body.push(<path key="c" d={`M${cx - 11} ${W - 13}V${W + 13}M${cx + 11} ${W - 13}V${W + 13}`} stroke={symColor} strokeWidth={2.2} />);
        if (closed && online) body.push(<rect key="cf" x={cx - 9} y={W - 11} width={18} height={22} fill="var(--c-on)" opacity={0.18} />);
        if (i.op === 'NC') body.push(<path key="s" d={`M${cx - 8} ${W + 11}L${cx + 8} ${W - 11}`} stroke={symColor} strokeWidth={1.8} />);
        if (d.symbol && i.op !== 'NC') body.push(<text key="t" x={cx} y={W + 4} textAnchor="middle" fontSize={i.op === 'NOT' ? 8.5 : 11} fontWeight={700} fill={symColor} className="ladder-text">{d.symbol}</text>);
      } else {
        body.push(<path key="c" d={`M${cx - half + 4} ${W - 13}Q${cx - half - 3} ${W} ${cx - half + 4} ${W + 13}M${cx + half - 4} ${W - 13}Q${cx + half + 3} ${W} ${cx + half - 4} ${W + 13}`} fill="none" stroke={symColor} strokeWidth={2.2} />);
        if (d.symbol) body.push(<text key="t" x={cx} y={W + 4} textAnchor="middle" fontSize={d.symbol.length > 2 ? 8 : 11} fontWeight={700} fill={symColor} className="ladder-text">{d.symbol}</text>);
        if (closed && online) body.push(<circle key="cf" cx={cx} cy={W} r={9} fill="var(--c-on)" opacity={0.15} />);
      }
      if (d.operand || i.op === 'RT') {
        const disp = displayOperand(project, i.operand);
        if (disp.addr) body.push(<text key="addr" x={cx} y={W - 33} textAnchor="middle" fontSize={9} fill="var(--c-mute)" className="ladder-text">{disp.addr}</text>);
        body.push(<OperandText project={project} onEdit={startEdit} key="op" x={cx} y={W - 20} anchor="middle" i={i} field="operand" value={i.operand} placeholder={i.op === 'RT' ? '<???>' : '<??.?>'} />);
      }
      const extra = d.pins.find(pp => pp.name === 'M_BIT' || pp.name === 'N');
      if (extra) {
        const v = i.params[extra.name] ?? '';
        body.push(<OperandText project={project} onEdit={startEdit} key="ex" x={cx} y={W + 31} anchor="middle" i={i} field={extra.name} value={v} placeholder={extra.name === 'N' ? '<N>' : '<M_BIT>'} size={9.5} />);
      }
    } else if (d.shape === 'cmp') {
      const w = li.w, cx = w / 2;
      const c = online ? (out ? 'var(--c-on)' : 'var(--c-off)') : 'var(--c-ink)';
      body.push(<Wire online={online} key="w1" x1={0} y1={W} x2={cx - 22} y2={W} on={pin} />);
      body.push(<Wire online={online} key="w2" x1={cx + 22} y1={W} x2={w} y2={W} on={out} />);
      body.push(<rect key="r" x={cx - 22} y={W - 15} width={44} height={30} rx={3} fill="var(--c-panel2)" stroke={c} strokeWidth={1.8} />);
      body.push(<text key="s" x={cx} y={W} textAnchor="middle" fontSize={12} fontWeight={700} fill={c} className="ladder-text">{d.symbol}</text>);
      body.push(<text key="t" x={cx} y={W + 11} textAnchor="middle" fontSize={8} fill="var(--c-mute)" className="ladder-text">{i.dataType}</text>);
      body.push(<OperandText project={project} onEdit={startEdit} key="a" x={cx} y={W - 21} anchor="middle" i={i} field="IN1" value={i.params.IN1 ?? ''} placeholder="<???>" />);
      body.push(<OperandText project={project} onEdit={startEdit} key="b" x={cx} y={W + 29} anchor="middle" i={i} field="IN2" value={i.params.IN2 ?? ''} placeholder="<???>" />);
      if (online) {
        const v1 = monitorValue(project, i.params.IN1, i.dataType), v2 = monitorValue(project, i.params.IN2, i.dataType);
        if (v1) body.push(<text key="v1" x={cx} y={W - 33} textAnchor="middle" fontSize={9} fill="var(--c-on)" className="ladder-text">{formatValue(v1.v, v1.dt)}</text>);
        if (v2) body.push(<text key="v2" x={cx} y={W + 40} textAnchor="middle" fontSize={9} fill="var(--c-on)" className="ladder-text">{formatValue(v2.v, v2.dt)}</text>);
      }
    } else {
      // box
      const M = G.BOX_MARGIN, BW = G.BOX_W;
      const { ins, outs } = boxRows(i);
      const top = 20, bottom = li.h - 8;
      const c = online ? (out ? 'var(--c-on)' : 'var(--c-off)') : 'var(--c-line)';
      body.push(<Wire online={online} key="w1" x1={0} y1={W} x2={M} y2={W} on={pin} />);
      body.push(<Wire online={online} key="w2" x1={M + BW} y1={W} x2={li.w} y2={W} on={out} />);
      body.push(<rect key="r" x={M} y={top} width={BW} height={bottom - top} rx={5} fill="var(--c-panel2)" stroke={c} strokeWidth={online ? 2 : 1.4} />);
      body.push(<rect key="hd" x={M} y={top} width={BW} height={22} rx={5} fill="var(--c-panel3)" />);
      body.push(<rect key="hd2" x={M} y={top + 14} width={BW} height={8} fill="var(--c-panel3)" />);
      const title = i.op === 'CALL' ? (i.params.BLOCK || 'CALL') : d.title;
      body.push(<text key="ti" x={M + 7} y={top + 15} fontSize={11} fontWeight={700} fill="var(--c-ink)" className={`ladder-text ${i.op === 'CALL' ? 'cursor-text' : ''}`}
        onClick={i.op === 'CALL' ? e => startEdit(e, i.id, 'BLOCK', i.params.BLOCK ?? '') : undefined}>{trunc(title, 11)}</text>);
      const typeLabel = i.op === 'CONV' ? `${i.dataType}→${i.dataType2}` : i.op === 'CALL' ? 'FC' : d.instance === 'timer' ? 'Time' : i.dataType ?? '';
      if (typeLabel) body.push(<text key="ty" x={M + BW - 6} y={top + 15} textAnchor="end" fontSize={8.5} fill="var(--c-accent)" className="ladder-text">{typeLabel}</text>);
      if (d.instance) {
        body.push(<OperandText project={project} onEdit={startEdit} key="inst" x={M + BW / 2} y={13} anchor="middle" i={i} field="instance" value={i.instance ?? ''} placeholder="<instance DB>" size={10} />);
      } else if (d.operand) {
        body.push(<OperandText project={project} onEdit={startEdit} key="op" x={M + BW / 2} y={13} anchor="middle" i={i} field="operand" value={i.operand} placeholder="<??.?>" />);
      }
      if (d.powerIn) body.push(<text key="pi" x={M + 5} y={W + 4} fontSize={9.5} fill="var(--c-mute)" className="ladder-text">{d.powerIn}</text>);
      if (d.powerOut) body.push(<text key="po" x={M + BW - 5} y={W + 4} textAnchor="end" fontSize={9.5} fill="var(--c-mute)" className="ladder-text">{d.powerOut}</text>);
      ins.forEach((name, r) => {
        const y = W + (r + 1) * G.PIN;
        const pd = d.pins.find(pp => pp.name === name)!;
        const val = i.params[name] ?? '';
        const bOn = online && pd.kind === 'bool' && val ? operandState(project, val) : null;
        body.push(<line key={`il${r}`} x1={M - 9} y1={y} x2={M} y2={y} stroke={bOn ? 'var(--c-on)' : 'var(--c-wire)'} strokeWidth={1.4} />);
        body.push(<text key={`in${r}`} x={M + 5} y={y + 4} fontSize={9.5} fill="var(--c-mute)" className="ladder-text">{name}</text>);
        body.push(<OperandText project={project} onEdit={startEdit} key={`io${r}`} x={M - 12} y={y + 4} anchor="end" i={i} field={name} value={val} placeholder={pd.optional ? '...' : pd.kind === 'bool' ? '<??.?>' : '<???>'} />);
        body.push(<g key={`iv${r}`}>{valueText(M - 12, y - 7, 'end', val, pinTypeFor(i, name))}</g>);
      });
      outs.forEach((name, r) => {
        const y = W + (r + 1) * G.PIN;
        const pd = d.pins.find(pp => pp.name === name)!;
        const val = i.params[name] ?? '';
        body.push(<line key={`ol${r}`} x1={M + BW} y1={y} x2={M + BW + 9} y2={y} stroke="var(--c-wire)" strokeWidth={1.4} />);
        body.push(<text key={`on${r}`} x={M + BW - 5} y={y + 4} textAnchor="end" fontSize={9.5} fill="var(--c-mute)" className="ladder-text">{name}</text>);
        body.push(<OperandText project={project} onEdit={startEdit} key={`oo${r}`} x={M + BW + 12} y={y + 4} anchor="start" i={i} field={name} value={val} placeholder={pd.optional ? '...' : '<???>'} />);
        body.push(<g key={`ov${r}`}>{valueText(M + BW + 12, y - 7, 'start', val, pinTypeFor(i, name))}</g>);
        if (online && !val && d.instance && name === 'ET') {
          const t = runtime.timers.get(i.instance ?? '');
          if (t) body.push(<text key="etv" x={M + BW + 12} y={y - 7} fontSize={9} fill="var(--c-on)" className="ladder-text">{formatValue(t.ET, 'Time')}</text>);
        }
        if (online && !val && d.instance === 'counter' && name === 'CV') {
          const cc = runtime.counters.get(i.instance ?? '');
          if (cc) body.push(<text key="cvv" x={M + BW + 12} y={y - 7} fontSize={9} fill="var(--c-on)" className="ladder-text">{cc.CV}</text>);
        }
      });
    }

    return (
      <g key={key} onClick={e => selectElem(i.id, e)} onDoubleClick={e => { e.stopPropagation(); st().openProps(); }} className="cursor-pointer">
        <rect x={1} y={2} width={li.w - 2} height={li.h - 4} rx={8} fill={isSel ? 'var(--c-sel)' : 'transparent'} stroke={hasErr ? 'var(--c-danger)' : isSel ? 'var(--c-accent)' : 'transparent'} strokeWidth={1.2} strokeDasharray={hasErr && !isSel ? '4 3' : undefined} />
        {body}
      </g>
    );
  }

  const seriesOut = (ls: LSer, pin: boolean | undefined): boolean | undefined => {
    if (!ls.items.length) return pin;
    const last = ls.items[ls.items.length - 1];
    return pw(last.el.id)?.[1];
  };

  function renderSeries(ls: LSer, pin: boolean | undefined): ReactNode {
    const W = G.WIRE;
    const parts: ReactNode[] = [];
    if (ls.items.length === 0) {
      parts.push(<Wire online={online} key="ew" x1={0} y1={W} x2={ls.w} y2={W} on={pin} />);
      if (armed) parts.push(<Marker onInsert={insertAt} key="em" x={ls.w / 2} y={W} seriesId={ls.el.id} idx={0} />);
      return parts;
    }
    let prevOut = pin;
    ls.items.forEach((it, k) => {
      const x = ls.xs[k];
      if (k > 0) {
        const pe = ls.xs[k - 1] + ls.items[k - 1].w;
        if (x > pe) parts.push(<Wire online={online} key={`g${k}`} x1={pe} y1={W} x2={x} y2={W} on={prevOut} />);
      }
      const ip = it.kind === 'instr' ? pw(it.el.id)?.[0] : pw(it.el.id)?.[0];
      parts.push(<g key={it.el.id} transform={`translate(${x},0)`}>{it.kind === 'instr' ? renderInstr(it, it.el.id) : renderPar(it, ip ?? prevOut)}</g>);
      prevOut = pw(it.el.id)?.[1];
    });
    const lastEnd = ls.xs[ls.xs.length - 1] + ls.items[ls.items.length - 1].w;
    if (!ls.open && lastEnd < ls.w) parts.push(<Wire online={online} key="tail" x1={lastEnd} y1={W} x2={ls.w} y2={W} on={prevOut} />);
    if (armed) {
      ls.items.forEach((_, k) => parts.push(<Marker onInsert={insertAt} key={`m${k}`} x={ls.xs[k]} y={W} seriesId={ls.el.id} idx={k} />));
      parts.push(<Marker onInsert={insertAt} key="mend" x={lastEnd} y={W} seriesId={ls.el.id} idx={ls.items.length} />);
    }
    return parts;
  }

  function renderPar(lp: LPar, pin: boolean | undefined): ReactNode {
    const W = G.WIRE;
    const parts: ReactNode[] = [];
    const out = pw(lp.el.id)?.[1];
    const firstY = lp.ys[0] + W, lastY = lp.ys[lp.ys.length - 1] + W;
    parts.push(<Wire online={online} key="lv" x1={0} y1={firstY} x2={0} y2={lastY} on={pin} />);
    lp.branches.forEach((b, k) => {
      const y = lp.ys[k];
      parts.push(<Wire online={online} key={`st${k}`} x1={0} y1={y + W} x2={G.PAD} y2={y + W} on={pin} />);
      parts.push(<g key={b.el.id} transform={`translate(${G.PAD},${y})`}>{renderSeries(b, pin)}</g>);
      if (!lp.open) {
        const bo = seriesOut(b, pin);
        parts.push(<Wire online={online} key={`ex${k}`} x1={G.PAD + b.w} y1={y + W} x2={lp.w} y2={y + W} on={bo} />);
      }
    });
    if (!lp.open) parts.push(<Wire online={online} key="rv" x1={lp.w} y1={firstY} x2={lp.w} y2={lastY} on={out} />);
    return parts;
  }

  const svgW = Math.max(LEFT + layout.w + 40, phone ? 300 : 0);
  const svgH = layout.h + 10;
  // zoom 100 % = fit the screen width on phones (never enlarged beyond natural size, not smaller than 65 %)
  const base = phone && boxW > 0 ? Math.min(1, Math.max(0.65, (boxW - 2) / svgW)) : 1;
  const scale = phone ? Math.min(2, Math.max(0.4, base * zoom)) : zoom;
  const railOn = online;

  const mutate = useStore(s => s.mutate);
  const setNet = (fn: (n: Network) => void) => mutate(p => {
    const b = p.blocks.find(x => x.id === blockId);
    const n = b?.networks.find(x => x.id === net.id);
    if (n) fn(n);
  }, false);

  const moveNet = (dir: -1 | 1) => mutate(p => {
    const b = p.blocks.find(x => x.id === blockId);
    if (!b) return;
    const k = b.networks.findIndex(x => x.id === net.id);
    const j = k + dir;
    if (j < 0 || j >= b.networks.length) return;
    [b.networks[k], b.networks[j]] = [b.networks[j], b.networks[k]];
  });

  return (
    <div className={`card overflow-hidden transition-colors ${selected ? 'border-accent/60 shadow-[0_0_0_1px_var(--c-accent)]/10' : ''}`}
      onClick={e => { e.stopPropagation(); st().select({ netId: net.id, elemId: null }); }}>
      <div className="flex items-center gap-2 px-3 py-1.5 max-lg:py-1 bg-panel2 border-b border-line group">
        <button className="text-mute hover:text-ink max-lg:p-2 max-lg:-ml-2" onClick={e => { e.stopPropagation(); setCollapsed(c => !c); }} aria-label={collapsed ? 'Expand network' : 'Collapse network'}>
          {collapsed ? <ChevronRight size={15} /> : <ChevronDown size={15} />}
        </button>
        <span className="text-xs font-semibold text-accent whitespace-nowrap">Network {index + 1}:</span>
        <input value={net.title} placeholder="Network title…" onClick={e => e.stopPropagation()}
          onChange={e => setNet(n => { n.title = e.target.value; })}
          className="flex-1 min-w-0 bg-transparent text-xs max-lg:text-[14px] max-lg:py-2 text-ink outline-none placeholder:text-mute/60" />
        {netErrors > 0 && <span className="flex items-center gap-1 text-[11px] text-danger"><AlertCircle size={13} />{netErrors}</span>}
        <button className="lg:hidden btn btn-ghost btn-icon" aria-label="Comment" aria-pressed={showComment} onClick={e => { e.stopPropagation(); setShowComment(v => !v); }}><span className="text-[11px] font-bold">//</span></button>
        <div className={`hidden lg:flex items-center gap-0.5 ${selected ? 'opacity-100' : 'opacity-0 group-hover:opacity-100'} transition-opacity`}>
          <button className="btn btn-ghost btn-icon" title="Comment" onClick={e => { e.stopPropagation(); setShowComment(v => !v); }}><span className="text-[10px] font-bold">//</span></button>
          <button className="btn btn-ghost btn-icon" title="Move up" disabled={index === 0} onClick={e => { e.stopPropagation(); moveNet(-1); }}><ArrowUp size={14} /></button>
          <button className="btn btn-ghost btn-icon" title="Move down" disabled={index === total - 1} onClick={e => { e.stopPropagation(); moveNet(1); }}><ArrowDown size={14} /></button>
          <button className="btn btn-ghost btn-icon" title="Copy network" onClick={e => { e.stopPropagation(); st().select({ netId: net.id, elemId: null }); setTimeout(() => st().copy()); }}><Copy size={14} /></button>
          <button className="btn btn-ghost btn-icon" title="Insert network below" onClick={e => { e.stopPropagation(); st().addNetwork(net.id); }}><Plus size={14} /></button>
          <button className="btn btn-ghost btn-icon hover:!text-danger" title="Delete network" onClick={e => { e.stopPropagation(); st().select({ netId: net.id, elemId: null }); setTimeout(() => st().deleteSelected()); }}><Trash2 size={14} /></button>
        </div>
      </div>
      {showComment && !collapsed && (
        <textarea value={net.comment} placeholder="Comment" rows={1} onClick={e => e.stopPropagation()}
          onChange={e => setNet(n => { n.comment = e.target.value; })}
          className="w-full resize-y bg-panel px-3 py-1.5 text-xs text-mute italic outline-none border-b border-line" />
      )}
      {!collapsed && (
        <div ref={boxRef} className="relative overflow-x-auto overflow-y-hidden grid-bg">
          <svg width={svgW * scale} height={svgH * scale} viewBox={`0 0 ${svgW} ${svgH}`} className="block select-none">
            <line x1={LEFT - 4} y1={2} x2={LEFT - 4} y2={svgH - 2} stroke={railOn ? 'var(--c-on)' : 'var(--c-wire)'} strokeWidth={4} strokeLinecap="round" />
            <g transform={`translate(${LEFT - 4},5)`}>{renderSeries(layout, online ? true : undefined)}</g>
            {net.root.items.length === 0 && !armed && (
              <text x={LEFT + 90} y={G.WIRE + 9} fontSize={11} fill="var(--c-mute)">{phone ? 'Tap + Instruction to start' : 'Select an instruction (or drag it here) to start this network'}</text>
            )}
          </svg>
          {edit && (
            <div className="absolute z-20" style={{ left: Math.max(4, edit.left), top: Math.max(2, edit.top), width: edit.width }} onClick={e => e.stopPropagation()}>
              <input ref={el => { if (el && document.activeElement !== el) el.focus({ preventScroll: true }); }} list={edit.field === 'BLOCK' ? 'dl-blocks' : edit.field === 'instance' || (edit.field === 'operand' && findOp(net, edit.elemId) === 'RT') ? 'dl-instances' : 'dl-tags'}
                defaultValue={edit.value} className="input !py-1 !text-xs font-mono shadow-xl"
                onFocus={e => e.currentTarget.select()}
                onKeyDown={e => {
                  if (e.key === 'Enter') { commitOperand(edit.elemId, edit.field, e.currentTarget.value); setEdit(null); }
                  if (e.key === 'Escape') setEdit(null);
                }}
                onBlur={e => { commitOperand(edit.elemId, edit.field, e.currentTarget.value); setEdit(null); }} />
            </div>
          )}
        </div>
      )}
    </div>
  );
}

function findOp(net: Network, id: string): string {
  let op = '';
  const f = (items: Network['root']['items']) => items.forEach(it => { if (it.kind === 'instr') { if (it.id === id) op = it.op; } else it.branches.forEach(b => f(b.items)); });
  f(net.root.items);
  return op;
}
