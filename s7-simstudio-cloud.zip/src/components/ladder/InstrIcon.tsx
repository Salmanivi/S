import { INSTR_MAP } from '../../catalog/instructions';

export function InstrIcon({ op, size = 30 }: { op: string; size?: number }) {
  const d = INSTR_MAP[op];
  if (!d) return null;
  const s = 'currentColor';
  return (
    <svg width={size} height={size * 0.62} viewBox="0 0 50 31" className="shrink-0">
      {d.shape === 'contact' && (
        <g stroke={s} strokeWidth={2} fill="none">
          <path d="M2 15.5H19M31 15.5H48M19 6V25M31 6V25" />
          {op === 'NC' && <path d="M21 23L29 8" strokeWidth={1.6} />}
          {d.symbol && op !== 'NC' && <text x="25" y="19.5" textAnchor="middle" fontSize={op === 'NOT' ? 7 : 11} fontWeight={700} fill={s} stroke="none">{d.symbol}</text>}
        </g>
      )}
      {d.shape === 'coil' && (
        <g stroke={s} strokeWidth={2} fill="none">
          <path d="M2 15.5H16M34 15.5H48M19 6Q13 15.5 19 25M31 6Q37 15.5 31 25" />
          {d.symbol && <text x="25" y="19.5" textAnchor="middle" fontSize={d.symbol.length > 2 ? 6 : 11} fontWeight={700} fill={s} stroke="none">{d.symbol.length > 3 ? d.symbol.slice(0, 3) : d.symbol}</text>}
        </g>
      )}
      {d.shape === 'cmp' && (
        <g stroke={s} strokeWidth={2} fill="none">
          <path d="M2 15.5H13M37 15.5H48" />
          <rect x="13" y="5" width="24" height="21" rx="2" />
          <text x="25" y="19.5" textAnchor="middle" fontSize={10} fontWeight={700} fill={s} stroke="none">{d.symbol}</text>
        </g>
      )}
      {d.shape === 'box' && (
        <g stroke={s} strokeWidth={1.8} fill="none">
          <path d="M2 12H9M41 12H48" />
          <rect x="9" y="3" width="32" height="25" rx="3" />
          <text x="25" y="19" textAnchor="middle" fontSize={d.title.length > 4 ? 6.5 : 8.5} fontWeight={700} fill={s} stroke="none">{d.title.slice(0, 7)}</text>
        </g>
      )}
    </svg>
  );
}
