import type { DataType, Project } from '../../types';
import { getResolver } from '../../store';
import { refType } from '../../plc/resolve';
import { runtime } from '../../plc/runtime';

export interface MonVal { v: number | boolean; dt: DataType }

export function monitorValue(p: Project, s: string | undefined, hint?: DataType): MonVal | null {
  if (!s || !s.trim()) return null;
  const r = getResolver(p).resolve(s);
  if (r.k === 'mem' || r.k === 'inst') {
    const dt = refType(r, hint) ?? 'Int';
    return { v: runtime.readRef(r, dt), dt };
  }
  return null;
}

export function operandState(p: Project, s: string | undefined): boolean | null {
  const m = monitorValue(p, s, 'Bool');
  if (!m) return null;
  return typeof m.v === 'boolean' ? m.v : m.v !== 0;
}
