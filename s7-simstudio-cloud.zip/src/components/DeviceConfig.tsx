import { useMemo, useState } from 'react';
import { Plus, X, Cpu, Settings2, Table2, Replace, Check, Search, Pencil, AlertTriangle, CheckCircle2 } from 'lucide-react';
import { useStore } from '../store';
import { CPUS, FAMILIES, cpuById, computeAddresses, ioProblemMessages, modulesForCpu, slotRange, areaAddressText, type CpuDef, type ModuleDef, type IoArea, type ModuleAddr } from '../catalog/hardware';
import { shiftAddresses } from '../plc/addrmap';
import { IO_BYTES } from '../plc/values';
import { Modal } from './Shell';
import { useIsPhone } from './Sheet';
import { Field } from './TaskCards';
import { CpuFaceplate } from './SimPanel';

const KIND_COLOR: Record<string, string> = { DI: '#3ddc84', DQ: '#f2b84b', DIQ: '#8bd450', AI: '#4fa3f7', AQ: '#c084fc', AIQ: '#7aa2ff', CM: '#94a3b8', CP: '#94a3b8', PS: '#f06464', TM: '#2ec4b6' };

interface SlotDef { slot: number; kinds: string[]; label: string }

function slotsFor(cpu: CpuDef): { left: SlotDef[]; right: SlotDef[] } {
  const r = slotRange(cpu);
  const right: SlotDef[] = [];
  for (let s = r.first; s <= r.last; s++) right.push({ slot: s, kinds: ['DI', 'DQ', 'DIQ', 'AI', 'AQ', 'AIQ', 'TM', 'CP', 'CM'], label: `${s}` });
  const left: SlotDef[] = [];
  if (cpu.family === 'S7-1200') {
    left.push({ slot: 103, kinds: ['CM', 'CP'], label: '103' }, { slot: 102, kinds: ['CM', 'CP'], label: '102' }, { slot: 101, kinds: ['CM', 'CP'], label: '101' });
    right.forEach(x => (x.kinds = ['DI', 'DQ', 'DIQ', 'AI', 'AQ', 'AIQ']));
  } else if (cpu.family === 'S7-1500' && cpu.modFamily === 'S7-1500') left.push({ slot: 0, kinds: ['PS'], label: '0' });
  else if (cpu.family === 'S7-300') left.push({ slot: 1, kinds: ['PS'], label: '1' });
  else if (cpu.family === 'S7-400') left.push({ slot: 1, kinds: ['PS'], label: '1' });
  return { left, right };
}

export function DeviceConfig() {
  const project = useStore(s => s.project);
  const mutate = useStore(s => s.mutate);
  const st = useStore.getState;
  const hw = project.hardware;
  const cpu = cpuById(hw.cpuId);
  const [picker, setPicker] = useState<{ slot: number; kinds: string[]; board?: boolean } | null>(null);
  const [tab, setTab] = useState<'overview' | 'props'>('overview');
  const [addrFor, setAddrFor] = useState<string | null>(null);
  const phone = useIsPhone();
  const addrs = useMemo(() => computeAddresses(hw), [hw]);
  const { left, right } = slotsFor(cpu);
  const modAt = (slot: number) => hw.modules.find(m => m.slot === slot);
  const allMods = modulesForCpu(cpu);
  const board = hw.modules.find(m => m.slot === 1 && cpu.family === 'S7-1200');

  const place = (def: ModuleDef) => {
    if (!picker) return;
    mutate(p => {
      p.hardware.modules = p.hardware.modules.filter(m => m.slot !== picker.slot);
      p.hardware.modules.push({ slot: picker.slot, moduleId: def.id });
    });
    setPicker(null);
    st().showToast(`${def.name} inserted in slot ${picker.slot}`, 'ok');
  };
  const remove = (slot: number) => mutate(p => { p.hardware.modules = p.hardware.modules.filter(m => m.slot !== slot); });

  const ModuleCard = ({ s }: { s: SlotDef }) => {
    const mi = modAt(s.slot);
    const def = mi ? allMods.find(x => x.id === mi.moduleId) : undefined;
    if (!def) {
      return (
        <button onClick={() => setPicker({ slot: s.slot, kinds: s.kinds })}
          className="w-[86px] h-[190px] shrink-0 rounded-lg border border-dashed border-line flex flex-col items-center justify-center gap-1 text-mute hover:text-accent hover:border-accent/60 transition-colors">
          <Plus size={18} /><span className="text-[10px]">Slot {s.label}</span>
        </button>
      );
    }
    const a = addrs.find(x => x.id === `slot-${s.slot}`);
    return (
      <div role="button" tabIndex={0} title="Edit I/O addresses" onClick={() => setAddrFor(`slot-${s.slot}`)} onKeyDown={e => e.key === 'Enter' && setAddrFor(`slot-${s.slot}`)}
        className={`group relative w-[86px] h-[190px] shrink-0 rounded-lg bg-gradient-to-b from-[#3b4148] to-[#23282e] border shadow-md overflow-hidden text-white cursor-pointer ${a?.conflicts.length ? 'border-danger ring-1 ring-danger' : 'border-black/40 hover:ring-1 hover:ring-accent/70'}`}>
        <div className="h-1.5" style={{ background: KIND_COLOR[def.kind] }} />
        <div className="p-1.5">
          <div className="text-[9px] text-white/50">Slot {s.label}</div>
          <div className="text-[10px] font-semibold leading-tight mt-0.5">{def.name}</div>
          <div className="text-[8.5px] font-mono text-white/50 mt-1 break-all">{def.article}</div>
          {a && (a.iRange || a.qRange) && <div className="mt-1.5 text-[8.5px] font-mono leading-tight">{a.iRange && <div className="text-[#3ddc84]">I {a.iRange}</div>}{a.qRange && <div className="text-[#f2b84b]">Q {a.qRange}</div>}{a.conflicts.length > 0 && <div className="text-[#ff8080] mt-0.5">address conflict</div>}</div>}
        </div>
        <div className="absolute bottom-1.5 inset-x-1.5 grid grid-cols-4 gap-[3px]">
          {Array.from({ length: 8 }).map((_, k) => <span key={k} className="h-1 rounded-sm bg-white/10" />)}
        </div>
        <button aria-label="Remove module" onClick={e => { e.stopPropagation(); remove(s.slot); }} className="absolute top-2 right-1 p-0.5 rounded bg-black/40 opacity-0 group-hover:opacity-100 hover:bg-danger/80 transition"><X size={11} /></button>
      </div>
    );
  };

  const hp = hw.props;
  const setProp = <K extends keyof typeof hp>(k: K, v: (typeof hp)[K]) => mutate(p => { p.hardware.props[k] = v; });

  return (
    <div className="h-full overflow-y-auto">
      <div className="p-3 sm:p-5 space-y-4 max-w-[1400px]">
        <div className="flex flex-wrap items-center gap-3">
          <div>
            <h2 className="text-base font-semibold text-ink flex items-center gap-2"><Cpu size={18} className="text-accent" />Device configuration</h2>
            <p className="text-xs text-mute">{hp.name} [{cpu.name}{cpu.variant ? ' ' + cpu.variant : ''}] · {cpu.family} · Rack 0</p>
          </div>
          <div className="flex-1" />
          <button className="btn btn-accent" onClick={() => st().set({ dialog: 'cpu' })}><Replace size={14} />Change CPU</button>
        </div>

        {!phone && <div className="card p-4 overflow-x-auto grid-bg">
          <div className="flex items-end gap-1.5 min-w-max">
            {left.map(s => <ModuleCard key={s.slot} s={s} />)}
            <div className="w-[190px] shrink-0">
              <div className="relative">
                <CpuFaceplate compact />
                {cpu.family === 'S7-1200' && (
                  <div className="mt-1.5">
                    {board ? (
                      <div className="flex items-center gap-1 rounded-md bg-panel2 border border-line px-2 py-1 text-[10px]">
                        <span className="w-1.5 h-4 rounded" style={{ background: KIND_COLOR[allMods.find(x => x.id === board.moduleId)?.kind ?? 'DI'] }} />
                        <span className="flex-1 truncate">{allMods.find(x => x.id === board.moduleId)?.name}</span>
                        <button onClick={() => remove(1)} className="text-mute hover:text-danger"><X size={11} /></button>
                      </div>
                    ) : (
                      <button onClick={() => setPicker({ slot: 1, kinds: ['DI', 'DQ', 'DIQ', 'AI', 'AQ'], board: true })} className="w-full rounded-md border border-dashed border-line py-1 text-[10px] text-mute hover:text-accent">+ Signal board</button>
                    )}
                  </div>
                )}
              </div>
              <div className="mt-1.5 grid grid-cols-4 gap-1 text-center">
                {(['di', 'dq', 'ai', 'aq'] as const).map(k => (
                  <div key={k} className="rounded bg-panel2 border border-line py-0.5"><div className="text-[8px] uppercase text-mute">{k}</div><div className="text-[11px] font-mono text-ink">{cpu.onboard[k]}</div></div>
                ))}
              </div>
              {(addrs[0]?.areas.length ?? 0) > 0 && (
                <button onClick={() => setAddrFor('cpu')} className={`mt-1.5 w-full rounded-md border py-1 text-[10px] flex items-center justify-center gap-1 ${addrs[0].conflicts.length ? 'border-danger text-danger' : 'border-line text-mute hover:text-accent hover:border-accent/60'}`}><Pencil size={10} />I/O addresses</button>
              )}
            </div>
            {cpu.family === 'S7-300' && <div className="w-[50px] h-[190px] shrink-0 rounded-lg border border-line bg-panel2 flex items-center justify-center text-[9px] text-mute [writing-mode:vertical-rl]">Slot 3 · IM (reserved)</div>}
            {right.map(s => <ModuleCard key={s.slot} s={s} />)}
          </div>
          {cpu.family === 'S7-1200' && cpu.maxModules === 0 && <p className="text-[11px] text-mute mt-3">CPU 1211C does not support signal modules — use a signal board or a CPU 1212C or higher.</p>}
        </div>}

        {addrs.some(a => a.conflicts.length) && (
          <div className="rounded-xl border border-danger/50 bg-danger/10 p-3 text-[12.5px] text-danger flex gap-2">
            <AlertTriangle size={16} className="shrink-0 mt-0.5" />
            <div>
              <div className="font-semibold">I/O address conflict</div>
              <ul className="mt-0.5 space-y-0.5 list-disc pl-4">{ioProblemMessages(addrs).slice(0, 4).map(c => <li key={c}>{c}</li>)}</ul>
              <div className="mt-1 opacity-80">The program cannot be downloaded until the addresses are unique. Open the module and change its start address.</div>
            </div>
          </div>
        )}

        <div className="grid lg:grid-cols-[1fr_340px] gap-4">
          <div className="card overflow-hidden">
            <div className="flex border-b border-line px-2">
              <button className={`tab ${tab === 'overview' ? 'tab-active' : ''}`} onClick={() => setTab('overview')}><Table2 size={13} className="inline mr-1" />{phone ? 'Slots' : 'Device overview'}</button>
              <button className={`tab ${tab === 'props' ? 'tab-active' : ''}`} onClick={() => setTab('props')}><Settings2 size={13} className="inline mr-1" />CPU properties</button>
            </div>
            {tab === 'overview' ? (phone ? (
              <SlotList addrs={addrs} left={left} right={right} cpu={cpu} board={board?.moduleId} allMods={allMods} modAt={modAt}
                onPick={(slot, kinds, isBoard) => setPicker({ slot, kinds, board: isBoard })} onEdit={setAddrFor} />
            ) : (
              <div className="overflow-x-auto">
                <table className="w-full text-xs">
                  <thead className="text-mute bg-panel2">
                    <tr>{['Module', 'Slot', 'I address', 'Q address', 'Type', 'Article no.', 'Firmware'].map((h, i) => <th key={i} className="text-left font-medium px-3 py-2 whitespace-nowrap">{h}</th>)}</tr>
                  </thead>
                  <tbody>
                    {addrs.map(a => (
                      <tr key={a.id} className="border-t border-line hover:bg-panel2/60">
                        <td className="px-3 py-1 text-ink whitespace-nowrap">
                          <span className="align-middle">{a.name}</span>
                          {a.conflicts.length > 0 && <span title={a.conflicts.join('\n')} className="inline-flex text-danger ml-1.5 align-middle"><AlertTriangle size={14} /></span>}
                          <button className="btn btn-ghost btn-icon align-middle ml-0.5" title="Edit I/O start addresses" aria-label={`Edit I/O addresses of ${a.name}`} disabled={!a.areas.length} onClick={() => setAddrFor(a.id)}><Pencil size={13} /></button>
                        </td>
                        <td className="px-3 py-1.5 font-mono">{a.slot}</td>
                        <td className="px-3 py-1.5 font-mono text-on whitespace-nowrap">{a.iRange}{a.areas.some(x => x.proc === 'I' && x.custom) && <span className="ml-1 text-accent" title="Custom start address">•</span>}</td>
                        <td className="px-3 py-1.5 font-mono text-warn whitespace-nowrap">{a.qRange}{a.areas.some(x => x.proc === 'Q' && x.custom) && <span className="ml-1 text-accent" title="Custom start address">•</span>}</td>
                        <td className="px-3 py-1.5">{a.kind}</td>
                        <td className="px-3 py-1.5 font-mono text-mute whitespace-nowrap">{a.article}</td>
                        <td className="px-3 py-1.5 text-mute">{a.fw}</td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            )) : (
              <div className="p-4 grid sm:grid-cols-2 gap-4">
                <Field label="PLC name"><input className="input" value={hp.name} onChange={e => setProp('name', e.target.value)} /></Field>
                <Field label="PROFINET IP address"><input className="input font-mono" value={hp.ip} onChange={e => setProp('ip', e.target.value)} /></Field>
                <div className="space-y-2">
                  <label className="flex items-center gap-2 text-sm"><input type="checkbox" checked={hp.clockEnabled} onChange={e => setProp('clockEnabled', e.target.checked)} className="accent-[var(--c-accent)]" />Enable clock memory byte</label>
                  <Field label="Address of clock memory byte (MBx)"><input type="number" min={0} className="input" value={hp.clockByte} onChange={e => setProp('clockByte', Math.max(0, parseInt(e.target.value) || 0))} /></Field>
                  <p className="text-[11px] text-mute font-mono leading-relaxed">.0 10 Hz · .1 5 Hz · .2 2.5 Hz · .3 2 Hz<br />.4 1.25 Hz · .5 1 Hz · .6 0.625 Hz · .7 0.5 Hz</p>
                </div>
                <div className="space-y-2">
                  <label className={`flex items-center gap-2 text-sm ${cpu.family === 'S7-300' || cpu.family === 'S7-400' ? 'opacity-50' : ''}`}><input type="checkbox" disabled={cpu.family === 'S7-300' || cpu.family === 'S7-400'} checked={hp.sysEnabled} onChange={e => setProp('sysEnabled', e.target.checked)} className="accent-[var(--c-accent)]" />Enable system memory byte</label>
                  <Field label="Address of system memory byte (MBx)"><input type="number" min={0} className="input" value={hp.sysByte} onChange={e => setProp('sysByte', Math.max(0, parseInt(e.target.value) || 0))} /></Field>
                  <p className="text-[11px] text-mute font-mono leading-relaxed">.0 FirstScan · .1 DiagStatusUpdate<br />.2 AlwaysTRUE · .3 AlwaysFALSE{cpu.family === 'S7-300' || cpu.family === 'S7-400' ? <><br />(S7-1200/1500 only)</> : null}</p>
                </div>
                <Field label="Maximum cycle time (watchdog, ms)"><input type="number" min={1} className="input" value={hp.watchdogMs} onChange={e => setProp('watchdogMs', Math.max(1, parseInt(e.target.value) || 150))} /></Field>
              </div>
            )}
          </div>
          <CpuDetails cpu={cpu} />
        </div>
      </div>

      {addrFor && <AddressDialog rowId={addrFor} onClose={() => setAddrFor(null)} />}
      {picker && (
        <ModulePicker mods={allMods.filter(m => picker.kinds.includes(m.kind) && (cpu.family !== 'S7-1200' || !!m.board === !!picker.board))} slot={picker.slot} onPick={place} onClose={() => setPicker(null)} />
      )}
    </div>
  );
}

export function CpuDetails({ cpu }: { cpu: CpuDef }) {
  const rows: [string, string][] = [
    ['Article number', cpu.article],
    ['Firmware', cpu.firmware],
    ['Family', `${cpu.family} · ${cpu.sub}`],
    ['Work memory', cpu.workMem],
    ['Load memory', cpu.loadMem],
    ['Bit memory (M)', `${cpu.mBytes.toLocaleString()} bytes`],
    ['Bit operation', `${cpu.bitOpNs} ns`],
    ['Onboard I/O', cpu.onboard.di + cpu.onboard.dq + cpu.onboard.ai + cpu.onboard.aq ? `DI ${cpu.onboard.di} / DQ ${cpu.onboard.dq} / AI ${cpu.onboard.ai} / AQ ${cpu.onboard.aq}` : 'none'],
    ['Expansion', cpu.family === 'S7-1200' ? `${cpu.maxModules} signal modules` : `up to ${cpu.maxModules} modules (central)`],
    ['Interfaces', cpu.interfaces],
    ['Supply', cpu.supply],
  ];
  return (
    <div className="card p-4">
      <div className="label mb-2">Catalog information</div>
      <div className="text-sm font-semibold text-ink">{cpu.name} {cpu.variant}</div>
      <dl className="mt-2 space-y-1.5 text-xs">
        {rows.map(([k, v]) => <div key={k} className="flex gap-2"><dt className="w-28 shrink-0 text-mute">{k}</dt><dd className="text-ink font-mono text-[11px] break-words min-w-0">{v}</dd></div>)}
      </dl>
      <ul className="mt-3 space-y-1 text-[11px] text-mute list-disc pl-4">{cpu.extras.map(e => <li key={e}>{e}</li>)}</ul>
      {cpu.safety && <div className="mt-3 text-[11px] rounded-md bg-warn/10 text-warn px-2 py-1.5">Fail-safe CPU: the standard program is simulated; safety program (F-blocks) is not part of this simulator.</div>}
    </div>
  );
}

/** Phone replacement for the rack picture: one row per slot with its I/O ranges. */
function SlotList({ addrs, left, right, cpu, board, allMods, modAt, onPick, onEdit }: {
  addrs: ModuleAddr[]; left: SlotDef[]; right: SlotDef[]; cpu: CpuDef; board?: string; allMods: ModuleDef[];
  modAt: (slot: number) => { moduleId: string } | undefined;
  onPick: (slot: number, kinds: string[], board?: boolean) => void;
  onEdit: (id: string) => void;
}) {
  const remove = (slot: number) => useStore.getState().mutate(p => { p.hardware.modules = p.hardware.modules.filter(m => m.slot !== slot); });

  const Row = ({ badge, color, title, a, empty, onTap, onRemove, hint }: { badge: string; color?: string; title: string; a?: ModuleAddr; empty?: boolean; onTap: () => void; onRemove?: () => void; hint?: string }) => (
    <div role="button" tabIndex={0} onClick={onTap} onKeyDown={e => e.key === 'Enter' && onTap()}
      className={`flex items-center gap-2.5 rounded-xl border p-2.5 active:bg-panel3 ${a?.conflicts.length ? 'border-danger/60 bg-danger/5' : empty ? 'border-dashed border-line' : 'border-line bg-panel2/60'}`}>
      <div className="w-10 h-10 shrink-0 rounded-lg bg-panel3 flex items-center justify-center text-[12px] font-mono font-semibold text-ink" style={color ? { boxShadow: `inset 3px 0 0 ${color}` } : undefined}>{badge}</div>
      <div className="min-w-0 flex-1">
        <div className={`text-[14px] truncate ${empty ? 'text-mute' : 'font-medium text-ink'}`}>{title}</div>
        {a && (a.iRange || a.qRange || a.conflicts.length > 0) ? (
          <div className="flex flex-wrap gap-1 mt-1 text-[11.5px] font-mono">
            {a.iRange && <span className="px-1.5 rounded bg-on/15 text-on">I {a.iRange}</span>}
            {a.qRange && <span className="px-1.5 rounded bg-warn/15 text-warn">Q {a.qRange}</span>}
            {a.areas.some(x => x.custom) && <span className="px-1.5 rounded bg-accent/15 text-accent font-sans">custom</span>}
            {a.conflicts.length > 0 && <span className="px-1.5 rounded bg-danger/15 text-danger font-sans">conflict</span>}
          </div>
        ) : hint ? <div className="text-[12px] text-mute mt-0.5">{hint}</div> : null}
      </div>
      {empty ? <Plus size={18} className="text-mute shrink-0" /> : (
        <>
          {a && a.areas.length > 0 && <Pencil size={16} className="text-mute shrink-0" />}
          {onRemove && <button aria-label="Remove module" className="btn btn-ghost btn-icon shrink-0 hover:!text-danger" onClick={e => { e.stopPropagation(); onRemove(); }}><X size={17} /></button>}
        </>
      )}
    </div>
  );

  const slotRow = (s: SlotDef, boardRow = false) => {
    const mi = modAt(s.slot);
    const def = mi ? allMods.find(x => x.id === mi.moduleId) : undefined;
    if (!def) return <Row key={s.slot} badge={String(s.slot)} title={`Empty slot ${s.slot}`} empty hint={undefined} onTap={() => onPick(s.slot, s.kinds, boardRow)} />;
    const a = addrs.find(x => x.id === `slot-${s.slot}`);
    return <Row key={s.slot} badge={String(s.slot)} color={KIND_COLOR[def.kind]} title={def.name} a={a} onTap={() => onEdit(`slot-${s.slot}`)} onRemove={() => remove(s.slot)} />;
  };

  const cpuAddr = addrs[0];
  const boardDef = board ? allMods.find(x => x.id === board) : undefined;
  return (
    <div className="p-2.5 space-y-2">
      <Row badge="CPU" title={`${cpu.name}${cpu.variant ? ' ' + cpu.variant : ''}`} a={cpuAddr} hint="No onboard I/O" onTap={() => cpuAddr.areas.length && onEdit('cpu')} />
      {cpu.family === 'S7-1200' && (boardDef
        ? <Row badge="SB" color={KIND_COLOR[boardDef.kind]} title={boardDef.name} a={addrs.find(x => x.id === 'slot-1')} onTap={() => onEdit('slot-1')} onRemove={() => remove(1)} />
        : <Row badge="SB" title="Add signal board" empty onTap={() => onPick(1, ['DI', 'DQ', 'DIQ', 'AI', 'AQ'], true)} />)}
      {right.map(s => slotRow(s))}
      {left.length > 0 && <div className="label pt-2 px-1">{left[0].kinds.includes('PS') ? 'Power supply' : 'Communication'}</div>}
      {left.map(s => slotRow(s))}
      <p className="text-[11.5px] text-mute px-1 pt-1 leading-snug">Tap a module to set its I/O start addresses.</p>
    </div>
  );
}

/** Edit the start address of each I/O area of a module (or of the CPU's onboard I/O). */
function AddressDialog({ rowId, onClose }: { rowId: string; onClose: () => void }) {
  const project = useStore(s => s.project);
  const mutate = useStore(s => s.mutate);
  const st = useStore.getState;
  const rows = useMemo(() => computeAddresses(project.hardware), [project.hardware]);
  const row = rows.find(r => r.id === rowId);
  const [move, setMove] = useState(true);
  if (!row) return null;

  const commit = (area: IoArea, raw: string) => {
    const txt = raw.trim();
    let next: number | null;
    if (txt === '') next = null;
    else {
      const n = Math.floor(Number(txt));
      if (!Number.isFinite(n) || n < 0) { st().showToast('Enter a start address of 0 or more', 'err'); return; }
      next = Math.min(n, IO_BYTES - area.bytes);
    }
    if (next === area.auto) next = null;
    const newStart = next ?? area.auto;
    if (newStart === area.start && (next !== null) === area.custom) return;
    let moved = 0;
    mutate(p => {
      const mi = rowId === 'cpu' ? null : p.hardware.modules.find(m => `slot-${m.slot}` === rowId);
      const holder = rowId === 'cpu' ? (p.hardware.cpuStart ??= {}) : mi ? (mi.start ??= {}) : null;
      if (!holder) return;
      if (next === null) delete holder[area.key]; else holder[area.key] = next;
      if (Object.keys(holder).length === 0) { if (rowId === 'cpu') delete p.hardware.cpuStart; else if (mi) delete mi.start; }
      if (move && newStart !== area.start) moved = shiftAddresses(p, area.proc, area.start, area.start + area.bytes - 1, newStart - area.start);
    });
    st().showToast(moved ? `Start address set to ${newStart} — ${moved} tag${moved > 1 ? 's' : ''} moved` : `Start address set to ${newStart}`, 'ok');
  };

  return (
    <Modal title={`I/O addresses — ${row.name}${row.id === 'cpu' ? '' : ` (slot ${row.slot})`}`} onClose={onClose}>
      <div className="p-4 space-y-3">
        {row.areas.map(a => (
          <div key={a.key} className="rounded-xl border border-line bg-panel2/60 p-3 space-y-2">
            <div className="flex items-center gap-2">
              <div className="font-semibold text-[13.5px] flex-1">{a.label}</div>
              <span className="text-[11.5px] text-mute">{a.count} channel{a.count > 1 ? 's' : ''} · {a.bytes} byte{a.bytes > 1 ? 's' : ''}</span>
            </div>
            <div className="flex items-end gap-2">
              <label className="flex-1 min-w-0">
                <div className="label mb-1">Start address (byte)</div>
                <input key={`${a.key}-${a.start}-${a.custom}`} type="number" inputMode="numeric" min={0} max={IO_BYTES - a.bytes} defaultValue={a.start} className="input font-mono"
                  onBlur={e => commit(a, e.target.value)} onKeyDown={e => { if (e.key === 'Enter') (e.target as HTMLInputElement).blur(); }} />
              </label>
              <button className="btn" disabled={!a.custom} onClick={() => commit(a, '')}>Automatic</button>
            </div>
            <div className="text-[12px] font-mono text-mute break-words">{areaAddressText(a, a.count)}</div>
            <div className={`text-[11.5px] ${a.custom ? 'text-accent' : 'text-mute'}`}>{a.custom ? `Custom start address (automatic would be ${a.auto})` : 'Assigned automatically'}</div>
          </div>
        ))}
        <label className="flex items-start gap-2.5 text-[13px] leading-snug cursor-pointer py-1">
          <input type="checkbox" checked={move} onChange={e => setMove(e.target.checked)} className="mt-0.5 w-4 h-4 accent-[var(--c-accent)]" />
          <span>Move tags, watch rows and plant signals that use these addresses together with the module<span className="block text-[11.5px] text-mute">Keeps the program working after a change. Turn off to leave them where they are.</span></span>
        </label>
        {row.conflicts.length > 0 ? (
          <div className="rounded-lg border border-danger/50 bg-danger/10 p-2.5 text-[12.5px] text-danger space-y-1">
            <div className="flex items-center gap-1.5 font-semibold"><AlertTriangle size={14} />Address conflict</div>
            {row.conflicts.map(c => <div key={c}>{c}</div>)}
          </div>
        ) : (
          <div className="flex items-center gap-1.5 text-[12.5px] text-on"><CheckCircle2 size={14} />No address conflicts</div>
        )}
        <button className="btn btn-accent w-full justify-center !py-2.5" onClick={onClose}>Done</button>
      </div>
    </Modal>
  );
}

function ModulePicker({ mods, slot, onPick, onClose }: { mods: ModuleDef[]; slot: number; onPick: (m: ModuleDef) => void; onClose: () => void }) {
  return (
    <div className="fixed inset-0 z-50 bg-black/50 backdrop-blur-sm flex items-end sm:items-center justify-center p-0 sm:p-6" onClick={onClose}>
      <div className="card w-full sm:max-w-2xl max-h-[80vh] flex flex-col anim-in rounded-b-none sm:rounded-b-xl" onClick={e => e.stopPropagation()}>
        <div className="flex items-center px-4 py-3 border-b border-line"><div className="font-semibold text-sm">Hardware catalog — slot {slot}</div><button className="ml-auto btn btn-ghost btn-icon" onClick={onClose}><X size={16} /></button></div>
        <div className="overflow-y-auto p-2 grid sm:grid-cols-2 gap-1.5">
          {mods.map(m => (
            <button key={m.id} onClick={() => onPick(m)} className="text-left rounded-lg border border-line bg-panel2 hover:border-accent/60 hover:bg-panel3 p-2.5 flex gap-2.5 transition-colors">
              <span className="w-1.5 rounded-full shrink-0" style={{ background: KIND_COLOR[m.kind] }} />
              <span className="min-w-0">
                <span className="block text-[12.5px] font-semibold text-ink">{m.name}</span>
                <span className="block text-[10.5px] font-mono text-mute">{m.article}</span>
                <span className="block text-[11px] text-mute mt-0.5">{m.desc}</span>
              </span>
            </button>
          ))}
          {!mods.length && <div className="text-sm text-mute p-4">No modules available for this slot.</div>}
        </div>
      </div>
    </div>
  );
}

export function CpuCatalogDialog() {
  const project = useStore(s => s.project);
  const mutate = useStore(s => s.mutate);
  const st = useStore.getState;
  const cur = cpuById(project.hardware.cpuId);
  const [fam, setFam] = useState(cur.family);
  const [selId, setSelId] = useState(cur.id);
  const [q, setQ] = useState('');
  const sel = cpuById(selId);
  const list = CPUS.filter(c => c.family === fam && `${c.name} ${c.variant} ${c.article}`.toLowerCase().includes(q.toLowerCase()));
  const subs = Array.from(new Set(list.map(c => c.sub)));

  const apply = () => {
    const changeFam = sel.modFamily !== cur.modFamily;
    mutate(p => {
      p.hardware.cpuId = sel.id;
      delete p.hardware.cpuStart;
      if (changeFam) p.hardware.modules = [];
      else {
        const r = slotRange(sel);
        p.hardware.modules = p.hardware.modules.filter(m => m.slot === 1 || m.slot >= 100 || m.slot === 0 || (m.slot >= r.first && m.slot <= r.last));
      }
      if (sel.family === 'S7-300' || sel.family === 'S7-400') p.hardware.props.sysEnabled = false;
    });
    st().set({ dialog: null });
    st().showToast(`Device changed to ${sel.name} ${sel.variant}${changeFam ? ' — modules removed (different family)' : ''}`, 'ok');
  };

  return (
    <div className="fixed inset-0 z-50 bg-black/55 backdrop-blur-sm flex items-end sm:items-center justify-center sm:p-6" onClick={() => st().set({ dialog: null })}>
      <div className="card w-full sm:max-w-5xl h-[88vh] sm:h-[80vh] flex flex-col anim-in rounded-b-none sm:rounded-b-xl overflow-hidden" onClick={e => e.stopPropagation()}>
        <div className="flex items-center gap-2 px-4 py-3 border-b border-line">
          <Cpu size={16} className="text-accent" /><div className="font-semibold text-sm">Change device — CPU catalog</div>
          <button className="ml-auto btn btn-ghost btn-icon" onClick={() => st().set({ dialog: null })}><X size={16} /></button>
        </div>
        <div className="flex gap-1 px-3 pt-2 overflow-x-auto">
          {FAMILIES.map(f => <button key={f} onClick={() => setFam(f)} className={`tab ${fam === f ? 'tab-active' : ''}`}>SIMATIC {f}</button>)}
        </div>
        <div className="flex-1 min-h-0 grid md:grid-cols-[1fr_360px]">
          <div className="flex flex-col min-h-0 border-r border-line">
            <div className="p-2 relative"><Search size={13} className="absolute left-4 top-1/2 -translate-y-1/2 text-mute" /><input className="input !pl-7" placeholder="Filter by name or article number" value={q} onChange={e => setQ(e.target.value)} /></div>
            <div className="flex-1 overflow-y-auto px-2 pb-2">
              {subs.map(sub => (
                <div key={sub} className="mb-2">
                  <div className="label px-1 py-1.5">{sub}</div>
                  <div className="grid sm:grid-cols-2 gap-1.5">
                    {list.filter(c => c.sub === sub).map(c => (
                      <button key={c.id} onClick={() => setSelId(c.id)} onDoubleClick={apply}
                        className={`text-left rounded-lg border p-2.5 transition-colors ${selId === c.id ? 'border-accent bg-accent/10' : 'border-line bg-panel2 hover:bg-panel3'}`}>
                        <div className="flex items-center gap-1.5"><span className="text-[12.5px] font-semibold text-ink">{c.name}</span>{c.variant && <span className="text-[10px] px-1.5 rounded bg-panel3 text-accent font-mono">{c.variant}</span>}{c.id === cur.id && <Check size={13} className="text-on ml-auto" />}</div>
                        <div className="text-[10.5px] font-mono text-mute">{c.article}</div>
                        <div className="text-[10.5px] text-mute mt-0.5 truncate">{c.workMem}</div>
                      </button>
                    ))}
                  </div>
                </div>
              ))}
            </div>
          </div>
          <div className="hidden md:flex flex-col min-h-0 overflow-y-auto p-3 gap-3">
            <CpuFacePreview cpu={sel} />
            <CpuDetails cpu={sel} />
          </div>
        </div>
        <div className="flex items-center gap-2 px-4 py-3 border-t border-line">
          <span className="text-xs text-mute truncate md:hidden">{sel.name} {sel.variant} · {sel.article}</span>
          <div className="flex-1" />
          <button className="btn" onClick={() => st().set({ dialog: null })}>Cancel</button>
          <button className="btn btn-accent" onClick={apply}><Check size={14} />Use this CPU</button>
        </div>
      </div>
    </div>
  );
}

function CpuFacePreview({ cpu }: { cpu: CpuDef }) {
  return (
    <div className="rounded-xl p-4 bg-gradient-to-b from-[#3b4148] to-[#22272d] text-white border border-black/40 relative overflow-hidden">
      <div className="absolute inset-x-0 top-0 h-1.5" style={{ background: cpu.family === 'S7-1200' ? '#00a19a' : cpu.family === 'S7-1500' ? '#009999' : '#7c8a96' }} />
      <div className="text-[10px] tracking-[0.25em] text-white/50 font-bold">SIEMENS</div>
      <div className="text-lg font-semibold">{cpu.name}</div>
      <div className="text-xs text-white/60">{cpu.variant || cpu.sub}</div>
      <div className="mt-3 flex gap-1 flex-wrap">
        {Array.from({ length: Math.min(cpu.onboard.di, 16) }).map((_, i) => <span key={`i${i}`} className="w-2 h-2 rounded-full bg-[#3ddc84]/40" />)}
        {Array.from({ length: Math.min(cpu.onboard.dq, 16) }).map((_, i) => <span key={`q${i}`} className="w-2 h-2 rounded-full bg-[#f2b84b]/40" />)}
      </div>
    </div>
  );
}
