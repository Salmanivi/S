import { useEffect, useRef, useState } from 'react';
import { Pencil, Hand, Plus, Trash2, Copy, X, ZoomIn, ZoomOut, RotateCcw, Cable, ArrowRight, ArrowLeft, Factory } from 'lucide-react';
import { useStore, getResolver } from '../store';
import { DEVICE_DEFS, DEVICE_MAP, DEVICE_CATEGORIES, getSt, plantState, cfgOf } from '../plant/devices';
import { DeviceVisual } from '../plant/DeviceVisual';
import type { PlantDevice, Project } from '../types';
import { uid } from '../plc/ladder';
import { computeAddresses } from '../catalog/hardware';
import { normalizeAddress } from '../plc/values';
import { Field } from './TaskCards';
import { useIsPhone } from './Sheet';

const HEADER = 22;
const snap = (v: number) => Math.max(0, Math.round(v / 10) * 10);

function usedAddresses(p: Project): Set<string> {
  const used = new Set(p.tags.map(t => normalizeAddress(t.address)));
  const res = getResolver(p);
  p.devices.forEach(d => Object.values(d.bind).forEach(s => {
    if (!s) return;
    const r = res.resolve(s);
    if (r.k === 'mem') used.add(r.a.size === 'X' ? `%${r.a.area}${r.a.byte}.${r.a.bit}` : `%${r.a.area}${r.a.size}${r.a.byte}`);
  }));
  return used;
}

export function autoWire(devId: string) {
  const st = useStore.getState();
  let wired = 0, missing = 0;
  st.mutate(p => {
    const dev = p.devices.find(d => d.id === devId);
    if (!dev) return;
    const def = DEVICE_MAP[dev.type];
    const used = usedAddresses(p);
    const chans = computeAddresses(p.hardware).flatMap(m => m.channels);
    for (const b of def.binds) {
      if (dev.bind[b.key]?.trim()) continue;
      if (b.optional && b.key !== 'fb' && b.key !== 'sRet' && b.key !== 'sExt' && b.key !== 'lvl' && b.key !== 'temp') continue;
      const kind = b.kind === 'bool' ? (b.dir === 'toPlc' ? 'DI' : 'DQ') : (b.dir === 'toPlc' ? 'AI' : 'AQ');
      const ch = chans.find(c => c.kind === kind && !used.has(c.address));
      if (!ch) { missing++; continue; }
      used.add(ch.address);
      let name = `${dev.name}_${b.key}`.replace(/[^\w]+/g, '_').replace(/^(\d)/, '_$1');
      let k = 2;
      while (p.tags.some(t => t.name.toLowerCase() === name.toLowerCase())) name = `${dev.name}_${b.key}_${k++}`.replace(/[^\w]+/g, '_');
      p.tags.push({ id: uid('t'), name, dataType: b.kind === 'bool' ? 'Bool' : 'Int', address: ch.address, comment: `${def.name}: ${b.label}` });
      dev.bind[b.key] = name;
      wired++;
    }
  }, true);
  st.showToast(wired ? `${wired} signal${wired > 1 ? 's' : ''} wired to free I/O channels${missing ? ` — ${missing} without free channel (add modules)` : ''}` : missing ? 'No free I/O channels — add signal modules in Device configuration' : 'All signals already wired', wired ? 'ok' : 'info');
}

function DeviceCard({ dev, edit, selected, pos, onPointerDown }: { dev: PlantDevice; edit: boolean; selected: boolean; pos: { x: number; y: number }; onPointerDown: (e: React.PointerEvent) => void }) {
  const def = DEVICE_MAP[dev.type];
  const st = getSt(dev.id);
  if (!def) return null;
  const isLabel = dev.type === 'label';
  const operate = !edit;

  const handlers: React.HTMLAttributes<HTMLDivElement> = {};
  if (operate) {
    if (dev.type === 'pushbutton') {
      handlers.onPointerDown = e => { (e.currentTarget as HTMLElement).setPointerCapture(e.pointerId); st.pressed = true; };
      handlers.onPointerUp = () => { st.pressed = false; };
      handlers.onPointerCancel = () => { st.pressed = false; };
    } else if (dev.type === 'switch' || dev.type === 'keyswitch' || dev.type === 'sensor' || dev.type === 'limit') {
      handlers.onClick = () => { st.on = !st.on; };
    } else if (dev.type === 'estop') {
      handlers.onClick = () => { st.pressed = !st.pressed; };
    } else if (dev.type === 'selector3') {
      handlers.onClick = e => { const r = (e.currentTarget as HTMLElement).getBoundingClientRect(); const fx = (e.clientX - r.left) / r.width; st.pos = fx < 0.36 ? -1 : fx > 0.64 ? 1 : 0; };
    }
  }

  return (
    <div className={`absolute select-none ${isLabel ? '' : 'card shadow-lg'} ${selected ? 'ring-2 ring-accent' : ''} ${edit ? 'cursor-move' : ''} transition-shadow`}
      style={{ left: pos.x, top: pos.y, width: def.w, height: isLabel ? def.h : def.h + HEADER, touchAction: edit ? 'none' : 'auto' }}
      onPointerDown={edit ? onPointerDown : undefined}>
      {!isLabel && (
        <div className="h-[22px] px-2 flex items-center gap-1.5 border-b border-line text-[10.5px] text-mute bg-panel2 rounded-t-xl">
          <span className="truncate flex-1 font-medium text-ink/80">{dev.name}</span>
          {(dev.type === 'motor' || dev.type === 'vfd') && operate && (
            <button className={`px-1 rounded text-[9px] font-bold ${st.trip ? 'bg-danger text-white' : 'bg-panel3 text-mute'}`} onClick={e => { e.stopPropagation(); st.trip = !st.trip; }} title="Simulate overload / fault">{st.trip ? 'TRIP' : 'OL'}</button>
          )}
          {dev.type === 'conveyor' && operate && (
            <button className="px-1.5 rounded text-[9px] font-bold bg-panel3 text-accent" onClick={e => { e.stopPropagation(); const items = st.items ?? (st.items = []); if (!items.some(p => p < 0.12)) items.push(0.02); }}>+ PART</button>
          )}
          {dev.type === 'tank' && operate && (
            <button className="px-1.5 rounded text-[9px] font-bold bg-panel3 text-mute" onClick={e => { e.stopPropagation(); st.level = 0; }}>EMPTY</button>
          )}
        </div>
      )}
      <div className={`relative ${operate && Object.keys(handlers).length ? 'cursor-pointer' : ''}`} style={{ height: def.h }} {...handlers}>
        {dev.type === 'pot' ? (
          <div className="p-3 space-y-2">
            <div className="flex justify-between text-[11px]"><span className="text-mute">{String(cfgOf(dev, 'label'))}</span><span className="font-mono text-accent">{(((st.value ?? 0) * Number(cfgOf(dev, 'eu') ?? 100))).toFixed(1)} {String(cfgOf(dev, 'unit'))}</span></div>
            <input type="range" min={0} max={1000} value={Math.round((st.value ?? 0) * 1000)} disabled={edit} onChange={e => { st.value = parseInt(e.target.value) / 1000; }} className="w-full accent-[var(--c-accent)]" onPointerDown={e => e.stopPropagation()} />
            <div className="text-[10px] font-mono text-mute">raw: {Math.round((st.value ?? 0) * Number(cfgOf(dev, 'max') ?? 27648))}</div>
          </div>
        ) : dev.type === 'numinput' ? (
          <div className="p-3 space-y-1.5">
            <div className="text-[11px] text-mute">{String(cfgOf(dev, 'label'))}</div>
            <input type="number" disabled={edit} className="input font-mono" defaultValue={st.value ?? 0} min={Number(cfgOf(dev, 'min'))} max={Number(cfgOf(dev, 'max'))}
              onPointerDown={e => e.stopPropagation()}
              onChange={e => { const v = parseInt(e.target.value); if (Number.isFinite(v)) st.value = Math.max(Number(cfgOf(dev, 'min')), Math.min(Number(cfgOf(dev, 'max')), v)); }} />
          </div>
        ) : <DeviceVisual dev={dev} w={def.w} h={def.h} />}
      </div>
    </div>
  );
}

export function PlantView() {
  const project = useStore(s => s.project);
  const edit = useStore(s => s.plantEdit);
  const selId = useStore(s => s.plantSel);
  useStore(s => s.tick);
  const mutate = useStore(s => s.mutate);
  const st = useStore.getState;
  const [zoom, setZoom] = useState(1);
  const [lib, setLib] = useState(false);
  const [tmp, setTmp] = useState<{ id: string; x: number; y: number } | null>(null);
  const drag = useRef<{ id: string; sx: number; sy: number; ox: number; oy: number; moved: boolean } | null>(null);
  const scroller = useRef<HTMLDivElement>(null);
  const phone = useIsPhone();
  // on a phone, open zoomed out so all devices are visible without scrolling sideways
  useEffect(() => {
    const sc = scroller.current;
    if (!phone || !sc || !project.devices.length) return;
    const right = Math.max(...project.devices.map(d => d.x + (DEVICE_MAP[d.type]?.w ?? 100))) + 24;
    setZoom(+Math.min(1, Math.max(0.5, sc.clientWidth / right)).toFixed(2));
    // only when entering phone mode / opening the view, not on every device move
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [phone]);
  const sel = project.devices.find(d => d.id === selId) ?? null;

  const W = Math.max(1600, ...project.devices.map(d => d.x + (DEVICE_MAP[d.type]?.w ?? 100) + 200));
  const H = Math.max(1000, ...project.devices.map(d => d.y + (DEVICE_MAP[d.type]?.h ?? 100) + 200));

  const addDevice = (type: string) => {
    const def = DEVICE_MAP[type];
    const sc = scroller.current;
    const x = snap(((sc?.scrollLeft ?? 0) + 60) / zoom + Math.random() * 40);
    const y = snap(((sc?.scrollTop ?? 0) + 60) / zoom + Math.random() * 40);
    const cfg: PlantDevice['cfg'] = {};
    def.cfg.forEach(c => (cfg[c.key] = c.def));
    const count = project.devices.filter(d => d.type === type).length + 1;
    const dev: PlantDevice = { id: uid('d'), type, name: `${def.name.split(' (')[0]} ${count}`, x, y, bind: {}, cfg };
    mutate(p => { p.devices.push(dev); }, false);
    st().set({ plantEdit: true, plantSel: dev.id });
    setLib(false);
  };

  const onDown = (dev: PlantDevice) => (e: React.PointerEvent) => {
    e.stopPropagation();
    (e.currentTarget as HTMLElement).setPointerCapture(e.pointerId);
    drag.current = { id: dev.id, sx: e.clientX, sy: e.clientY, ox: dev.x, oy: dev.y, moved: false };
    st().set({ plantSel: dev.id });
  };
  const onMove = (e: React.PointerEvent) => {
    const d = drag.current;
    if (!d) return;
    const dx = (e.clientX - d.sx) / zoom, dy = (e.clientY - d.sy) / zoom;
    if (Math.abs(dx) + Math.abs(dy) > 3) d.moved = true;
    if (d.moved) setTmp({ id: d.id, x: snap(d.ox + dx), y: snap(d.oy + dy) });
  };
  const onUp = () => {
    const d = drag.current;
    drag.current = null;
    if (d && d.moved && tmp) {
      const t = tmp;
      mutate(p => { const dv = p.devices.find(x => x.id === t.id); if (dv) { dv.x = t.x; dv.y = t.y; } }, false);
    }
    setTmp(null);
  };

  return (
    <div className="flex h-full min-h-0 relative">
      <div className="flex-1 flex flex-col min-w-0">
        <div className="flex items-center gap-1.5 px-2 py-1.5 border-b border-line bg-panel overflow-x-auto shrink-0">
          <Factory size={16} className="text-accent ml-1" />
          <span className="text-sm font-semibold mr-2 whitespace-nowrap hidden sm:inline">Plant simulation</span>
          <div className="flex p-0.5 rounded-lg bg-bg border border-line text-[11px] max-lg:text-[13px] shrink-0">
            <button onClick={() => st().set({ plantEdit: false, plantSel: null })} className={`flex items-center gap-1 px-2 py-1 max-lg:px-3 max-lg:py-2 rounded-md ${!edit ? 'bg-on/15 text-on' : 'text-mute'}`}><Hand size={12} />Operate</button>
            <button onClick={() => st().set({ plantEdit: true })} className={`flex items-center gap-1 px-2 py-1 max-lg:px-3 max-lg:py-2 rounded-md ${edit ? 'bg-accent/15 text-accent' : 'text-mute'}`}><Pencil size={12} />Edit</button>
          </div>
          <button className="btn btn-accent shrink-0" onClick={() => setLib(true)}><Plus size={14} />Add device</button>
          <div className="flex-1" />
          <button className="btn btn-ghost btn-icon" title="Reset plant state" onClick={() => { plantState.clear(); st().showToast('Plant state reset', 'info'); }}><RotateCcw size={15} /></button>
          <button className="btn btn-ghost btn-icon" onClick={() => setZoom(z => Math.max(0.4, +(z - 0.1).toFixed(2)))}><ZoomOut size={15} /></button>
          <span className="text-[11px] text-mute w-9 text-center">{Math.round(zoom * 100)}%</span>
          <button className="btn btn-ghost btn-icon" onClick={() => setZoom(z => Math.min(2, +(z + 0.1).toFixed(2)))}><ZoomIn size={15} /></button>
        </div>
        <div ref={scroller} className="flex-1 overflow-auto bg-bg" onPointerMove={onMove} onPointerUp={onUp} onPointerCancel={onUp} onClick={() => edit && st().set({ plantSel: null })}>
          <div style={{ width: W * zoom, height: H * zoom }} className="relative">
            <div className="absolute top-0 left-0 grid-bg origin-top-left" style={{ width: W, height: H, transform: `scale(${zoom})` }}>
              {project.devices.map(d => (
                <div key={d.id} onClick={e => e.stopPropagation()}>
                  <DeviceCard dev={d} edit={edit} selected={edit && selId === d.id} pos={tmp?.id === d.id ? tmp : d} onPointerDown={onDown(d)} />
                </div>
              ))}
              {project.devices.length === 0 && (
                <div className="absolute left-10 top-10 max-w-md card p-5 text-sm">
                  <div className="font-semibold mb-1">Build your machine</div>
                  <p className="text-mute text-xs leading-relaxed">Add push buttons, sensors, motors, tanks, conveyors, cylinders, drives… then bind them to PLC tags. Use <b>Auto-wire</b> to connect a device to free I/O channels in one click.</p>
                  <button className="btn btn-accent mt-3" onClick={() => setLib(true)}><Plus size={14} />Add first device</button>
                </div>
              )}
            </div>
          </div>
        </div>
      </div>

      {edit && sel && <DeviceProps dev={sel} />}

      {lib && (
        <div className="fixed inset-0 z-50 bg-black/50 backdrop-blur-sm flex items-end sm:items-center justify-center sm:p-6" onClick={() => setLib(false)}>
          <div className="card w-full sm:max-w-3xl max-h-[85vh] flex flex-col anim-in rounded-b-none sm:rounded-b-xl" onClick={e => e.stopPropagation()}>
            <div className="flex items-center px-4 py-3 border-b border-line"><div className="font-semibold text-sm">Device library</div><button className="ml-auto btn btn-ghost btn-icon" onClick={() => setLib(false)}><X size={16} /></button></div>
            <div className="overflow-y-auto p-3 space-y-4">
              {DEVICE_CATEGORIES.map(cat => (
                <div key={cat}>
                  <div className="label mb-1.5">{cat}</div>
                  <div className="grid grid-cols-2 sm:grid-cols-3 gap-1.5">
                    {DEVICE_DEFS.filter(d => d.category === cat).map(d => (
                      <button key={d.type} onClick={() => addDevice(d.type)} className="text-left rounded-lg border border-line bg-panel2 hover:border-accent/60 hover:bg-panel3 p-2.5 transition-colors">
                        <div className="text-[12.5px] font-semibold text-ink">{d.name}</div>
                        <div className="text-[10.5px] text-mute leading-snug mt-0.5 line-clamp-2">{d.desc}</div>
                      </button>
                    ))}
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>
      )}
    </div>
  );
}

function DeviceProps({ dev }: { dev: PlantDevice }) {
  const project = useStore(s => s.project);
  const mutate = useStore(s => s.mutate);
  const st = useStore.getState;
  const def = DEVICE_MAP[dev.type];
  const res = getResolver(project);
  const set = (fn: (d: PlantDevice) => void, program = false) => mutate(p => { const d = p.devices.find(x => x.id === dev.id); if (d) fn(d); }, program);

  return (
    <div className="absolute inset-x-0 bottom-0 max-h-[60%] lg:max-h-none lg:static lg:w-[310px] z-30 border-t lg:border-t-0 lg:border-l border-line bg-panel flex flex-col shadow-2xl lg:shadow-none anim-in">
      <div className="flex items-center gap-2 px-3 py-2 border-b border-line">
        <span className="text-sm font-semibold truncate flex-1">{def.name}</span>
        <button className="btn btn-ghost btn-icon" title="Duplicate" onClick={() => {
          const copy: PlantDevice = { ...structuredClone(dev), id: uid('d'), x: dev.x + 30, y: dev.y + 30, name: dev.name + ' copy', bind: {} };
          mutate(p => { p.devices.push(copy); }, false);
          st().set({ plantSel: copy.id });
        }}><Copy size={14} /></button>
        <button className="btn btn-ghost btn-icon hover:!text-danger" title="Delete" onClick={() => { mutate(p => { p.devices = p.devices.filter(x => x.id !== dev.id); }, false); st().set({ plantSel: null }); }}><Trash2 size={14} /></button>
        <button className="btn btn-ghost btn-icon" onClick={() => st().set({ plantSel: null })}><X size={14} /></button>
      </div>
      <div className="flex-1 overflow-y-auto p-3 space-y-3">
        <p className="text-[11px] text-mute leading-relaxed">{def.desc}</p>
        <Field label="Name"><input className="input" key={dev.id + 'n'} defaultValue={dev.name} onBlur={e => set(d => { d.name = e.target.value; })} /></Field>
        {def.binds.length > 0 && (
          <div className="space-y-2">
            <div className="flex items-center"><span className="label flex-1">Signals (PLC tag / address)</span>
              <button className="btn btn-accent !py-0.5 !text-[11px]" onClick={() => autoWire(dev.id)}><Cable size={12} />Auto-wire</button>
            </div>
            {def.binds.map(b => {
              const v = dev.bind[b.key] ?? '';
              const r = v ? res.resolve(v) : null;
              const err = r?.k === 'err' ? r.msg : r && r.k === 'mem' && ((b.kind === 'bool') !== (r.a.size === 'X')) ? `${b.kind === 'bool' ? 'Bool' : 'Word'} address required` : r?.k === 'const' ? 'Constant not allowed' : null;
              const addr = r?.k === 'mem' ? (r.a.size === 'X' ? `%${r.a.area}${r.a.byte}.${r.a.bit}` : `%${r.a.area}${r.a.size}${r.a.byte}`) : '';
              return (
                <div key={b.key}>
                  <div className="flex items-center gap-1 text-[11px] text-ink/90 mb-0.5">
                    {b.dir === 'toPlc' ? <ArrowRight size={11} className="text-on" /> : <ArrowLeft size={11} className="text-warn" />}
                    <span className="flex-1">{b.label}</span>{b.optional && <span className="text-[9px] text-mute">optional</span>}
                  </div>
                  <div className="flex gap-1 items-center">
                    <input list="dl-tags" key={dev.id + b.key + v} defaultValue={v} placeholder={b.kind === 'bool' ? (b.dir === 'toPlc' ? '%I0.0 or tag' : '%Q0.0 or tag') : (b.dir === 'toPlc' ? '%IW64' : '%QW64')}
                      className={`input font-mono !text-[11.5px] ${err ? '!border-danger/70' : ''}`}
                      onBlur={e => e.target.value !== v && set(d => { d.bind[b.key] = e.target.value.trim(); })} onKeyDown={e => e.key === 'Enter' && (e.target as HTMLInputElement).blur()} />
                    {addr && addr !== normalizeAddress(v) && <span className="text-[10px] font-mono text-mute shrink-0">{addr}</span>}
                  </div>
                  {err && <div className="text-[10.5px] text-danger mt-0.5">{err}</div>}
                </div>
              );
            })}
          </div>
        )}
        {def.cfg.length > 0 && (
          <div className="space-y-2">
            <div className="label">Configuration</div>
            {def.cfg.map(c => {
              const v = dev.cfg[c.key] ?? c.def;
              return (
                <Field key={c.key} label={c.label}>
                  {c.type === 'select' || c.type === 'color' ? (
                    <select className="input" value={String(v)} onChange={e => set(d => { d.cfg[c.key] = e.target.value; })}>{(c.options ?? []).map(o => <option key={o}>{o}</option>)}</select>
                  ) : c.type === 'bool' ? (
                    <input type="checkbox" checked={!!v} onChange={e => set(d => { d.cfg[c.key] = e.target.checked; })} className="accent-[var(--c-accent)]" />
                  ) : (
                    <input className="input" type={c.type === 'number' ? 'number' : 'text'} key={dev.id + c.key + String(v)} defaultValue={String(v)} step="any"
                      onBlur={e => set(d => { d.cfg[c.key] = c.type === 'number' ? (parseFloat(e.target.value) || 0) : e.target.value; })} />
                  )}
                </Field>
              );
            })}
          </div>
        )}
      </div>
    </div>
  );
}
