import { useMemo, useState } from 'react';
import { Plus, Trash2, Tags, Eye, Zap, Search, Wand2, ToggleLeft } from 'lucide-react';
import { useStore, getResolver } from '../store';
import { ALL_TYPES, type DataType, type Tag, type WatchRow } from '../types';
import { parseAddress, sizeOfType, normalizeAddress, formatValue, parseConstant, parseTime } from '../plc/values';
import { nextFreeAddress, uniqueTagName, tagTypeForSize } from '../plc/tags';
import { computeAddresses } from '../catalog/hardware';
import { runtime } from '../plc/runtime';
import { refType } from '../plc/resolve';
import { uid } from '../plc/ladder';
import { useIsPhone } from './Sheet';

const dotClass = (area?: string) => (area === 'I' ? 'bg-on' : area === 'Q' ? 'bg-warn' : 'bg-accent2');

export function TagTable() {
  const project = useStore(s => s.project);
  const mutate = useStore(s => s.mutate);
  const monitoring = useStore(s => s.monitoring);
  useStore(s => (s.monitoring ? s.tick : 0));
  const [q, setQ] = useState('');
  const phone = useIsPhone();
  const st = useStore.getState;
  const res = getResolver(project);

  const dupes = useMemo(() => {
    const c = new Map<string, number>();
    project.tags.forEach(t => c.set(t.name.trim().toLowerCase(), (c.get(t.name.trim().toLowerCase()) ?? 0) + 1));
    return c;
  }, [project.tags]);

  const setTag = (id: string, fn: (t: Tag) => void) => mutate(p => { const t = p.tags.find(x => x.id === id); if (t) fn(t); });
  const add = () => mutate(p => { p.tags.push({ id: uid('t'), name: uniqueTagName(p.tags), dataType: 'Bool', address: nextFreeAddress(p.tags, 'Bool'), comment: '' }); });
  const remove = (id: string) => mutate(p => { p.tags = p.tags.filter(x => x.id !== id); });
  const genIO = () => {
    let n = 0;
    mutate(p => {
      const used = new Set(p.tags.map(t => normalizeAddress(t.address)));
      computeAddresses(p.hardware).forEach(m => m.channels.forEach(c => {
        if (used.has(c.address)) return;
        const name = `${c.kind}_${c.address.replace('%', '').replace('.', '_')}`;
        if (p.tags.some(t => t.name.toLowerCase() === name.toLowerCase())) return;
        p.tags.push({ id: uid('t'), name, dataType: c.kind === 'AI' || c.kind === 'AQ' ? 'Int' : 'Bool', address: c.address, comment: c.label });
        n++;
      }));
    });
    st().showToast(n ? `${n} I/O tags generated from hardware configuration` : 'All hardware channels already have tags', 'info');
  };

  // changing the address to a different size also switches the data type (auto data type)
  const commitAddress = (t: Tag, raw: string) => {
    const addr = normalizeAddress(raw);
    const a = parseAddress(addr);
    const retype = a && sizeOfType(t.dataType) !== a.size ? tagTypeForSize(a.size) : null;
    setTag(t.id, x => { x.address = addr; if (retype) x.dataType = retype; });
    if (retype) st().showToast(`Data type set to ${retype} to fit ${addr}`, 'info');
  };
  const changeType = (t: Tag, dt: DataType) => setTag(t.id, x => {
    x.dataType = dt;
    const cur = parseAddress(x.address);
    if (cur && sizeOfType(dt) !== cur.size) x.address = nextFreeAddress(project.tags.filter(o => o.id !== t.id), dt, cur.area);
  });

  const list = project.tags.filter(t => !q || `${t.name} ${t.address} ${t.comment}`.toLowerCase().includes(q.toLowerCase()));
  const online = monitoring && runtime.mode === 'RUN';

  const info = (t: Tag) => {
    const a = parseAddress(t.address);
    const addrErr = !a ? 'Invalid address' : sizeOfType(t.dataType) !== a.size ? `${t.dataType} does not fit ${normalizeAddress(t.address)}` : '';
    const nameErr = !t.name.trim() ? 'Name required' : (dupes.get(t.name.trim().toLowerCase()) ?? 0) > 1 ? 'Duplicate name' : !/^[A-Za-z_][\w ]*$/.test(t.name.trim()) ? 'Invalid name' : '';
    let mon = '';
    if (online && !addrErr) {
      const r = res.resolve(t.name);
      if (r.k === 'mem') mon = formatValue(runtime.readRef(r, t.dataType), t.dataType);
    }
    return { a, addrErr, nameErr, mon };
  };

  return (
    <div className="flex flex-col h-full min-h-0">
      <div className="flex flex-wrap items-center gap-2 px-3 py-2 border-b border-line bg-panel">
        <Tags size={16} className="text-accent" /><h2 className="text-sm font-semibold">PLC tags <span className="text-mute font-normal">— Default tag table ({project.tags.length})</span></h2>
        <div className="flex-1 max-lg:hidden" />
        <div className="relative max-lg:w-full max-lg:order-last"><Search size={13} className="absolute left-2.5 top-1/2 -translate-y-1/2 text-mute" /><input className="input !pl-8 lg:!w-44" placeholder="Filter" type="search" value={q} onChange={e => setQ(e.target.value)} /></div>
        <button className="btn max-lg:flex-1 justify-center" onClick={genIO} title="Create tags for all configured I/O channels"><Wand2 size={14} />I/O tags</button>
        <button className="btn btn-accent max-lg:flex-1 justify-center" onClick={add}><Plus size={14} />Add tag</button>
      </div>

      {phone ? (
        <div className="flex-1 overflow-y-auto overscroll-contain p-2.5 space-y-2.5">
          {list.map(t => {
            const { a, addrErr, nameErr, mon } = info(t);
            return (
              <div key={t.id} className="rounded-xl border border-line bg-panel p-2.5 space-y-2">
                <div className="flex items-center gap-1.5">
                  <span className={`shrink-0 w-2.5 h-2.5 rounded-full ml-0.5 ${dotClass(a?.area)}`} />
                  <input key={t.id + t.name} defaultValue={t.name} aria-label="Tag name" className={`input font-semibold ${nameErr ? '!border-danger/70' : ''}`}
                    onBlur={e => e.target.value !== t.name && setTag(t.id, x => { x.name = e.target.value.trim(); })} onKeyDown={e => e.key === 'Enter' && (e.target as HTMLInputElement).blur()} />
                  {online && mon && <span className="shrink-0 font-mono text-[13px] text-on px-1">{mon}</span>}
                  <button className="btn btn-ghost btn-icon shrink-0 hover:!text-danger" aria-label={`Delete ${t.name}`} onClick={() => remove(t.id)}><Trash2 size={16} /></button>
                </div>
                <div className="grid grid-cols-2 gap-2">
                  <label><div className="label mb-0.5">Data type</div>
                    <select value={t.dataType} className="input" onChange={e => changeType(t, e.target.value as DataType)}>{ALL_TYPES.map(d => <option key={d}>{d}</option>)}</select></label>
                  <label><div className="label mb-0.5">Address</div>
                    <input key={t.id + t.address} defaultValue={t.address} autoCapitalize="characters" autoCorrect="off" spellCheck={false} className={`input font-mono ${addrErr ? '!border-danger/70' : ''}`}
                      onBlur={e => e.target.value !== t.address && commitAddress(t, e.target.value)} onKeyDown={e => e.key === 'Enter' && (e.target as HTMLInputElement).blur()} /></label>
                </div>
                {(nameErr || addrErr) && <div className="text-[12px] text-danger">{nameErr || addrErr}</div>}
                <input key={t.id + t.comment} defaultValue={t.comment} placeholder="Comment" aria-label="Comment" className="input text-mute"
                  onBlur={e => e.target.value !== t.comment && setTag(t.id, x => { x.comment = e.target.value; })} />
              </div>
            );
          })}
          {list.length === 0 && <div className="text-center text-sm text-mute py-8">{q ? 'No tag matches the filter.' : 'No tags yet.'}</div>}
          <button className="w-full btn btn-ghost text-mute justify-center !py-3" onClick={add}><Plus size={15} />Add new tag</button>
          <div className="h-2" />
        </div>
      ) : (
        <div className="flex-1 overflow-auto">
          <table className="w-full text-xs min-w-[720px]">
            <thead className="sticky top-0 bg-panel2 text-mute z-10">
              <tr>
                <th className="w-8 px-2 py-2"></th>
                <th className="text-left font-medium px-2 py-2">Name</th>
                <th className="text-left font-medium px-2 py-2 w-28">Data type</th>
                <th className="text-left font-medium px-2 py-2 w-28">Address</th>
                {online && <th className="text-left font-medium px-2 py-2 w-28">Monitor value</th>}
                <th className="text-left font-medium px-2 py-2">Comment</th>
                <th className="w-10"></th>
              </tr>
            </thead>
            <tbody>
              {list.map(t => {
                const { a, addrErr, nameErr, mon } = info(t);
                return (
                  <tr key={t.id} className="border-t border-line hover:bg-panel2/50 group">
                    <td className="px-2 text-center"><span className={`inline-block w-2 h-2 rounded-full ${dotClass(a?.area)}`} /></td>
                    <td className="px-1 py-0.5"><input key={t.id + t.name} defaultValue={t.name} title={nameErr} className={`input !bg-transparent !border-transparent hover:!border-line focus:!border-accent ${nameErr ? '!text-danger' : ''}`} onBlur={e => e.target.value !== t.name && setTag(t.id, x => { x.name = e.target.value.trim(); })} onKeyDown={e => e.key === 'Enter' && (e.target as HTMLInputElement).blur()} /></td>
                    <td className="px-1 py-0.5">
                      <select value={t.dataType} className="input !bg-transparent !border-transparent hover:!border-line" onChange={e => changeType(t, e.target.value as DataType)}>
                        {ALL_TYPES.map(d => <option key={d}>{d}</option>)}
                      </select>
                    </td>
                    <td className="px-1 py-0.5"><input key={t.id + t.address} defaultValue={t.address} title={addrErr} className={`input font-mono !bg-transparent !border-transparent hover:!border-line focus:!border-accent ${addrErr ? '!text-danger' : ''}`} onBlur={e => e.target.value !== t.address && commitAddress(t, e.target.value)} onKeyDown={e => e.key === 'Enter' && (e.target as HTMLInputElement).blur()} /></td>
                    {online && <td className="px-2 font-mono text-on">{mon}</td>}
                    <td className="px-1 py-0.5"><input key={t.id + t.comment} defaultValue={t.comment} className="input !bg-transparent !border-transparent hover:!border-line focus:!border-accent text-mute" onBlur={e => e.target.value !== t.comment && setTag(t.id, x => { x.comment = e.target.value; })} /></td>
                    <td className="px-1"><button className="btn btn-ghost btn-icon opacity-50 group-hover:opacity-100 hover:!text-danger" onClick={() => remove(t.id)}><Trash2 size={13} /></button></td>
                  </tr>
                );
              })}
            </tbody>
          </table>
          <button className="m-3 btn btn-ghost text-mute" onClick={add}><Plus size={14} />Add new</button>
        </div>
      )}
    </div>
  );
}

function parseModify(s: string, dt: DataType): number | boolean | null {
  const t = s.trim();
  if (!t) return null;
  if (dt === 'Bool') {
    const u = t.toUpperCase();
    if (u === 'TRUE' || u === '1') return true;
    if (u === 'FALSE' || u === '0') return false;
    return null;
  }
  if (dt === 'Time') { const v = parseTime(t); if (v !== null) return v; }
  const c = parseConstant(t);
  if (!c || typeof c.value === 'boolean') return null;
  return c.value;
}

export function WatchTable() {
  const project = useStore(s => s.project);
  const mutate = useStore(s => s.mutate);
  useStore(s => s.tick);
  const phone = useIsPhone();
  const st = useStore.getState;
  const res = getResolver(project);
  const online = runtime.mode === 'RUN' || !!runtime.prog;

  const setRow = (id: string, fn: (w: WatchRow) => void) => mutate(p => { const w = p.watch.find(x => x.id === id); if (w) fn(w); }, false);
  const add = (operand = '') => mutate(p => { p.watch.push({ id: uid('w'), operand, format: 'auto', modify: '' }); }, false);
  const remove = (id: string) => mutate(p => { p.watch = p.watch.filter(x => x.id !== id); }, false);

  const doModify = (w: WatchRow, val?: number | boolean) => {
    const r = res.resolve(w.operand);
    if (r.k !== 'mem') { st().showToast('Only PLC tags / addresses can be modified', 'err'); return; }
    const dt = refType(r) ?? 'Int';
    const v = val ?? parseModify(w.modify, dt);
    if (v === null) { st().showToast(`Invalid modify value for ${dt}`, 'err'); return; }
    runtime.modify(r, dt, v);
  };

  const row = (w: WatchRow) => {
    const r = w.operand.trim() ? res.resolve(w.operand) : null;
    const ok = r && (r.k === 'mem' || r.k === 'inst');
    const dt = ok ? refType(r!) : undefined;
    const v = ok && online ? runtime.readRef(r!, dt ?? 'Int') : undefined;
    return { r, dt, v };
  };

  const quickAdd = (
    <div className="p-3 flex flex-wrap gap-1.5">
      <button className="btn btn-ghost text-mute" onClick={() => add()}><Plus size={14} />Add new</button>
      <span className="text-[11px] text-mute self-center">Quick add:</span>
      {project.tags.filter(t => !project.watch.some(w => w.operand === t.name)).slice(0, 12).map(t => (
        <button key={t.id} className="text-[11px] max-lg:text-[12.5px] px-2 py-0.5 max-lg:py-1.5 max-lg:px-3 rounded-full border border-line text-mute hover:text-accent hover:border-accent/50" onClick={() => add(t.name)}>{t.name}</button>
      ))}
    </div>
  );

  return (
    <div className="flex flex-col h-full min-h-0">
      <div className="flex flex-wrap items-center gap-2 px-3 py-2 border-b border-line bg-panel">
        <Eye size={16} className="text-accent" /><h2 className="text-sm font-semibold">Watch and force tables <span className="text-mute font-normal">› Watch table_1</span></h2>
        <div className="flex-1 max-lg:hidden" />
        <button className="btn max-lg:flex-1 justify-center" onClick={() => project.watch.forEach(w => w.modify.trim() && doModify(w))}><Zap size={14} />Modify all now</button>
        <button className="btn btn-accent max-lg:flex-1 justify-center" onClick={() => add()}><Plus size={14} />Add row</button>
      </div>
      {!runtime.prog && <div className="px-3 py-2 text-xs text-warn bg-warn/10 border-b border-warn/30">No program in the simulated CPU — download first to monitor values.</div>}

      {phone ? (
        <div className="flex-1 overflow-y-auto overscroll-contain p-2.5 space-y-2.5">
          {project.watch.map(w => {
            const { r, dt, v } = row(w);
            return (
              <div key={w.id} className="rounded-xl border border-line bg-panel p-2.5 space-y-2">
                <div className="flex items-center gap-1.5">
                  <input list="dl-tags" key={w.id + w.operand} defaultValue={w.operand} placeholder="Tag or address" aria-label="Operand" autoCapitalize="none" autoCorrect="off" spellCheck={false}
                    className={`input font-mono font-semibold ${r?.k === 'err' ? '!border-danger/70' : ''}`}
                    onBlur={e => e.target.value !== w.operand && setRow(w.id, x => { x.operand = e.target.value.trim(); })} onKeyDown={e => e.key === 'Enter' && (e.target as HTMLInputElement).blur()} />
                  <button className="btn btn-ghost btn-icon shrink-0 hover:!text-danger" aria-label="Delete row" onClick={() => remove(w.id)}><Trash2 size={16} /></button>
                </div>
                {r?.k === 'err' && <div className="text-[12px] text-danger">{r.msg}</div>}
                <div className="flex items-center gap-3">
                  <div className="flex-1 min-w-0 font-mono text-[18px] leading-none">
                    {v !== undefined ? (typeof v === 'boolean'
                      ? <span className="inline-flex items-center gap-2"><span className={`w-3 h-3 rounded-full ${v ? 'bg-on shadow-[0_0_6px_var(--c-on)]' : 'bg-line'}`} />{formatValue(v, dt, w.format)}</span>
                      : <span className="text-on">{formatValue(v, dt, w.format)}</span>) : <span className="text-mute text-[14px]">—</span>}
                    {dt && <span className="ml-2 text-[11px] text-mute">{dt}</span>}
                  </div>
                  <select className="input !w-auto" aria-label="Display format" value={w.format} onChange={e => setRow(w.id, x => { x.format = e.target.value as WatchRow['format']; })}>
                    {['auto', 'dec', 'hex', 'bin', 'bool'].map(f => <option key={f} value={f}>{f === 'auto' ? 'Default' : f.toUpperCase()}</option>)}
                  </select>
                </div>
                <div className="flex gap-1.5">
                  <input key={w.id + w.modify} defaultValue={w.modify} aria-label="Modify value" placeholder={dt === 'Bool' ? 'TRUE / FALSE' : dt === 'Time' ? 'T#5s' : 'Modify value'} className="input font-mono"
                    onBlur={e => e.target.value !== w.modify && setRow(w.id, x => { x.modify = e.target.value; })}
                    onKeyDown={e => { if (e.key === 'Enter') { (e.target as HTMLInputElement).blur(); setTimeout(() => doModify({ ...w, modify: (e.target as HTMLInputElement).value })); } }} />
                  {dt === 'Bool' && r?.k === 'mem' && <button className="btn shrink-0" onClick={() => doModify(w, !(v as boolean))}><ToggleLeft size={16} />Toggle</button>}
                  <button className="btn btn-accent shrink-0" onClick={() => doModify(w)}><Zap size={15} />Set</button>
                </div>
              </div>
            );
          })}
          {project.watch.length === 0 && <div className="text-center text-sm text-mute py-8">No watch rows yet. Add a tag below to monitor it.</div>}
          {quickAdd}
        </div>
      ) : (
        <div className="flex-1 overflow-auto">
          <table className="w-full text-xs min-w-[680px]">
            <thead className="sticky top-0 bg-panel2 text-mute z-10">
              <tr>
                <th className="text-left font-medium px-2 py-2">Name / address</th>
                <th className="text-left font-medium px-2 py-2 w-24">Display</th>
                <th className="text-left font-medium px-2 py-2 w-36">Monitor value</th>
                <th className="text-left font-medium px-2 py-2 w-40">Modify value</th>
                <th className="w-24"></th>
              </tr>
            </thead>
            <tbody>
              {project.watch.map(w => {
                const { r, dt, v } = row(w);
                return (
                  <tr key={w.id} className="border-t border-line hover:bg-panel2/50 group">
                    <td className="px-1 py-0.5">
                      <input list="dl-tags" key={w.id + w.operand} defaultValue={w.operand} placeholder="<Add new>" className={`input font-mono !bg-transparent !border-transparent hover:!border-line focus:!border-accent ${r?.k === 'err' ? '!text-danger' : ''}`}
                        onBlur={e => e.target.value !== w.operand && setRow(w.id, x => { x.operand = e.target.value.trim(); })} onKeyDown={e => e.key === 'Enter' && (e.target as HTMLInputElement).blur()} />
                      {r?.k === 'err' && <div className="text-[10px] text-danger px-2">{r.msg}</div>}
                    </td>
                    <td className="px-1"><select className="input !bg-transparent !border-transparent hover:!border-line" value={w.format} onChange={e => setRow(w.id, x => { x.format = e.target.value as WatchRow['format']; })}>
                      {['auto', 'dec', 'hex', 'bin', 'bool'].map(f => <option key={f} value={f}>{f === 'auto' ? 'Default' : f.toUpperCase()}</option>)}
                    </select></td>
                    <td className="px-2 font-mono">
                      {v !== undefined && (typeof v === 'boolean'
                        ? <span className="inline-flex items-center gap-1.5"><span className={`w-2.5 h-2.5 rounded-full ${v ? 'bg-on shadow-[0_0_6px_var(--c-on)]' : 'bg-line'}`} />{formatValue(v, dt, w.format)}</span>
                        : <span className="text-on">{formatValue(v, dt, w.format)}</span>)}
                      {dt && <span className="ml-2 text-[10px] text-mute">{dt}</span>}
                    </td>
                    <td className="px-1"><input key={w.id + w.modify} defaultValue={w.modify} placeholder={dt === 'Bool' ? 'TRUE / FALSE' : dt === 'Time' ? 'T#5s' : 'value'} className="input font-mono !bg-transparent !border-transparent hover:!border-line focus:!border-accent"
                      onBlur={e => e.target.value !== w.modify && setRow(w.id, x => { x.modify = e.target.value; })} onKeyDown={e => { if (e.key === 'Enter') { (e.target as HTMLInputElement).blur(); setTimeout(() => doModify({ ...w, modify: (e.target as HTMLInputElement).value })); } }} /></td>
                    <td className="px-1 whitespace-nowrap">
                      {dt === 'Bool' && r?.k === 'mem' && <button className="btn btn-ghost btn-icon" title="Toggle" onClick={() => doModify(w, !(v as boolean))}><ToggleLeft size={14} /></button>}
                      <button className="btn btn-ghost btn-icon" title="Modify now" onClick={() => doModify(w)}><Zap size={13} /></button>
                      <button className="btn btn-ghost btn-icon hover:!text-danger" onClick={() => remove(w.id)}><Trash2 size={13} /></button>
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
          {quickAdd}
        </div>
      )}
    </div>
  );
}
