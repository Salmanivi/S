import test from 'node:test';
import assert from 'node:assert/strict';
import { startServer, Client, newUser, PW } from './helpers.mjs';

const s = await startServer();
test.after(() => s.close());
const anon = (ip) => new Client(s.base, { ip });

test('health and public config work before anything is set up', async () => {
  const h = await anon('9.9.0.1').get('/api/health');
  assert.equal(h.status, 200);
  assert.equal(h.json.checks.database, 'ok');
  assert.equal(h.json.adminCreated, false);
  assert.ok(!JSON.stringify(h.json).includes('setup-token'), 'health must never leak secret values');
  const c = await anon('9.9.0.1').get('/api/config');
  assert.equal(c.json.needsSetup, true);
  assert.equal(c.json.registrationEnabled, true);
  assert.equal(c.json.operatorName, 'Salman', 'the author is credited by default');
  assert.equal(c.json.contactEmail, 'salmanino.ahmedino@gmail.com');
  assert.equal(c.json.contactPhone, '+20 11 54390240');
});

test('setup: wrong token rejected, right token creates the one and only first admin', async () => {
  const c = anon('9.9.1.1');
  const bad = await c.post('/api/setup', { token: 'x'.repeat(20), email: 'root@example.com', name: 'Root', password: PW });
  assert.equal(bad.status, 403);
  assert.equal(bad.json.error.code, 'invalid_setup_token');
  const weak = await c.post('/api/setup', { token: 'setup-token-1234567890', email: 'root@example.com', name: 'Root', password: 'short' });
  assert.equal(weak.status, 400);
  const ok = await c.post('/api/setup', { token: 'setup-token-1234567890', email: 'root@example.com', name: 'Root', password: PW });
  assert.equal(ok.status, 201);
  assert.equal(ok.json.user.role, 'admin');
  const again = await anon('9.9.1.2').post('/api/setup', { token: 'setup-token-1234567890', email: 'evil@example.com', name: 'Evil', password: PW });
  assert.equal(again.status, 404, 'setup must disappear once an admin exists');
  assert.equal((await anon('9.9.1.3').get('/api/config')).json.needsSetup, false);
});

test('register: validation, duplicates, cookie flags, no secrets in the answer', async () => {
  const c = anon('9.9.2.1');
  for (const [body, field] of [
    [{ email: 'nope', name: 'A', password: PW }, 'email'],
    [{ email: 'a@example.com', name: '', password: PW }, 'name'],
    [{ email: 'a@example.com', name: 'A', password: 'short' }, 'password'],
    [{ email: 'a@example.com', name: 'A', password: 'password123' }, 'password'],
    [{ email: 'alice.smith@example.com', name: 'A', password: 'alice.smith-1' }, 'password'],
    [{ email: 'a@example.com', name: 'A'.repeat(200), password: PW }, 'name'],
  ]) {
    const r = await c.post('/api/auth/register', body);
    assert.equal(r.status, 400, JSON.stringify(body));
    assert.equal(r.json.error.details?.field, field);
  }
  const r = await c.post('/api/auth/register', { email: 'Alice@Example.com', name: 'Alice', password: PW });
  assert.equal(r.status, 201);
  assert.ok(!r.text.includes('password_hash') && !r.text.includes('s1$'), 'no hash in response');
  const cookie = r.setCookie.join(';');
  assert.match(cookie, /HttpOnly/i);
  assert.match(cookie, /SameSite=Lax/i);
  const dup = await anon('9.9.2.2').post('/api/auth/register', { email: 'alice@example.com', name: 'Other', password: PW });
  assert.equal(dup.status, 409, 'email is unique case-insensitively');
});

test('register is rate limited per IP', async () => {
  const c = anon('9.9.3.1');
  let last;
  for (let i = 0; i < 12; i++) last = await c.post('/api/auth/register', { email: `rl${i}@example.com`, name: 'R', password: PW });
  assert.equal(last.status, 429);
  assert.ok(Number(last.headers.get('retry-after')) > 0);
});

test('login: generic failure for unknown user and wrong password, lockout after repeated tries', async () => {
  const u = await newUser(s.base, { email: 'bob@example.com' });
  const c = anon('9.9.4.1');
  const wrong = await c.post('/api/auth/login', { email: 'bob@example.com', password: 'wrong password!!' });
  const unknown = await c.post('/api/auth/login', { email: 'nobody@example.com', password: 'wrong password!!' });
  assert.equal(wrong.status, 401);
  assert.equal(unknown.status, 401);
  assert.deepEqual([wrong.json.error.code, wrong.json.error.message], [unknown.json.error.code, unknown.json.error.message], 'must not reveal whether the account exists');
  const ok = await c.post('/api/auth/login', { email: 'BOB@example.com', password: PW });
  assert.equal(ok.status, 200);
  assert.equal(ok.json.user.email, 'bob@example.com');
  assert.equal((await c.get('/api/auth/me')).status, 200);
  // brute force: the same account from many IPs is still locked out
  let res;
  for (let i = 0; i < 14; i++) res = await anon(`9.9.5.${i}`).post('/api/auth/login', { email: 'bob@example.com', password: 'guess-' + i + '-xxxxx' });
  assert.equal(res.status, 429, 'per-account limiter must trip');
  void u;
});

test('CSRF: cross-site and origin-less writes are blocked, reads are fine', async () => {
  const c = anon('9.9.6.1');
  const evil = await c.post('/api/auth/login', { email: 'a@example.com', password: PW }, { origin: 'https://evil.example' });
  assert.equal(evil.status, 403); assert.equal(evil.json.error.code, 'csrf');
  const none = await c.post('/api/auth/login', { email: 'a@example.com', password: PW }, { noOrigin: true });
  assert.equal(none.status, 403);
  const sameSite = await c.post('/api/auth/login', { email: 'a@example.com', password: PW }, { noOrigin: true, headers: { 'sec-fetch-site': 'same-origin' } });
  assert.notEqual(sameSite.status, 403);
  const garbage = await c.post('/api/auth/login', {}, { origin: 'not a url' });
  assert.equal(garbage.status, 403);
  assert.equal((await c.get('/api/config', { noOrigin: true })).status, 200);
});

test('content-type and body hygiene', async () => {
  const c = anon('9.9.7.1');
  assert.equal((await c.req('POST', '/api/auth/login', undefined, { raw: 'a=b', contentType: 'application/x-www-form-urlencoded' })).status, 415);
  assert.equal((await c.req('POST', '/api/auth/login', undefined, { raw: '{not json', contentType: 'application/json' })).status, 400);
  assert.equal((await c.req('POST', '/api/auth/login', undefined, { raw: '[1,2]', contentType: 'application/json' })).status, 400);
  const huge = await c.req('POST', '/api/auth/login', undefined, { raw: JSON.stringify({ email: 'a@b.co', password: 'x'.repeat(200_000) }), contentType: 'application/json' });
  assert.equal(huge.status, 413);
});

test('sessions: logout kills the session; password change revokes other devices; wrong current password refused', async () => {
  const phone = await newUser(s.base, { email: 'carol@example.com' });
  const laptop = anon('9.9.8.1');
  assert.equal((await laptop.post('/api/auth/login', { email: 'carol@example.com', password: PW })).status, 200);
  const list = await phone.get('/api/auth/sessions');
  assert.equal(list.json.sessions.length, 2);
  assert.equal(list.json.sessions.filter(x => x.current).length, 1);

  assert.equal((await phone.post('/api/auth/password', { currentPassword: 'wrong-wrong-wrong', newPassword: 'a brand new password 1' })).status, 403);
  assert.equal((await phone.post('/api/auth/password', { currentPassword: PW, newPassword: 'short' })).status, 400);
  assert.equal((await phone.post('/api/auth/password', { currentPassword: PW, newPassword: 'a brand new password 1' })).status, 200);
  assert.equal((await laptop.get('/api/auth/me')).status, 401, 'other devices are signed out after a password change');
  assert.equal((await phone.get('/api/auth/me')).status, 200, 'the current device stays signed in');
  assert.equal((await anon('9.9.8.2').post('/api/auth/login', { email: 'carol@example.com', password: PW })).status, 401);
  assert.equal((await anon('9.9.8.3').post('/api/auth/login', { email: 'carol@example.com', password: 'a brand new password 1' })).status, 200);

  const stale = new Client(s.base); stale.jar = new Map(phone.jar);
  assert.equal((await phone.post('/api/auth/logout')).status, 200);
  assert.equal((await phone.get('/api/auth/me')).status, 401);
  assert.equal((await stale.get('/api/auth/me')).status, 401, 'a copied cookie is useless after logout');
});

test('device list: revoke one device or all others', async () => {
  const a = await newUser(s.base, { email: 'dave@example.com' });
  const b = anon('9.9.9.1'), c = anon('9.9.9.2');
  await b.post('/api/auth/login', { email: 'dave@example.com', password: PW });
  await c.post('/api/auth/login', { email: 'dave@example.com', password: PW });
  const ids = (await a.get('/api/auth/sessions')).json.sessions;
  const other = ids.find(x => !x.current);
  assert.equal((await a.del(`/api/auth/sessions/${other.id}`)).status, 200);
  assert.equal((await a.post('/api/auth/sessions/revoke-others')).json.revoked, 1);
  assert.equal((await a.get('/api/auth/me')).status, 200);
  const stranger = await newUser(s.base);
  assert.equal((await stranger.del(`/api/auth/sessions/${other.id}`)).status, 404, 'cannot touch another user\'s session');
});

test('profile update only accepts a name', async () => {
  const u = await newUser(s.base);
  assert.equal((await u.patch('/api/auth/profile', { name: 'New Name' })).json.user.name, 'New Name');
  assert.equal((await u.patch('/api/auth/profile', { name: 'X', role: 'admin' })).status, 400, 'mass-assignment of role is rejected');
  assert.equal((await u.get('/api/auth/me')).json.user.role, 'user');
});

test('password reset by e-mail: disabled without a provider', async () => {
  const r = await anon('9.9.10.1').post('/api/auth/forgot', { email: 'a@example.com' });
  assert.equal(r.status, 501);
  assert.equal(r.json.error.code, 'mail_disabled');
});

test('account deletion needs the password and removes everything', async () => {
  const u = await newUser(s.base, { email: 'erin@example.com' });
  const p = await u.post('/api/projects', { name: 'P', data: { name: 'P', blocks: [], hardware: { cpuId: 'x' }, tags: [] } });
  assert.equal(p.status, 201);
  assert.equal((await u.post('/api/auth/delete-account', { password: 'nope-nope-nope-1' })).status, 403);
  assert.equal((await u.post('/api/auth/delete-account', { password: PW })).status, 200);
  assert.equal((await u.get('/api/auth/me')).status, 401);
  const left = s.driver.raw.prepare('SELECT COUNT(*) AS n FROM projects WHERE id = ?').get(p.json.project.id).n;
  assert.equal(left, 0, 'projects are deleted with the account');
  assert.equal((await anon('9.9.11.1').post('/api/auth/login', { email: 'erin@example.com', password: PW })).status, 401);
});

test('data export contains the user\'s projects and no password hash', async () => {
  const u = await newUser(s.base);
  await u.post('/api/projects', { name: 'Exp', data: { name: 'Exp', blocks: [], hardware: { cpuId: 'x' }, tags: [] } });
  const r = await u.get('/api/auth/export');
  assert.equal(r.status, 200);
  assert.equal(r.json.projects.length, 1);
  assert.ok(!r.text.includes('password_hash') && !r.text.includes('s1$'));
});
