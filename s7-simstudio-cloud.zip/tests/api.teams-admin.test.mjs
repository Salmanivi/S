import test from 'node:test';
import assert from 'node:assert/strict';
import { startServer, Client, newUser, sampleProject, PW } from './helpers.mjs';

const s = await startServer();
test.after(() => s.close());
const admin = new Client(s.base, { ip: '10.50.0.1' });
const setup = await admin.post('/api/setup', { token: 'setup-token-1234567890', email: 'boss@example.com', name: 'Boss', password: PW });
assert.equal(setup.status, 201);

const mkTeam = async (c, name = 'Plant crew') => (await c.post('/api/teams', { name })).json.team;
const invite = async (c, teamId, role = 'editor', extra = {}) => (await c.post(`/api/teams/${teamId}/invites`, { role, ...extra })).json.code;
const join = async (c, code) => c.post('/api/invites/accept', { code });
const mkProject = async (c, teamId, name = 'TP') => (await c.post('/api/projects', { name, data: sampleProject(name), teamId })).json?.project;

test('team roles: owner / admin / editor / viewer permissions on shared projects', async () => {
  const owner = await newUser(s.base), editor = await newUser(s.base), viewer = await newUser(s.base), outsider = await newUser(s.base);
  const team = await mkTeam(owner);
  assert.equal(team.role, 'owner');
  assert.equal((await join(editor, await invite(owner, team.id, 'editor'))).status, 201);
  assert.equal((await join(viewer, await invite(owner, team.id, 'viewer'))).status, 201);

  const p = await mkProject(owner, team.id, 'Line 1');
  assert.equal(p.scope, 'team'); assert.equal(p.teamName, 'Plant crew');
  // everyone in the team sees it, the outsider does not
  for (const c of [owner, editor, viewer]) assert.equal((await c.get('/api/projects')).json.projects.length, 1);
  assert.equal((await outsider.get('/api/projects')).json.projects.length, 0);
  assert.equal((await outsider.get(`/api/projects/${p.id}`)).status, 404);

  // viewer: read yes, write no
  assert.equal((await viewer.get(`/api/projects/${p.id}`)).json.project.role, 'viewer');
  assert.equal((await viewer.put(`/api/projects/${p.id}`, { baseRevision: 1, name: 'nope' })).status, 403);
  assert.equal((await viewer.post('/api/projects', { name: 'x', data: sampleProject(), teamId: team.id })).status, 403);
  assert.equal((await viewer.del(`/api/projects/${p.id}`)).status, 403);
  // editor: can save, cannot delete someone else's project, cannot move it
  assert.equal((await editor.put(`/api/projects/${p.id}`, { baseRevision: 1, data: sampleProject('edited by editor') })).status, 200);
  assert.equal((await editor.del(`/api/projects/${p.id}`)).status, 403);
  assert.equal((await editor.post(`/api/projects/${p.id}/move`, { teamId: null })).status, 403);
  const mine = await mkProject(editor, team.id, 'Editor made');
  assert.equal((await editor.del(`/api/projects/${mine.id}`)).status, 200, 'an editor may delete what they created');
  // the save is attributed
  assert.equal((await owner.get(`/api/projects/${p.id}/meta`)).json.project.updatedBy, editor.user.name);
  // owner can move it to personal space and the team loses access
  assert.equal((await owner.post(`/api/projects/${p.id}/move`, { teamId: null })).status, 200);
  assert.equal((await editor.get(`/api/projects/${p.id}`)).status, 404);
  assert.equal((await owner.get(`/api/projects/${p.id}`)).json.project.scope, 'personal');
});

test('invites: single use, expiry, revoke, role limits, no code leak', async () => {
  const owner = await newUser(s.base), a = await newUser(s.base), b = await newUser(s.base), c = await newUser(s.base);
  const team = await mkTeam(owner, 'Invites');
  const code = await invite(owner, team.id, 'editor', { maxUses: 1 });
  assert.equal((await a.get(`/api/invites/${code}`)).json.team.name, 'Invites');
  assert.equal((await join(a, code)).status, 201);
  assert.equal((await join(b, code)).status, 404, 'single-use invite is spent');
  const again = await join(a, code);
  assert.equal(again.status, 200); assert.equal(again.json.alreadyMember, true, 'a member re-opening their own spent link is welcomed, not rejected');
  assert.equal((await a.get(`/api/invites/${code}`)).json.alreadyMember, true);
  const detail = (await owner.get(`/api/teams/${team.id}`)).json;
  assert.ok(!JSON.stringify(detail).includes(code), 'codes are never stored or returned again');
  const multi = await invite(owner, team.id, 'viewer', { maxUses: 2 });
  assert.equal((await join(b, multi)).status, 201);
  assert.equal((await join(c, multi)).status, 201);
  const revoked = await invite(owner, team.id, 'viewer');
  const id = (await owner.get(`/api/teams/${team.id}`)).json.invites.find(i => i.role === 'viewer' && i.uses === 0).id;
  assert.equal((await owner.del(`/api/teams/${team.id}/invites/${id}`)).status, 200);
  assert.equal((await newUser(s.base).then(x => join(x, revoked))).status, 404);
  // expiry
  const exp = await invite(owner, team.id, 'viewer');
  s.driver.raw.prepare('UPDATE team_invites SET expires_at = ? WHERE team_id = ?').run(Date.now() - 1000, team.id);
  assert.equal((await newUser(s.base).then(x => join(x, exp))).status, 404, 'expired');
  // junk codes
  for (const bad of ['short', 'x'.repeat(500), "' OR 1=1 --' OR 1=1 --"]) assert.ok([400, 404].includes((await a.post('/api/invites/accept', { code: bad })).status));
  // an admin cannot mint admin invites, a viewer cannot invite at all
  const adm = await newUser(s.base); await join(adm, await invite(owner, team.id, 'admin'));
  assert.equal((await adm.post(`/api/teams/${team.id}/invites`, { role: 'admin' })).status, 403);
  assert.equal((await adm.post(`/api/teams/${team.id}/invites`, { role: 'editor' })).status, 201);
  assert.equal((await b.post(`/api/teams/${team.id}/invites`, { role: 'viewer' })).status, 403);
});

test('members: role changes, removal, leaving, last-owner protection, privilege escalation blocked', async () => {
  const owner = await newUser(s.base), adm = await newUser(s.base), ed = await newUser(s.base), vw = await newUser(s.base);
  const team = await mkTeam(owner, 'Members');
  await join(adm, await invite(owner, team.id, 'admin')); await join(ed, await invite(owner, team.id, 'editor')); await join(vw, await invite(owner, team.id, 'viewer'));
  // editors and viewers cannot manage anyone
  assert.equal((await ed.patch(`/api/teams/${team.id}/members/${vw.user.id}`, { role: 'editor' })).status, 403);
  // an admin cannot promote themselves or others to owner/admin, nor touch the owner
  assert.equal((await adm.patch(`/api/teams/${team.id}/members/${ed.user.id}`, { role: 'owner' })).status, 403);
  assert.equal((await adm.patch(`/api/teams/${team.id}/members/${ed.user.id}`, { role: 'admin' })).status, 403);
  assert.equal((await adm.patch(`/api/teams/${team.id}/members/${owner.user.id}`, { role: 'viewer' })).status, 403);
  assert.equal((await adm.del(`/api/teams/${team.id}/members/${owner.user.id}`)).status, 403);
  assert.equal((await adm.patch(`/api/teams/${team.id}/members/${adm.user.id}`, { role: 'owner' })).status, 400, 'cannot change own role');
  // but may manage editors/viewers
  assert.equal((await adm.patch(`/api/teams/${team.id}/members/${vw.user.id}`, { role: 'editor' })).status, 200);
  assert.equal((await vw.put('/api/projects/' + (await mkProject(owner, team.id)).id, { baseRevision: 1, name: 'now allowed' })).status, 200);
  assert.equal((await adm.del(`/api/teams/${team.id}/members/${vw.user.id}`)).status, 200);
  assert.equal((await vw.get(`/api/teams/${team.id}`)).status, 404, 'removed member loses access immediately');
  // emails are only visible to admins/owners
  const asEditor = (await ed.get(`/api/teams/${team.id}`)).json.members;
  assert.ok(asEditor.filter(m => !m.me).every(m => m.email === null));
  assert.ok((await owner.get(`/api/teams/${team.id}`)).json.members.every(m => typeof m.email === 'string'));
  // last owner can neither leave nor be demoted
  assert.equal((await owner.del(`/api/teams/${team.id}/members/${owner.user.id}`)).status, 409);
  assert.equal((await owner.patch(`/api/teams/${team.id}/members/${owner.user.id}`, { role: 'admin' })).status, 400);
  // transfer: make admin a second owner, then the first may leave
  assert.equal((await owner.patch(`/api/teams/${team.id}/members/${adm.user.id}`, { role: 'owner' })).status, 200);
  assert.equal((await owner.del(`/api/teams/${team.id}/members/${owner.user.id}`)).status, 200);
  assert.equal((await adm.get(`/api/teams/${team.id}`)).json.myRole, 'owner');
  // self-leave for a normal member
  assert.equal((await ed.del(`/api/teams/${team.id}/members/${ed.user.id}`)).status, 200);
});

test('team deletion requires an owner and explicit confirmation when projects exist', async () => {
  const owner = await newUser(s.base), ed = await newUser(s.base), out = await newUser(s.base);
  const team = await mkTeam(owner, 'Doomed');
  await join(ed, await invite(owner, team.id, 'editor'));
  const p = await mkProject(owner, team.id);
  assert.equal((await ed.del(`/api/teams/${team.id}`)).status, 403);
  assert.equal((await out.del(`/api/teams/${team.id}`)).status, 404);
  const warn = await owner.del(`/api/teams/${team.id}`);
  assert.equal(warn.status, 409); assert.equal(warn.json.error.details.count, 1);
  assert.equal((await owner.del(`/api/teams/${team.id}?deleteProjects=1`)).status, 200);
  assert.equal(s.driver.raw.prepare('SELECT COUNT(*) AS n FROM projects WHERE id = ?').get(p.id).n, 0);
});

test('team limits: members, teams per user', async () => {
  assert.equal((await admin.put('/api/admin/settings', { maxTeamsPerUser: 1, maxMembersPerTeam: 2 })).status, 200);
  const o = await newUser(s.base);
  const t = await mkTeam(o, 'First');
  assert.equal((await o.post('/api/teams', { name: 'Second' })).status, 409);
  const x = await newUser(s.base), y = await newUser(s.base);
  assert.equal((await join(x, await invite(o, t.id, 'viewer', { maxUses: 5 }))).status, 201);
  const code = await invite(o, t.id, 'viewer', { maxUses: 5 });
  assert.equal((await join(y, code)).status, 409, 'member limit');
  await admin.put('/api/admin/settings', { maxTeamsPerUser: 10, maxMembersPerTeam: 50 });
});

test('admin API is closed to everyone who is not an admin', async () => {
  const user = await newUser(s.base), anon = new Client(s.base);
  const probes = [
    ['GET', '/api/admin/stats'], ['GET', '/api/admin/users'], ['POST', '/api/admin/users', { email: 'x@y.co', name: 'x', password: PW }],
    ['GET', `/api/admin/users/${user.user.id}`], ['PATCH', `/api/admin/users/${user.user.id}`, { role: 'admin' }],
    ['POST', `/api/admin/users/${user.user.id}/reset-link`, {}], ['POST', `/api/admin/users/${user.user.id}/revoke-sessions`, {}],
    ['POST', `/api/admin/users/${user.user.id}/delete`, { confirmEmail: user.email }], ['GET', '/api/admin/projects'], ['GET', '/api/admin/teams'],
    ['GET', '/api/admin/audit'], ['GET', '/api/admin/settings'], ['PUT', '/api/admin/settings', { registrationEnabled: false }],
  ];
  for (const [m, p, b] of probes) {
    assert.equal((await user.req(m, p, b)).status, 403, `user ${m} ${p}`);
    assert.equal((await anon.req(m, p, b)).status, 401, `anon ${m} ${p}`);
  }
  assert.equal((await user.get('/api/auth/me')).json.user.role, 'user', 'attempted escalation changed nothing');
});

test('admin: stats, search (wildcards escaped), details', async () => {
  const u = await newUser(s.base, { name: 'Zed % Unique_Name', email: 'zed.unique@example.com' });
  await u.post('/api/projects', { name: 'P', data: sampleProject() });
  const st = (await admin.get('/api/admin/stats')).json;
  assert.ok(st.users.total >= 2 && st.projects.total >= 1 && st.signups14d.length === 14);
  assert.ok(st.storageBytes > 0);
  const found = (await admin.get('/api/admin/users?q=' + encodeURIComponent('zed.unique'))).json;
  assert.equal(found.total, 1);
  assert.equal((await admin.get('/api/admin/users?q=' + encodeURIComponent('%'))).json.total, 1, 'literal % matches only the name containing it');
  assert.equal((await admin.get('/api/admin/users?q=' + encodeURIComponent("' OR 1=1 --"))).json.total, 0);
  assert.equal((await admin.get('/api/admin/users?limit=1000')).status, 400);
  const d = (await admin.get(`/api/admin/users/${u.user.id}`)).json;
  assert.equal(d.projects.count, 1);
  assert.ok(!JSON.stringify(d).includes('password'), 'no password material in admin views');
  const projects = (await admin.get('/api/admin/projects')).json.projects;
  assert.ok(projects.length >= 1 && projects.every(p => !('data' in p)), 'admins see project metadata, not contents');
});

test('admin: disable blocks login and kills live sessions; enable restores', async () => {
  const u = await newUser(s.base, { email: 'victim@example.com' });
  assert.equal((await u.get('/api/auth/me')).status, 200);
  assert.equal((await admin.patch(`/api/admin/users/${u.user.id}`, { status: 'disabled' })).status, 200);
  assert.equal((await u.get('/api/auth/me')).status, 401, 'live session ended immediately');
  const login = await new Client(s.base, { ip: '10.60.0.1' }).post('/api/auth/login', { email: 'victim@example.com', password: PW });
  assert.equal(login.status, 403); assert.equal(login.json.error.code, 'account_disabled');
  const wrong = await new Client(s.base, { ip: '10.60.0.2' }).post('/api/auth/login', { email: 'victim@example.com', password: 'wrong-wrong-wrong' });
  assert.equal(wrong.status, 401, 'a wrong password still looks like any other failed login');
  assert.equal((await admin.patch(`/api/admin/users/${u.user.id}`, { status: 'active' })).status, 200);
  assert.equal((await new Client(s.base, { ip: '10.60.0.3' }).post('/api/auth/login', { email: 'victim@example.com', password: PW })).status, 200);
});

test('admin guard rails: no self-lockout, no removing the last admin, no unknown fields', async () => {
  const me = setup.json.user.id;
  assert.equal((await admin.patch(`/api/admin/users/${me}`, { role: 'user' })).status, 403);
  assert.equal((await admin.patch(`/api/admin/users/${me}`, { status: 'disabled' })).status, 403);
  assert.equal((await admin.post(`/api/admin/users/${me}/delete`, { confirmEmail: 'boss@example.com' })).status, 403);
  assert.equal((await admin.patch(`/api/admin/users/${me}`, { passwordHash: 'x' })).status, 400);
  assert.equal((await admin.post('/api/auth/delete-account', { password: PW })).status, 409, 'the only admin cannot delete themselves');
  const second = await newUser(s.base, { email: 'second-admin@example.com' });
  assert.equal((await admin.patch(`/api/admin/users/${second.user.id}`, { role: 'admin' })).status, 200);
  assert.equal((await second.get('/api/admin/stats')).status, 200);
  assert.equal((await second.patch(`/api/admin/users/${me}`, { role: 'user' })).status, 200, 'with two admins demotion is allowed');
  assert.equal((await second.patch(`/api/admin/users/${second.user.id}`, { role: 'user' })).status, 403);
  assert.equal((await second.post('/api/auth/delete-account', { password: PW })).status, 409, 'now second is the last admin');
  assert.equal((await second.patch(`/api/admin/users/${me}`, { role: 'admin' })).status, 200);
});

test('admin: reset link flow, forced sign-out, delete with confirmation and cascade', async () => {
  const u = await newUser(s.base, { email: 'forgetful@example.com' });
  const p = await u.post('/api/projects', { name: 'Mine', data: sampleProject() });
  const t = await mkTeam(u, 'Sole owner team');
  const link = (await admin.post(`/api/admin/users/${u.user.id}/reset-link`)).json.link;
  const token = new URL(link).searchParams.get('token');
  assert.ok(token && token.length > 30);
  const fresh = new Client(s.base, { ip: '10.61.0.1' });
  assert.equal((await fresh.post('/api/auth/reset', { token, password: 'short' })).status, 400);
  assert.equal((await fresh.post('/api/auth/reset', { token, password: 'a very new password 77' })).status, 200);
  assert.equal((await fresh.post('/api/auth/reset', { token, password: 'a very new password 78' })).status, 400, 'one-time token');
  assert.equal((await u.get('/api/auth/me')).status, 401, 'all old sessions ended');
  assert.equal((await new Client(s.base, { ip: '10.61.0.2' }).post('/api/auth/login', { email: 'forgetful@example.com', password: 'a very new password 77' })).status, 200);
  s.driver.raw.prepare("UPDATE one_time_tokens SET expires_at = 1");
  const link2 = (await admin.post(`/api/admin/users/${u.user.id}/reset-link`)).json.link;
  s.driver.raw.prepare('UPDATE one_time_tokens SET expires_at = ?').run(Date.now() - 1000);
  assert.equal((await fresh.post('/api/auth/reset', { token: new URL(link2).searchParams.get('token'), password: 'yet another password 9' })).status, 400, 'expired');
  assert.equal((await admin.post(`/api/admin/users/${u.user.id}/delete`, { confirmEmail: 'wrong@example.com' })).status, 400);
  assert.equal((await admin.post(`/api/admin/users/${u.user.id}/delete`, { confirmEmail: 'FORGETFUL@example.com' })).status, 200);
  assert.equal(s.driver.raw.prepare('SELECT COUNT(*) AS n FROM projects WHERE id = ?').get(p.json.project.id).n, 0);
  assert.equal(s.driver.raw.prepare('SELECT COUNT(*) AS n FROM teams WHERE id = ?').get(t.id).n, 0, 'a team nobody else is in disappears with its last owner');
});

test('deleting a team owner hands the team to a remaining member', async () => {
  const owner = await newUser(s.base), member = await newUser(s.base);
  const team = await mkTeam(owner, 'Survivors');
  await join(member, await invite(owner, team.id, 'editor'));
  await mkProject(owner, team.id, 'Team asset');
  assert.equal((await admin.post(`/api/admin/users/${owner.user.id}/delete`, { confirmEmail: owner.email })).status, 200);
  const t = (await member.get(`/api/teams/${team.id}`)).json;
  assert.equal(t.myRole, 'owner');
  assert.equal((await member.get('/api/projects')).json.projects.length, 1, 'team projects survive');
});

test('settings: validation, registration switch, announcement, audit trail', async () => {
  for (const bad of [{ maxProjectKB: 5 }, { maxProjectKB: 'lots' }, { registrationEnabled: 'yes' }, { announcement: 'x'.repeat(400) }, { contactEmail: 'not-an-email' }, { nonsense: 1 }]) {
    assert.equal((await admin.put('/api/admin/settings', bad)).status, 400, JSON.stringify(bad));
  }
  for (const bad of ['abc', '<script>', '+20 11 54390240 ; DROP', '1'.repeat(50)]) assert.equal((await admin.put('/api/admin/settings', { contactPhone: bad })).status, 400, 'phone ' + bad);
  assert.equal((await admin.put('/api/admin/settings', { contactPhone: '+44 20 7946 0958' })).status, 200);
  assert.equal((await new Client(s.base).get('/api/config')).json.contactPhone, '+44 20 7946 0958');
  await admin.put('/api/admin/settings', { contactPhone: '+20 11 54390240' });
  assert.equal((await admin.put('/api/admin/settings', { announcement: 'Maintenance tonight <b>22:00</b>', operatorName: 'ACME Labs', contactEmail: 'help@acme.test' })).status, 200);
  const cfg = (await new Client(s.base).get('/api/config')).json;
  assert.equal(cfg.announcement, 'Maintenance tonight <b>22:00</b>');
  assert.equal(cfg.operatorName, 'ACME Labs');
  assert.equal((await admin.put('/api/admin/settings', { registrationEnabled: false })).status, 200);
  const closed = await new Client(s.base, { ip: '10.62.0.1' }).post('/api/auth/register', { email: 'late@example.com', name: 'Late', password: PW });
  assert.equal(closed.status, 403); assert.equal(closed.json.error.code, 'registration_closed');
  assert.equal((await new Client(s.base).get('/api/config')).json.registrationEnabled, false);
  assert.equal((await admin.post('/api/admin/users', { email: 'made-by-admin@example.com', name: 'Made', password: PW })).status, 201, 'admins can still create accounts');
  await admin.put('/api/admin/settings', { registrationEnabled: true });
  const audit = (await admin.get('/api/admin/audit?limit=200')).json.events;
  for (const a of ['setup.admin_created', 'auth.register', 'auth.login', 'auth.login_failed', 'admin.user_update', 'admin.user_delete', 'admin.settings_update', 'team.create', 'team.join', 'project.create']) {
    assert.ok(audit.some(e => e.action === a), 'audit has ' + a);
  }
  assert.ok(!JSON.stringify(audit).includes('s1$') && !JSON.stringify(audit).includes(PW), 'audit never records secrets');
  assert.equal((await admin.get('/api/admin/audit?action=admin.&limit=5')).json.events.every(e => e.action.startsWith('admin.')), true);
});
