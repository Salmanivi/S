// Test-only database driver: runs the application's SQL on an in-memory SQLite database (node:sqlite).
// The SQL in api/_lib is written in the subset both SQLite and PostgreSQL understand.
import { DatabaseSync } from 'node:sqlite';

export function makeSqliteDriver() {
  const db = new DatabaseSync(':memory:');
  db.exec('PRAGMA foreign_keys = ON');
  let chain = Promise.resolve();
  const lock = (fn) => { const p = chain.then(fn, fn); chain = p.catch(() => {}); return p; };

  // $1, $2 ... -> ? (in order of appearance, so a placeholder may be used several times)
  const convert = (text, params) => {
    const order = [];
    const sql = text.replace(/\$(\d+)/g, (_, n) => { order.push(Number(n) - 1); return '?'; });
    return [sql, order.map(i => { const v = params[i]; return v === undefined ? null : v; })];
  };
  const run = (text, params = []) => {
    const [sql, p] = convert(text, params);
    const st = db.prepare(sql);
    if (/^\s*(select|with)\b/i.test(sql) || /\breturning\b/i.test(sql)) return st.all(...p).map(r => ({ ...r }));
    st.run(...p);
    return [];
  };
  const inner = { query: async (t, p) => run(t, p), exec: async (s) => { db.exec(s); } };
  return {
    query: (t, p) => lock(async () => run(t, p)),
    exec: (s) => lock(async () => { db.exec(s); }),
    tx: (fn) => lock(async () => {
      db.exec('BEGIN');
      try { const r = await fn(inner); db.exec('COMMIT'); return r; }
      catch (e) { db.exec('ROLLBACK'); throw e; }
    }),
    raw: db,
    close: () => db.close(),
  };
}
