import test from 'node:test';
import assert from 'node:assert/strict';
import { startServer, Client, newUser, sampleProject, PW } from './helpers.mjs';

const s = await startServer();
test.after(() => s.close());
const create = async (c, name = 'P', data = sampleProject(name), extra = {}) => {
  const r = await c.post('/api/projects', { name, data, ...extra });
  assert.equal(r.status, 201, r.text);
  return r.json.project;
};

test('create → list → get → save keeps revisions and the document intact', async () => {
  const u = await newUser(s.base);
  const p = await create(u, 'Motor', sampleProject('Motor', { tags: [{ id: 't1', name: 'Start', dataType: 'Bool', address: '%I0.0', comment: 'ünïcode ✓ <b>' }] }));
  assert.equal(p.revision, 1); assert.equal(p.scope, 'personal'); assert.equal(p.role, 'owner');
  const list = await u.get('/api/projects');
  assert.equal(list.json.projects.length, 1);
  assert.ok(!('data' in list.json.projects[0]), 'the list never carries project documents');
  const g = await u.get(`/api/projects/${p.id}`);
  assert.equal(g.json.data.tags[0].comment, 'ünïcode ✓ <b>', 'documents round-trip byte for byte');
  const w = await u.put(`/api/projects/${p.id}`, { baseRevision: 1, data: sampleProject('Motor v2'), name: 'Motor v2' });
  assert.equal(w.json.revision, 2);
  const m = await u.get(`/api/projects/${p.id}/meta`);
  assert.equal(m.json.project.name, 'Motor v2'); assert.equal(m.json.project.revision, 2);
});

test('two devices: the second writer with a stale revision gets a 409 and nothing is lost', async () => {
  const a = await newUser(s.base, { email: 'sync@example.com' });
  const b = new Client(s.base, { ip: '10.77.0.2' });
  await b.post('/api/auth/login', { email: 'sync@example.com', password: PW });
  const p = await create(a, 'Shared across devices');
  const fromA = await a.put(`/api/projects/${p.id}`, { baseRevision: 1, data: sampleProject('edit from phone') });
  assert.equal(fromA.status, 200);
  const fromB = await b.put(`/api/projects/${p.id}`, { baseRevision: 1, data: sampleProject('edit from laptop') });
  assert.equal(fromB.status, 409);
  assert.equal(fromB.json.error.code, 'conflict');
  assert.equal(fromB.json.error.details.revision, 2);
  assert.equal((await a.get(`/api/projects/${p.id}`)).json.data.name, 'edit from phone', 'the stale write changed nothing');
  const retry = await b.put(`/api/projects/${p.id}`, { baseRevision: 2, data: sampleProject('edit from laptop') });
  assert.equal(retry.json.revision, 3);
});

test('concurrent saves with the same revision: exactly one wins', async () => {
  const u = await newUser(s.base);
  const p = await create(u);
  const results = await Promise.all(Array.from({ length: 6 }, (_, i) => u.put(`/api/projects/${p.id}`, { baseRevision: 1, data: sampleProject('race ' + i) })));
  assert.equal(results.filter(r => r.status === 200).length, 1);
  assert.equal(results.filter(r => r.status === 409).length, 5);
});

test('validation: malformed, hostile and oversized documents are refused', async () => {
  const u = await newUser(s.base);
  const bad = async (body, label) => { const r = await u.post('/api/projects', body); assert.equal(r.status, 400, label + ' → ' + r.text); };
  await bad({ name: 'x', data: 'string' }, 'not an object');
  await bad({ name: 'x', data: {} }, 'missing sections');
  await bad({ name: 'x', data: { blocks: 'no', hardware: {}, tags: [] } }, 'blocks not array');
  await bad({ name: '', data: sampleProject() }, 'empty name');
  await bad({ name: 'x'.repeat(500), data: sampleProject() }, 'long name');
  await bad({ name: 'x', data: sampleProject(), extra: 1 }, 'unknown field');
  const proto = await u.req('POST', '/api/projects', undefined, { raw: '{"name":"x","data":{"blocks":[],"hardware":{"cpuId":"a"},"tags":[],"__proto__":{"admin":true}}}' });
  assert.equal(proto.status, 400, '__proto__ key refused');
  await bad({ name: 'x', data: sampleProject('x', { nested: { constructor: { prototype: 1 } } }) }, 'constructor key');
  let deep = {}; const root = deep; for (let i = 0; i < 80; i++) { deep.a = {}; deep = deep.a; }
  await bad({ name: 'x', data: sampleProject('x', { deep: root }) }, 'too deep');
  const big = await u.post('/api/projects', { name: 'x', data: sampleProject('x', { pad: 'y'.repeat(1_500_000) }) });
  assert.ok([400, 413].includes(big.status), 'oversized: ' + big.status);
  await bad({ name: 'x', data: sampleProject('x', { s: 'z'.repeat(30_000) }) }, 'one giant string');
  assert.equal((await u.get('/api/projects')).json.projects.length, 0, 'nothing was stored');
});

test('isolation: another user can never read, write, move, copy or even detect a private project', async () => {
  const owner = await newUser(s.base), other = await newUser(s.base);
  const p = await create(owner, 'Secret');
  await owner.post(`/api/projects/${p.id}/checkpoint`, { label: 'cp' });
  const v = (await owner.get(`/api/projects/${p.id}/versions`)).json.versions[0];
  const probes = [
    ['GET', `/api/projects/${p.id}`], ['GET', `/api/projects/${p.id}/meta`], ['PUT', `/api/projects/${p.id}`, { baseRevision: 1, name: 'hacked' }],
    ['DELETE', `/api/projects/${p.id}`], ['POST', `/api/projects/${p.id}/duplicate`, {}], ['POST', `/api/projects/${p.id}/move`, { teamId: null }],
    ['GET', `/api/projects/${p.id}/versions`], ['GET', `/api/projects/${p.id}/versions/${v.id}`], ['POST', `/api/projects/${p.id}/versions/${v.id}/restore`, {}],
    ['POST', `/api/projects/${p.id}/checkpoint`, {}], ['POST', `/api/projects/${p.id}/restore`, {}],
  ];
  for (const [m, path, body] of probes) {
    const r = await other.req(m, path, body);
    assert.equal(r.status, 404, `${m} ${path} must look like it does not exist (got ${r.status})`);
  }
  assert.equal((await other.get('/api/projects')).json.projects.length, 0);
  assert.equal((await other.get('/api/projects?trash=1')).json.projects.length, 0);
  assert.equal((await owner.get(`/api/projects/${p.id}`)).json.project.name, 'Secret');
  assert.equal((await new Client(s.base).get(`/api/projects/${p.id}`)).status, 401);
});

test('malformed ids never reach the database', async () => {
  const u = await newUser(s.base);
  for (const id of ["1' OR '1'='1", '../../etc/passwd', '%00', 'x'.repeat(5000), "00000000-0000-0000-0000-00000000000'; DROP TABLE projects;--"]) {
    const r = await u.get('/api/projects/' + encodeURIComponent(id));
    assert.equal(r.status, 400, id.slice(0, 30));
  }
  assert.equal((await u.get('/api/projects')).status, 200, 'tables are intact');
});

test('SQL-injection and markup payloads are stored as plain text, never executed', async () => {
  const u = await newUser(s.base);
  const nasty = ["Robert'); DROP TABLE users;--", '" OR 1=1 --', '<script>alert(1)</script>', '${process.exit(1)}', '%_\\'];
  for (const name of nasty) {
    const p = await create(u, name, sampleProject(name, { tags: [{ id: 'x', name, dataType: 'Bool', address: '%M0.0', comment: name }] }));
    assert.equal(p.name, name);
  }
  assert.equal((await u.get('/api/projects')).json.projects.length, nasty.length);
  for (const q of ["' OR '1'='1", '%', '_', '\\', 'DROP TABLE']) {
    const r = await u.get('/api/projects?q=' + encodeURIComponent(q));
    assert.equal(r.status, 200, q);
  }
  assert.equal((await u.get('/api/projects?q=' + encodeURIComponent('%'))).json.projects.length, 1, 'LIKE wildcards are escaped');
  assert.equal((await u.post('/api/auth/login', { email: "' OR 1=1 --", password: 'x'.repeat(12) })).status, 401);
  const users = s.driver.raw.prepare('SELECT COUNT(*) AS n FROM users').get().n;
  assert.ok(users > 0, 'users table survived');
  const r = await u.get('/api/projects');
  assert.match(r.headers.get('content-type'), /application\/json/);
  assert.equal(r.headers.get('x-content-type-options'), 'nosniff');
});

test('trash: soft delete, restore, permanent delete', async () => {
  const u = await newUser(s.base);
  const p = await create(u, 'Trash me');
  assert.equal((await u.del(`/api/projects/${p.id}`)).status, 200);
  assert.equal((await u.get('/api/projects')).json.projects.length, 0);
  assert.equal((await u.get('/api/projects?trash=1')).json.projects.length, 1);
  assert.equal((await u.get(`/api/projects/${p.id}`)).status, 404, 'a trashed project cannot be opened');
  assert.equal((await u.put(`/api/projects/${p.id}`, { baseRevision: 1, name: 'zombie' })).status, 404, 'nor saved to');
  assert.equal((await u.del(`/api/projects/${p.id}?permanent=1`)).status, 200);
  assert.equal((await u.get('/api/projects?trash=1')).json.projects.length, 0);
  const q = await create(u, 'Back again');
  await u.del(`/api/projects/${q.id}`);
  assert.equal((await u.post(`/api/projects/${q.id}/restore`)).status, 200);
  assert.equal((await u.get(`/api/projects/${q.id}`)).status, 200);
  assert.equal((await u.del(`/api/projects/${q.id}?permanent=1`)).status, 400, 'only trashed projects can be purged');
});

test('version history: snapshot on create, checkpoints, restore (undoable), capped', async () => {
  const u = await newUser(s.base);
  const p = await create(u, 'History', sampleProject('v1'));
  let versions = (await u.get(`/api/projects/${p.id}/versions`)).json.versions;
  assert.equal(versions.length, 1);
  await u.put(`/api/projects/${p.id}`, { baseRevision: 1, data: sampleProject('v2') });
  assert.equal((await u.get(`/api/projects/${p.id}/versions`)).json.versions.length, 1, 'rapid saves do not flood history');
  await u.post(`/api/projects/${p.id}/checkpoint`, { label: 'Before refactor' });
  versions = (await u.get(`/api/projects/${p.id}/versions`)).json.versions;
  assert.equal(versions.length, 2);
  assert.equal(versions[0].label, 'Before refactor');
  const first = versions.find(v => v.label === null);
  assert.equal((await u.get(`/api/projects/${p.id}/versions/${first.id}`)).json.data.name, 'v1');
  const rest = await u.post(`/api/projects/${p.id}/versions/${first.id}/restore`);
  assert.equal(rest.json.revision, 3);
  assert.equal((await u.get(`/api/projects/${p.id}`)).json.data.name, 'v1');
  versions = (await u.get(`/api/projects/${p.id}/versions`)).json.versions;
  assert.ok(versions.some(v => v.label === 'Before restore'), 'the replaced state was kept so the restore can be undone');
  for (let i = 0; i < 30; i++) await u.post(`/api/projects/${p.id}/checkpoint`, { label: 'c' + i });
  assert.ok((await u.get(`/api/projects/${p.id}/versions`)).json.versions.length <= 20, 'history is capped');
});

test('duplicate and quotas', async () => {
  const u = await newUser(s.base);
  const p = await create(u, 'Original', sampleProject('Original', { tags: [{ id: 'a', name: 'A', dataType: 'Bool', address: '%M0.0', comment: '' }] }));
  const d = await u.post(`/api/projects/${p.id}/duplicate`, {});
  assert.equal(d.status, 201); assert.equal(d.json.project.name, 'Original (copy)'); assert.equal(d.json.project.revision, 1);
  assert.equal((await u.get(`/api/projects/${d.json.project.id}`)).json.data.tags.length, 1);
  const admin = new Client(s.base, { ip: '10.88.0.1' });
  await admin.post('/api/setup', { token: 'setup-token-1234567890', email: 'quota-admin@example.com', name: 'Q', password: PW });
  assert.equal((await admin.put('/api/admin/settings', { maxPersonalProjects: 3 })).status, 200);
  const q = await newUser(s.base);
  for (let i = 0; i < 3; i++) await create(q, 'p' + i);
  const over = await q.post('/api/projects', { name: 'one too many', data: sampleProject() });
  assert.equal(over.status, 409); assert.equal(over.json.error.code, 'quota_exceeded');
  await admin.put('/api/admin/settings', { maxPersonalProjects: 50 });
});

test('writes without any change are refused and rate limiting protects the database', async () => {
  const u = await newUser(s.base);
  const p = await create(u);
  assert.equal((await u.put(`/api/projects/${p.id}`, { baseRevision: 1 })).status, 400);
  assert.equal((await u.put(`/api/projects/${p.id}`, { name: 'x' })).status, 400, 'baseRevision is mandatory');
  assert.equal((await u.put(`/api/projects/${p.id}`, { baseRevision: 'abc', name: 'x' })).status, 400);
  assert.equal((await u.put(`/api/projects/${p.id}`, { baseRevision: 1, name: 'x', ownerId: 'someone' })).status, 400, 'no mass assignment');
});
