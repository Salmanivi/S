import './env.mjs';
import http from 'node:http';
import { setDriver } from '../api/_lib/db.js';
import { makeSqliteDriver } from './sqlite-driver.mjs';
import handler from '../api/_lib/handler.js';
import { invalidateSettings } from '../api/_lib/settings.js';

process.env.NODE_ENV = 'test';

export async function startServer({ env = {} } = {}) {
  Object.assign(process.env, { SETUP_TOKEN: 'setup-token-1234567890', CRON_SECRET: 'cron-secret-for-tests-123', ...env });
  const driver = makeSqliteDriver();
  setDriver(driver);
  invalidateSettings();
  const server = http.createServer((req, res) => handler(req, res));
  await new Promise(r => server.listen(0, '127.0.0.1', r));
  const base = `http://127.0.0.1:${server.address().port}`;
  return { base, driver, close: () => new Promise(r => server.close(r)) };
}

/** A tiny browser: keeps cookies, sends a same-origin Origin header like fetch() in a page does. */
export class Client {
  constructor(base, { ip = '10.0.0.1' } = {}) { this.base = base; this.jar = new Map(); this.ip = ip; }
  cookieHeader() { return [...this.jar].map(([k, v]) => `${k}=${v}`).join('; '); }
  async req(method, path, body, { origin = this.base, headers = {}, raw, contentType = 'application/json', noOrigin = false } = {}) {
    const h = { 'x-forwarded-for': this.ip, 'user-agent': 'TestBrowser/1.0 (Linux)', ...headers };
    if (this.jar.size) h.cookie = this.cookieHeader();
    if (!noOrigin) h.origin = origin;
    let payload;
    if (raw !== undefined) { payload = raw; h['content-type'] = contentType; }
    else if (body !== undefined) { payload = JSON.stringify(body); h['content-type'] = contentType; }
    const res = await fetch(this.base + path, { method, headers: h, body: payload });
    for (const sc of res.headers.getSetCookie?.() ?? []) {
      const [pair] = sc.split(';');
      const i = pair.indexOf('=');
      const k = pair.slice(0, i), v = decodeURIComponent(pair.slice(i + 1));
      if (/Max-Age=0/i.test(sc) || v === '') this.jar.delete(k); else this.jar.set(k, v);
    }
    const text = await res.text();
    let json; try { json = text ? JSON.parse(text) : undefined; } catch { json = undefined; }
    return { status: res.status, json, text, headers: res.headers, setCookie: res.headers.getSetCookie?.() ?? [] };
  }
  get(p, o) { return this.req('GET', p, undefined, o); }
  post(p, b, o) { return this.req('POST', p, b ?? {}, o); }
  put(p, b, o) { return this.req('PUT', p, b, o); }
  patch(p, b, o) { return this.req('PATCH', p, b, o); }
  del(p, o) { return this.req('DELETE', p, undefined, o); }
}

let n = 0;
export const PW = 'correct horse battery staple';
export async function newUser(base, { name = 'Tester', ip, admin = false, email } = {}) {
  const c = new Client(base, { ip: ip ?? `10.1.${Math.floor(++n / 250)}.${n % 250}` });
  const e = email ?? `user${n}-${Math.random().toString(36).slice(2, 7)}@example.com`;
  const r = await c.post('/api/auth/register', { email: e, name, password: PW });
  if (r.status !== 201) throw new Error('register failed: ' + r.text);
  c.email = e; c.user = r.json.user;
  return c;
}

export const sampleProject = (name = 'Demo', extra = {}) => ({
  name, blocks: [{ id: 'b1', kind: 'main', name: 'Main', networks: [] }], hardware: { cpuId: '1214C_DC_DC_DC', modules: [], props: {} },
  tags: [], devices: [], watch: [], ...extra,
});
