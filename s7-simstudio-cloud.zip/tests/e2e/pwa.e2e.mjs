// The installable ONLINE web app: opens offline from the cache, simulator works offline, accounts resume when online.
import { createRequire } from 'node:module';
import { startStack } from '../dev-server.mjs';
const require = createRequire(process.env.PW_MODULE_DIR ? process.env.PW_MODULE_DIR.replace(/\/?$/, '/') : import.meta.url);
const { chromium } = require('playwright');

const stack = await startStack();
const browser = await chromium.launch();
const ctx = await browser.newContext({ viewport: { width: 1280, height: 800 } });
const page = await ctx.newPage();
page.setDefaultTimeout(9000);
const problems = [];
page.on('console', m => { if (/Content Security Policy|Refused to/.test(m.text()) || (m.type() === 'error' && !/40[0-9]|net::ERR|Failed to load resource/.test(m.text()))) problems.push(m.text().slice(0, 140)); });
page.on('pageerror', e => problems.push('pageerror ' + e.message));
let failures = 0;
const check = (name, c, extra = '') => { console.log(`${c ? '  ✓' : '  ✗'} ${name}${extra ? ' — ' + extra : ''}`); if (!c) failures++; };

console.log('\nInstallability');
await page.goto(stack.base + '/');
await page.waitForSelector('text=Siemens S7 ladder simulator');
const manifestHref = await page.locator('link[rel=manifest]').getAttribute('href');
const mf = await (await fetch(stack.base + manifestHref)).json();
check('web app manifest is linked and valid', mf.name === 'S7 SimStudio' && mf.display === 'standalone' && mf.start_url === '/');
const sizes = mf.icons.map(i => `${i.sizes}/${i.purpose}`);
check('192px, 512px and maskable icons are declared', sizes.includes('192x192/any') && sizes.includes('512x512/any') && sizes.includes('512x512/maskable'), sizes.join(', '));
let iconsOk = true;
for (const i of mf.icons.filter(i => i.type === 'image/png')) { const b = Buffer.from(await (await fetch(stack.base + i.src)).arrayBuffer()); if (b.slice(1, 4).toString() !== 'PNG') iconsOk = false; }
check('icon files exist and are real PNGs', iconsOk);
await page.evaluate(() => navigator.serviceWorker.ready);
await page.waitForFunction(() => !!navigator.serviceWorker.controller, null, { timeout: 8000 }).catch(async () => { await page.reload(); });
const cached = await page.evaluate(async () => { const k = (await caches.keys()).filter(x => x.startsWith('s7sim-')); const c = await caches.open(k[0]); return { caches: k.length, urls: (await c.keys()).map(r => new URL(r.url).pathname) }; });
check('service worker installed and the app shell is cached', cached.caches === 1 && cached.urls.includes('/') && cached.urls.some(u => /^\/assets\/app-.*\.js$/.test(u)) && cached.urls.some(u => /^\/assets\/app-.*\.css$/.test(u)), `${cached.urls.length} files`);
check('API addresses are never precached', !cached.urls.some(u => u.startsWith('/api')));

console.log('\nOnline: accounts work as before');
const r = await page.evaluate(async () => (await fetch('/api/auth/register', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ email: 'pwa@e2e.test', name: 'PWA User', password: 'pwa-user-long-password-9' }) })).status);
check('register works through the page', r === 201, String(r));
await page.reload();
await page.waitForSelector('text=Your cloud projects');
check('signed in: account menu and cloud projects visible', await page.getByLabel('Account menu').isVisible());

console.log('\nOffline');
await ctx.setOffline(true);
await page.reload();
await page.waitForSelector('text=Siemens S7 ladder simulator');
await page.waitForTimeout(800);
const offBody = await page.locator('body').innerText();
check('the app opens with no internet (served from the cache)', /Siemens S7 ladder simulator/.test(offBody));
check('cloud features step aside instead of showing dead buttons', !/Your cloud projects|Save online and work together/.test(offBody));
check('author credit still shown', /Created by\s+Salman/.test(offBody));
await page.getByRole('button', { name: /Motor start\/stop/ }).click();
await page.waitForSelector('.grid-bg');
await page.getByTitle('Compile (Ctrl+B)').click();
await page.waitForSelector('text=Compilation successful');
await page.getByTitle('Download to device (Ctrl+L)').click();
await page.getByTitle('RUN', { exact: true }).click();
await page.waitForTimeout(500);
check('the simulator works offline', /RUN/.test(await page.locator('body').innerText()));
const apiOffline = await page.evaluate(() => fetch('/api/health').then(() => 'answered').catch(() => 'failed'));
check('API calls fail while offline (never answered from the cache)', apiOffline === 'failed', apiOffline);

console.log('\nBack online');
await ctx.setOffline(false);
await page.evaluate(() => window.dispatchEvent(new Event('online')));
await page.getByRole('button', { name: /Close project|S7 SimStudio/ }).first().isVisible().catch(() => {});
await page.waitForFunction(() => document.querySelector('button[aria-label="Account menu"]') !== null, null, { timeout: 9000 });
check('accounts come back automatically (still signed in)', await page.getByLabel('Account menu').first().isVisible());
const health = await page.evaluate(() => fetch('/api/health').then(r => r.json()));
check('API reachable again', health.checks.database === 'ok');
check('no CSP violations or console errors', problems.length === 0, problems.join(' | '));

await browser.close(); await stack.close();
console.log(failures ? `\n${failures} PWA check(s) FAILED\n` : '\nPWA checks passed ✓\n');
process.exit(failures ? 1 : 0);
