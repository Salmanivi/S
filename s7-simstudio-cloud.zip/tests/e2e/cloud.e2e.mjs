import { createRequire } from 'node:module';
import { startStack } from '../dev-server.mjs';
// Needs Playwright:  npm i -D playwright && npx playwright install chromium   (PW_MODULE_DIR can point to another install)
const require = createRequire(process.env.PW_MODULE_DIR ? process.env.PW_MODULE_DIR.replace(/\/?$/, '/') : import.meta.url);
const { chromium } = require('playwright');

const stack = await startStack();
const browser = await chromium.launch();
const problems = [];           // console errors, CSP violations, page errors from every page
let failures = 0;
const step = async (name, fn) => {
  try { await fn(); console.log('  ✓ ' + name); }
  catch (e) { failures++; console.log('  ✗ ' + name + '\n      ' + String(e.message).split('\n').slice(0, 3).join('\n      ')); }
};
const expect = (c, msg) => { if (!c) throw new Error(msg || 'assertion failed'); };
const PW = 'e2e-password-correct-horse';

async function newPage(opts = {}) {
  const ctx = await browser.newContext({ viewport: { width: 1440, height: 900 }, ...opts });
  const page = await ctx.newPage();
  page.setDefaultTimeout(7000);
  page.on('console', m => { const t = m.text(); if (m.type() === 'error' || /Content Security Policy|Refused to/.test(t)) problems.push(`[console.${m.type()}] ${t.slice(0, 200)}`); });
  page.on('pageerror', e => problems.push('[pageerror] ' + e.message));
  await page.goto(stack.base + '/');
  await page.waitForSelector('text=Siemens S7 ladder simulator');
  return page;
}
const phoneOpts = { viewport: { width: 390, height: 844 }, deviceScaleFactor: 2, hasTouch: true, isMobile: true };
const api = (page, method, path, body) => page.evaluate(async ([m, p, b]) => {
  const r = await fetch('/api' + p, { method: m, headers: b ? { 'Content-Type': 'application/json' } : undefined, body: b ? JSON.stringify(b) : undefined, credentials: 'same-origin' });
  return { status: r.status, json: await r.json().catch(() => null) };
}, [method, path, body]);
const chip = (page) => page.locator('button[aria-label^="Cloud status"]:visible');
const waitSaved = (page) => page.waitForFunction(() => [...document.querySelectorAll('button[aria-label^="Cloud status"]')].some(b => b.offsetParent && /Saved/.test(b.getAttribute('aria-label'))), null, { timeout: 8000 });
const networks = (page) => page.locator('.grid-bg').count();

async function register(page, name, email) {
  await page.getByRole('button', { name: 'Sign in' }).first().click();
  await page.getByRole('button', { name: 'Create an account' }).click();
  await page.locator('input[autocomplete=name]').fill(name);
  await page.locator('input[type=email]').fill(email);
  await page.locator('input[type=password]').fill(PW);
  await page.locator('input[type=checkbox]').check();
  await page.locator('[role=dialog] button[type=submit]').click();
  await page.waitForSelector('text=Siemens S7 ladder simulator');
}
async function login(page, email) {
  await page.getByRole('button', { name: 'Sign in' }).first().click();
  await page.locator('input[type=email]').fill(email);
  await page.locator('input[type=password]').fill(PW);
  await page.getByRole('button', { name: /^Sign in$/ }).last().click();
  await page.waitForSelector('text=Your cloud projects');
}
const createProject = async (page, name) => {
  await page.getByRole('button', { name: 'New project' }).first().click();
  await page.getByLabel('Project name').fill(name);
  await page.getByRole('button', { name: 'Create project' }).click();
  await page.waitForSelector('.grid-bg');
};

console.log('\n=== FIRST-TIME SETUP ===');
let admin, adminPage;
await step('start screen offers cloud sign-in and the setup banner', async () => {
  adminPage = await newPage();
  expect(await adminPage.getByText('Finish setting up your server').isVisible(), 'setup banner missing');
  expect(await adminPage.getByRole('button', { name: 'Sign in' }).first().isVisible());
});
await step('wrong setup token is refused', async () => {
  await adminPage.getByRole('button', { name: 'Create administrator' }).click();
  const pw = adminPage.locator('input[type=password]');
  await pw.nth(0).fill('totally-wrong-token-value');
  await adminPage.locator('input[autocomplete=name]').fill('Root Admin');
  await adminPage.locator('input[type=email]').fill('admin@e2e.test');
  await pw.nth(1).fill(PW);
  await adminPage.getByRole('button', { name: 'Create administrator' }).last().click();
  await adminPage.waitForSelector('text=setup token is not correct');
});
await step('correct token creates the administrator and opens the admin console', async () => {
  await adminPage.locator('input[type=password]').nth(0).fill(process.env.SETUP_TOKEN);
  await adminPage.getByRole('button', { name: 'Create administrator' }).last().click();
  await adminPage.waitForSelector('text=Admin console');
  await adminPage.waitForSelector('text=Deployment health');
  expect(await adminPage.getByText('Users', { exact: true }).first().isVisible());
  expect(await adminPage.getByRole('tab', { name: 'Users' }).isVisible());
});
await step('setup disappears once an admin exists', async () => {
  const r = await api(adminPage, 'POST', '/setup', { token: process.env.SETUP_TOKEN, email: 'x@e2e.test', name: 'X', password: PW });
  expect(r.status === 404, 'setup still reachable: ' + r.status);
});

console.log('\n=== ACCOUNTS ===');
let a, aEmail = 'alice@e2e.test';
await step('register through the UI lands on the start screen, signed in', async () => {
  a = await newPage();
  await register(a, 'Alice Tester', aEmail);
  await a.waitForSelector('text=Your cloud projects');
  expect(await a.getByLabel('Account menu').isVisible());
});
await step('weak password and unchecked terms are blocked in the form', async () => {
  const p = await newPage();
  await p.getByRole('button', { name: 'Sign in' }).first().click();
  await p.getByRole('button', { name: 'Create an account' }).click();
  await p.locator('input[autocomplete=name]').fill('W');
  await p.locator('input[type=email]').fill('weak@e2e.test');
  await p.locator('input[type=password]').fill('short');
  expect(await p.locator('[role=dialog] button[type=submit]').isDisabled(), 'submit should be disabled');
  await p.context().close();
});
await step('wrong password shows a generic error', async () => {
  const p = await newPage();
  await p.getByRole('button', { name: 'Sign in' }).first().click();
  await p.locator('input[type=email]').fill(aEmail);
  await p.locator('input[type=password]').fill('not-the-right-password-1');
  await p.getByRole('button', { name: /^Sign in$/ }).last().click();
  await p.waitForSelector('text=Incorrect email or password');
  await p.context().close();
});

console.log('\n=== CLOUD PROJECTS & AUTOSAVE ===');
let projectId;
await step('new project can be created straight into the cloud and shows "Saved"', async () => {
  await createProject(a, 'Conveyor line');
  await waitSaved(a);
  const list = await api(a, 'GET', '/projects');
  expect(list.json.projects.length === 1 && list.json.projects[0].name === 'Conveyor line', JSON.stringify(list.json));
  projectId = list.json.projects[0].id;
});
let before;
await step('editing autosaves (revision goes up) without any button press', async () => {
  before = await networks(a);
  await a.getByText('+ Add network').click();
  await a.waitForFunction(() => [...document.querySelectorAll('button[aria-label^="Cloud status"]')].some(b => b.offsetParent && /Saving/.test(b.getAttribute('aria-label'))), null, { timeout: 4000 }).catch(() => {});
  await waitSaved(a);
  const m = await api(a, 'GET', `/projects/${projectId}/meta`);
  expect(m.json.project.revision >= 2, 'revision ' + m.json.project.revision);
  expect((await networks(a)) === before + 1);
});
await step('reload → project is in the list → opens with the saved content', async () => {
  await a.reload();
  await a.waitForSelector('text=Your cloud projects');
  await a.getByRole('button', { name: /Conveyor line/ }).click();
  await a.waitForSelector('.grid-bg');
  expect((await networks(a)) === before + 1, `networks ${await networks(a)} vs ${before + 1}`);
  await waitSaved(a);
});
await step('guest mode still works: local project, no cloud binding', async () => {
  const g = await newPage();
  await g.getByRole('button', { name: 'New project' }).first().click();
  await g.getByRole('button', { name: 'Create project' }).click();
  await g.waitForSelector('.grid-bg');
  expect(await g.locator('button[aria-label="Sign in to save online"]:visible').count() === 1, 'guest should see the sign-in-to-save chip');
  await g.context().close();
});

console.log('\n=== TWO DEVICES ===');
let b;
await step('second device signs in and sees the same project', async () => {
  b = await newPage();
  await login(b, aEmail);
  await b.getByRole('button', { name: /Conveyor line/ }).click();
  await b.waitForSelector('.grid-bg');
  expect((await networks(b)) === before + 1);
});
await step('an edit on device A shows up on device B without reloading', async () => {
  await a.getByText('+ Add network').click();
  await waitSaved(a);
  await b.evaluate(() => document.dispatchEvent(new Event('visibilitychange')));   // what happens when the tab is focused
  await b.waitForFunction(n => document.querySelectorAll('.grid-bg').length === n, before + 2, { timeout: 6000 });
});
await step('simultaneous edits: the second save is NOT silently overwritten — conflict dialog, "Keep both"', async () => {
  const held = []; let hold = true;
  await b.route('**/api/projects/*', r => (hold && r.request().method() === 'PUT' ? held.push(r) : r.continue()));
  await b.getByText('+ Add network').click();
  await new Promise(r => setTimeout(r, 2200));                        // B's autosave request is now parked
  expect(held.length === 1, 'B save not issued: ' + held.length);
  await a.getByText('+ Add network').click();                         // A saves first
  await waitSaved(a);
  hold = false;
  await held[0].continue();                                           // B's stale save reaches the server
  await b.waitForSelector('text=This project changed elsewhere');
  await b.getByRole('button', { name: /Keep both/ }).click();
  await b.waitForFunction(() => !document.body.innerText.includes('This project changed elsewhere'));
  const list = await api(b, 'GET', '/projects');
  expect(list.json.projects.length === 2, 'expected the original and a copy: ' + list.json.projects.map(p => p.name));
  expect(list.json.projects.some(p => /my copy/.test(p.name)));
});

console.log('\n=== OFFLINE ===');
await step('losing the connection keeps edits and syncs when it returns', async () => {
  await a.getByRole('button', { name: /Conveyor line|Project/ }).first().isVisible().catch(() => {});
  const ctx = a.context();
  await ctx.setOffline(true);
  const n = await networks(a);
  await a.getByText('+ Add network').click();
  await a.waitForFunction(() => [...document.querySelectorAll('button[aria-label^="Cloud status"]')].some(b => b.offsetParent && /Offline|Saving/.test(b.getAttribute('aria-label'))), null, { timeout: 8000 });
  await ctx.setOffline(false);
  await a.evaluate(() => window.dispatchEvent(new Event('online')));
  await waitSaved(a);
  const m = await api(a, 'GET', `/projects/${projectId}`);
  expect(m.json.data.blocks.some(blk => blk.networks.length >= n + 1), 'offline edit was not stored');
});

console.log('\n=== TEAMS ===');
let bob, bobEmail = 'bob@e2e.test', inviteLink, teamId;
await step('create a team and an invite link in the UI', async () => {
  await a.getByRole('button', { name: /Cloud status/ }).first().isVisible();
  await a.getByLabel('Account menu').click();
  await a.getByRole('menuitem', { name: 'Teams' }).click();
  await a.getByLabel('Team name').fill('Plant crew');
  await a.getByRole('button', { name: /^Create$/ }).click();
  await a.waitForSelector('text=Invite people');
  await a.locator('select').first().selectOption('viewer');
  await a.getByRole('button', { name: 'Create invite link' }).click();
  await a.waitForSelector('text=shown only once');
  inviteLink = await a.getByLabel('Link').inputValue();
  expect(/\/invite\/[\w-]{20,}$/.test(inviteLink), inviteLink);
  const t = await api(a, 'GET', '/teams');
  teamId = t.json.teams[0].id;
});
await step('a new user opens the invite link, registers, and joins as viewer', async () => {
  await a.getByRole('button', { name: 'Back' }).click();                // leave the Teams page
  bob = await (await browser.newContext({ viewport: { width: 1440, height: 900 } })).newPage();
  bob.setDefaultTimeout(7000);
  bob.on('console', m => { if (m.type() === 'error' || /Content Security Policy|Refused to/.test(m.text())) problems.push(`[bob ${m.type()}] ${m.text().slice(0, 200)}`); });
  await bob.goto(inviteLink);
  await bob.waitForSelector('text=Welcome back');
  await bob.getByRole('button', { name: 'Create an account' }).click();
  await bob.locator('input[autocomplete=name]').fill('Bob Viewer');
  await bob.locator('input[type=email]').fill(bobEmail);
  await bob.locator('input[type=password]').fill(PW);
  await bob.locator('input[type=checkbox]').check();
  await bob.locator('[role=dialog] button[type=submit]').click();
  await bob.waitForSelector('text=Team invitation');
  await bob.waitForSelector('text=Plant crew');
  await bob.getByRole('button', { name: 'Join team' }).click();
  await bob.waitForSelector('text=Members');
  const mine = (await api(bob, 'GET', '/teams')).json.teams;
  expect(mine.length === 1 && mine[0].name === 'Plant crew' && mine[0].role === 'viewer', 'bob teams: ' + JSON.stringify(mine));
  const txt = await bob.locator('[role=dialog]').last().innerText();
  expect(/you are\s+viewer/i.test(txt), 'UI should state the role, got: ' + txt.replace(/\s+/g, ' ').slice(0, 160));
});
await step('team project: viewer opens it read-only and cannot edit', async () => {
  const p = await api(a, 'POST', '/projects', { name: 'Shared line', data: { name: 'Shared line', blocks: [{ id: 'b1', kind: 'main', name: 'Main', comment: '', networks: [{ id: 'n1', title: '', comment: '', root: { kind: 'series', id: 's1', items: [] } }] }], hardware: { cpuId: '1214C_DC_DC_DC', modules: [], props: { name: 'PLC_1', ip: '', clockEnabled: true, clockByte: 0, sysEnabled: true, sysByte: 1, watchdogMs: 150 } }, tags: [], devices: [], watch: [] }, teamId });
  expect(p.status === 201, JSON.stringify(p));
  await bob.goto(stack.base + '/');
  await bob.waitForSelector('text=Your cloud projects');
  await bob.getByRole('button', { name: /Shared line/ }).click();
  await bob.waitForSelector('.grid-bg');
  expect(await bob.locator('button[aria-label^="Cloud status"]:visible').getAttribute('aria-label') === 'Cloud status: View only');
  const n = await networks(bob);
  await bob.getByText('+ Add network').click();
  await bob.waitForSelector('text=View-only');
  expect((await networks(bob)) === n, 'view-only project must not change');
});
await step('API enforces the same rule even if the UI is bypassed', async () => {
  const pid = (await api(bob, 'GET', '/projects')).json.projects.find(p => p.name === 'Shared line').id;
  const w = await api(bob, 'PUT', `/projects/${pid}`, { baseRevision: 1, name: 'hacked' });
  expect(w.status === 403, 'viewer write status ' + w.status);
});
await step('removing the viewer ends their access immediately', async () => {
  const members = (await api(a, 'GET', `/teams/${teamId}`)).json.members;
  const bobId = members.find(m => !m.me).id;
  await api(a, 'DELETE', `/teams/${teamId}/members/${bobId}`);
  const r = await api(bob, 'GET', '/projects');
  expect(r.json.projects.every(p => p.name !== 'Shared line'), 'still visible after removal');
});

console.log('\n=== ADMIN ===');
await step('admin sees users, can open details and disable an account → that user is signed out', async () => {
  await adminPage.reload();
  await adminPage.waitForSelector('text=Siemens S7 ladder simulator');
  await adminPage.getByLabel('Account menu').click();
  await adminPage.getByRole('menuitem', { name: 'Admin console' }).click();
  await adminPage.getByRole('tab', { name: 'Users' }).click();
  await adminPage.getByPlaceholder('Search name or email').fill('bob@');
  await adminPage.getByRole('button', { name: /Bob Viewer/ }).click();
  await adminPage.getByRole('button', { name: /^Disable$/ }).click();
  await adminPage.waitForSelector('text=Disabled');
  const r = await api(bob, 'GET', '/auth/me');
  expect(r.status === 401, 'disabled user still signed in: ' + r.status);
});
await step('announcement set by the admin appears for everyone', async () => {
  await adminPage.keyboard.press('Escape');                            // closes the user dialog (Escape works in dialogs)
  await adminPage.getByRole('tab', { name: 'Settings' }).click();
  await adminPage.getByLabel('Announcement (leave empty for none)').fill('Maintenance tonight at 22:00 <b>UTC</b>');
  await adminPage.getByRole('button', { name: 'Save settings' }).click();
  await adminPage.waitForSelector('text=Saved ✓');
  const fresh = await newPage();
  await fresh.waitForSelector('text=Maintenance tonight at 22:00');
  expect((await fresh.locator('b', { hasText: 'UTC' }).count()) === 0, 'announcement HTML must be shown as text, not rendered');
  await fresh.context().close();
});
await step('audit log records what happened', async () => {
  const ev = (await api(adminPage, 'GET', '/admin/audit?limit=100')).json.events.map(e => e.action);
  for (const need of ['setup.admin_created', 'auth.register', 'auth.login', 'team.create', 'team.join', 'admin.user_update']) expect(ev.includes(need), 'missing ' + need);
});

console.log('\n=== SIGN OUT ===');
await step('signing out closes the private project and shows the sign-in prompt', async () => {
  await a.getByLabel('Account menu').click();
  await a.getByRole('menuitem', { name: 'Sign out' }).click();
  await a.waitForSelector('text=Save online and work together');
  expect((await api(a, 'GET', '/auth/me')).status === 401);
});

console.log('\n=== SECURITY HEADERS / CSP ===');
await step('no CSP violations or console errors during the whole run', async () => {
  const relevant = problems.filter(p => !/401 \(Unauthorized\)|403 \(Forbidden\)|409 \(Conflict\)|404 \(Not Found\)|429|Failed to load resource/.test(p));
  expect(relevant.length === 0, relevant.slice(0, 5).join('\n      '));
});
await step('bundle loads from /assets with immutable caching and CSP forbids inline script', async () => {
  const html = await (await fetch(stack.base + '/')).text();
  expect(!/<script(?![^>]*\bsrc=)[^>]*>[^<]/.test(html), 'inline <script> in index.html');
  const css = html.match(/assets\/app-\w+\.js/)[0];
  const r = await fetch(stack.base + '/' + css);
  expect(/immutable/.test(r.headers.get('cache-control')));
});

await browser.close();
await stack.close();
console.log(failures ? `\n${failures} E2E step(s) FAILED\n` : '\nAll E2E steps passed ✓\n');
process.exit(failures ? 1 : 0);
