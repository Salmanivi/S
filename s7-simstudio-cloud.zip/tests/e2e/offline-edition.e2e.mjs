// The OFFLINE EDITION (single-file build, `npm run build:single`) as it runs inside an APK/EXE wrapper.
// A wrapper serves local files from its own origin and often answers EVERY path with the app itself (worst case below).
import http from 'node:http';
import fs from 'node:fs';
import path from 'node:path';
import { createRequire } from 'node:module';
import { fileURLToPath } from 'node:url';
const require = createRequire(process.env.PW_MODULE_DIR ? process.env.PW_MODULE_DIR.replace(/\/?$/, '/') : import.meta.url);
const { chromium } = require('playwright');
const root = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '../..');
const htmlPath = process.env.OFFLINE_HTML || path.join(root, 'dist/index.html');
const html = fs.readFileSync(htmlPath, 'utf8');
let failures = 0;
const check = (name, c, extra = '') => { console.log(`${c ? '  ✓' : '  ✗'} ${name}${extra ? ' — ' + extra : ''}`); if (!c) failures++; };

const hits = [];
const srv = http.createServer((req, res) => { hits.push(req.url); res.setHeader('Content-Type', 'text/html; charset=utf-8'); res.end(html); });
await new Promise(r => srv.listen(0, '127.0.0.1', r));
const base = `http://127.0.0.1:${srv.address().port}/`;
const browser = await chromium.launch();

async function run(label, url, hitsExpected) {
  console.log(`\n${label}`);
  const ctx = await browser.newContext({ viewport: { width: 1280, height: 800 }, acceptDownloads: true });
  const page = await ctx.newPage();
  page.setDefaultTimeout(8000);
  const logs = [];
  page.on('console', m => { if (['error', 'warning'].includes(m.type())) logs.push(m.text().slice(0, 140)); });
  page.on('pageerror', e => logs.push('pageerror ' + e.message));
  hits.length = 0;
  await page.goto(url);
  await page.waitForSelector('text=Siemens S7 ladder simulator');
  await page.waitForTimeout(700);
  const body = await page.locator('body').innerText();
  if (hitsExpected !== null) check('makes no request to any /api address', !hits.some(h => h.startsWith('/api')), JSON.stringify(hits));
  check('shows no sign-in, account or cloud UI', !/Sign in|Create account|Save online and work together|Finish setting up|Your cloud projects/.test(body));
  check('credits the author on the start screen', /Created by\s+Salman/.test(body));

  await page.getByRole('button', { name: /About & contact/ }).click();
  await page.getByRole('dialog', { name: 'About & contact' }).waitFor();
  const dlg = page.getByRole('dialog', { name: 'About & contact' });
  check('About page names the author', await dlg.getByText('Salman', { exact: false }).first().isVisible());
  check('email is a working mailto: link', await dlg.locator('a[href="mailto:salmanino.ahmedino@gmail.com"]').count() === 1);
  check('phone is a working tel: link', await dlg.locator('a[href="tel:+201154390240"]').count() === 1);
  check('phone number is displayed as given', (await dlg.innerText()).includes('+20 11 54390240'));
  check('explains this is the offline edition', /Offline edition/.test(await dlg.innerText()));
  check('no Terms/Privacy links when there is no server', !/Terms of use|Privacy policy/.test(await dlg.innerText()));
  await page.getByRole('button', { name: 'Back' }).click();

  await page.getByRole('button', { name: /Motor start\/stop/ }).click();
  await page.waitForSelector('.grid-bg');
  check('no cloud status chip inside the editor', (await page.locator('button[aria-label^="Cloud status"], button[aria-label="Save to cloud"], button[aria-label="Sign in to save online"]').count()) === 0);
  await page.getByTitle('Compile (Ctrl+B)').click();
  await page.waitForSelector('text=Compilation successful');
  await page.getByTitle('Download to device (Ctrl+L)').click();
  await page.getByTitle('RUN', { exact: true }).click();
  await page.waitForTimeout(600);
  check('the simulator compiles and runs', /RUN/.test(await page.locator('body').innerText()));
  const dl = page.waitForEvent('download', { timeout: 4000 }).catch(() => null);
  await page.keyboard.press('Control+s');
  const d = await dl;
  check('project can be exported to a file (works without any server)', !!d, d ? d.suggestedFilename() : 'no download');
  await page.getByRole('button', { name: /Help|Quick guide/ }).first().click().catch(() => {});
  if (hitsExpected !== null) check('still no /api request after using the app', !hits.some(h => h.startsWith('/api')), JSON.stringify(hits));
  check('no console errors', logs.length === 0, logs.join(' | '));
  await ctx.close();
}

await run('Wrapper serving the app for every path (https://localhost-style)', base, true);
await run('Same, deep path inside the wrapper', base + 'index.html?x=1', true);
await run('Opened straight from disk (file://)', 'file://' + htmlPath, null);

await browser.close(); srv.close();
console.log(failures ? `\n${failures} offline-edition check(s) FAILED\n` : '\nOffline edition checks passed ✓\n');
process.exit(failures ? 1 : 0);
