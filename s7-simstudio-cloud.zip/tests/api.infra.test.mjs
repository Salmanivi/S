import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
import { startServer, Client, newUser, sampleProject, PW } from './helpers.mjs';
import { setDriver, getDb, classifyDbError } from '../api/_lib/db.js';
import { migrate, fullSchemaSql } from '../api/_lib/migrate.js';
import { hashPassword, verifyPassword, passwordProblem } from '../api/_lib/crypto.js';
import { makeSqliteDriver } from './sqlite-driver.mjs';

const s = await startServer();
test.after(() => s.close());
const admin = new Client(s.base, { ip: '10.70.0.1' });
await admin.post('/api/setup', { token: 'setup-token-1234567890', email: 'infra-admin@example.com', name: 'Infra', password: PW });

test('unknown routes, wrong methods and bad input answer with a clean JSON error', async () => {
  const c = new Client(s.base, { ip: '10.70.1.1' });
  const nf = await c.get('/api/does/not/exist');
  assert.equal(nf.status, 404); assert.equal(nf.json.error.code, 'not_found');
  assert.ok(nf.headers.get('x-request-id'));
  const m = await c.req('DELETE', '/api/config');
  assert.equal(m.status, 405); assert.ok(m.headers.get('allow').includes('GET'));
  assert.equal((await c.get('/api/auth/me')).status, 401);
  for (const h of ['x-content-type-options', 'cache-control', 'referrer-policy']) assert.ok((await c.get('/api/config')).headers.get(h), h);
  assert.equal((await c.get('/api/config')).headers.get('cache-control'), 'no-store');
  assert.equal((await c.req('OPTIONS', '/api/config')).status, 405, 'no CORS: cross-origin pages cannot use this API');
  assert.ok(!(await c.get('/api/config')).headers.get('access-control-allow-origin'));
});

test('an internal failure is logged with a request id and never leaks details to the client', async () => {
  const good = (await getDb());
  const broken = { ...good, query: async () => { throw new Error('SECRET connection string postgres://user:hunter2@db/prod'); } };
  setDriver(broken);
  const errors = []; const orig = console.error; console.error = (...a) => errors.push(a.join(' '));
  try {
    const r = await new Client(s.base, { ip: '10.70.2.1' }).get('/api/config');
    assert.equal(r.status, 500);
    assert.equal(r.json.error.code, 'server_error');
    assert.ok(r.json.error.requestId);
    assert.ok(!r.text.includes('hunter2') && !r.text.includes('postgres://') && !r.text.includes('at '), 'no secrets or stack traces in the response');
    assert.ok(errors.some(e => e.includes(r.json.error.requestId) && e.includes('hunter2')), 'details are in the server log, tied to the request id');
  } finally { console.error = orig; setDriver(good); }
});

test('health reports a database problem as a short category, not a message', async () => {
  const good = await getDb();
  setDriver({ ...good, query: async () => { const e = new Error('password authentication failed for user "x"'); e.code = '28P01'; throw e; } });
  const h = await new Client(s.base, { ip: '10.70.3.1' }).get('/api/health');
  setDriver(good);
  assert.equal(h.json.ok, false);
  assert.equal(h.json.checks.database, 'auth_failed');
  assert.ok(!h.text.includes('password authentication'));
  assert.equal(classifyDbError({ code: 'ENOTFOUND' }), 'unreachable');
  assert.equal(classifyDbError({ code: '3D000' }), 'database_missing');
});

test('cron cleanup: hidden without a secret, locked with a wrong one, removes expired data', async () => {
  const c = new Client(s.base, { ip: '10.70.4.1' });
  assert.equal((await c.get('/api/cron/cleanup')).status, 403);
  assert.equal((await c.get('/api/cron/cleanup', { headers: { authorization: 'Bearer wrong' } })).status, 403);
  const u = await newUser(s.base);
  const p = (await u.post('/api/projects', { name: 'old', data: sampleProject() })).json.project;
  await u.del(`/api/projects/${p.id}`);
  s.driver.raw.prepare('UPDATE sessions SET expires_at = 1 WHERE user_id = ?').run(u.user.id);
  s.driver.raw.prepare('UPDATE projects SET deleted_at = ? WHERE id = ?').run(Date.now() - 40 * 86400000, p.id);
  const ok = await c.get('/api/cron/cleanup', { headers: { authorization: 'Bearer cron-secret-for-tests-123' } });
  assert.equal(ok.status, 200);
  assert.ok(ok.json.removed.sessions >= 1 && ok.json.removed.trashedProjects >= 1);
  assert.equal((await u.get('/api/auth/me')).status, 401);
  const saved = process.env.CRON_SECRET; delete process.env.CRON_SECRET;
  assert.equal((await c.get('/api/cron/cleanup')).status, 404, 'cron endpoint does not exist when no secret is configured');
  process.env.CRON_SECRET = saved;
});

test('session cookie is __Host- prefixed and Secure behind HTTPS, plain on http', async () => {
  const email = `tls${Date.now()}@example.com`;
  const https = new Client(s.base, { ip: '10.70.5.1' });
  const r = await https.post('/api/auth/register', { email, name: 'T', password: PW }, { headers: { 'x-forwarded-proto': 'https' } });
  const cookie = r.setCookie[0];
  assert.match(cookie, /^__Host-s7s=/); assert.match(cookie, /; Secure/); assert.match(cookie, /Path=\//); assert.ok(!/Domain=/i.test(cookie));
  assert.match(cookie, /Max-Age=2592000/);
  assert.equal((await https.get('/api/auth/me', { headers: { 'x-forwarded-proto': 'https' } })).status, 200);
});

test('e-mail: provider payloads, enumeration-safe forgot password, working reset link', async () => {
  Object.assign(process.env, { MAIL_PROVIDER: 'resend', RESEND_API_KEY: 're_test_123', MAIL_FROM: 'SimStudio <no-reply@example.com>', APP_URL: 'https://sim.example.com/' });
  const sent = [];
  const realFetch = globalThis.fetch;
  globalThis.fetch = async (url, opts) => {
    if (String(url).startsWith('https://api.resend.com') || String(url).startsWith('https://api.brevo.com')) { sent.push({ url: String(url), opts }); return new Response('{"id":"x"}', { status: 200 }); }
    return realFetch(url, opts);
  };
  try {
    const email = `mail${Date.now()}@example.com`;
    const u = await newUser(s.base, { email });
    assert.ok((await new Client(s.base).get('/api/config')).json.mailEnabled);
    assert.equal(sent.length, 1, 'confirmation mail sent on registration');
    const reg = sent[0];
    assert.equal(reg.url, 'https://api.resend.com/emails');
    assert.equal(reg.opts.headers.Authorization, 'Bearer re_test_123');
    const body = JSON.parse(reg.opts.body);
    assert.deepEqual(body.to, [email]); assert.equal(body.from, 'SimStudio <no-reply@example.com>');
    assert.match(body.text, /https:\/\/sim\.example\.com\/verify-email\?token=[\w-]{20,}/, 'links use APP_URL, not the request host');
    const vtoken = /token=([\w-]+)/.exec(body.text)[1];
    assert.equal((await new Client(s.base, { ip: '10.70.6.1' }).post('/api/auth/verify', { token: vtoken })).status, 200);
    assert.equal((await u.get('/api/auth/me')).json.user.emailVerified, true);
    assert.equal((await new Client(s.base, { ip: '10.70.6.2' }).post('/api/auth/verify', { token: vtoken })).status, 400, 'one time');

    sent.length = 0;
    const c = new Client(s.base, { ip: '10.70.6.3' });
    const known = await c.post('/api/auth/forgot', { email });
    const unknown = await c.post('/api/auth/forgot', { email: 'ghost@example.com' });
    assert.deepEqual([known.status, known.json], [unknown.status, unknown.json], 'identical answer for known and unknown addresses');
    assert.equal(sent.length, 1, 'only the real account got a mail');
    const rtoken = /reset-password\?token=([\w-]+)/.exec(JSON.parse(sent[0].opts.body).text)[1];
    assert.equal((await c.post('/api/auth/reset', { token: rtoken, password: 'reset via the email link 1' })).status, 200);
    assert.equal((await new Client(s.base, { ip: '10.70.6.4' }).post('/api/auth/login', { email, password: 'reset via the email link 1' })).status, 200);
    for (let i = 0; i < 4; i++) await c.post('/api/auth/forgot', { email });
    assert.equal((await c.post('/api/auth/forgot', { email })).status, 429, 'reset mails are rate limited per account');

    // Brevo shape
    Object.assign(process.env, { MAIL_PROVIDER: 'brevo', BREVO_API_KEY: 'xkeysib-test', MAIL_FROM: 'SimStudio <me@example.com>' });
    sent.length = 0;
    await newUser(s.base, { email: `brevo${Date.now()}@example.com` });
    assert.equal(sent[0].url, 'https://api.brevo.com/v3/smtp/email');
    assert.equal(sent[0].opts.headers['api-key'], 'xkeysib-test');
    const bb = JSON.parse(sent[0].opts.body);
    assert.deepEqual(bb.sender, { name: 'SimStudio', email: 'me@example.com' }); assert.ok(bb.htmlContent && bb.textContent);

    // a failing provider must not break registration
    globalThis.fetch = async (url, opts) => (String(url).includes('brevo') ? new Response('nope', { status: 500 }) : realFetch(url, opts));
    const oldErr = console.error; console.error = () => {};
    const r = await new Client(s.base, { ip: '10.70.6.9' }).post('/api/auth/register', { email: `fail${Date.now()}@example.com`, name: 'F', password: PW });
    console.error = oldErr;
    assert.equal(r.status, 201);
  } finally {
    globalThis.fetch = realFetch;
    for (const k of ['MAIL_PROVIDER', 'RESEND_API_KEY', 'BREVO_API_KEY', 'MAIL_FROM', 'APP_URL']) delete process.env[k];
  }
});

test('required e-mail verification blocks sign-in until the link is used', async () => {
  Object.assign(process.env, { MAIL_PROVIDER: 'resend', RESEND_API_KEY: 'k', MAIL_FROM: 'a@example.com' });
  const realFetch = globalThis.fetch; const sent = [];
  globalThis.fetch = async (url, opts) => (String(url).includes('resend') ? (sent.push(JSON.parse(opts.body)), new Response('{}', { status: 200 })) : realFetch(url, opts));
  try {
    await admin.put('/api/admin/settings', { requireEmailVerification: true });
    const c = new Client(s.base, { ip: '10.70.7.1' });
    const email = `strict${Date.now()}@example.com`;
    const r = await c.post('/api/auth/register', { email, name: 'S', password: PW });
    assert.equal(r.status, 201); assert.equal(r.json.needsVerification, true); assert.equal(c.jar.size, 0, 'no session before verification');
    const blocked = await c.post('/api/auth/login', { email, password: PW });
    assert.equal(blocked.status, 403); assert.equal(blocked.json.error.code, 'email_not_verified');
    await c.post('/api/auth/verify', { token: /token=([\w-]+)/.exec(sent[0].text)[1] });
    assert.equal((await c.post('/api/auth/login', { email, password: PW })).status, 200);
  } finally {
    globalThis.fetch = realFetch; await admin.put('/api/admin/settings', { requireEmailVerification: false });
    for (const k of ['MAIL_PROVIDER', 'RESEND_API_KEY', 'MAIL_FROM']) delete process.env[k];
  }
});

test('invite last slot: concurrent joins cannot over-subscribe a single-use link', async () => {
  const owner = await newUser(s.base);
  const team = (await owner.post('/api/teams', { name: 'Race' })).json.team;
  const code = (await owner.post(`/api/teams/${team.id}/invites`, { role: 'viewer', maxUses: 1 })).json.code;
  const users = await Promise.all(Array.from({ length: 6 }, () => newUser(s.base)));
  const results = await Promise.all(users.map(u => u.post('/api/invites/accept', { code })));
  assert.equal(results.filter(r => r.status === 201).length, 1);
  assert.equal(s.driver.raw.prepare('SELECT COUNT(*) AS n FROM team_members WHERE team_id = ?').get(team.id).n, 2);
});

test('migrations are idempotent and the published schema.sql builds the same database', async () => {
  const d = makeSqliteDriver();
  assert.deepEqual(await migrate(d), ['001_init']);
  assert.deepEqual(await migrate(d), [], 'running again changes nothing');
  const tables = (db) => db.raw.prepare("SELECT name FROM sqlite_master WHERE type='table' AND name NOT LIKE 'sqlite_%' ORDER BY name").all().map(r => r.name);
  const d2 = makeSqliteDriver();
  d2.raw.exec(fullSchemaSql());
  assert.deepEqual(tables(d2), tables(d));
  assert.equal(d2.raw.prepare('SELECT COUNT(*) AS n FROM schema_migrations').get().n, 1);
  assert.deepEqual(await migrate(d2), [], 'a database prepared by schema.sql is recognised as up to date');
  const f = path.join(path.dirname(fileURLToPath(import.meta.url)), '..', 'db', 'schema.sql');
  if (fs.existsSync(f)) {
    const strip = (x) => x.replace(/VALUES \('001_init', \d+\)/, "VALUES ('001_init', 0)");
    assert.equal(strip(fs.readFileSync(f, 'utf8')), strip(fullSchemaSql()), 'db/schema.sql is up to date with migrations.js');
  }
});

test('foreign keys: orphan rows are impossible', async () => {
  const d = s.driver.raw;
  assert.throws(() => d.prepare("INSERT INTO sessions (id, user_id, token_hash, created_at, last_used_at, expires_at) VALUES ('s','nope','h',1,1,1)").run(), /FOREIGN KEY/);
  assert.throws(() => d.prepare("INSERT INTO projects (id, owner_user_id, team_id, name, data, size_bytes, created_at, updated_at) VALUES ('p',NULL,NULL,'n','{}',2,1,1)").run(), /CHECK/, 'a project must belong to exactly one owner');
});

test('password hashing: salted, verifiable, tamper-resistant; policy blocks weak choices', async () => {
  const a = await hashPassword('Correct-Horse-9'), b = await hashPassword('Correct-Horse-9');
  assert.notEqual(a, b, 'random salt');
  assert.match(a, /^s1\$\d+\$8\$1\$/);
  assert.equal(await verifyPassword('Correct-Horse-9', a), true);
  assert.equal(await verifyPassword('correct-horse-9', a), false);
  for (const junk of ['', 'x', 's1$a$b$c$d$e', 's2$1$1$1$a$b', null, undefined, 's1$2$8$1$AAAA$AAAA']) assert.equal(await verifyPassword('x', junk), false);
  assert.ok(passwordProblem('short1'));
  assert.ok(passwordProblem('password123'));
  assert.ok(passwordProblem('aaaaaaaaaaaa'));
  assert.ok(passwordProblem('x'.repeat(201)));
  assert.equal(passwordProblem('a long and unusual passphrase', 'bob@example.com'), null);
});

test('production Postgres driver: pooled queries, transactions commit/rollback, connection string cleanup', async () => {
  // a stand-in for the "pg" package, installed only for the duration of this test
  const dir = path.join(path.dirname(fileURLToPath(import.meta.url)), '..', 'node_modules', 'pg');
  fs.mkdirSync(dir, { recursive: true });
  fs.writeFileSync(path.join(dir, 'package.json'), '{"name":"pg","version":"0.0.0-mock","main":"index.js"}');
  fs.writeFileSync(path.join(dir, 'index.js'), `
    const log = (globalThis.__pglog ??= []);
    class Client { async query(t, p) { log.push(['query', t, p]); if (/FAIL/.test(t)) throw new Error('boom'); return { rows: [{ ok: 1 }] }; } release() { log.push(['release']); } }
    class Pool { constructor(o) { log.push(['pool', o]); this.c = new Client(); } on() {} async query(t, p) { return this.c.query(t, p); } async connect() { return this.c; } async end() {} }
    module.exports = { Pool, types: { setTypeParser(oid) { log.push(['parser', oid]); } } };`);
  const saved = { u: process.env.DATABASE_URL, m: process.env.AUTO_MIGRATE };
  process.env.DATABASE_URL = 'postgresql://user:pw@ep-x-pooler.eu-central-1.aws.neon.tech/neondb?sslmode=require&channel_binding=require';
  process.env.AUTO_MIGRATE = 'false';
  try {
    setDriver(null);
    const db = await getDb();
    const log = globalThis.__pglog;
    const pool = log.find(e => e[0] === 'pool')[1];
    assert.ok(!pool.connectionString.includes('channel_binding'), 'unsupported channel_binding parameter removed');
    assert.ok(pool.connectionString.includes('sslmode=require'));
    assert.ok(log.some(e => e[0] === 'parser' && e[1] === 20) && log.some(e => e[0] === 'parser' && e[1] === 1700), 'BIGINT/NUMERIC are returned as numbers');
    assert.deepEqual(await db.query('SELECT $1', [1]), [{ ok: 1 }]);
    log.length = 0;
    await db.tx(async t => { await t.query('SELECT 1'); });
    assert.deepEqual(log.map(e => e[0] === 'query' ? e[1] : e[0]), ['BEGIN', 'SELECT 1', 'COMMIT', 'release']);
    log.length = 0;
    await assert.rejects(db.tx(async t => { await t.query('FAIL now'); }), /boom/);
    assert.deepEqual(log.map(e => e[0] === 'query' ? e[1] : e[0]), ['BEGIN', 'FAIL now', 'ROLLBACK', 'release'], 'rolled back and the connection returned to the pool');
    delete process.env.DATABASE_URL; delete process.env.POSTGRES_URL; setDriver(null);
    await assert.rejects(getDb(), (e) => e.status === 503 && e.code === 'not_configured');
  } finally {
    fs.rmSync(path.join(dir, '..'), { recursive: true, force: true });
    if (saved.u === undefined) delete process.env.DATABASE_URL; else process.env.DATABASE_URL = saved.u;
    if (saved.m === undefined) delete process.env.AUTO_MIGRATE; else process.env.AUTO_MIGRATE = saved.m;
    setDriver(s.driver);
  }
});
