// Local full stack for end-to-end tests: the real API handler (SQLite instead of Postgres) + the production build in dist/,
// with the response headers from vercel.json applied (including the Content-Security-Policy).
import http from 'node:http';
import fs from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';

process.env.NODE_ENV = 'test';
const root = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '..');
const MIME = { '.webmanifest': 'application/manifest+json', '.png': 'image/png', '.html': 'text/html; charset=utf-8', '.js': 'text/javascript; charset=utf-8', '.css': 'text/css; charset=utf-8', '.svg': 'image/svg+xml', '.txt': 'text/plain; charset=utf-8' };

export async function startStack({ env = {} } = {}) {
  Object.assign(process.env, { SETUP_TOKEN: 'e2e-setup-token-1234567890', CRON_SECRET: 'cron-e2e-secret-123456', ...env });
  const { setDriver } = await import('../api/_lib/db.js');
  const { makeSqliteDriver } = await import('./sqlite-driver.mjs');
  const { default: handler } = await import('../api/_lib/handler.js');
  const driver = makeSqliteDriver();
  setDriver(driver);

  const vj = JSON.parse(fs.readFileSync(path.join(root, 'vercel.json'), 'utf8'));
  const globalHeaders = Object.fromEntries(vj.headers.find(h => h.source === '/(.*)').headers.map(h => [h.key, h.value]));
  const assetHeaders = Object.fromEntries(vj.headers.find(h => h.source === '/assets/(.*)').headers.map(h => [h.key, h.value]));
  const dist = path.join(root, 'dist');
  const log = [];

  const server = http.createServer((req, res) => {
    const url = new URL(req.url, 'http://x');
    if (url.pathname.startsWith('/api/')) {
      log.push(`${req.method} ${url.pathname}`);
      for (const [k, v] of Object.entries(globalHeaders)) res.setHeader(k, v);
      return handler(req, res);
    }
    let p = decodeURIComponent(url.pathname);
    let file = path.join(dist, p);
    if (!file.startsWith(dist)) { res.statusCode = 403; return res.end(); }
    let isAsset = p.startsWith('/assets/');
    if (!fs.existsSync(file) || fs.statSync(file).isDirectory()) {
      if (isAsset) { res.statusCode = 404; return res.end('not found'); }
      file = path.join(dist, 'index.html');                      // SPA fallback, like the rewrite in vercel.json
    }
    for (const [k, v] of Object.entries(globalHeaders)) res.setHeader(k, v);
    if (isAsset) for (const [k, v] of Object.entries(assetHeaders)) res.setHeader(k, v);
    if (p === '/sw.js') res.setHeader('Cache-Control', 'no-cache, no-store, must-revalidate');
    res.setHeader('Content-Type', MIME[path.extname(file)] ?? 'application/octet-stream');
    fs.createReadStream(file).pipe(res);
  });
  await new Promise(r => server.listen(0, '127.0.0.1', r));
  const base = `http://127.0.0.1:${server.address().port}`;
  return { base, driver, log, close: () => new Promise(r => server.close(r)) };
}

if (process.argv[1] === fileURLToPath(import.meta.url)) {
  const s = await startStack();
  console.log('Local stack on', s.base, '— setup token:', process.env.SETUP_TOKEN);
}
