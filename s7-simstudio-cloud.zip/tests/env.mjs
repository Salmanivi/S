// Imported first by every test so that code reading NODE_ENV at load time (cheaper password hashing) sees "test".
process.env.NODE_ENV = 'test';
