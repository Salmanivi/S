import path from "path";
import { fileURLToPath } from "url";
import tailwindcss from "@tailwindcss/vite";
import react from "@vitejs/plugin-react";
import { defineConfig } from "vite";
import { viteSingleFile } from "vite-plugin-singlefile";

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

// Normal build (Vercel): index.html + hashed files in dist/assets, which lets the strict
// Content-Security-Policy in vercel.json forbid inline scripts.
// `npm run build:single` (SINGLE_FILE=1) still produces one self-contained index.html for offline use.
const single = process.env.SINGLE_FILE === "1";

// https://vite.dev/config/
export default defineConfig({
  // the offline edition (single file) has no server: a flag lets the app skip every network call
  define: { __OFFLINE__: JSON.stringify(single) },
  plugins: [
    react(),
    tailwindcss(),
    ...(single ? [viteSingleFile()] : []),
    // PWA links only make sense for the online build
    { name: "offline-edition-html", transformIndexHtml: (html: string) => (single ? html.replace(/\s*<link rel="(manifest|apple-touch-icon)"[^>]*>/g, "") : html) },
  ],
  resolve: {
    alias: {
      "@": path.resolve(__dirname, "src"),
    },
  },
  server: {
    // `npm run dev` serves the web app only; use `vercel dev` to run the API together with it.
    proxy: process.env.API_PROXY ? { "/api": { target: process.env.API_PROXY, changeOrigin: true } } : undefined,
  },
});
