// Regenerates db/schema.sql from api/_lib/migrations.js (paste it into a database console if you prefer).
import fs from 'node:fs';
import { fullSchemaSql } from '../api/_lib/migrate.js';
fs.writeFileSync(new URL('../db/schema.sql', import.meta.url), fullSchemaSql());
console.log('db/schema.sql written');
