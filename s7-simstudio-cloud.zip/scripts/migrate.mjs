// Applies database migrations:   DATABASE_URL="postgresql://..." npm run db:migrate
// (The app also does this automatically on its first request unless AUTO_MIGRATE=false.)
process.env.AUTO_MIGRATE = 'false';
const { getDb } = await import('../api/_lib/db.js');
const { migrate } = await import('../api/_lib/migrate.js');
try {
  const db = await getDb();
  const applied = await migrate(db);
  console.log(applied.length ? `Applied: ${applied.join(', ')}` : 'Database is already up to date.');
  await db.close?.();
} catch (e) {
  console.error('Migration failed:', e.message);
  process.exit(1);
}
