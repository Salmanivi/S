// Static security review:   npm run check:security
// Fails (exit 1) on: dynamic SQL, unreviewed public API routes, unsafe DOM APIs, leaked secrets, weakened headers.
import fs from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';

const root = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '..');
const issues = [];
const warn = (m) => issues.push(m);
const walk = (d, acc = []) => { for (const e of fs.readdirSync(d, { withFileTypes: true })) { if (['node_modules', 'dist', '.git', '.vercel'].includes(e.name)) continue; const p = path.join(d, e.name); e.isDirectory() ? walk(p, acc) : acc.push(p); } return acc; };
const files = walk(root);
const rel = (f) => path.relative(root, f);
const read = (f) => fs.readFileSync(f, 'utf8');

// 1. SQL must be parameterised. The only template expressions allowed inside SQL are reviewed fragments that
//    build placeholders ($1, $2 ...) or choose between fixed strings; user input is never interpolated.
const REVIEWED = new Set([
  // placeholder numbers built from an array length (never user input)
  '${params.length}', '${params.length + 1}', '${params.length + 2}',
  // fragments assembled only from fixed strings and placeholders earlier in the same function
  '${where}', '${w}', "${sets.join(', ')}",
  "${trash ? 'p.deleted_at' : 'p.updated_at'}", "${where.length ? 'WHERE ' + where.join(' AND ') : ''}",
]);
function templateExpressions(src, start) {            // start = index of the opening backtick
  const out = []; let i = start + 1;
  while (i < src.length && src[i] !== '`') {
    if (src[i] === '\\') { i += 2; continue; }
    if (src[i] === '$' && src[i + 1] === '{') {
      let depth = 1, j = i + 2;
      while (j < src.length && depth) { if (src[j] === '{') depth++; else if (src[j] === '}') depth--; j++; }
      out.push(src.slice(i, j)); i = j; continue;
    }
    i++;
  }
  return out;
}
for (const f of files.filter(f => /api\/.*\.js$/.test(f))) {
  const src = read(f);
  for (const m of src.matchAll(/\.(?:query|exec)\(\s*(`|'|")/g)) {
    if (m[1] === '`') {
      const start = m.index + m[0].length - 1;
      for (const expr of templateExpressions(src, start)) {
        if (!REVIEWED.has(expr)) warn(`SQL: unreviewed interpolation ${expr} in ${rel(f)}`);
      }
    }
  }
  if (/\.(?:query|exec)\(\s*['"][^'"]*['"]\s*\+/.test(src)) warn(`SQL: string concatenation passed to query in ${rel(f)}`);
}

// 2. Every API route is authenticated unless it is on the reviewed public list.
const PUBLIC = new Set(['GET /config', 'GET /health', 'POST /setup', 'GET /cron/cleanup', 'POST /auth/register', 'POST /auth/login', 'POST /auth/logout', 'POST /auth/forgot', 'POST /auth/reset', 'POST /auth/verify']);
let routes = 0;
for (const f of files.filter(f => /api\/_lib\/routes\/.*\.js$/.test(f))) {
  for (const m of read(f).matchAll(/route\('(\w+)',\s*'([^']+)',\s*\{([^}]*)\}/g)) {
    routes++;
    const [, method, p, opts] = m;
    const isPublic = /auth:\s*'public'/.test(opts);
    if (isPublic && !PUBLIC.has(`${method} ${p}`)) warn(`API: ${method} ${p} is public but not on the reviewed list (scripts/security-check.mjs)`);
    if (p.startsWith('/admin') && !/auth:\s*'admin'/.test(opts)) warn(`API: ${method} ${p} is under /admin but not admin-only`);
  }
}
if (routes < 40) warn(`API: only ${routes} routes found, route scanner may be broken`);

// 3. Dangerous browser APIs in the web app.
const DANGEROUS = /dangerouslySetInnerHTML|\.innerHTML\s*=|\.outerHTML\s*=|insertAdjacentHTML|document\.write\(|\beval\(|new Function\(|javascript:/;
for (const f of files.filter(f => /src\/.*\.(tsx?|jsx?)$/.test(f))) {
  const src = read(f);
  if (DANGEROUS.test(src)) warn(`WEB: potentially unsafe DOM/JS API in ${rel(f)}`);
  if (/process\.env|import\.meta\.env/.test(src)) warn(`WEB: environment access in client code ${rel(f)} (secrets must never reach the browser)`);
  if (/localStorage\.setItem\([^)]*(token|password|secret|session)/i.test(src)) warn(`WEB: credential written to localStorage in ${rel(f)}`);
}

// 4. Secrets committed to the repo, or leaked into the built bundle.
const SECRET = /postgres(?:ql)?:\/\/[^\s'"<>]+:[^\s'"<>@]{4,}@|-----BEGIN [A-Z ]*PRIVATE KEY-----|\b(?:sk|rk)_live_[0-9a-zA-Z]{10,}|re_[A-Za-z0-9]{20,}|xkeysib-[a-f0-9]{20,}|AKIA[0-9A-Z]{16}/;
for (const f of files) {
  if (/\.(png|jpg|ico|woff2?|zip)$/.test(f) || /\.env\.example$/.test(f) || /package-lock\.json$/.test(f)) continue;
  if (/^tests\//.test(rel(f)) || /DEPLOYMENT|README|SECURITY/.test(rel(f))) continue;
  if (SECRET.test(read(f))) warn(`SECRET: something that looks like a credential in ${rel(f)}`);
}
for (const f of files) if (/(^|\/)\.env(\..*)?$/.test(f) && !/\.env\.example$/.test(f)) warn(`SECRET: ${rel(f)} must not be committed`);
if (!/^\.env$/m.test(read(path.join(root, '.gitignore')))) warn('.gitignore does not exclude .env');
const dist = path.join(root, 'dist');
if (fs.existsSync(dist)) for (const f of walk(dist)) {
  const t = read(f);
  // names of settings may appear as help text; what must never appear is server code or credential-shaped values
  if (/process\.env\.(DATABASE_URL|APP_SECRET|CRON_SECRET|SETUP_TOKEN|RESEND_API_KEY|BREVO_API_KEY)/.test(t)) warn(`BUNDLE: server environment access in ${rel(f)}`);
  if (SECRET.test(t)) warn(`BUNDLE: credential-shaped value in ${rel(f)}`);
  if (/node:crypto|require\(["']pg["']\)|from ?["']pg["']/.test(t)) warn(`BUNDLE: server-only module in ${rel(f)}`);
}

// 5. Response headers configured for Vercel.
const vj = JSON.parse(read(path.join(root, 'vercel.json')));
const hdr = Object.fromEntries((vj.headers.find(h => h.source === '/(.*)')?.headers ?? []).map(h => [h.key.toLowerCase(), h.value]));
const csp = hdr['content-security-policy'] || '';
const scriptSrc = /script-src([^;]*)/.exec(csp)?.[1] || '';
if (!/'self'/.test(scriptSrc) || /unsafe-inline|unsafe-eval|\*/.test(scriptSrc)) warn('HEADERS: script-src must be \'self\' only');
for (const need of ["frame-ancestors 'none'", "object-src 'none'", "base-uri 'self'", "default-src 'self'", "connect-src 'self'"]) if (!csp.includes(need)) warn(`HEADERS: CSP is missing ${need}`);
for (const k of ['x-content-type-options', 'referrer-policy', 'strict-transport-security', 'permissions-policy', 'x-frame-options']) if (!hdr[k]) warn(`HEADERS: ${k} missing in vercel.json`);
if (!vj.crons?.some(c => c.path === '/api/cron/cleanup')) warn('CRON: cleanup job missing in vercel.json');

// 6. Supply chain: keep the runtime dependency list short and deliberate.
const pkg = JSON.parse(read(path.join(root, 'package.json')));
const ALLOWED_DEPS = new Set(['clsx', 'lucide-react', 'pg', 'react', 'react-dom', 'tailwind-merge', 'zustand']);
for (const d of Object.keys(pkg.dependencies)) if (!ALLOWED_DEPS.has(d)) warn(`DEPS: unreviewed runtime dependency ${d}`);
if (pkg.scripts?.postinstall || pkg.scripts?.preinstall) warn('DEPS: install scripts present');

if (issues.length) { console.error('Security check FAILED:\n' + issues.map(i => '  ✗ ' + i).join('\n')); process.exit(1); }
console.log(`Security check passed ✓  (${routes} API routes, ${files.length} files scanned)`);
