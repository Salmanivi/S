// Post-deployment check against a LIVE server:   npm run smoke -- https://your-app.vercel.app
// Creates a throw-away account, exercises the main features (accounts, projects, sync conflicts, teams) and deletes everything again.
// To test with an existing account instead:  SMOKE_EMAIL=you@example.com SMOKE_PASSWORD=... npm run smoke -- <url>   (the account is NOT deleted)
const base = (process.argv[2] || process.env.SMOKE_URL || '').replace(/\/+$/, '');
if (!/^https?:\/\//.test(base)) { console.error('Usage: npm run smoke -- https://your-app.vercel.app'); process.exit(2); }

const jar = new Map();
let failures = 0;
const ok = (name, cond, extra = '') => { console.log(`${cond ? '  ✓' : '  ✗'} ${name}${extra ? '  — ' + extra : ''}`); if (!cond) failures++; return cond; };
async function req(method, path, body) {
  const headers = { Origin: new URL(base).origin };
  if (jar.size) headers.Cookie = [...jar].map(([k, v]) => `${k}=${v}`).join('; ');
  if (body !== undefined) headers['Content-Type'] = 'application/json';
  const res = await fetch(base + path, { method, headers, body: body !== undefined ? JSON.stringify(body) : undefined, redirect: 'manual' });
  for (const sc of res.headers.getSetCookie?.() ?? []) {
    const [pair] = sc.split(';'); const i = pair.indexOf('=');
    const k = pair.slice(0, i), v = decodeURIComponent(pair.slice(i + 1));
    if (/Max-Age=0/i.test(sc) || !v) jar.delete(k); else jar.set(k, v);
  }
  const text = await res.text();
  let json; try { json = JSON.parse(text); } catch { /* not json */ }
  return { status: res.status, json, headers: res.headers, text };
}
const project = (name) => ({ name, blocks: [{ id: 'b1', kind: 'main', name: 'Main', networks: [] }], hardware: { cpuId: '1214C_DC_DC_DC', modules: [], props: {} }, tags: [], devices: [], watch: [] });

console.log(`\nSmoke test against ${base}\n`);
console.log('Server');
const h = await req('GET', '/api/health');
ok('API reachable', h.status === 200 && !!h.json, `HTTP ${h.status}`);
if (h.json) {
  for (const [k, v] of Object.entries(h.json.checks)) ok(`health: ${k}`, v === true || v === 'ok' || k === 'mail' || k === 'setupToken' || k === 'appUrl' || k === 'cronSecret', String(v));
  ok('database connection works', h.json.checks.database === 'ok', h.json.checks.database);
}
if (!h.json || h.json.checks.database !== 'ok') { console.log('\nFix the database connection first (see the deployment guide, "Troubleshooting").'); process.exit(1); }
const page = await fetch(base + '/', { redirect: 'manual' });
const csp = page.headers.get('content-security-policy') || '';
ok('web app is served', page.status === 200);
ok('security headers present', /script-src 'self'/.test(csp) && page.headers.get('x-content-type-options') === 'nosniff' && !!page.headers.get('strict-transport-security'), base.startsWith('https') ? '' : 'plain http: HSTS is only sent over https');
const cfg = await req('GET', '/api/config');
ok('public config readable', cfg.status === 200);

console.log('\nAccount');
const existing = process.env.SMOKE_EMAIL && process.env.SMOKE_PASSWORD;
const email = existing ? process.env.SMOKE_EMAIL : `smoke-${Date.now().toString(36)}@example.com`;
const password = existing ? process.env.SMOKE_PASSWORD : `Smoke-${Math.random().toString(36).slice(2)}-Test9`;
if (!existing && cfg.json && !cfg.json.registrationEnabled) { console.log('  – registration is closed; set SMOKE_EMAIL and SMOKE_PASSWORD to test with an existing account'); process.exit(failures ? 1 : 0); }
const login = existing ? await req('POST', '/api/auth/login', { email, password }) : await req('POST', '/api/auth/register', { email, name: 'Smoke Test', password });
ok(existing ? 'sign in' : 'register', login.status === 200 || login.status === 201, login.json?.error?.message || `HTTP ${login.status}`);
if (login.json?.needsVerification) { console.log('  – email confirmation is required on this server; use SMOKE_EMAIL/SMOKE_PASSWORD with a confirmed account'); process.exit(failures ? 1 : 0); }
ok('session cookie set', jar.size === 1);
ok('/auth/me works', (await req('GET', '/api/auth/me')).status === 200);
const noCookie = await fetch(base + '/api/auth/me');
ok('protected route refuses anonymous requests', noCookie.status === 401);
const evil = await fetch(base + '/api/auth/logout', { method: 'POST', headers: { Origin: 'https://evil.example', 'Content-Type': 'application/json', Cookie: [...jar].map(([k, v]) => `${k}=${v}`).join('; ') }, body: '{}' });
ok('cross-site request is blocked (CSRF)', evil.status === 403, `HTTP ${evil.status}`);

console.log('\nProjects and sync');
const created = await req('POST', '/api/projects', { name: 'Smoke project', data: project('Smoke project') });
const pid = created.json?.project?.id;
ok('create project', created.status === 201 && !!pid, created.json?.error?.message);
if (pid) {
  const s1 = await req('PUT', `/api/projects/${pid}`, { baseRevision: 1, data: project('Smoke project v2') });
  ok('save (revision 1 → 2)', s1.status === 200 && s1.json.revision === 2);
  const stale = await req('PUT', `/api/projects/${pid}`, { baseRevision: 1, data: project('stale') });
  ok('stale save is rejected (conflict detection)', stale.status === 409 && stale.json.error.code === 'conflict');
  const g = await req('GET', `/api/projects/${pid}`);
  ok('read back saved data', g.json?.data?.name === 'Smoke project v2');
  ok('list shows it', (await req('GET', '/api/projects?q=smoke')).json?.projects?.some(p => p.id === pid));
  ok('version history exists', (await req('GET', `/api/projects/${pid}/versions`)).json?.versions?.length >= 1);
  ok('move to trash', (await req('DELETE', `/api/projects/${pid}`)).status === 200);
  ok('delete permanently', (await req('DELETE', `/api/projects/${pid}?permanent=1`)).status === 200);
}

console.log('\nTeams');
const team = await req('POST', '/api/teams', { name: 'Smoke team' });
const tid = team.json?.team?.id;
ok('create team', team.status === 201 && !!tid, team.json?.error?.message);
if (tid) {
  const inv = await req('POST', `/api/teams/${tid}/invites`, { role: 'viewer', days: 1, maxUses: 1 });
  ok('create invite link', inv.status === 201 && !!inv.json?.code);
  ok('delete team', (await req('DELETE', `/api/teams/${tid}?deleteProjects=1`)).status === 200);
}

console.log('\nAdmin area');
ok('admin API is closed to normal users', (await req('GET', '/api/admin/stats')).status === 403);

if (!existing) {
  console.log('\nClean up');
  ok('delete the smoke-test account', (await req('POST', '/api/auth/delete-account', { password })).status === 200);
}
console.log(failures ? `\n${failures} check(s) FAILED\n` : '\nAll checks passed ✓\n');
process.exit(failures ? 1 : 0);
