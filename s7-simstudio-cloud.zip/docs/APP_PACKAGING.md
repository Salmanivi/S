# Using S7 SimStudio as an installed app (APK, EXE) and offline

Short answer: **converting the HTML to an APK or EXE does not break anything, but a converted app runs from local files, so accounts, cloud projects, sync and teams cannot work inside it.** The simulator itself works fully offline. If you want an installed app **and** accounts, use the installable web app (option A), which is built in.

## The three ways to get an "app"

| | A. Installable web app (recommended) | B. Offline edition wrapped as APK/EXE | C. Wrapper that opens your website |
|---|---|---|---|
| How | Open your site, tap **Install** | `npm run build:single`, then wrap `dist/index.html` | Wrapper loads `https://your-site` |
| Simulator works offline | **Yes** (after the first visit) | **Yes** | No (needs internet) |
| Accounts, cloud save, sync, teams | **Yes, whenever online** | No (hidden on purpose) | Yes, online only |
| Projects offline | Export / Open files | Export / Open files | not possible |
| Updates | automatic | you rebuild and reinstall | automatic |
| Store needed | No | No | No |

### A. Install the web app (PWA)

The deployed site is installable and caches itself for offline use.

- **Android (Chrome):** menu → *Install app* (or *Add to Home screen*).
- **Windows / macOS / Linux (Chrome or Edge):** the install icon in the address bar → *Install*. It opens in its own window like an EXE.
- **iPhone / iPad (Safari):** Share → *Add to Home Screen*.

What happens offline: the app opens from the cache, the whole simulator works, and projects can be exported/opened as files. Cloud features step aside (no dead buttons) and come back automatically when the connection returns; you stay signed in. API calls are never cached, so accounts and projects always come from the server.

**Want a real APK or EXE of the installable app?** Use PWABuilder (pwabuilder.com): enter your site address and download the Android package (Trusted Web Activity) or a Windows package. For Android it gives you an `assetlinks.json` file: put it in `public/.well-known/assetlinks.json`, push, and redeploy. Because these packages are your website in a shell, accounts keep working.

### B. Offline edition wrapped as APK / EXE

```bash
npm install
npm run build:single      # -> dist/index.html, one self-contained file
```

Give `dist/index.html` to your APK/EXE tool (an "HTML to APK/EXE" converter, Capacitor, Electron, ...). The build is flagged as the **offline edition**: it never contacts any server, shows no sign-in or cloud buttons, says "Offline edition" on the About page, and keeps your contact details. This was tested in a browser against a wrapper-style local server that answers *every* path with the app (the worst case) and from `file://`: no network requests, no console errors, simulator and export work.

**Why accounts cannot work inside a file-based wrapper.** The server only accepts requests from its own website address (session cookie, same-origin check, no cross-site access). That is a deliberate security choice. Supporting a local app would need a second, token-based login and a list of allowed origins, which is a larger security change. It is not included; ask if you want it designed.

**Things to test on your own device**, because converters differ:
- **Export:** saving a project (Ctrl+S / *Export project*) uses a normal browser download. Some Android WebViews ignore downloads unless the wrapper supports them. If it does not work, use a wrapper with download support, or tell me and I will add a share/save option.
- **Open project file:** the file picker must be enabled by the wrapper.
- **Phone and email links** (About page) open the phone's dialer and mail app.

Minimal Electron EXE (not run here):

```js
// main.js
const { app, BrowserWindow } = require('electron');
app.whenReady().then(() => {
  const w = new BrowserWindow({ width: 1280, height: 800, autoHideMenuBar: true });
  w.loadFile('index.html');          // the file from npm run build:single
});
```
Package it with `electron-builder`. For Android with Capacitor: `npm i @capacitor/core @capacitor/cli @capacitor/android`, `npx cap init`, set `webDir` to the folder holding `index.html`, `npx cap add android`, `npx cap sync`, then build in Android Studio.

Be careful with free online converters: they repackage your app on their servers and some add ads or tracking. Open-source tools you run yourself (Capacitor, Electron) are safer.

### C. A shell that opens your website

Everything online works, but it needs internet, so it is not what you described. Option A gives the same result and also works offline.

## Which one should I choose?

- Want accounts **and** an installed app: **A**.
- Want a file you can hand to people with no internet at all and no accounts: **B**.
- Want both: publish A on the web and give B to people who need a standalone copy; they can move projects between them with Export / Open.

## Test checklist for your APK/EXE

1. Switch the device to airplane mode and start the app.
2. Create a new project, compile (Ctrl+B), download, press RUN.
3. Export the project, close the app, open the app and import the file again.
4. Open *About & contact*: your name, email and phone are shown and tappable.
5. Confirm there is no Sign in button (offline edition) or, for option A, that it appears again when you are back online.
