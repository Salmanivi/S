# Security model and test report

This document describes how S7 SimStudio protects accounts and data, what was tested, which problems the testing found, and what is **not** covered. It is a code-level review with automated tests, **not** an independent penetration test or certification.

## 1. Threats and controls

| Threat | Controls |
|---|---|
| Password guessing / credential stuffing | scrypt hashing (N=32768, r=8, per-user 16-byte salt); database-backed rate limits per IP **and** per account (so many IPs cannot attack one account); identical error and equalised timing for unknown accounts and wrong passwords; password policy (10+ characters, common-password and "contains your email name" checks) |
| Session theft | 256-bit random session token; only its SHA-256 is stored; cookie is `HttpOnly`, `Secure`, `SameSite=Lax`, `__Host-` prefixed, 30-day sliding expiry; sessions are revoked on password change/reset, account disable and delete; users can see and revoke their devices; nothing secret in `localStorage` |
| Cross-site request forgery | every state-changing request must come from the same origin (`Origin` check) and be `application/json`; no CORS headers at all; `SameSite=Lax` as a second layer |
| Cross-site scripting | React escaping; no `innerHTML`/`eval`/`dangerouslySetInnerHTML` anywhere (enforced by `npm run check:security`); strict `Content-Security-Policy` (`script-src 'self'`, no inline scripts); project documents are structurally validated on the server (no `__proto__`/`constructor` keys, depth and size caps); admin announcement is rendered as text |
| SQL injection | every query is parameterised; the only template interpolations in SQL are a reviewed allow-list of placeholder builders; `npm run check:security` (which also runs before every production build) fails on anything else; injection payloads are part of the test-suite |
| Access to other people's data (IDOR) | every project/team route resolves the caller's role first; foreign resources answer **404** (existence is not revealed); an isolation test probes 11 project routes as another user |
| Privilege escalation | request bodies accept only whitelisted fields (mass-assignment such as `role` is rejected); role matrices for team owner/admin/editor/viewer enforced server-side; admins cannot demote/disable/delete themselves, the last administrator or last team owner cannot be removed |
| First-admin takeover | the setup endpoint needs the secret `SETUP_TOKEN`, is rate-limited, and answers 404 as soon as any administrator exists |
| Password-reset abuse | one-time tokens, 1 hour, only the hash is stored, "forgot" answers identically for unknown accounts, rate-limited per IP and account, all sessions revoked after a reset, link not burned by a rejected weak password |
| Information leakage | unexpected errors return a generic message plus a request id; details go only to server logs; `/api/health` exposes yes/no facts and short error categories, never secrets or messages; no password material in any response or the audit log |
| Abuse / denial of service | body size limits, per-user project/team quotas, project size and complexity caps, version-history caps, rate limits on writes, trash and old logs purged daily |
| Clickjacking, MIME sniffing, leaking referrers | `frame-ancestors 'none'`, `X-Frame-Options`, `X-Content-Type-Options: nosniff`, `Referrer-Policy`, `Permissions-Policy`, HSTS |
| Poisoned links in emails | links are built from `APP_URL` when set |
| Supply chain | one runtime dependency was added (`pg`); an install-script and allow-list check runs in `npm run check:security` |
| Secrets exposure | secrets exist only as Vercel environment variables; the browser bundle is scanned for server variables and credential-shaped values |

Privacy by design: administrators see account details, project names and sizes, **not** project contents; team members see e-mail addresses only if they are team admins; IP addresses are kept only in the audit log (180 days).

## 2. What was tested

| Suite | Count | Covers |
|---|---|---|
| API: authentication | 13 | setup, registration rules, rate limits, generic login failure, lockout across IPs, CSRF, body hygiene, sessions/devices, password change, deletion, export |
| API: projects | 11 | revisions, concurrent writes (exactly one wins), validation of hostile documents, isolation from other users, malformed ids, SQL-injection and markup payloads, trash, versions, quotas |
| API: teams and admin | 12 | role matrices, invites (single use, expiry, revoke), member management, last-owner rules, admin lock-out guards, escalation attempts, reset links, cascade deletes, settings, audit trail |
| API: infrastructure | 12 | clean error format, no leaks on failure, health categories, cron, secure cookie flags, e-mail provider payloads (stubbed), required verification, invite race, migrations, schema file, foreign keys, password hashing, production PostgreSQL driver wrapper (transactions, rollback, parsers) |
| Browser end-to-end (Chromium, CSP enforced) | 26 steps | first-time setup, registration, cloud save and autosave, reload, **two devices**, **conflict dialog**, offline recovery, team invite by link, view-only role in UI *and* API, admin actions, announcement rendered as text, sign-out, zero CSP violations |
| Installable app (service worker, manifest, offline reload, accounts return) | 15 checks | opens offline from cache, simulator works offline, API never cached, signed-in session resumes when back online |
| Offline edition in a wrapper-style server and from disk | 3 runs, 40 checks | no network calls, no cloud UI, About/contact correct, compile/run/export work |
| Browser phone pass (390×844, touch) | 12 checks | every new screen fits the screen without sideways scrolling, 16px inputs, no console/CSP errors |
| Simulator regression | 565 address layouts, 6 examples, 22 type-detection scenarios, 18 address checks | the original simulator logic is unchanged |
| Static review (`npm run check:security`) | 56 routes | dynamic SQL, unreviewed public routes, admin routes without admin guard, unsafe DOM APIs, environment access in the browser, committed credentials, weakened headers, new dependencies. **Mutation-tested:** 10 deliberately injected flaws were each caught |

## 3. Problems found by testing, and fixed

1. **Registration lockout on typos.** The rate limiter counted *invalid* submissions, so a user who mistyped the form a few times would be blocked for an hour. It now counts only validated attempts (where the expensive hashing starts).
2. **Spent invite links rejected members.** Someone who had already joined via a single-use link got "invalid or expired" when opening it again. They are now told they are already a member.
3. **Reset link consumed by a weak password.** The one-time link was used up before the new password was validated. The password is now checked first.
4. **Background reachable behind full-screen pages.** Keyboard and screen-reader users could tab into the hidden app while Account/Admin/Teams were open. Pages now render in a portal and the app behind is marked `inert`.
5. **Dialogs and menus ignored Escape.** Fixed for modals, sheets and row menus.
6. **Error badge double counting** the compile summary line (from the earlier phase).
7. **Security checker blind spots.** The first version of the bundle check flagged harmless variable *names* in help text and mis-parsed placeholder builders; both were corrected, and the checker was then mutation-tested so a passing result means something.

## 3b. Installable app and offline edition

- The service worker caches only static files of the app itself. **API requests are never cached or answered from the cache**, and it does not store credentials or project data.
- The offline edition is built with a flag that removes every network call. It has no accounts, so there is nothing to attack remotely; its data stays on the device.
- A local-file wrapper cannot use the online API by design (same-origin cookies, origin check, no CORS). Enabling it would need a separate token-based login and an origin allow-list; that was deliberately not added.

## 4. What is NOT verified, and residual risks

- **Real PostgreSQL was not available while building.** The SQL is written in the subset PostgreSQL and SQLite share and was executed on SQLite; the production driver wrapper was tested against a mock of `pg`. PostgreSQL-specific behaviour (integer types, constraint messages) is therefore confirmed only after deployment: run **`npm run smoke -- https://YOUR-SITE`** and check `/api/health`. Treat the first deployment as the final test.
- **Vercel runtime behaviour** (catch-all function routing, cron, plan limits) is written from documentation and was not executed on Vercel. The smoke test and health endpoint verify it.
- **Dependencies were not vulnerability-scanned** (no network access). Run `npm audit` and enable GitHub Dependabot.
- **Browsers:** tested with Chromium (desktop and mobile emulation). Safari, Firefox and real phones were not.
- **E-mail** was tested against stubbed provider APIs only.
- **Account enumeration:** registration must tell a visitor when an address is taken. It is rate-limited; login and password reset reveal nothing.
- **No two-factor authentication or single sign-on.** Recommended next steps for administrator accounts.
- **Rate limiting is stored in the database.** Under a large attack it costs database writes; Vercel's firewall/attack protection can absorb floods before they reach the function.
- `style-src` allows inline styles because the interface sets some styles from code; scripts are strictly `self`.
- The offline single-file build opened from disk has no server, no accounts and no CSP header.
- Terms and Privacy texts are **templates**, not legal advice.

## 4b. Operating it safely

- Keep the GitHub repository private; never commit `.env` files.
- Use a unique `APP_SECRET`, `SETUP_TOKEN` and `CRON_SECRET`; remove `SETUP_TOKEN` after setup.
- Review **Admin → Activity** after launch and weekly: look for bursts of `auth.login_failed` and unexpected `admin.*` actions.
- Keep dependencies current (Dependabot) and redeploy after security updates.
- Take and test database backups (see the deployment guide).
- To report a vulnerability to the operator, use the contact address configured in Admin → Settings.
