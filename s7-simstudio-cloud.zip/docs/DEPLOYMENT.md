# Deploying S7 SimStudio on Vercel (free plan) with a PostgreSQL database

This guide takes you from the downloaded project to a live, secured site with accounts, cloud projects, teams and an admin console. Plan on about **30–45 minutes**. No payment details are needed anywhere.

## 0. What you are deploying

| Part | Where it runs | Notes |
|---|---|---|
| Web app (React) | Vercel static hosting | built by `npm run build` into `dist/` |
| API (accounts, projects, teams, admin) | **one** Vercel serverless function: `api/[...path].js` | one function keeps you inside the free-plan function limit |
| Database | PostgreSQL (Neon recommended, free) | tables are created automatically on the first request |
| Daily cleanup | Vercel Cron | removes expired sessions, old trash, old logs |
| Email (optional) | Resend or Brevo (free tiers) | only for password-reset and confirmation emails |

**Good to know before you start**

- Vercel's free **Hobby** plan is meant for **personal, non-commercial** use. If you will run this for a business or charge for access, use a paid Vercel plan (this project itself contains no payments).
- On the free database the compute **sleeps after a few idle minutes**; the first request after a pause can take 1–3 seconds longer. That is normal.
- Free-plan limits change over time. Check the current limits on vercel.com/pricing and neon.com/pricing.

You need free accounts on **GitHub** and **Vercel** (sign in with GitHub). A database account is created in step 2.

---

## 1. Put the code on GitHub

1. Unzip the project. Open the folder: you should see `api/`, `src/`, `db/`, `docs/`, `package.json`, `vercel.json`.
2. Create a **new private repository** on GitHub (github.com → New). Do not add a README or license (the project has its own files).
3. Upload the project:

   **With git (recommended):**
   ```bash
   cd s7-simstudio
   git init
   git add .
   git commit -m "S7 SimStudio"
   git branch -M main
   git remote add origin https://github.com/YOUR-NAME/YOUR-REPO.git
   git push -u origin main
   ```
   **Without git:** on the empty repository page choose *uploading an existing file*, drag in the *contents* of the folder (not the folder itself) and commit. Do not upload a `node_modules` folder.

4. *(Recommended)* If Node.js 22 is installed on your computer, run `npm install` once and commit the generated `package-lock.json`. It makes every later build use exactly the same package versions.

> The project ships **without** a lock file because it was prepared offline. Vercel will install the newest versions allowed by `package.json`, which also works.

---

## 2. Create the database

Pick **one** option.

### Option A: Neon through Vercel (easiest)

You do this *after* step 3, because it connects the database to your Vercel project. Skip to step 3, then come back here.

### Option B: Neon directly

1. Go to **neon.com**, sign up (GitHub login works) and **Create project**.
2. Choose the **region closest to your visitors**, and remember it (for example *Europe – Frankfurt* or *US East – N. Virginia*).
3. On the project dashboard click **Connect**. Choose the **pooled connection** (the host name contains `-pooler`) and copy the connection string. It looks like:
   `postgresql://neondb_owner:…@ep-xxx-pooler.eu-central-1.aws.neon.tech/neondb?sslmode=require`
4. Keep it secret: anyone with this string can read all data.

### Option C: Supabase or any other PostgreSQL

Any PostgreSQL 13+ works. For Supabase use the **Transaction pooler** connection string (port 6543). Put it in `DATABASE_URL` in step 4.

> You do **not** need to create tables. The app creates and updates them itself the first time it runs (set `AUTO_MIGRATE=false` if you prefer to run `db/schema.sql` yourself in the database's SQL editor).

---

## 3. Import the project into Vercel

1. Go to **vercel.com → Add New… → Project** and import your GitHub repository.
2. Settings on the import screen:
   - **Framework Preset:** Vite (detected automatically)
   - **Root Directory:** `./`
   - Build/Output settings: leave the defaults (they come from `vercel.json`).
3. Click **Deploy**. The first deployment succeeds but the API will say it is not configured yet. That is expected.
4. Open **Project → Settings → General** and set **Node.js Version** to **22.x**.
5. Open **Project → Settings → Functions** and set **Function Region** to the region closest to your database (Frankfurt = `fra1`, N. Virginia = `iad1`, and so on). A function far from the database makes every request noticeably slower.

**If you chose Option A:** open the project's **Storage** tab → **Create Database** → **Neon** (Postgres) → accept the defaults, choose the same region, and connect it to the project for **Production** (and Preview if offered). Vercel then adds the connection string as environment variables automatically; the app reads `DATABASE_URL` (or `POSTGRES_URL`).

---

## 4. Environment variables

Open **Project → Settings → Environment Variables** and add these for **Production**. Names are case-sensitive; paste values without quotes.

| Name | Required | What it is |
|---|---|---|
| `DATABASE_URL` | **yes** | PostgreSQL connection string (already present with Option A) |
| `APP_SECRET` | **yes** | random text, 32+ characters |
| `SETUP_TOKEN` | **yes**, for the first admin | random text, 16+ characters |
| `APP_URL` | recommended | your site address, e.g. `https://your-project.vercel.app` (no trailing slash) |
| `CRON_SECRET` | recommended | random text; protects the daily cleanup job |
| `MAIL_PROVIDER`, `MAIL_FROM`, `RESEND_API_KEY` / `BREVO_API_KEY` | optional | email (see step 9) |

**Generate random values** (any one of these):

- macOS / Linux / Git Bash: `openssl rand -base64 48`
- Anywhere Node.js is installed: `node -e "console.log(require('crypto').randomBytes(48).toString('base64'))"`
- Windows PowerShell:
  ```powershell
  $b = New-Object byte[] 48; [Security.Cryptography.RandomNumberGenerator]::Create().GetBytes($b); [Convert]::ToBase64String($b)
  ```
- Or let your password manager generate a 48-character password.

Use a **different** value for each variable, and never reuse a real password.

Environment variables only apply to **new** deployments: after adding them go to **Deployments → ⋯ → Redeploy**.

---

## 5. Check that it works

Open `https://YOUR-SITE/api/health`. You should see something like:

```json
{ "ok": true, "version": "1.0.0", "checks": { "databaseUrl": true, "appSecret": true, "setupToken": true, "cronSecret": true, "appUrl": true, "mail": false, "database": "ok" }, "adminCreated": false }
```

`ok: true` and `"database": "ok"` mean the app reached the database and created its tables. Otherwise see the table in the *Troubleshooting* section.

---

## 6. Create the first administrator

1. Open your site. At the top of the start page you see **Finish setting up your server**.
2. Click **Create administrator**, enter the `SETUP_TOKEN`, your name, email and a password (10+ characters).
3. You land in the **Admin console**. The *Deployment health* list shows what is still missing (for example `APP_URL`).
4. *(Optional, tidy)* Delete the `SETUP_TOKEN` variable and redeploy. The setup page already disappeared by itself once an administrator existed, and it cannot be used again while one exists.

---

## 7. Run the smoke test (verifies the real database)

The automated tests ran against a stand-in database, so this is the check that exercises **your** PostgreSQL end to end. On your computer (Node.js 22):

```bash
npm install
npm run smoke -- https://YOUR-SITE
```

It registers a throw-away account, saves a project, provokes and detects a sync conflict, creates a team and an invite, checks that the admin API refuses normal users and that cross-site requests are blocked, and then deletes the account. Every line should show ✓. If registration is closed or email confirmation is required, run it with an existing account:
`SMOKE_EMAIL=you@example.com SMOKE_PASSWORD='…' npm run smoke -- https://YOUR-SITE`.

---

## 8. First configuration

In the app: **account menu → Admin console → Settings**

- **Operator name / contact email / phone**: shown in the Terms, Privacy and About pages (they default to the details in `src/brand.ts`). The legal texts are **templates**: have them reviewed for your country and purpose.
- **Allow new registrations**: switch off to make the site invitation-only (you can still add users under *Users → Add*).
- **Limits**: projects per user/team, project size, versions kept, team size. They protect the free database from filling up.
- **Announcement**: a banner shown to everyone (plain text).

---

## 9. Optional: email (password reset and confirmation)

The app works without email: administrators can create a **reset link** for any user (*Admin → Users → user → Reset link*) and team invitations are shared as links. Add email if you want self-service password reset.

**Resend** (resend.com, free tier): create an API key. To send to *any* address you must verify a domain you own; without one, Resend only delivers to your own address.
Variables: `MAIL_PROVIDER=resend`, `RESEND_API_KEY=re_…`, `MAIL_FROM="S7 SimStudio <no-reply@your-domain.com>"`.

**Brevo** (brevo.com, free tier): create an API key (SMTP & API → API keys) and verify a sender address; no domain is needed for a single verified sender.
Variables: `MAIL_PROVIDER=brevo`, `BREVO_API_KEY=xkeysib-…`, `MAIL_FROM="S7 SimStudio <you@example.com>"` (the verified sender).

Redeploy, then check `/api/health` shows `"mail": true` and use *Forgot password* with a test account. To make email confirmation mandatory switch on **Admin → Settings → Require confirmed email**.

---

## 10. Optional: your own domain

Vercel → **Settings → Domains → Add**, then create the DNS records Vercel shows at your domain provider. Afterwards update `APP_URL` to the new address and redeploy. Use **one** public address: the API only accepts requests whose origin matches the address in the browser bar.

---

## 10b. Installable app

Your site can be installed like an app (Android: *Install app*; desktop Chrome/Edge: install icon in the address bar; iPhone: *Add to Home Screen*) and opens offline once visited. For APK/EXE packages and the separate offline edition see `docs/APP_PACKAGING.md`.

## 11. Daily cleanup job

`vercel.json` schedules `/api/cron/cleanup` once a day (03:00 UTC). It needs `CRON_SECRET` (Vercel sends it automatically). Check **Settings → Cron Jobs**; you can run it once by hand there. It deletes expired sessions, trash older than 30 days, old rate-limit rows, expired invites and audit entries older than 180 days.

---

## 12. Backups

Your users' work lives in the database, so back it up.

- Neon keeps a short restore history on free plans (check the current length in its dashboard) and offers **branches**: create a branch from your main branch before risky changes.
- Make your own copy regularly (monthly at least). With PostgreSQL tools installed:
  ```bash
  pg_dump "YOUR_DATABASE_URL" -Fc -f backup-$(date +%F).dump
  ```
  Store it somewhere private. Restore with `pg_restore -d NEW_DATABASE_URL --clean backup.dump`.
- Every user can also download all their personal projects from **Account → Download my data**, and export any project as a file.

---

## 13. Updating the app

1. Change the code and push to GitHub. Vercel builds and deploys automatically.
2. New database changes are applied automatically at the first request (they are numbered migrations in `api/_lib/migrations.js` and never edited after release).
3. **Preview deployments** (created for every branch/pull request) use the same environment variables as production **unless you scope them**. Point Preview's `DATABASE_URL` at a separate Neon **branch**, so tests never touch real users' data.

Local development: `npm install`, then `vercel dev` (Vercel CLI) with `vercel env pull .env.local` to run the app and API together. `npm test` runs the automated test-suite, `npm run check:security` the static security review.

---

## 14. Running it day to day

- **Logs:** Vercel → Project → *Logs*. Every API error response contains a `requestId`; search for it in the logs to see the full server-side error (users never see internals).
- **Who did what:** Admin → *Activity* (sign-ins, failures, team changes, admin actions).
- **Storage:** Admin → Overview shows project storage; the database dashboard shows the total against your plan.
- **Lost the only admin password:** another admin can reset it. If there is none, in the database's SQL editor run `UPDATE users SET role = 'user' WHERE role = 'admin';`, make sure `SETUP_TOKEN` is set, redeploy, and use the setup page again.
- **Locked out by the rate limiter:** wait 10 minutes, or in the SQL editor run `DELETE FROM rate_limits;`.
- **Rotating secrets:** changing `APP_SECRET` only resets rate-limit counters (safe). To rotate the database password, change it at the provider and update `DATABASE_URL`, then redeploy.

---

## 15. Troubleshooting

| Symptom | Likely cause | What to do |
|---|---|---|
| `/api/health` shows the web app or a 404 | API function not deployed | Root Directory must be the folder containing `api/`; in the deployment's **Functions** tab you should see `api/[...path]`; redeploy |
| `503 not_configured` | `DATABASE_URL` or `APP_SECRET` missing/too short | add them (step 4) and **redeploy** |
| `database: "auth_failed"` | wrong user/password in the connection string | copy the string again from the provider |
| `database: "unreachable"` | wrong host, network, or paused database | check the host name; open the database dashboard to wake it |
| `database: "ssl_error"` | connection string lacks SSL | make sure it ends with `?sslmode=require` |
| `database: "database_missing"` | wrong database name | use the name from the provider |
| First page load is slow after idle | free database waking up | normal; the next requests are fast |
| Login works, then you are signed out immediately | cookies blocked, or the site is opened over `http://` | use the `https://` address and allow cookies |
| `403 csrf` on every action | the site is reached through a different address than the one in the browser bar (proxy/second domain) | access it through one domain only |
| `429 rate_limited` | too many attempts | wait 10 minutes (see step 14) |
| Emails do not arrive | sender/domain not verified, spam folder | check the provider's log; `/api/health` must show `"mail": true` |
| Build fails: `X is not exported by lucide-react` | an icon was renamed in a newer version | replace that icon name with the new one, or pin `lucide-react` to the version in `package.json` |
| Build fails on `npm ci` lock mismatch | stale lock file | delete `package-lock.json`, run `npm install`, commit |

Still stuck? Run `npm run smoke -- https://YOUR-SITE`; its first failing line usually names the cause.

---

## 16. Go-live checklist

- [ ] `/api/health` shows `ok: true` and every check except `mail` (optional) is true/ok
- [ ] `npm run smoke` passes against the live site
- [ ] First administrator created; `SETUP_TOKEN` removed
- [ ] Function region = database region
- [ ] Preview deployments use a separate database branch
- [ ] Operator name and contact email set; Terms/Privacy reviewed for your situation
- [ ] Registration open/closed as you intend; limits reviewed
- [ ] A backup was taken and restored once on a spare database
- [ ] GitHub repository is private; no `.env` file was committed (`npm run check:security` verifies)
- [ ] Dependabot (GitHub → Settings → Code security) enabled, and `npm audit` run

## Not included on purpose

Payments or subscriptions (as requested), email-based team invitations (links are used instead), single sign-on, public share links, and administrators reading private project contents.
